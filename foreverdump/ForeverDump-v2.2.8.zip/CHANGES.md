# ForeverDump: changes

v1 (`ForeverDump.lua`, 333 lines; one SavedVariable `ForeverDumpDB`) collected the APIs (`C_*` functions), events,
enums and CVars in one pass and showed them in a copy window via `/fdump` and `/foreverdump`. **All of that still
works:** plain `/fdump` runs the same quick dump into the same `ForeverDumpDB` fields.

## v2.2.8 (2026-10-08, hotfix: capture-data bugs, engine health, counters at OFF)

Small, low-risk hotfix after the runs 6/6b/7 analysis (real/2026-10-08-run6/out/FINDINGS.md). No behaviour change for
attribution rules; no new probes.

- **WorldCapture pack (data bug).** `ws` records carry two exact 32-bit words (`p` = fields 1-8, `q` = fields 9-16).
  2.2.6/2.2.7 packed 16 codes in one Lua double and lost exists/health/healthMax (run 7: 92/92 records `p`-only).
  `tools/fdump/worldcap.py` decodes both formats (legacy lost nibbles = `L`). Test: tests/worldcap_pack.lua.
- **NPC IdKey (data bug).** `ReplayLog.IdKey` took the GUID's instance id, so every NPC was `npc:1` and per-unit world
  rows merged. Now the npc id (Creature/Vehicle, `npc:N`). Test: tests/worldcap_pack.lua.
- **Engine starts even when a helper fails.** `I.NewHSM` isolates Knowledge / KnowledgePatch / Timing / Learned (each in
  pcall): a failure costs that seed only (state `degraded`), recorded as selfError `hsm:<name>`. A failed
  `HybridState.New` or `I.Start` is `down` (no half-started engine). Runs 6/6b lost the whole engine to one helper.
- **Visible engine warning.** One chat line per capture (`ENGINE DOWN` red / `engine degraded` yellow, naming the
  failed helper) and the same row at the top of the HSM window.
- **Counters at OFF.** The replay tape header gets `hdr.stats`: `hsm` (up/degraded/down/off), `hsmFailed`, `hsmRunning`,
  HSM counters (numbers only), `guard.tokenScan` / `guard.worldCapture` (CheckInteractDistance skips in combat),
  world-capture samples/slices/dropped, and this capture's selfError count. Run 7 could not show any of this.
- **Converter.** `analyze` engine-health reads `hsm:*` selfErrors and the tape header (`engine down` high,
  `engine degraded` medium).
- Tests: tests/hsm_health.lua (degraded 11, down 10, guard 9 checks; all with `os` = nil) wired into the runner;
  tests/test_v227_findings.py +1 (tape-header health). Plus the post-ship fixes below (coverage fallbacks, meter join by
  time, VACUOUS determinism, real-client slice budget flags).

## v2.2.7 (2026-10-08, run 6/6b error fixes, secret-value audit, static dump once per build)

### Error root causes fixed (runs 6 and 6b)
- **ADDON_ACTION_BLOCKED** (run 6: 47; run 6b SV, cumulative: 198 attributed to FD): `CheckInteractDistance` is protected
  in combat. It was called from `Tokens.lua:296` (token range probe) and `WorldCapture.lua:141` (range snapshot).
  New `ns.CombatGuard`/`ns.CombatLocked`: the probe is skipped in combat (range = guarded code `G`=6) and runs again
  out of combat. No hooks and no protected calls in combat.
- **DamageMeter.lua:51 "attempt to perform boolean test on a secret value"** (run 6 18:30:48, run 6b 18:40:15): the
  `ok and v or nil` idiom tested a secret return value. `field()`/`api()` now return `ok, v` explicitly and classify
  before any truth test.
- **Drift.lua:156 `os` is nil** (FD self-error at each capture start): use the game's `time()` global (`os.time` only if present).
- **ObjectiveTracker `LayoutContents` nil call**: there's no evidence FD is involved. It recurred in 6b after /reload with no
  full dump. It's triggered by CRITERIA_UPDATE/quest progress, and its `[C]` frame is a third-party secure hook.
  FD installs no hooks. New `ns.UISig` instrumentation (`ForeverDumpLogDB.uiIntegrity`) records whether the tracker modules'
  `LayoutContents` still matches their mixin before/after every FD section and capture.

### Secret-value audit (DamageMeter, WorldCapture, ReplayLog, Tokens, Identity, HybridState, Inference)
- Core helpers: `ns.ClearOf(v, want)`, `ClearNum`, `ClearStr`, `ClearBool`, `ClearTable`, `ClearWithCode`,
  `ns.IsTrue` (type check + classify + `rawequal`), and `ns.IsNil` (`type(v) == "nil"`). `ClassifyValue`/`IsSecret` start with a
  `type()` check, so they never truth-test their input.
- No `x and y or z`, `if v then`, `not v` or `==` on an API-returned value before it has been cleared. Event handler
  arguments (`rawUnit`, `rawA1`, ...) are cleared on entry.
- HybridState boundary guard: every On/Record/CD/GCD/Set/Learn entry point scrubs secret scalars to nil, copies tables
  without their secret fields (depth 3), and skips calls whose required key is nil (counter `secretDropped`).

### Static dump: once per client build (no longer at FD_Logs ON)
- New `Static.lua` and its own SavedVariable **`ForeverDumpStaticDB`** (docs, api, globals, strings, widgets, templates,
  frames, addons, cvars, protected, extras, plus the v1 apis/events/enums/cvars).
- Build signature = `GetBuildInfo` + a djb hash of the sorted `C_*` namespaces with their function counts + the Enum count. At
  login (out of combat, after `static.loginDelay`=15 s), FD runs the full dump once **only if the signature changed**:
  chunked, deferred until idle, paused in combat and during captures, with no user action. Completion is marked per build.
- `ForeverDumpDB` (capture data) only holds the ~1 KB marker `static = {key, build, version, toc, apiHash, ...}`.
- `FD_Logs ON` no longer queues any dump.
- Commands: `/fdump all` = manual force (it also upgrades a waiting auto run), `/fdump static [status|run|force|check]`,
  `/fdump static clear` (wipe after ingest; the marker stays, so it won't dump again for that build).
- Size (real run 6): SV total 14.31 MB, of which static is 11.61 MB. A typical capture after `/fdump static clear` is 2.70 MB
  (run 6b: 15.45 MB → 3.83 MB).
- Converter: reads `ForeverDumpStaticDB` (and the legacy layout). When static data is missing it falls back to
  `fixtures/forever-70245` (`Dump.static_source`).

### Tests
- `tests/test_v227_secret_lint.py`: a permanent static lint (taint flow from API/handler returns to truth/compare/index
  sinks, no `and IDENT or`, no inline `select(2, pcall())`, the Core contract, and HybridState BOUNDARY coverage) plus a self-test.
  Against v2.2.6 it fails (it catches DamageMeter.lua:51).
- `tests/secret_inject.lua`: injects secret booleans, numbers and strings into every field (7 modes × 2 passes). It checks for
  escaped errors, uses a line hook to find secrets reaching truth or compare sites, checks for SV leaks, and checks the meter `S` codes.
- `tests/static_once.lua`: one dump per signature, deferral in combat and during capture, the force/clear commands, and the marker-only capture SV.
- `tests/test_v227_lint.py` + `tests/combat_guard.lua`: no protected API without `ns.CombatGuard`; combat guard behaviour.
- The perf gates are unchanged (storm ≤0.5%, raid40 N=5 median ≤0.12 ms).

### Post-ship fixes (after ForeverDump-v2.2.7.zip; shipped in v2.2.8)

- **WorldCapture pack precision (data bug).** The 16 five-state codes were packed into one 64-bit value in a Lua double
  (53-bit mantissa); whenever a high field was set the low nibbles (exists, health, part of healthMax) were rounded away.
  Now two exact 32-bit words (`p` = fields 1-8, `q` = fields 9-16). `tools/fdump/worldcap.py` decodes both and marks
  legacy lost nibbles as `L` (never a wrong code). Test: tests/worldcap_pack.lua (5000 random round-trips).
- **ReplayLog.IdKey npc (data bug).** The Creature pattern captured the instance id, so every NPC was `npc:1`. Now the
  npc id field (Creature/Vehicle and `npc:N`). Test: tests/worldcap_pack.lua (4094/3573, distinct NPCs distinct keys).
- **Engine health in analyze.** New high leads "capture module failed" (selfErrors where=capture:*) and "live HSM did not
  run" (combat recorded, no HSM export, no decide records). Test: tests/hsm_alive.lua (whole capture with `os` = nil)
  and tests/test_v227_findings.py.
- **coverage fallbacks when the HSM did not run.** Target timeline rebuilt from my offensive log events
  (`targetSource=log-inferred`) and own casts rebuilt from raw UNIT_SPELLCAST_* (`castSource=raw-events`); both are
  bannered in COVERAGE.md. Run 6 interrupt replay 0/1 → 1/1.
- **damagemeter_join picked the meter fight by index.** The SV keeps earlier captures' meter fights, so run 6b fight 1
  was joined with run 6's meter (false per-unit "off"). Now by time (epoch in [start-2, stop+15], deep snapshot first,
  None when nothing matches). Test: tests/test_v227_findings.py.
- **replay determinism.** "OK (0 groups)" with combat on the tape is now VACUOUS and fails the summary (it hid the dead
  HSM in 6/6b). Test: tests/test_v227_findings.py.
- **perf.** A real capture whose mean WorldCapture/TokenScan slice exceeds the bench budget (0.10/0.12 ms) is flagged
  (6/6b: 0.126-0.130 ms unflagged). Test: tests/test_v227_findings.py.

## v2.2.6 (2026-10-08, sealed replay tape + dual verbosity)

- Damage-meter **self-reconcile** (liveEst ↔ post-combat meter ↔ offline CLEU): multi-metric match/off/unexplained
  verdicts + per-unit IdKey sources; HSM UI status. Capture-only **WorldCapture** logs casts/auras/hp/power/threat/range/target-of
  (five-state codes, tape `ws`). See `docs/FINDINGS-v226.md`.

**One zip / one build.** Default verbosity is **release** (<1% CPU). FD_Logs ON elevates to **test** (or configured `captureLevel` diag, ≤10%) for tracing, data gathering and live evaluation of prior findings; FD_Logs OFF restores the prior level. `/fdump level [status|release|test|diag|capturelevel …]` is a manual override between captures. Perf gates measured in the same build: release <1%, capture ≤10%.

### Addon
- **ReplayLog.lua**: session_hdr (verbosity, seeds hashes, group/map/combatLog, ring caps, TimeAnchor), sealed tape ring (hdr/decide/verdict/anchor/map/sec/api) with byte budgets + priority drops, cast-sync anchors on own SUCCEEDED (every N in release; all in test), salted FNV `IdKey` (no raw GUIDs/names), overflow notes for verify/recorder/combat rings.
- Capture module wires BeginCapture/EndCapture into FD_Logs; elevate/restore levels.
- Inference: OnInfer/OnVerdict → decide/verdict; OnOwnSucceeded anchors; test-only OnApiSample on CDPayload change.
- Identity: test-only OnMapDelta (token family + IdKey).
- Recorder/CombatLog: test-only critical-event sec nibbles (N/S/T/K/C packed); NoteOverflow on ring wrap.
- Verify: dynamic VerifyCap from ReplayLog level.
- Commands: `/fdump level`; status prints verbosity. HSMUI shows `log:release|test (capture)`.
- Core: `config.replay` defaults; VERSION 2.2.6 / SCHEMA 3; toc loads ReplayLog after Verify.

### Converter
- `fdump replay DUMP [-o out/replay] [--file WoWCombatLog]`: reconstruct tape, decide determinism, privacy scan, optional CLEU cast-sync join → REPLAY.md + replay.json.

### Tests / perf
- `tests/test_v226_replay.py` (12): tape order, determinism, privacy, CLEU join, Lua API surface, toc/commands/config.
- `perf_bench.lua`: capture-mode gate ≤10%; post-`logs off` release window <1%.
- PERFORMANCE.md: dual-level rule.
### Follow-ups (same day)
- Golden asserts restored (canonicalize token-gate bug fixed; `higher-order:` leads re-emitted).
- `fdump replay` re-executes `Lib/HybridState.lua` offline; exact-match decide determinism + CLEU anchor diff;
  `tests/replay_tape_harness.lua` + `test_v226_replay_exec.py` (incl. perturbed-tape failure).
- Capture-mode shadow verdicts: `shadow-dm-type7`, `shadow-totem-heal` (evaluate prior findings live, non-acting).

### Damage meter + world state (same day, end-to-end)
- **Caps:** tapeCap binds 25-min 40BG capture under ~30 MB SV; KEEP decide/verdict/anchor/shadow/reconcile; `ws`/sec/api thin first with counted overflow. Lazy rings. `SerializeProxy` reports MB/min + serializeMs. See `docs/CAPS-v226.md`.
- **In combat:** every `DAMAGE_METER_*` on tape (type, sessionID, codes); structure classify ~2/s/type (codes/lengths only).
- **Post-combat (capture deep):** every `Enum.DamageMeterType`, all sources/spells/details IdKey'd, DamageTaken + EnemyDamageTaken, Deaths, interrupts, dispels, session history → `ReconcileDM` multi-metric + per-unit.
- **WorldCapture.lua** (capture-only): casts/auras/hp/power/threat/range/target-of across all tokens → tape `ws`.
- **Offline:** `damagemeter_join` three-way live↔meter↔log in `fdump analyze`; facts → miner findings / correlate markdown. Run-5 smoke: 3 fights, 9 match / 1 off / 5 unexplained.
- **Tests / perf:** `test_v226_reconcile.py`; perf_bench `wc40` world-capture storm (≤10% capture ceiling); `sv_serialize_bench.lua` (test ring fill ≤26 MB). Raid40 scanner slice gate is strict at budgetMs (0.12): median of N=5 per-run maxSlice and p99 (every raw run logged). Storm gate already uses median of 3 windows (raw windows logged; a single window may exceed 0.5% while the median holds).


## v2.2.5 (2026-10-08, offline higher-order correlation)

**Converter / tools (no addon Lua changes; no new zip)**
- `correlate_findings.py`: distinct-findings layer — token-alias collapse (`targettarget`→`player` when strong; same-frame payload dedup), add-½ smoothed lift + CI (no 9999), chain minimality, holdout status (`cross-run` / `held-1` / `provisional` / `failed`), echo appendix, ≤12-row Distinct findings table.
- `correlate_ho.py` / `correlate.py`: profiles full|quick; identity/elim preserved after lift smoothing; `--quick` / `--no-higher`; elapsed printed.
- Confirmed offline: (a) SPELL_UPDATE_COOLDOWN clear spellID already in CooldownTracker CDPayload; (b) totem-heal live signal (review-only; on-me heals already attributed); (c) DM type 7 ↔ enemy melee; (d) meter frame-join already live; (e) interrupt identity provisional on run 5.
- Tests: `test_v225_ho.py`, `test_v225_findings.py` (alias/lift/minimality/flags/echoes + expected ids on real correlate.json).

## v2.2.4 (2026-10-08, run 5: live attribution, cooldown/GCD tracker, learned data, drift guard, offline analysis)

Run 5 was the first capture with an ungrouped player (a mage) hitting my target, an interrupt (Earth Shock) and three fights
with a post-combat C_DamageMeter read. Findings: `real/2026-10-08-run5/FINDINGS.md`.

**Standing design rule (drift):** every learned or static value is a starting point. Values are keyed by build, re-verified
live, decayed when not re-confirmed and drift-flagged with a changelog entry; `fdump analyze` proposes the seed update and
nothing is hard-coded without an override path (ADDON-USAGE.md "Drift", guide section 12).

### Addon

- **Live source attribution (HybridState MINOR 3).** `UNIT_COMBAT` is clear on 1.60.1 in combat (action, amount, school) for
  player and target. Rules attribute each hit from clear timing only: my cast frame, the swing lag (melee combat text lags the
  swing by about 0.46 s), the `DAMAGE_METER_COMBAT_SESSION_UPDATED` frame, interrupt cast + meter, and elimination. Run 5:
  damage on my target, damage taken, heals, misses and the interrupt all 100% correct against the log (before: 0%), and no
  other-player damage credited to me. The secret-timing window is 0.35 s (was 2.4 s).
- **Ledger (MINOR 4).** "Collect while available, retain, resolve later": token→GUID, aura instances and cast GUIDs cached while
  clear, LRU-capped, with live / cached-fresh / cached-stale / maybe-removed confidence. Identity.lua feeds it. Enemy
  cast-duration model per NPC id (interrupt window in the HSM window).
- **Cooldown / GCD tracker (MINOR 5).** Per-spell ready / gcd / cooling state fused from my clear casts, isActive / isOnGCD
  flips, categories, `UNIT_SPELLCAST_FAILED` and clear API reads. O(due + budget) per event (see the perf gate below).
- **Timing.lua + Data/spell-timing.lua.** Per-spell GCD/cooldown table, seeded offline and learned live per build (running
  min/max/sum/count, LRU). Known answers: totems 1.0 s, Lightning Shield 1.5 s.
- **Learned.lua + Data/learned-seed.lua.** Persistent learned spell / NPC / class DB per build: spell ids, cast times, NPC kits.
  Player names and GUIDs stay in memory and are never saved.
- **Drift.lua.** Drift guard: seeds lose to consistent live disagreement; every override is logged with old, new, evidence and
  build in a changelog that `fdump analyze` turns into a seed proposal.
- **Verify.lua.** Live verification ring: verdicts V / C / U for cooldowns, cast ends, damage ranges, interrupts and meter
  totals; readability flips against the baseline are kept in an "unexpected" LRU.
- **Group-aware token scanner (Tokens.lua `T.Scan`).** Budgeted round-robin discovery over party / raid / nameplate / boss /
  arena tokens in combat: secrecy codes per token family and context only, alias/duplicate detection, 0.12 ms per 0.1 s slice
  with a per-field deadline.
- **Knowledge.lua.** The parser classifies every duration phrase by clause, with a permanent semantic lint. Tooltip header
  cross-check against the APIs, every power cost (multi-cost spells), 20 tooltip lines, spell→aura map learned by correlation.
  `cdLineProbe` records the tooltip line count/types for the extra-line cooldown hypothesis. `hsm.tooltipCooldownSignal` stays
  **off** (not proven).
- **DamageMeter.lua.** C_DamageMeter as evidence: event counts per type, HSM timing, one field classification per combat and
  after combat. Post-combat reconciliation in the HSM ("others on my target = live total − meter mine").
- **HSM window.** Rows for attribution / meter, a Ledger section, GCD (tracker) bar, cooldown lines (max 8 + "+N more"),
  interrupt window; dirty-only line-pool redraws at most every 0.5 s.
- Data/KnowledgePatch.lua: facts observed in earlier real captures (generated by `fdump verify-live` / `analyze`).

### Converter (tools/fdump)

- `coverage`: combat-log (truth, offline) vs live matrix per category × source × context; HSM before/after replay scoring;
  timing models; per-fight log vs C_DamageMeter; the other player on my target; meter field classification. New sections:
  cooldown/GCD tracker vs the log, cooldown model vs log fails, enemy cast bars, overheal, Ledger, live verdicts.
- `knowledge` (knowlint): reparse with the current parser, lint, header-vs-API checks, log cross-check, tooltip extra-line
  cooldown evidence table.
- `verify-live`: verify ring joined with the log (VERIFY.md) → knowledge patch.
- `analyze`: the whole pipeline with history captures → ANALYSIS.md (ranked leads with severity / evidence / timestamps),
  analysis.json, VERIFY.md, TOKENS.md, knowledge patch, `spell-timing.proposed.json`, `learned-seed.proposed.json`.
  `--write-seed` adopts the merged seeds (idempotent per evidence id; conflicts stay flagged, never overwritten).
- New modules: `timing.py`, `learned.py`, `tokenscan.py` (TOKENS.md generator: matrix, cost, alias, change alerts),
  `misses.py` (every missed log event with a reason class and a fix hint), `correlate.py` (co-occurrence miner live↔log with
  holdout across captures and rare-pair p-values), `analysis.py`.
- Privacy: miner keys redact player names (`<player>`; UNIT_SPELLCAST_SENT target names are kept only for known NPCs).
- Guide: new section 12, "Cooldown/GCD tracker, learned data and the drift rule" (`guide --analysis analysis.json`).
- Ledger scoring fix: "maybe-removed" entries are doubts, not claims. They were counted as 35 wrong claims; the log
  confirms 35 of the 50 doubted removals.

### Tests

- `tests/test_v224_tools.py` (synthetic, 64 checks): timing merge / promotion / conflicts / idempotence / known answers / Lua
  writer, learned from_log / from_sv / merge / anonymisation, TOKENS.md, analyze leads, correlate (planted link found, noise
  rejected, rare pairs), verify_live judging, misses grouping and hints, knowlint data checks.
- `tests/test_golden_run5.py` (real run 5, 20 checks; skipped without the capture): the miner rediscovers the Earth Shock
  interrupt link, the known-answer GCD table holds, no refuted verdict, cooldown verdicts 100%, no rule-gap misses, the
  cd-line hypothesis stays not proven, seeds idempotent.
- Lua: `knowledge_parse.lua`, `timing.lua`, `learned.lua`, `hsm.lua` (160), perf bench with gate asserts.

### Perf gate

- **Perf gate passed** (PERFORMANCE.md, "Perf gate"):
  - aged/fresh frame-time impact 1.00-1.18 (gate <= 1.5; aged 0.19-0.25%);
  - SPELL_UPDATE_COOLDOWN storm 0.29-0.39% (gate <= 0.5%);
  - 40-man scanner max slice 0.093-0.115 ms (budget 0.12 ms).
- **Bench artifact found.** Most of the "aged session is slower" growth was glibc fastbin consolidation on the first
  >= 1 KB malloc after a large free. Lua instruction counts were flat. `tests/perf_bench.lua` re-executes itself with
  fastbins off (`FD_BENCH_ALLOC=native` to compare). The earlier "Lua string-hash collision" explanation for the HSM body
  was wrong; the line-pool rendering stays.
- **CooldownTracker per-event cost is now O(due + budget)** instead of O(cooling spells):
  - dense active array, lazy min-heap of predicted ready times and a due set;
  - round-robin re-reads at most once per second per far spell;
  - `HS:CDCheckList()` with a reused buffer;
  - the UI "latest cooldown" pointer is maintained by the tracker, and at most 8 cooldown lines are rendered.
  - Storm handler: 4,142 → 1,654 Lua instructions per event.
- **Allocation-free hot paths:**
  - `Secrets.ObserveLive` scratch tables and memoised key/context strings;
  - O(1) recent-list repeats;
  - numeric alias keys in `Tokens.Scan.OnCast`;
  - token-map entry reuse, cached families and profiler clock;
  - SPELL_UPDATE_COOLDOWN payload codes classified once.
- **Scanner budget enforced inside the loop.** The deadline is checked after every field read; a cut-off token resumes at
  the next field in the next slice. The `tokenscan.bailMs` margin is 0.04 ms, and `cost.overBudget` is recorded per
  capture. The scanner frame is timed by the self-perf monitor.
- **Bench and tests:**
  - 25-cast windows (4 fresh, 5 aged) with median gates; storm median of 3 windows.
  - New asserts: aged/fresh ratio <= 1.5, storm <= 0.5%, slice max <= budget.
  - `tests/learned.lua`: per-field deadline and resume, plus CDCheckList (due set, once-per-second round-robin,
    swap-remove, latest re-pick, heap rebuild).
  - Runner now runs knowledge_parse / timing / learned and test_v224.
- Fixes: `fdump all`/`guide` no longer try to serialise the in-memory coverage context (`_ctx`). `probes.dominant` accepts
  count-valued fields (`powerCost.n`).

## v2.2.3 (2026-10-07, run 4: frame-rate drop, self-perf monitor, live HSM verification)

- **Frame-rate root cause.** The run-4 report was "as I cast more abilities the framerate drops".
  - `ns.Meta()` → `ns.ProjectInfo()` walked all of `_G` (52,517 globals, about 17 ms per walk) on every call.
  - It was called from hot paths. The HSM window redraw called it once per text line at 5 Hz (spell names → `Knowledge.DB()`
    → `K.Build()` → `ns.Meta()`), and the line count grew with the predictions. Every `UNIT_AURA` called it through the
    container DB, and so did every combat-probe read in lockdown (`PathBlocked`), `Knowledge.Learn` and `Errors`.
  - In game the application frame time went from 20.7 to 59.3 ms during the 86 s capture.
  - Fix: the project info is now cached for the session. The walk moved to `ns.ScanProjectInfo()`, and the hot paths use the
    new cached `ns.Build()`.
- **O(n) work removed from per-event paths:**
  - `HybridState.push` trims in amortised O(1); it no longer calls `table.remove(list, 1)` on every insert once full.
  - `Appliers` is cached per knowledge version.
  - The HSM text uses counters instead of re-walking every inference input.
  - `CombatProbe`/`Containers` contexts are cached per frame (they made 6 pcalls per call).
  - `GetAuraSlots` is skipped after it errors in a context.
  - Containers `ObserveEvent` exits early in O(1).
  - Stale unknown-duration auras (300 s) and empty per-GUID unit state are dropped.
- **HSM window: dirty-only, throttled redraws.**
  - The window registers its own `UNIT_SPELLCAST_*`, `UNIT_HEALTH`, `PLAYER_TARGET_CHANGED` and `SPELL_UPDATE_COOLDOWN`
    events, only while it is shown.
  - Changes mark it dirty. The OnUpdate is installed on demand, runs at 10 Hz and removes itself when idle, so there is no idle
    OnUpdate.
  - Text is rebuilt only when `hs.version` changes (at most every `hsm.updateInterval`=0.25 s), and countdowns tick at 1 Hz.
  - Spell names are cached.
- **HSM layout.** Eight fixed 14 px rows with a label column:
  1. player cast predicted
  2. player cast engine
  3. target cast predicted
  4. target cast engine
  5. cooldown predicted
  6. real cooldown (its own row with icon swipe and value)
  7. player HP
  8. target HP

  The text body starts below row 8. This fixes the "player HP, secret (engine-displayed)" line overlapping "real cooldown".
  Idle bars say "idle", "not casting", "no unit" or "none" instead of staying empty.
- **Why run 4's predictions stayed "unverified".**
  - All 16 predictions had no spell knowledge. The knowledge pass finishes asynchronously after `Inference.Start`, and the HSM
    copied knowledge only once, at start.
  - In combat the UNIT_AURA payload is a wholly secret list, so no spellId could be matched.
  - Fixes:
    - knowledge is fed live (`Knowledge.onCollected` plus a lazy lookup on the first cast)
    - an observed aura with a clear spellId verifies a prediction even without aura knowledge (Ghost Wolf)
    - new timing verification: a secret `addedAuras` on the predicted unit right after the cast verifies the prediction as
      "aura event seen (secret payload, timing)", with rule `secret-timing` at medium confidence. In run 4 this would have
      verified Flame Shock (+4 ms) and Lightning Shield (+4 ms).
    - until-cancelled auras are learned.

  No values are read from secrets; only the secret-vs-nil fact and event timing are used.
- **Self-perf monitor (new `Perf.lua`, always on in FD_Logs).** Writes per-handler calls, total/max ms and 15 s windows, plus
  5 s samples (heap, fps, C_AddOnProfiler application/overall/own, table sizes) to `ForeverDumpLogDB.perf`. Numbers only, keeps
  4 sessions. `/fdump perf` prints the top handlers and the % of wall time.
- **PERFORMANCE.md (standing rule):**
  - <1% framerate impact
  - no idle OnUpdate
  - O(1) per event
  - dirty-only throttled redraws
  - heavy work out of combat or offline
  - every perf test run finishes within 2 minutes

  Enforcement:
  - `tests/perf_bench.lua` (25/50/100-cast checkpoints plus an aged 2,110-cast session, `--cap` 100 s) and
    `fdump.py perfcheck --strict` are part of the default runner, which now uses `pipefail`.
  - `migrate` reports a Performance section.
  - Generated mocks ship `perf_guard.lua` and `spec/perf_spec.lua`.
- **Benchmark (mock client, box Lua 5.1).**

  | build | ms per event | ms per frame | frame impact |
  |---|---|---|---|
  | v2.2.2 | 3.0-3.6 | 1.5 / 2.6 / 5.2 / 9.5 after 1 / 2 / 4 / 8 casts (grows with casts) | 57-64% |
  | v2.2.3 | 0.026-0.047 | 0.004-0.009, flat through 2,110 casts | 0.04-0.08% |

  v2.2.3 leaves 0 idle OnUpdates.
- **Converter:**
  - `fdump perf` writes PERF.md and perf.json. It flags impact ≥1%, per-call cost growing with session length and unbounded
    sizes, and falls back to the profile snapshots for older SVs. It is part of `all`.
  - New `fdump perfcheck` command.
  - taint: Blizzard mixin code on our own hidden ScrollingMessageFrame is now `contained`. `ChatFrameN:UpdateFading`
    reading `oldestFadingLineTimestamp` after one of our chat lines is now `benign-chat` (no secret, no blocked action).

## v2.2.2 (2026-10-07, run 3: blocked-action attribution, containers, HSM summons)
- **Blocked actions:** the 36 run-3 `ADDON_ACTION_BLOCKED "UNKNOWN()"` came from `CheckInteractDistance`, which is protected in combat for
  friendly units (CombatProbe.lua:163 via :412). Every probe call is now marked (`ns.ProbeMark`/`ProbeDone`), and Errors.lua records
  `resolved = "Module:path(unit)"` plus our own stack frames. Blocked paths are learned in `ForeverDumpDB.blockedPaths[build]` and skipped in
  combat. `CheckInteractDistance` is skipped up front for non-hostile units, and docs-tagged Protected/HasRestrictions/RequiresNonCombat
  rows are skipped in lockdown.
- **No more secrets in ChatFrame1:** the ops-matrix print test writes to our own hidden ScrollingMessageFrame (`secrets.opsPrint="chat"`
  restores the old behaviour). This removes the `ChatFrame1:UpdateFading` taint.
- **Containers module (new, permanent):** walks every probed return recursively (depth 3) and records each field's state
  (absent/nil/secret/container/clear), the container flags (issecrettable, canaccesstable, hasanysecretvalues, HasSecretValues()),
  length/clear count and key lists. Coverage is per context (ooc, combat, restriction states) and per unit class (player, target NPC,
  party/raid, pet). Probes: aura by index (4 filters), GetAuraSlots, GetUnitAuras, count by iteration, aura duration, cast info, health,
  power, name, GUID, spell cooldown/charges/info, GetTotemInfo, and the UNIT_AURA payload. Runs automatically in every FD_Logs capture
  (ooc, combat start/end, restriction flips, encounters); in combat only non-protected reads. Stored as `ForeverDumpLogDB.containers`,
  classifications only, never values.
- **HSM:** totems are summon predictions on the player, verified live through `PLAYER_TOTEM_UPDATE` + `GetTotemInfo`. Purge/cleanse
  spells are dispel predictions. Self, helpful and summon spells with a hostile target are attributed to the player. Up to 4 sessions are
  kept (`inference.history`, `hsm.keepSessions`).
- **HSM window:** fixed 190 px label column (no more bars over the labels), a value text on each bar, wider default window, and the HP bar
  resets when the unit is gone.
- **Knowledge parser:** "health" is no longer a heal. Totem durations are summon durations, not aura durations. Dispel and weapon-imbue
  text is recognised.
- **Identity:** on Forever `UnitName("player")` returns (first, last), so the last name is taken from that second value.
- **Converter:** `fdump containers` (CONTAINERS.md, containers.json, schema diff vs `fixtures/baselines/<build>/containers.json`,
  `--write-baseline`; also part of `all`). Legacy SVs are reconstructed from combat-probe cells and UNIT_AURA events. `taint` classifies
  every line as expected / contained / probe-blocked / blizzard-frame / unexpected. `errors` shows the resolved source and the learned
  blocked paths. Offline inference scores summons (SPELL_SUMMON, plus lifetime when an end event exists) and dispels (SPELL_DISPEL*).
  A cooldown is only judged when a recast falls in its window. Replay ignores gaps >180 s and is seeded from SV knowledge.
  Multi-session history is scored.
- **Guide:** new "Partial secrets and containers" section (aura field matrix per context and unit class, UNIT_AURA payload, counts,
  partial containers, diff).
- **Tests:** hsm.lua v2.2.2 block (77 checks), busted `tests/spec/containers_spec.lua` (mocked mixed tables), `tests/test_v222.py`.

## v2.2.1 (2026-10-07, player identity)
- **Addon:** every capture start (FD_Logs ON and resume after `/reload`) writes the player identity to the SV meta
  (`ForeverDumpDB.meta.identity`, also `ForeverDumpLogDB.identity` and `ForeverDumpDB.identities[guid]`): `UnitName`,
  `UnitFullName`, `GetUnitName("player", true)`, `GetRealmName`, `GetNormalizedRealmName`, `UnitGUID`, `UnitClass`, `UnitLevel`,
  `UnitRace`, plus first/last name split (Forever characters are "First Last"; the combat log shows only `First-Realm-Region`).
  Every value is classified first. A secret value is never stored: it is recorded as code `S`, `secret[field] = true` and
  `anySecret = true`, which also tests empirically whether the player's identity is ever secret.
- **Converter:** `--player` (inference, guide, xref, cl-compare) and `combatlog --forever-player` accept a GUID, "First Last",
  a first name or Name-Realm, and need no flag at all. The log owner is chosen from the SV's identity by GUID, then by name,
  then from the optional `tools/fdump/characters.json` (for logs without a matching SV; ships Grukk Stonefist and Healy-Belzy),
  then by the old unit-flags 0x511 auto-detect. Older SVs fall back to the recorder sessions' playerGUID. `combatlog
  --forever-player auto [--sv ForeverDump.lua]`.
- **Anonymizer (`fixtures`):** takes the names and GUID from the SV identity (plus characters.json) automatically and scrubs
  first **and** last names anywhere in a line (`PlayerN` / `SurnameN`, word boundaries), in addition to the combat-log
  name/GUID rules. The leak scan checks those names and GUIDs too.
- Tests: `tests/hsm.lua` identity checks (54 total, including a secret UnitName that is flagged and not stored);
  `tests/test_identity.py` (name forms, SV GUID/name selection, characters.json fallback, anonymizer, fixtures end to end, run 2).

## v2.2.0 (2026-10-07/08, after the second real run)
**Fixes from run 2**
- **Bug B (Blizzard UI errors while FD_Logs was ON).** v2.1 post-hooked `EventRegistry.TriggerEvent` with
  `hooksecurefunc`. On Forever 70245 the hook trampoline breaks secure-dispatched `TriggerEvent` calls: Client.log had 405
  `attempt to call a nil value` errors raised by `[C]: in function 'TriggerEvent'` (GlobalCallbackRegistry,
  MainActionBarFrame, tooltips, ...), all inside the capture window. v2.2 installs **no hooks at all**. EventRegistry callbacks
  are opt-in (`record.callbacks`) through `EventRegistry:RegisterCallback`. `tests/regress.lua b-v21` reproduces the bug
  with the v2.1 code and `b-v22` proves zero errors. `/fdump health` checks for hooks and foreign wraps.
- The MoneyFrame "arithmetic on a secret value" taint in run 2 came from **TweaksForever** (`UI/Spellbook.lua:402`), not
  ForeverDump.

**Addon**
- **Verifier v2.2.** Five-state classifier: nil / secret / container with secrets / container clear / clear. Duration objects
  use `:HasSecretValues()`. SecretWhen* is expanded per field, and same-frame `C_Secrets.Should*BeSecret` predicates decide
  contradictions. Against the run-2 data the verifier now reports 0 CONTRADICTED and 0 UNDOCUMENTED-SECRET (v2.1 said 7 and 5,
  all classifier artefacts), plus 4 INCONCLUSIVE and 481 CONFIRMED.
- **Restrictions tracker** (`/fdump restrictions`). `C_RestrictedActions` state per type (Combat, Encounter,
  ChallengeMode, PvPMatch, Map, Chat), each flip stamped on the common timebase, a flip probe set at the event and on the
  next frame, and the always-on checks (combat log, addon chat).
- **Controls and ops matrix** (`/fdump secrets controls`) record what addon code can do with a secret (arithmetic,
  compare, tostring, concat, # ...): booleans and error texts only. The forced-restriction CVar sweep is opt-in and always
  restores the original values.
- **Workarounds lab** (`/fdump lab`). Sanctioned secret-value paths (StatusBar/FontString sinks, curves, duration
  objects), checked at the boundary, never extracted.
- **Every FD_Logs capture runs the probes automatically** through `ns.captureModules` (start at ON, stop at OFF, pcall-isolated):
  - **Combat probe set** (`CombatProbe.lua`, `/fdump combat`). Health, power, casting, movement, identity, threat, range,
    markers and auras (6 filters, slots, by-instance, duration objects, dispel colour) per unit class
    (target/focus/party/nameplate/player, hostile/friendly, NPC/player) and context (ooc/combat/restricted/encounter). Includes
    event payload codes, cast time left (derived vs duration object), the ops matrix per category, and the
    **detectability answers**: casting? which spell? any aura? MY aura? what aura? stacks/duration? dispellable?
    Each answer is yes/partial/no with evidence. Bounded and throttled; triggered by ON, combat start, restriction flips,
    and target/focus changes.
  - **Unit token survey** (`Tokens.lua`, `/fdump tokens`). Once per context per capture: 26 token families (player ... nameplate1-40,
    soft targets, compound chains) × UnitExists/GUID/Name/IsUnit/CanAttack/IsPlayer/Health/HealthMax/CanCompareUnitTokens/
    ShouldUnitIdentityBeSecret, split by resolved vs not.
  - **Spell knowledge** (`Knowledge.lua`, `/fdump knowledge`). The player's spellbook (≤150 spells, chunked): GetSpellInfo,
    description, base cooldown, power cost, charges, the secrecy functions, and tooltip lines with per-line codes. Durations
    and damage/heal ranges are parsed from clear text only. Stored per build, classified out of combat and in combat.
    Class/spec are recorded too.
  - **Inference engine + hybrid state machine** (`Inference.lua`, the reusable library `Lib/HybridState.lua`). Pure logic over
    values the API reports as non-secret plus event timing; no CLEU, no pixels, no parsing of secret text. Rules:
    cast-pair, observed, single-applier, cast-correlation (incl. retro correlation within the window), iid-map, count-delta,
    predicted-expiry. Each inference carries a rule and a confidence. Predictions cover aura + duration, damage/heal range
    and cooldown end for the player's casts, with live verification and contradictions. Rule-input readability is logged
    per context.
  - **HSM window** (`HSMUI.lua`, `/fdump hsm`). Movable, resizable and scrollable; Escape closes it; position saved; plain
    frames only (no secure templates, no Blizzard hooks). Shows restriction states, cast state (yellow predicted bar vs the
    engine bar through `SetTimerDuration`), per-unit auras (source, stacks, remaining, confidence), cooldown prediction vs
    `SetCooldownFromDurationObject`, the last predictions with outcomes, and counters. Secrets are shown only through engine
    passthrough widgets labelled "secret (engine-displayed)". Green observed, yellow inferred, grey unknown, red
    contradiction. Throttled to 0.2 s. FD_Logs ON opens it (`hsm.autoShow`) and OFF closes it. There is also an [HSM] button
    on the secrets panel.
  - **Baseline signature** (`Baseline.lua`, `/fdump baseline`). Docs hash (FNV-1a, identical in Lua and Python), secrecy per
    API position and context, ops, restriction timing, lab, combat, tokens, knowledge and frame types. Stored per build
    (keeps 6). After a build change a one-line **drift alert** prints in chat.
- Macro audit: every generated macro body and every `/run` snippet in the docs is ≤255 characters (`tests/regress.lua macro`,
  `tests/test_v22.py`).

**Converter**
- New: `restrictions`, `clientlog`, `size`, `ops` (OPS.md), `lab` (LAB.md + "Porting patterns for secret values"), `combat`
  (COMBAT-SECRETS.md + combat.json for the guide), `tokens` (UNIT-TOKENS.md), `knowledge` (KNOWLEDGE.md), `inference`
  (INFERENCE.md + HSM.md + hsm.json; scores the addon's inferences/predictions against the file combat log and replays the log
  through `Lib/HybridState.lua` offline in clear / secret / secret-pretrained modes), `drift OLD NEW` (DRIFT.md), `baseline`
  (fixtures/baselines/<build>/baseline.json; run 2 is the first), `guide` (regenerates SECRETS-GUIDE.html).
- `verify` uses the inventory TSV as ground truth (v2.2 classifier rules). `all` also writes ops/lab/combat/tokens/knowledge and runs
  **drift automatically** against the newest stored baseline.
- `xref --player` accepts a character name. `inference` defaults to the log owner (unit flags 0x511).
- **SECRETS-GUIDE.html** (generator in `tools/guide/`) is built from the converted SV and shipped at the zip root.
- Tests: `tests/regress.lua` (bug B before/after, restrictions, classifier, forced sweep, macros), `tests/hsm.lua` (51 checks:
  library, combat probe, tokens, knowledge, inference, HSM window, baseline, no secrets in SV, zero accidental secret touches),
  and `tests/test_v22.py` (guide JSON schemas, reports, drift, Barrens replay, guide build, Lua/Python hash parity, /run audit).

## v2.1.0 (2026-10-07, after the first real Forever 70245 run)
**Addon**
- **FD_Logs = capture everything.** One click starts all client logs plus the event recorder, combat recorder, error
  capture, secrets verifier and getter sweep, and probe and profiler snapshots. It queues `/fdump all` if the build has no
  full dump yet, and takes an automatic in-combat probe at the first combat. The second click stops everything, copies
  BugGrabber errors and runs `/reload` (synchronous OFF, so SavedVariables are written). `/stopmacro [combat]` guard.
  Capture resumes after `/reload`/relog. Running sessions are saved at logout.
- **Compact SavedVariables by default** (about half the size); `/fdump all full` or `set dump.full true` for the v2.0
  full dump. UTF-8-safe truncation (the v2.0 SV contained cut multi-byte characters).
- **Secrets verifier** (`Secrets.lua`, section `secrets`). Live `issecretvalue`/`canaccessvalue` tallies per event, API
  and struct field position, with context buckets (ooc/combat/encounter, instance type, self/other). Throttled sweep of
  documented conditionally secret getters. Live contradictions against the documentation. `/fdump secrets` live
  panel, `state` and `sweep` subcommands. Bounded counters only (`secrets.maxKeys/maxCtx/maxLive`).
- **Common timebase.** Session IDs and anchors (GetTime, time(), GetServerTime, UTC offset; refined at a time() tick) on
  capture, recorder and combat sessions. `sid/t/epoch/server` on probes, errors, blocked actions and contradictions.
  Everything persists to SavedVariables.
- **BugGrabber/BugSack coexistence.** Uses BugGrabber callbacks (`BugGrabber_BugGrabbed`) when it is loaded, polls `GetDB()`
  as a fallback, and chains the previous handler otherwise. `/fdump errors bg` and FD_Logs OFF copy BugGrabber session
  errors. `## OptionalDeps: !BugGrabber, BugSack`.
- Error attribution to the addon that raised it; CLEU is still never registered by default.

**Converter**
- `secrets` (secrets map: every documented flag; SECRETS.md), `verify` (CONFIRMED / CONTRADICTED / UNOBSERVED /
  UNDOCUMENTED-SECRET, coverage), `xref` (merged timeline with match quality), `migrate` + `migrate-db` (legacy addon
  migration report; 109 curated + 373 Blizzard_Deprecated shim mappings), `fixtures` (anonymized fixture pack).
- `check` gained the `secret-op` rule (arithmetic, comparison, length or boolean tests on documented/observed secret values,
  with guard detection). LuaLS stubs carry secrecy annotations marked `[verified]`/`[unverified]`/`[CONTRADICTED]`.
  Mocks return secret sentinels per documented/verified secrecy (`wow.secretMode`, per-field struct secrets, secret
  event payloads).
- Fixes from the real run: invalid UTF-8 in SV broke JSON export; combat log v22 ENVIRONMENTAL_* advanced-block order,
  ST/AOE scope marker, isOffHand padding; Ketho comparison scoping; `cl-compare` Forever mode.
- Tests: BugGrabber paths (`tests/buggrabber.lua`), verifier with deliberate contradictions (smoke), `tests/test_xref.py`
  (synthetic file log), `tests/test_migrate.py` (deliberate legacy addon), `tests/spec/forever_fixture_spec.lua`
  (anonymized real capture).

## v2.0.0

New in v2 compared to v1:
- **Structure:** 19 Lua files; `.toc` Interface 16001, Version 2.0.0; 6 SavedVariables (DB, DocsDB, StringsDB,
  RecordDB, LogDB, CombatLogDB) so large data stays separate; `schemaVersion` plus a meta header (build, locale,
  `WOW_PROJECT_ID` and **every** `WOW_PROJECT_*` constant, with Forever = 18 / CAMELOT, never assumed mainline;
  `C_AddOns.GetScriptsDisallowedForBeta()`).
- **Sections** (`/fdump all` or one at a time): full APIDocumentation walk with documented/present cross-check;
  C_ namespaces; global tables, functions (secure/insecure), constants and Enum; all global strings; widget API
  (methods per type, inheritance; `risky` option); XML templates; named frames; addons; CVars and console commands;
  protected info (issecurevariable plus doc restriction and secret flags); extras (bindings, slash commands, settings,
  fonts, SOUNDKIT, maps, classes, spells, talents, currencies); opt-in getters; profiling snapshot.
- **Recorders:** event recorder registers documented events individually (no RegisterAllEvents) and saves the
  skipped restricted/SecureOnly events with reasons. The Forever-safe combat recorder (`/fdump cl`) records
  UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING with swing range, COMBAT_TEXT_UPDATE with the C_CombatText getter,
  encounter and regen context with restriction states, and post-combat C_DamageMeter snapshots. Legacy CLEU is
  opt-in only (`cl cleu-force`, guarded). Probe (tooltips and getters, now or next combat).
- **Diagnostics:** chained Lua error handler (stack and locals); ADDON_ACTION_BLOCKED/FORBIDDEN, MACRO_ACTION_*,
  LUA_WARNING and ADDON_RESTRICTION_STATE_CHANGED log.
- **FD_Logs:** `/fdump logs` and the single account macro FD_Logs toggle the combat log, chat log,
  advancedCombatLogging, scriptErrors and taintLog together, with state in SavedVariables and a clear chat line.
- **Safety and UX:** refuses heavy work in combat; frame-sliced chunking with `/fdump cancel`; secret-value detection
  everywhere (`<secret>`); per-section toggles, clear and set; capped copy window; status view; /reload reminder.
- **Box-side converter** (`tools/`): SV to JSON, LuaLS stubs, luacheck std, busted mocks and replay, API checker,
  diff, combat log file parser, taint.log parser, error report, Ketho comparison.
