#!/usr/bin/env bash
# Full test run: addon smoke test in the mock client (writes tests/out/ForeverDump.lua), then converter e2e.
set -eo pipefail   # a failing test fails the run even when piped through tail (perf gate included)
cd "$(dirname "$0")/.."
mkdir -p tests/out
export FORE_DOCS="${FORE_DOCS:-$PWD/ref/wusf/Interface/AddOns}"
luac5.1 -p ForeverDump/*.lua ForeverDump/Lib/*.lua
luacheck ForeverDump tests --no-color -q --exclude-files "tests/legacy_addon/*"
lua5.1 tests/smoke.lua ForeverDump tests/out/ForeverDump.lua | tail -1
lua5.1 tests/hsm.lua ForeverDump | tail -1
lua5.1 tests/knowledge_parse.lua ForeverDump | tail -1
lua5.1 tests/timing.lua ForeverDump | tail -1
lua5.1 tests/learned.lua ForeverDump | tail -1
python3 tests/test_converter.py
lua5.1 tests/buggrabber.lua ForeverDump | tail -1
python3 tests/test_xref.py
python3 tests/test_migrate.py
lua5.1 tests/regress.lua ForeverDump | tail -1
python3 tests/test_v22.py
python3 tests/test_identity.py
python3 tests/test_v222.py
busted tests/spec/containers_spec.lua | tail -1
python3 tests/test_v223.py
python3 tests/test_v224.py
python3 tests/test_v224_tools.py
python3 tests/test_v225_ho.py
python3 tests/test_v225_findings.py
python3 tests/test_v226_replay.py
python3 tests/test_v226_replay_exec.py
python3 tests/test_v226_reconcile.py
python3 tests/test_golden_run5.py
# PERFORMANCE.md gate: static perf lint (errors and warnings fail) + runtime N-cast benchmark (25/50/100 casts + aged session):
# per-event cost flat, <1% frame impact, no idle OnUpdate. Hard 2-minute wall cap (bench --cap 100 aborts itself; timeout 120 backstop).
# v2.2.4 perf gate inside --assert: aged/fresh impact ratio <= 1.5, SPELL_UPDATE_COOLDOWN storm <= 0.5 %, 40-man scanner
# slice max <= budget (the bench re-executes itself with glibc fastbins off; see its header).
python3 tools/fdump.py perfcheck ForeverDump --strict | tail -1
timeout 120 lua5.1 tests/perf_bench.lua ForeverDump --assert --json tests/out/perf_bench.json | tail -1
# v2.2.6: SV size/serialize-time at full capture caps (test ring fill <= 26 MB, ~30 MB total target)
lua5.1 tests/sv_serialize_bench.lua test | tail -2
lua5.1 tests/sv_serialize_bench.lua diag | tail -2
# v2.2.7 (run 6): static lint (combat-protected APIs guarded, no hooks, no bare os, no secret truth tests, deferred
# blocked prints, ObjectiveTracker read-only) + combat-guard regression in the mock client
python3 tests/test_v227_lint.py
lua5.1 tests/combat_guard.lua ForeverDump
lua5.1 tests/hsm_alive.lua ForeverDump
lua5.1 tests/worldcap_pack.lua ForeverDump
# v2.2.8: engine health (helper failure -> degraded, New failure -> down, guard + counters in the tape header)
lua5.1 tests/hsm_health.lua ForeverDump degraded
lua5.1 tests/hsm_health.lua ForeverDump down
lua5.1 tests/hsm_health.lua ForeverDump guard
# v2.2.9 (run 8 BG): error-handler frames never make an error ours; FD_Logs macro never carries a stale /combatlog
lua5.1 tests/run8_regress.lua ForeverDump stack | tail -1
lua5.1 tests/run8_regress.lua ForeverDump macro | tail -1
python3 -W ignore tests/test_v229_run8.py 2>&1 | tail -1
python3 tests/test_v227_secret_lint.py
lua5.1 tests/secret_inject.lua ForeverDump
lua5.1 tests/static_once.lua ForeverDump
# v2.2.7 follow-up (runs 6/6b FINDINGS): engine-health leads, ws decode, coverage fallbacks, meter join by time
python3 tests/test_v227_findings.py
