-- ForeverDump v2.2.4 - C_DamageMeter as an evidence source for the HSM (run 5).
-- Facts (Forever 70245 docs + run 5): the four session/source getters are SecretWhenInCombat (SecretArguments
-- AllowedWhenUntainted); the DAMAGE_METER_COMBAT_SESSION_UPDATED(type, sessionID) arguments are clear in combat and
-- fire in the frame my (or my group's) meter moves; after PLAYER_REGEN_ENABLED the Current session is clear.
-- The meter tracks self/party only: an ungrouped player hitting my target is not in it (run 5, the other mage).
-- What this module does (event driven, no polling, no OnUpdate):
--   * every DAMAGE_METER_COMBAT_SESSION_UPDATED: O(1) count per type + HSM:OnDamageMeter(type) (timing evidence)
--   * once per combat (deferred one frame, out of the event): CLASSIFICATION ONLY of the Current session, its first
--     source and my source's first spell (codes N/S/T/K/C/E per field; never a value)
--   * PLAYER_REGEN_ENABLED + 0.5 s: the clear post-combat read: totals per type (me vs others), my spell breakdown for
--     DamageDone/HealingDone, the same field classification in the "after combat" context; stored as numbers + codes
--     (no names, no GUIDs: source kind only) and handed to HSM:ReconcileDM.
-- Nothing secret is stored: in-combat values are only classified; post-combat values are stored only when the API
-- reports them non-secret (ClassifyValue == "C").
local _, ns = ...
local DM = {}
ns.DamageMeter = DM

local function g(n) return rawget(_G, n) end
local function cfg() return (ns.config and ns.config.damageMeter) or {} end
local function code(v) return ns.ClassifyValue(v) end
local function clearNum(v) return (type(v) == "number" and code(v) == "C") and v or nil end
local function now() return (g("GetTime") or os.clock)() end

DM.TYPES = { DamageDone = 0, Dps = 1, HealingDone = 2, Hps = 3, Absorbs = 4, Interrupts = 5, Dispels = 6, DamageTaken = 7,
    AvoidableDamageTaken = 8, Deaths = 9, EnemyDamageTaken = 10 }
DM.READ = { "DamageDone", "HealingDone", "Absorbs", "Interrupts", "Dispels", "DamageTaken", "Deaths", "EnemyDamageTaken" }

local function enumType(name)
    local E = g("Enum")
    local t = type(E) == "table" and rawget(E, "DamageMeterType")
    return (type(t) == "table" and t[name]) or DM.TYPES[name]
end
local function currentSession()
    local E = g("Enum")
    local t = type(E) == "table" and rawget(E, "DamageMeterSessionType")
    return (type(t) == "table" and t.Current) or 1
end

local function db()
    local log = g("ForeverDumpLogDB")
    if type(log) ~= "table" then return nil end
    log.damageMeter = log.damageMeter or { v = 1 }
    return log.damageMeter
end
DM.DB = db

local function api() local D = g("C_DamageMeter") return type(D) == "table" and D or nil end

-- safe field read (secret tables may refuse indexing)
local function field(t, k)
    if type(t) ~= "table" then return nil end
    local ok, v = pcall(function() return t[k] end)
    return ok and v or nil
end

-- schema[ctx][path] = { [code] = n }  (codes only)
local function note(ctx, path, v)
    local d = db()
    if not d then return end
    d.schema = d.schema or {}
    d.schema[ctx] = d.schema[ctx] or {}
    local cell = d.schema[ctx][path]
    if not cell then cell = {} d.schema[ctx][path] = cell end
    local c = code(v)
    cell[c] = (cell[c] or 0) + 1
    -- the same observation feeds the secrets map / verifier (per context, positions only; never the value)
    if ns.ObserveArgs and c ~= "N" then
        local struct, fld = path:match("^(%u%a+)%.(%a+)$")
        if struct then ns.ObserveArgs("field", "DamageMeter" .. struct .. "." .. fld, 1, c == "S" and { 1 } or nil)
        elseif path:match("^%u%a+$") then ns.ObserveArgs("api", "C_DamageMeter." .. path, 1, (c == "S" or c == "T") and { 1 } or nil) end
    end
    return c
end

local SESSION_FIELDS = { "durationSeconds", "totalAmount", "maxAmount", "combatSources" }
local SOURCE_FIELDS = { "sourceGUID", "name", "classFilename", "isLocalPlayer", "totalAmount", "amountPerSecond", "sourceCreatureID",
    "classification", "specIconID", "deathRecapID", "deathTimeSeconds", "sourceDisplayType" }
local SPELL_FIELDS = { "spellID", "totalAmount", "amountPerSecond", "overkillAmount", "creatureName", "isAvoidable", "isDeadly", "combatSpellDetails" }
local DETAIL_FIELDS = { "unitName", "unitClassFilename", "classification", "isPet", "isMob", "amount", "specIconID" }

local function classifyStruct(ctx, prefix, t, fields)
    for _, f in ipairs(fields) do note(ctx, prefix .. "." .. f, field(t, f)) end
end

local function first(list)
    if type(list) ~= "table" or code(list) == "S" then return nil end
    return field(list, 1)
end

local function myGUID()
    local f = g("UnitGUID")
    if type(f) ~= "function" then return nil end
    local ok, v = pcall(f, "player")
    return ok and code(v) == "C" and v or nil
end

-- classification pass (codes only): Current session (DamageDone), first source, my source's first spell + detail
function DM.Classify(ctx)
    local D = api()
    if not D then return false end
    local cur = currentSession()
    note(ctx, "IsDamageMeterAvailable", type(D.IsDamageMeterAvailable) == "function" and select(2, pcall(D.IsDamageMeterAvailable)) or nil)
    if type(D.GetSessionDurationSeconds) == "function" then note(ctx, "GetSessionDurationSeconds", select(2, pcall(D.GetSessionDurationSeconds, cur))) end
    if type(D.GetAvailableCombatSessions) == "function" then
        local ok, list = pcall(D.GetAvailableCombatSessions)
        if ok then
            note(ctx, "GetAvailableCombatSessions", list)
            local s1 = first(list)
            if s1 then for _, f in ipairs({ "sessionID", "name", "durationSeconds" }) do note(ctx, "AvailableCombatSession." .. f, field(s1, f)) end end
        else note(ctx, "error:GetAvailableCombatSessions", true) end
    end
    if type(D.GetCombatSessionFromType) == "function" then
        local ok, s = pcall(D.GetCombatSessionFromType, cur, enumType("DamageDone"))
        if ok then
            note(ctx, "GetCombatSessionFromType", s)
            if code(s) ~= "S" then
                classifyStruct(ctx, "CombatSession", s, SESSION_FIELDS)
                local src = first(field(s, "combatSources"))
                if src then classifyStruct(ctx, "CombatSource", src, SOURCE_FIELDS) end
            end
        else note(ctx, "error:GetCombatSessionFromType", true) end
    end
    local guid = myGUID()
    if guid and type(D.GetCombatSessionSourceFromType) == "function" then
        local ok, s = pcall(D.GetCombatSessionSourceFromType, cur, enumType("DamageDone"), guid)
        if ok then
            note(ctx, "GetCombatSessionSourceFromType", s)
            if code(s) ~= "S" then
                note(ctx, "CombatSessionSource.totalAmount", field(s, "totalAmount"))
                note(ctx, "CombatSessionSource.combatSpells", field(s, "combatSpells"))
                local sp = first(field(s, "combatSpells"))
                if sp then
                    classifyStruct(ctx, "CombatSpell", sp, SPELL_FIELDS)
                    local det = first(field(sp, "combatSpellDetails"))
                    if det then classifyStruct(ctx, "CombatSpellUnitDetails", det, DETAIL_FIELDS) end
                end
            end
        else note(ctx, "error:GetCombatSessionSourceFromType", true) end
    end
    return true
end

local function sourceKind(guid)
    if type(guid) ~= "string" or code(guid) ~= "C" then return nil end
    return guid:match("^(%a+)%-")
end

-- post-combat clear read of one type: totals me vs others (numbers only, no names/GUIDs)
local function readType(D, cur, name)
    local ok, s = pcall(D.GetCombatSessionFromType, cur, enumType(name))
    if not ok then return { err = true } end
    if code(s) == "S" then return { secret = true } end
    local r = { total = clearNum(field(s, "totalAmount")), dur = clearNum(field(s, "durationSeconds")), me = 0, others = 0, n = 0, kinds = {} }
    local list = field(s, "combatSources")
    if type(list) == "table" and code(list) ~= "S" then
        for i = 1, 40 do
            local src = field(list, i)
            if src == nil then break end
            local amt = clearNum(field(src, "totalAmount"))
            local isMe = field(src, "isLocalPlayer")
            r.n = r.n + 1
            if amt then
                if isMe == true then r.me = r.me + amt else r.others = r.others + amt end
            else r.secretAmounts = (r.secretAmounts or 0) + 1 end
            local k = sourceKind(field(src, "sourceGUID")) or ((clearNum(field(src, "sourceCreatureID")) and "Creature") or "?")
            r.kinds[k] = (r.kinds[k] or 0) + 1
        end
    end
    return r
end

local function readSpells(D, cur, name, guid)
    local ok, s = pcall(D.GetCombatSessionSourceFromType, cur, enumType(name), guid)
    if not ok or code(s) == "S" then return nil end
    local list = field(s, "combatSpells")
    if type(list) ~= "table" or code(list) == "S" then return nil end
    local out, n = {}, 0
    for i = 1, 30 do
        local sp = field(list, i)
        if sp == nil then break end
        local id, amt = clearNum(field(sp, "spellID")), clearNum(field(sp, "totalAmount"))
        if id and amt then
            n = n + 1
            out[id] = { amount = amt, overkill = clearNum(field(sp, "overkillAmount")) }
        end
    end
    return n > 0 and out or nil
end

function DM.ReadClear(reason)
    local D = api()
    local d = db()
    if not (D and d) then return nil end
    if ns.InCombat() then return nil end   -- secret in combat: never read values there
    local cur = currentSession()
    local rec = { reason = reason, t = now(), epoch = g("time") and time() or nil, sid = d.sid, types = {} }
    if type(D.GetCombatSessionFromType) == "function" then
        for _, name in ipairs(DM.READ) do rec.types[name] = readType(D, cur, name) end
    end
    local guid = myGUID()
    if guid and type(D.GetCombatSessionSourceFromType) == "function" then
        rec.spells = readSpells(D, cur, "DamageDone", guid)
        rec.healSpells = readSpells(D, cur, "HealingDone", guid)
    end
    DM.Classify("after-combat")
    d.fights = d.fights or {}
    d.fights[#d.fights + 1] = rec
    while #d.fights > (tonumber(cfg().maxFights) or 20) do table.remove(d.fights, 1) end   -- perf-ok: post-combat, <= 21 entries
    DM.last = rec
    local hs = ns.Inference and ns.Inference.hs
    if hs and hs.ReconcileDM then
        local spells
        if rec.spells then spells = {} for id, v in pairs(rec.spells) do spells[id] = v.amount end end
        local dd, hd, it = rec.types.DamageDone, rec.types.HealingDone, rec.types.Interrupts
        hs:ReconcileDM({ damage = dd and dd.me, others = dd and dd.others, healing = hd and hd.me,
            interrupts = it and it.me, spells = spells, duration = dd and dd.dur })
    end
    if ns.HSMUI and ns.HSMUI.MarkDirty then ns.HSMUI.MarkDirty() end
    return rec
end

----------------------------------------------------------------------------
-- events
----------------------------------------------------------------------------
local frame
local probedCombat, inCombatSince = false, nil
local function deferredClassify()
    if not DM.running then return end
    local ctx = (ns.CombatProbe and ns.CombatProbe.Context and ns.CombatProbe.Context()) or (ns.InCombat() and "combat" or "ooc")
    DM.Classify(ctx)
end

function DM.OnEvent(event, a1, a2)
    local d = db()
    if not d then return end
    if event == "DAMAGE_METER_COMBAT_SESSION_UPDATED" then
        local ty = clearNum(a1)
        d.events = d.events or {}
        local k = ty and tostring(ty) or "?"
        d.events[k] = (d.events[k] or 0) + 1
        if code(a1) ~= "C" or code(a2) ~= "C" then d.secretArgs = (d.secretArgs or 0) + 1 end
        local hs = ns.Inference and ns.Inference.hs
        if hs and hs.OnDamageMeter and ty then hs:OnDamageMeter(ty) end
        if cfg().probe ~= false and not probedCombat and inCombatSince and now() - inCombatSince >= 1 then
            probedCombat = true
            if type(g("C_Timer")) == "table" then C_Timer.After(0, deferredClassify) end
        end
    elseif event == "DAMAGE_METER_CURRENT_SESSION_UPDATED" or event == "DAMAGE_METER_RESET" then
        d.events = d.events or {}
        d.events[event] = (d.events[event] or 0) + 1
    elseif event == "PLAYER_REGEN_DISABLED" then
        probedCombat, inCombatSince = false, now()
    elseif event == "PLAYER_REGEN_ENABLED" then
        inCombatSince = nil
        if type(g("C_Timer")) == "table" then C_Timer.After(0.5, function() if DM.running then DM.ReadClear("regen") end end) end
    end
end

function DM.Start()
    if cfg().enabled == false then return false end
    local d = db()
    if not d then return false end
    for k in pairs(d) do if k ~= "v" and k ~= "fights" then d[k] = nil end end   -- fights: last 20 across captures
    d.sid = ns.SessionId and ns.SessionId() or nil
    local D = api()
    if not D then d.unavailable = "C_DamageMeter missing" return false end
    d.functions = {}
    for _, f in ipairs({ "GetAvailableCombatSessions", "GetCombatSessionFromID", "GetCombatSessionFromType", "GetCombatSessionSourceFromID",
        "GetCombatSessionSourceFromType", "GetSessionDurationSeconds", "IsDamageMeterAvailable", "ResetAllCombatSessions" }) do
        d.functions[f] = type(D[f]) == "function"
    end
    if not frame then
        frame = CreateFrame("Frame")
        frame:SetScript("OnEvent", function(_, event, ...)
            local ok, err
            if ns.Perf then ok, err = ns.Perf.Run(ns.Perf.Key("DamageMeter", event), DM.OnEvent, event, ...)
            else ok, err = pcall(DM.OnEvent, event, ...) end
            if not ok then ns.NoteSelfError("DamageMeter." .. event, err) end
        end)
    end
    for _, ev in ipairs({ "DAMAGE_METER_COMBAT_SESSION_UPDATED", "DAMAGE_METER_CURRENT_SESSION_UPDATED", "DAMAGE_METER_RESET",
        "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED" }) do
        local ok = pcall(frame.RegisterEvent, frame, ev)
        if not ok then d.registerFailed = d.registerFailed or {} d.registerFailed[ev] = true end
    end
    DM.running = true
    probedCombat, inCombatSince = false, ns.InCombat() and now() or nil
    DM.Classify(ns.InCombat() and "combat" or "ooc")
    return true
end

function DM.Stop()
    DM.running = false
    if frame then pcall(frame.UnregisterAllEvents, frame) end
    local d = db()
    return d and d.fights and #d.fights or 0
end

ns.captureModules = ns.captureModules or {}
ns.captureModules[#ns.captureModules + 1] = { name = "damage meter evidence (C_DamageMeter)",
    start = function() return DM.Start() end,
    stop = function() local n = DM.Stop() return string.format("DamageMeter %d post-combat read(s)", n) end }
