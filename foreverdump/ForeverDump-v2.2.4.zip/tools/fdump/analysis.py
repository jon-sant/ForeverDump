"""v2.2.4 `fdump.py analyze`: one command, the whole offline pipeline (coverage + HSM replay, knowledge lint and reality
cross-check, live verification join, miss explainer, co-occurrence miner, secrecy drift, recorder/taint health,
accuracy trending) -> ANALYSIS.md with a ranked list of leads: severity, evidence and exact timestamps (user zone)."""
import collections
import datetime
import json

from fdump import coverage as covmod, knowlint, verify_live, misses as missmod, correlate
from fdump import timing as timingmod, learned as learnedmod, tokenscan as tokmod, probes
from fdump.luasv import as_list

SEV = {"high": 0, "medium": 1, "low": 2, "info": 3}


def ts(t):
    if not isinstance(t, (int, float)) or t < 1e9:
        return str(t)
    return datetime.datetime.fromtimestamp(t).strftime("%H:%M:%S.%f")[:12]


def accuracy_table(cov, ver=None):
    """per-rule accuracy for trending: attribution categories (replay after), casts, cooldowns, overheal, interrupts, verdicts"""
    out = {}
    for cat, s in (((cov or {}).get("replay") or {}).get("after") or {}).get("scores", {}).items():
        if s.get("accuracy") is not None:
            out["attr:" + cat] = {"accuracy": s["accuracy"], "n": s.get("scorable"), "coverage": s.get("coverage")}
    c = (cov or {}).get("casts") or {}
    if c.get("predicted"):
        out["enemy-cast-time"] = {"accuracy": round(100.0 * c.get("within150ms", 0) / c["predicted"], 1), "n": c["predicted"], "mae": c.get("mae")}
    oh = (cov or {}).get("overheal") or {}
    if oh.get("estimated"):
        out["overheal-estimate"] = {"accuracy": round(100.0 * oh.get("exact", 0) / oh["estimated"], 1), "n": oh["estimated"], "mae": oh.get("mae")}
    cd = ((cov or {}).get("cooldowns") or {}).get("counts") or {}
    judged = cd.get("confirms", 0) + cd.get("contradicts", 0)
    if judged:
        out["cooldown-fail"] = {"accuracy": round(100.0 * cd.get("confirms", 0) / judged, 1), "n": judged}
    for k, a in ((ver or {}).get("accuracy") or {}).items():
        if a.get("accuracy") is not None:
            out["verify:" + k] = {"accuracy": a["accuracy"], "n": a["n"], "coverage": a["coverage"]}
    return out


def leads(ctx):
    L = []

    def add(sev, kind, title, evidence, times=(), fix=""):
        L.append({"severity": sev, "kind": kind, "title": title, "evidence": evidence, "times": [ts(t) for t in times][:8], "fix": fix})
    cov, kl, ver, mi, mn = ctx.get("coverage") or {}, ctx.get("knowlint") or {}, ctx.get("verify") or {}, ctx.get("misses") or {}, ctx.get("miner") or {}
    # contradictions
    for r in kl.get("data", []) + kl.get("log", []):
        if r["severity"] in ("warn", "error"):
            add("high" if r["severity"] == "error" else "medium", "knowledge contradiction", "%s %s: %s" % (r["spell"], r.get("name"), r["check"]),
                r["detail"], fix="fix the parser / knowledge entry; the regression suite (tests/knowledge_parse.lua) gets a case")
    for r in ver.get("rows", []):
        if r["truth"] in ("refuted", "missed"):
            add("high", "verification refuted", "%s %s (spell %s)" % (r["kind"], r["v"], r.get("spell")), r.get("why") or "", [r.get("t")],
                "the live check disagreed with the log: inspect the rule inputs at that time")
    after = ((cov.get("replay") or {}).get("after") or {})
    for c in after.get("contradictions") or []:
        if isinstance(c, dict):
            add("medium", "HSM contradiction", str(c.get("kind") or c.get("rule") or "contradiction"), json.dumps(c, default=str)[:200], [c.get("t")])
    for e in after.get("errors") or []:
        add("high", "attribution error", "%s claimed %s, truth %s" % (e.get("cat"), e.get("claim"), e.get("truth")), "rule %s amount %s" % (e.get("rule"), e.get("amount")),
            [e.get("t")], "tighten the rule for this category")
    # verdict contradictions inside the engine (live/replay C verdicts)
    for v in cov.get("verdicts") or []:
        if isinstance(v, dict) and v.get("v") == "C":
            add("medium", "live check contradicted", "%s spell %s" % (v.get("kind"), v.get("spell")), "src %s, d %s, conf %s" % (v.get("src"), v.get("d"), v.get("conf")),
                [v.get("t")], "knowledge or model wrong for this case; it feeds the knowledge patch")
    # engine misses
    groups = missmod.group(mi.get("rows", []))
    sevmap = {"rule-gap": "high", "wrong-attribution": "high", "timing-window": "medium", "target-changed": "medium",
              "not-on-tracked-token": "medium", "amount-mismatch": "medium", "concurrent-source": "medium", "recorder-throttle": "low",
              "secret-payload": "low", "no-api-signal": "info", "outside-capture": "info", "no-log-record": "low"}
    for g in groups:
        times = [r["t"] for r in mi["rows"] if r["reason"] == g["reason"] and r["sub"] == g["sub"] and r["spell"] == g["spell"]]
        add(sevmap.get(g["reason"], "low"), "engine miss: " + g["reason"], "%dx %s %s %s>%s spell %s (%s)" % (g["n"], g["sub"], g["cat"], g["src"], g["dst"], g["spell"], g["ctx"]),
            g["detail"], times, missmod.HINT.get(g["reason"], ""))
    for u in mi.get("liveUnmatched", []):
        add("medium" if u["reason"] == "no-log-record" else "low", "unmatched live event", "%s %s on player (%s)" % (u["action"], u["amount"], u["ctx"]),
            u["reason"], [u["t"]], u["hint"])
    # secrecy flips / drift
    for x in (ctx.get("drift") or {}).get("newlySecret", [])[:20]:
        add("high", "secrecy flip", "newly secret: %s" % x, "vs baseline %s" % ctx.get("baseline"), fix="re-check the HSM inputs that read it")
    for x in (ctx.get("drift") or {}).get("newlyClear", [])[:20]:
        add("medium", "secrecy flip", "newly clear: %s" % x, "vs baseline %s" % ctx.get("baseline"), fix="new data available: consider using it")
    for u in ver.get("unexpected", [])[:40]:
        add("medium" if u.get("kind") in ("secrecy-flip", "payload-shape") else "low", "unexpected (live): " + str(u.get("kind")), str(u.get("key")),
            "%s (n=%s, ctx %s)" % (u.get("detail"), u.get("n"), u.get("c")))
    # unknown ids: my own spells in the log without knowledge
    for sid, n in (ctx.get("unknownSpells") or {}).items():
        add("low", "unknown id", "my spell %s cast %dx without a knowledge entry" % (sid, n), "log SPELL_CAST_SUCCESS by me", fix="it is queued by Knowledge.OnOwnCast on the next capture")
    # recorder health
    for k, n in sorted((ctx.get("recorder") or {}).get("dropped", {}).items(), key=lambda kv: -kv[1]):
        if k in ("UNIT_COMBAT", "UNIT_HEALTH", "UNIT_AURA", "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_INTERRUPTED"):
            add("low", "recorder throttle", "RecordDB dropped %d %s" % (n, k), "5/s per-event cap; CombatLogDB kept %s/%s; the HSM gets every event (own frame)" % (
                (ctx.get("recorder") or {}).get("clKept"), (ctx.get("recorder") or {}).get("clTotal")), fix="offline matcher uses CombatLogDB first")
    # taint
    t = ctx.get("taint") or {}
    for c, n in (t.get("byClass") or {}).items():
        if c in ("unexpected", "blizzard-frame", "probe-blocked"):
            add("high", "taint", "%d %s taint entr%s" % (n, c, "y" if n == 1 else "ies"), "taint.log", fix="see `fdump.py taint`")
    # accuracy changes vs previous captures
    hist = ctx.get("history") or []
    if hist:
        prev = hist[-1]
        for k, a in (ctx.get("accuracy") or {}).items():
            p = (prev.get("accuracy") or {}).get(k)
            if p and a.get("accuracy") is not None and p.get("accuracy") is not None and abs(a["accuracy"] - p["accuracy"]) >= 5:
                worse = a["accuracy"] < p["accuracy"]
                add("medium" if worse else "info", "accuracy change", "%s %s -> %s%% (vs %s)" % (k, p["accuracy"], a["accuracy"], prev["label"]),
                    "n %s -> %s" % (p.get("n"), a.get("n")))
    # miner: new correlations that held on other captures, rare frame-exact pairs with id match
    for r in mn.get("rules", []):
        held = sum(1 for v in r["holdout"].values() if v["status"] == "held")
        if r["known"] is None and held >= 1 and r["kind"] != "truth->truth" and r["capture"] == ctx.get("label"):
            if r["kind"] == "live->live" and not any(x in r["a"] + r["b"] for x in ("UNIT_", "BAG_UPDATE_COOLDOWN", "SPELL_", "PLAYER_TOTEM")):
                continue
            add("info", "miner: new correlation", "`%s` ~ `%s` (%d ms)" % (r["a"], r["b"], int(r["window"] * 1000)),
                "support %d/%d, precision %s, recall %s, lift %s, held on %d other capture(s)" % (r["support"], r["nA"], r["precision"], r["recall"], r["lift"], held))
    # v2.2.4 spell timing: known answers (totems 1.0 s, Lightning Shield 1.5 s) are a permanent regression check
    tm = ctx.get("timing") or {}
    for r in (tm.get("report") or {}).get("knownAnswers", []):
        if not r["ok"]:
            add("high", "known-answer mismatch", "spell %s (%s) known GCD %.1f s" % (r["spell"], r["label"], r["known"]), r["why"] + " in " + r["capture"],
                fix="the seed / tracker must never contradict a known answer: check the log span and the GCD learner")
    for c in (tm.get("report") or {}).get("conflicts", []):
        add("medium", "timing conflict", "spell %s %s: seed %s vs new %s" % (c["spell"], c["field"], c["seed"], c["new"]), "source %s, capture %s" % (c["source"], c["capture"]),
            fix="flagged, seed kept; review, then `fdump analyze --write-seed`")
    for p_ in (tm.get("report") or {}).get("promoted", []):
        add("info", "timing promoted", "spell %s %s = %s" % (p_["spell"], p_["field"], p_["value"]), p_["why"])
    lr = (ctx.get("learned") or {}).get("report") or {}
    for c in lr.get("conflicts", []):
        add("medium", "learned conflict", "%s %s %s: seed %s vs new %s" % (c.get("what", "spell"), c.get("spell", c.get("key")), c.get("field"), c.get("seed"), c.get("new")),
            "capture %s" % c.get("capture"), fix="drift proposal: review, then `--write-seed`")
    for p_ in lr.get("proposals", []):
        add("medium", "drift proposal", "%s %s: %s -> %s" % (p_.get("kind"), p_.get("key"), p_.get("old"), p_.get("new")),
            "n %s, build %s, %s (live drift guard flagged it)" % (p_.get("n"), p_.get("build"), p_.get("date")), fix="`fdump analyze --write-seed` adopts it")
    for sev_, kind, title, ev in tokmod.leads(ctx.get("tokens") or {}):
        add(sev_, kind, title, ev, fix="TOKENS.md")
    L.sort(key=lambda x: (SEV[x["severity"]], x["kind"]))
    # collapse the long tail of identical info leads
    return L


def trending_md(rows):
    keys = sorted(set(k for r in rows for k in (r.get("accuracy") or {})))
    if not keys:
        return []
    L = ["## Rule accuracy trending", "", "Current library replayed over every capture (pre-2.2.4 captures have no live verify ring: replay).", "",
         "| rule | " + " | ".join(r["label"] for r in rows) + " |", "|---|" + "---|" * len(rows)]
    for k in keys:
        cells = []
        for r in rows:
            a = (r.get("accuracy") or {}).get(k)
            cells.append("%s%% (n=%s)" % (a["accuracy"], a.get("n")) if a else "-")
        L.append("| %s | %s |" % (k, " | ".join(cells)))
    return L + [""]


def markdown(ctx):
    ls = ctx["leads"]
    sev = collections.Counter(x["severity"] for x in ls)
    L = ["# ANALYSIS: %s" % ctx.get("label"), "",
         "Generated by `fdump.py analyze`. Leads are ranked by severity (high > medium > low > info); times are box-local (ET).", "",
         "Summary: %s." % ", ".join("%s %d" % (k, sev.get(k, 0)) for k in ("high", "medium", "low", "info")), "",
         "| # | severity | kind | lead | evidence | times | what would fix it |", "|---|---|---|---|---|---|---|"]
    info_n = 0
    for i, x in enumerate(ls, 1):
        if x["severity"] == "info":
            info_n += 1
            if info_n > 25:
                continue
        L.append("| %d | %s | %s | %s | %s | %s | %s |" % (i, x["severity"], x["kind"], x["title"].replace("|", "/"), str(x["evidence"]).replace("|", "/"),
                                                      ", ".join(x["times"]), x["fix"]))
    if info_n > 25:
        L.append("| | info | ... | %d more info lead(s) in analysis.json | | | |" % (info_n - 25))
    L.append("")
    L += trending_md((ctx.get("history") or []) + [{"label": ctx.get("label"), "accuracy": ctx.get("accuracy")}])
    if ctx.get("verifyMd"):
        L += [ctx["verifyMd"].replace("# VERIFY", "## VERIFY", 1)]
    if ctx.get("missesMd"):
        L += [ctx["missesMd"]]
    if ctx.get("minerMd"):
        L += [ctx["minerMd"]]
    if ctx.get("knowlintMd"):
        L += [ctx["knowlintMd"]]
    if ctx.get("timingMd"):
        L += [ctx["timingMd"]]
    if ctx.get("learnedMd"):
        L += [ctx["learnedMd"]]
    if ctx.get("tokens"):
        b = ctx["tokens"].get("builds") or {}
        L += ["## Token matrix", "", "%d build(s), %d matrix row(s), %d change alert(s): see TOKENS.md." % (
            len(b), sum(len(x["rows"]) for x in b.values()), len(ctx["tokens"].get("changes") or [])), ""]
    return "\n".join(L) + "\n"


def unknown_spells(dump, fx, player):
    kdb = (dump.db.get("knowledge") or {}) if isinstance(getattr(dump, "db", None), dict) else {}
    known = set()
    for b, d in kdb.items():
        for sid in ((d or {}).get("spells") or {}):
            try:
                known.add(int(sid))
            except (TypeError, ValueError):
                pass
    c = collections.Counter(e["a"][11] for e in fx.get("events", []) if e.get("cleu") and e["sub"] == "SPELL_CAST_SUCCESS" and e["a"][3] == player
                            and isinstance(e["a"][11], int))
    return {sid: n for sid, n in c.items() if sid not in known}


def recorder(dump):
    cs = as_list((dump.combatlog or {}).get("sessions"))
    rs = as_list((dump.record or {}).get("sessions"))
    c, r = (cs[-1] if cs else {}), (rs[-1] if rs else {})
    return {"clKept": c.get("kept"), "clTotal": c.get("total"), "clOverwritten": c.get("overwritten"), "recKept": r.get("kept"),
            "dropped": dict(r.get("dropped") or {}), "perEventPerSec": (r.get("config") or {}).get("perEventPerSec")}


def run(dump, fx, player, label="capture", taint=None, baseline=None, history_caps=(), lua="lua5.1"):
    """history_caps: [(label, dump, fx, player)] older captures (miner holdout + trending)"""
    from fdump import drift as driftmod, taintlog
    ctx = {"label": label}
    cov = covmod.analyze(dump, fx, player, lua=lua)
    ctx["coverage"] = cov
    kl = knowlint.analyze(dump, fx, player, lua=lua)
    ctx["knowlint"] = kl
    ctx["knowlintMd"] = knowlint.markdown(kl)
    ver = verify_live.analyze(dump, fx, player, cov, kl, cov["_ctx"]["cls"], replay_verdicts=cov.get("verdicts"))
    ctx["verify"] = ver
    ctx["verifyMd"] = verify_live.markdown(ver)
    mi = missmod.explain(cov, fx, player)
    ctx["misses"] = mi
    ctx["missesMd"] = missmod.markdown(mi, ts)
    caps = list(history_caps) + [(label, dump, fx, player)]
    mn = correlate.run(caps)
    ctx["miner"] = mn
    ctx["minerMd"] = correlate.markdown(mn)
    if baseline:
        try:
            ctx["drift"] = driftmod.compare(driftmod.load(baseline), driftmod.from_dump(dump))
            ctx["baseline"] = baseline
        except Exception as ex:   # noqa: BLE001 - a broken baseline must not stop the analysis
            ctx["drift"] = {"error": str(ex)}
    if taint:
        t = taintlog.parse(taint)
        ctx["taint"] = {"count": t["count"], "byClass": t["summary"].get("byClass")}
    ctx["unknownSpells"] = unknown_spells(dump, fx, player)
    ctx["recorder"] = recorder(dump)
    ctx["accuracy"] = accuracy_table(cov, ver)
    hist = []
    for hl, hd, hfx, hp in history_caps:
        hc = covmod.analyze(hd, hfx, hp, lua=lua)
        hk = knowlint.analyze(hd, hfx, hp, lua=lua)
        hv = verify_live.analyze(hd, hfx, hp, hc, hk, hc["_ctx"]["cls"], replay_verdicts=hc.get("verdicts"))
        hist.append({"label": hl, "accuracy": accuracy_table(hc, hv)})
    ctx["history"] = hist
    seeds(ctx, dump, fx, player, label, history_caps)
    ctx["leads"] = leads(ctx)
    return ctx


def seeds(ctx, dump, fx, player, label, history_caps=()):
    """v2.2.4: evidence from every capture -> merged spell-timing and learned seeds (in memory; `--write-seed` writes them).
    Merges are idempotent per capture id, so re-running analyze on the same captures changes nothing."""
    caps = list(history_caps) + [(label, dump, fx, player)]
    tev = [timingmod.evidence(d, f, p, label=lab) for lab, d, f, p in caps]
    tseed, trep = timingmod.merge(timingmod.load_seed(), tev)
    ctx["timing"] = {"seed": tseed, "report": trep, "evidence": len(tev)}
    ctx["timingMd"] = timingmod.markdown(tseed, trep)
    seen = set()
    lev = []
    for lab, d, f, p in caps:
        date, build = timingmod._date(d)
        if f and p:
            lev.append(learnedmod.from_log(f, p, label=lab, seen=seen, build=build, date=date))
        sv = learnedmod.from_sv(d, label=lab)
        if sv["spells"] or sv["npcs"] or sv["drift"]:
            lev.append(sv)
    lseed, lrep = learnedmod.merge(learnedmod.load_seed(), lev)
    ctx["learned"] = {"seed": lseed, "report": lrep, "evidence": len(lev)}
    ctx["learnedMd"] = learnedmod.markdown(lseed, lrep)
    ctx["tokens"] = tokmod.analyze(dump)
    ctx["tokensMd"] = tokmod.markdown(ctx["tokens"], probes.tokens(dump))
    return ctx


def public(ctx):
    """JSON-safe summary (no in-memory context, no per-event miner tables)"""
    return {"label": ctx["label"], "leads": ctx["leads"], "accuracy": ctx["accuracy"], "history": ctx["history"],
            "verify": {k: v for k, v in ctx["verify"].items() if k != "rows"}, "misses": {"byReason": ctx["misses"]["byReason"],
            "liveUnmatched": ctx["misses"]["liveUnmatched"]}, "recorder": ctx["recorder"], "unknownSpells": ctx["unknownSpells"],
            "taint": ctx.get("taint"), "miner": {"captures": ctx["miner"]["captures"], "rules": _per_capture(ctx["miner"]["rules"], 150),
                                                  "rare": _per_capture(ctx["miner"]["rare"], 80), "durations": ctx["miner"]["durations"]},
            "drift": {k: ctx["drift"].get(k) for k in ("newlySecret", "newlyClear", "buildBump")} if ctx.get("drift") else None,
            "timing": {"report": (ctx.get("timing") or {}).get("report"), "spells": len(((ctx.get("timing") or {}).get("seed") or {}).get("spells") or {})},
            "learned": {"report": (ctx.get("learned") or {}).get("report"), "spells": len(((ctx.get("learned") or {}).get("seed") or {}).get("spells") or {}),
                        "npcs": len(((ctx.get("learned") or {}).get("seed") or {}).get("npcs") or {})},
            "tokens": {b: {"contexts": x["contexts"], "rows": len(x["rows"]), "cost": x["cost"], "dup": x["dup"], "alias": x["alias"]}
                       for b, x in ((ctx.get("tokens") or {}).get("builds") or {}).items()},
            "cdLine": _cdline_public((ctx.get("knowlint") or {}).get("cdLine")),
            "cdTracker": {k: ((ctx.get("coverage") or {}).get("cdtrack") or {}).get(k) for k in ("casts", "counts", "nyr")}}


def _per_capture(rows, cap):
    """first `cap` rows of every capture (rows are already ranked per capture), unknown pairs first"""
    out, n = [], {}
    for r in sorted(rows, key=lambda r: r.get("known") is not None):
        k = r.get("capture")
        if n.get(k, 0) < cap:
            n[k] = n.get(k, 0) + 1
            out.append(r)
    return out


def _cdline_public(c):
    """tooltip extra-line cooldown hypothesis: verdict + per-sample evidence (spell ids/names are game data; counts only)"""
    if not c:
        return None
    keep = ("spell", "name", "ctx", "lines", "extraLine", "onCooldownByOwnCast", "onCooldownShared")
    return {"verdict": c.get("verdict"), "proven": c.get("proven"), "scorable": c.get("scorable"), "agree": c.get("agree"),
            "agreeShared": c.get("agreeShared"), "sampleTimes": c.get("sampleTimes"),
            "rows": [{k: r.get(k) for k in keep} for r in c.get("rows") or []], "probe": c.get("probe") or []}
