# Run 5 findings (2026-10-08, Forever 1.60.1.70245, shaman, addon v2.2.3)

All times are ET (box-local) on 2026-10-08. Ground truth is the client's own `WoWCombatLog.txt`, read offline on the box only.
The addon never used CLEU and no side channels were used. Names of other players are replaced by labels ("other player A").
Reports: `out/coverage/COVERAGE.md`, `out/analysis/ANALYSIS.md` (ranked leads), `out/analysis/VERIFY.md`,
`out/analysis/TOKENS.md`, `out/knowledge/KNOWLEDGE.md`, `out/inference/HSM.md`, `out/perf/PERF.md`, guide section 12.
Re-create everything with `sh real/2026-10-08-run5/convert.sh` (about 80 s).

Capture: 151 s. Three fights: 00:02:03–00:02:31, 00:02:42–00:03:20 (contains my Earth Shock interrupt at 00:03:17.98) and
00:03:31–00:03:45. In the third fight an ungrouped mage ("other player A") hit my target.

## Top findings in plain words

1. **The addon can tell my damage from someone else's on my target, live, without the combat log.** The v2.2.4 attribution
   rules were replayed over the live events v2.2.3 recorded in game. Every hit was credited correctly: damage on my target,
   damage taken, heals, misses and the interrupt (100%, up from 0% with the v2.2.3 rules). Not one of the mage's hits was
   credited to me. A meter that counts everything on my target as mine would have given me 360 damage that was the mage's.
2. **The damage meter matches the combat log to the point after combat.** Post-combat `C_DamageMeter` values equal the log
   for my damage (1324 / 1213 / 799), damage taken (267 / 935 / 221) and interrupts (0 / 1 / 0). In combat its numbers are
   secret, but its update event is not, and it fires in the same frame as *my* damage. It does not track an ungrouped player at
   all, which is exactly what makes "live total minus meter = others" work.
3. **The cooldown tracker never contradicted reality.** None of my 25 casts landed while the tracker said "cooling" or
   "on GCD". All 4 "Not yet recovered" failures in the log happened while it said cooling. Every known GCD answer held:
   totems 1.0 s, Lightning Shield 1.5 s.
4. **The correlation miner found the Earth Shock interrupt by itself, with no rule written for it.** It also found that the
   damage meter's update of type 5 fired once in the whole capture, in exactly the frame of the interrupt. That is a
   candidate live "my interrupt landed" signal, worth confirming with more interrupts.
5. **The "tooltip gets an extra line while on cooldown" idea is not proven, so it stays off.** In combat every shock showed
   one extra tooltip line. That matches "the shocks share a cooldown and one was cooling" perfectly (21/21), but run 5 has
   only one sample moment, so it can't be told apart from "shocks always gain a line in combat". One more sample with the
   shocks ready decides it.
6. **v2.2.3 fixed the frame-rate drop in game.** In run 5 the whole addon used 0.185% of wall time, and the cost per call
   stayed flat over the session (run 4: frame time went from 20.7 to 59.3 ms).
7. **14 values became secret in combat compared with the run-2 baseline,** so the drift guard matters:
   `C_Spell.GetSpellCooldown`, `GetSpellCooldownDuration`, `UnitCastingInfo` / `UnitCastingDuration`, the
   `UNIT_SPELLCAST_*` spell/cast-id arguments and the `UNIT_AURA` payload. 6 became clear, among them `UnitHealthMax` and
   `UnitPowerMax` out of combat. The tracker exists because the cooldown API is now secret in combat.

## Coverage matrix summary (log truth vs what the addon read live)

Per category (log events in the capture span → seen live → amount readable → spell id readable). Full matrix: COVERAGE.md.

| what | log | seen live | amount | spell id | why the rest is missing |
|---|---|---|---|---|---|
| my damage (combat) | 44 | 39 | 39 | 9 | 4 killing-blow hits in the frame the mob died and the target changed, 1 dropped by the offline recorder (5/s cap); melee and DoT ticks carry no spell id |
| hostile NPC damage (to me / my totems) | 28 | 26 | 26 | 0 | 2 on units without a token |
| my misses / NPC misses on me | 4 / 10 | 4 / 10 | 4 / 10 | 3 / 0 | – |
| heals from my totems (combat + ooc) | 110 | 51 | 51 | 0 | ticks landing on the totem itself have no unit token |
| my auras gained / lost (combat) | 7 / 11 | 7 / 8 | 0 | 0 | payload secret in combat, presence readable |
| my casts (start / success / fail) | 3 / 24 / 4 | all | – | all | spell id is clear for the player |
| hostile casts (start / success) | 7 / 5 | 4 / 4 | – | 0 | spell id and cast GUID secret in combat |
| my interrupt | 1 | 1 | – | – | interrupter fields secret; timing identifies it |
| other players' events | 166 | 2 | 2 | 0 | not on a token the addon follows: invisible by design |
| deaths | 5 | 0 | – | – | no unit-token event (UNIT_HEALTH only) |

Miss explainer (every missed log event classified): no-api-signal 59 (totem heals on totems), secret-payload 10 (aura
presence only), target-changed 9, recorder-throttle 1. No rule gap and no wrong attribution.

## The other mage on my target (fight 3, 00:03:31–00:03:45)

- Log: other player A cast Frost Armor (00:03:29.7), then two Frostbolts on my target: 177 at 00:03:38.2 and 183 at
  00:03:41.4. That is 360 damage, against my 799 in the fight.
- Live, the addon saw both hits as `UNIT_COMBAT` WOUND on target, school 16 (frost), amounts readable. The mage's casts never
  reached a token the addon follows (5 casts in the log, 0 visible).
- The hard case: my Frost Shock is also frost (105 crit at 00:03:37.5). It was credited to me by the cast-frame rule (my
  own cast in the same frame). The Frostbolts had no own cast in their frame *and no damage-meter update in their frame*, so
  elimination credited them to "other".
- Result: live "other" 360 = log 360. Live "mine" 799 = log 799 = meter 799. 0 false self-attributions. The meter's
  "others" was 0 (it does not track ungrouped players), so the reconciliation "live total − meter mine = 360 others on my
  target" holds exactly.

## C_DamageMeter findings

| fight | duration log / meter | my damage log / meter | others on my target log / meter | taken log / meter | my effective heal log / meter | interrupts log / meter |
|---|---|---|---|---|---|---|
| 1 | 28.5 / 28 | 1324 / 1324 | 0 / 0 | 267 / 267 | 69 / 69 | 0 / 0 |
| 2 | 37.4 / 37 | 1213 / 1213 | 0 / 0 | 935 / 935 | 555 / 555 | 1 / 1 |
| 3 | 14.4 / 14 | 799 / 799 | 360 / 0 | 221 / 221 | 18 / 12 | 0 / 0 |

- Post-combat reads are clear and exact for my damage, damage taken and interrupts. Duration is whole seconds. Fight 3
  healing differs by 6 (log effective 18, meter 12); unexplained, so it is watched in the next run.
- In combat `C_DamageMeter.GetCombatSessionFromType` returns a container with secret contents: `durationSeconds`,
  `totalAmount` and `maxAmount` are secret, while the `combatSources` container is readable. Out of combat everything is
  clear. `IsDamageMeterAvailable` is always clear.
- `DAMAGE_METER_COMBAT_SESSION_UPDATED(type, sessionID)`: 426 events (414 in combat), with no secret argument ever. Counts
  per type: 0, 1, 10: 80 each; 2, 3: 66; 7: 52; 5: 2 (one frame, at the interrupt). It fires in the frame my damage or
  healing lands, so it is timing evidence of *my* events.
- An ungrouped player is absent from the meter. Others on my target = live `UNIT_COMBAT` total − meter mine.
- Live vs meter gaps: fight 1 live mine 1219 vs 1324. The 105 is the killing-blow swing, which landed in the frame the mob died
  and my target changed (miss class target-changed). Fight 2: 1088 vs 1213. The 125 is one swing the offline recorder dropped at its 5/s
  cap; the live HSM gets every event, so in game this gap would not exist.

## HSM before / after

Attribution, replay of the run-5 live events scored against the log (before = v2.2.3 library, after = v2.2.4 HybridState):

| category | n | before accuracy | after accuracy | after false self |
|---|---|---|---|---|
| aura on me | 2 | 50.0% | 100% | 0 |
| aura on target | 6 | 83.3% | 100% | 0 |
| damage on target | 41 | 0% | 100% | 0 |
| damage taken | 36 | 0% | 100% | 0 |
| heal on me | 54 | 0% | 100% | 0 |
| interrupt | 1 | 0% | 100% | 0 |
| miss on target | 4 | 0% | 100% | 0 |

Rule accuracy over all captures (current library, replay): damage on target 100% (run 3, n=1) → 90% (run 4, n=10) → 100%
(run 5, n=41). Damage taken and heals on me were 100% in all three runs. Overheal estimate 96.3% (52 of 54 exact).

New v2.2.4 checks on run 5 (replay):
- cooldown tracker: 25/25 casts consistent; 4/4 "Not yet recovered" confirmed.
- cooldown model vs log failures: 4 confirmations.
- enemy cast bars: 2 predictions, mean error 0.056 s; the NPC 4119 Lightning Bolt model has a median of 3.5 s.
- verification ring: 24 verdicts, 0 refuted; cooldown 100% (10 confirmed), cast-end, damage-range and interrupt
  attribution 100%.
- Ledger: target token→GUID right 41 of 44 times. Its 50 "maybe removed" doubts were justified 35 times. A scoring bug used
  to count those doubts as wrong claims; it is fixed.

The live HSM that ran in game (v2.2.3) scored aura presence 58.3% in combat (12 judged) and cooldowns 2/2 (10 pending).
That gap is why v2.2.4 moved to the timing-based attribution, Ledger and tracker above.

Cost: v2.2.3 in game 0.185% of wall time, flat per call. The v2.2.4 perf gate: aged/fresh 1.00–1.18, storm 0.29–0.39%,
40-man scanner slice at most 0.115 ms against a 0.12 ms budget (PERFORMANCE.md).

## Tooltip extra-line cooldown hypothesis: evidence table (signal disabled unless proven)

Rule: enable `hsm.tooltipCooldownSignal` only with at least 10 known-answer samples per phase, 100% agreement and at least
2 sample moments. Only tooltip line **counts** were recorded, never text. Sample moment: the in-combat knowledge pass (one
moment for all spells). "On cooldown" comes from the log (my last cast of the spell within its base cooldown).
**Verdict: NOT proven, so the signal stays off.** Agreement is 14/21 with "this exact spell was on cooldown" and 21/21 with
"a spell of the same shared shock cooldown was on cooldown", from 1 sample moment.

| spell | name | lines ooc → combat | extra line | on cooldown (my own last cast, log) | on cooldown (shared-cooldown view, assumption) | agrees (own / shared) |
|---|---|---|---|---|---|---|
| 556 | Astral Recall | 4 → 4 | no | no | no | ✓ / ✓ |
| 2484 | Earthbind Totem | 5 → 5 | no | no | no | ✓ / ✓ |
| 5730 | Stoneclaw Totem | 5 → 5 | no | no | no | ✓ / ✓ |
| 6390 | Stoneclaw Totem | 5 → 5 | no | no | no | ✓ / ✓ |
| 6391 | Stoneclaw Totem | 5 → 5 | no | no | no | ✓ / ✓ |
| 8042 | Earth Shock | 4 → 5 | yes | no | yes | ✗ / ✓ |
| 8044 | Earth Shock | 4 → 5 | yes | no | yes | ✗ / ✓ |
| 8045 | Earth Shock | 4 → 5 | yes | no | yes | ✗ / ✓ |
| 8046 | Earth Shock | 4 → 5 | yes | no | yes | ✗ / ✓ |
| 8050 | Flame Shock | 4 → 5 | yes | no | yes | ✗ / ✓ |
| 8052 | Flame Shock | 4 → 5 | yes | yes | yes | ✓ / ✓ |
| 8053 | Flame Shock | 4 → 5 | yes | no | yes | ✗ / ✓ |
| 8056 | Frost Shock | 4 → 5 | yes | no | yes | ✗ / ✓ |
| 8177 | Grounding Totem | 5 → 5 | no | no | no | ✓ / ✓ |
| 17364 | Stormstrike | 4 → 4 | no | no | no | ✓ / ✓ |
| 20572 | Blood Fury | 4 → 4 | no | no | no | ✓ / ✓ |
| 20608 | Reincarnation | 5 → 5 | no | no | no | ✓ / ✓ |
| 408341 | Fire Nova | 4 → 4 | no | no | no | ✓ / ✓ |
| 408342 | Fire Nova | 4 → 4 | no | no | no | ✓ / ✓ |
| 437009 | Totemic Projection | 4 → 4 | no | no | no | ✓ / ✓ |
| 1299026 | Shatter Curse | 4 → 4 | no | no | no | ✓ / ✓ |

What it means: the extra line appears on exactly the spells of one shared cooldown (the shocks), and Flame Shock 8052 was
cooling at that moment. Two explanations fit: "the line shows the shared cooldown" or "shocks gain a line in combat anyway".
To decide, the next run needs a second in-combat sample with all shocks ready. v2.2.4's `knowledge.cdLineProbe` records line
counts and types per phase automatically.

## What the correlation miner found that we hadn't

The miner pairs every live event shape with every log event shape at 50 / 150 / 300 / 750 ms. It scores each pair against
a null model and checks it on the other captures (run 3, run 4).
- **Rediscovered without a rule:** my `UNIT_SPELLCAST_SUCCEEDED` (Earth Shock 8046) ↔ `SPELL_INTERRUPT` 8046, same frame,
  matching spell id. The target's (and nameplate's / soft-enemy's) `UNIT_SPELLCAST_INTERRUPTED` lands in the frame of my
  Earth Shock (p = 0.002). The interrupter fields of that event are secret in combat; timing alone identifies it. This is
  the golden test (`tests/test_golden_run5.py`).
- **New: damage meter type 5.** `DAMAGE_METER_COMBAT_SESSION_UPDATED` with type 5 occurred once in 151 s, in the
  interrupt frame (p = 0.0007). It is a candidate clear "my interrupt counted" signal. It needs at least 3 more interrupts to
  become a rule, so for now it is provisional.
- **New: the soft-enemy token reports the shock crit.** `UNIT_COMBAT softenemy CRITICAL school 8` in the interrupt frame is
  the Earth Shock hit itself (nature, crit), seen through the soft-enemy token as well as target and nameplate. That makes
  soft-enemy a third view of the same unit; it is not a separate interrupt signal.
- **New: targettarget mirrors me.** When the mob targets me, `UNIT_SPELLCAST_SENT/SUCCEEDED targettarget` repeats my own
  casts (precision 0.86–1.0, held on 2 other captures). That is a token alias: useful for dedupe, and no new information.
- **New: free "my cast happened" echo.** `BAG_UPDATE_COOLDOWN` fires on every one of my successful casts (25/25,
  precision 1.0, held on 2 captures).
- **New: totem heal ticks are visible as `UNIT_HEAL_PREDICTION player`** (precision 0.9, recall 1.0, held on 2 captures).
  The heal tick itself only shows when it lands on me.
- Privacy fix found on the way: miner keys carried `UNIT_SPELLCAST_SENT` target names. Player names are now redacted
  (`<player>`), and NPC names (game data) stay.

## Dungeon / battleground capture checklist (next run)

Run v2.2.4 with FD_Logs ON, `/combatlog` running from before FD_Logs ON until after OFF, and the file log copied together
with the SV. Each line says what it fills.
1. **Target / focus / mouseover / soft target.** Set a focus on a second mob and mouse over a third during a pull: fills the
   token matrix for focus, mouseover and soft-enemy in combat, and the Ledger token→GUID cache.
2. **A party member with a target.** In a group, have one member target something else: `party1target`, and group-meter
   "others" (the meter tracks group members, so the reconciliation changes).
3. **Raid member targeting** (any raid group, 6+ players): `raidNtarget` families, scanner cost per slice with 40 tokens
   (the budget must hold in game, not only in the bench).
4. **Arena or battleground:** `arenaN` tokens and PvP-restricted APIs (`UnitTokenPvPRestrictedForAddOns`). Look for
   restriction flips and the drift changelog's "build-change" / category entries.
5. **A boss encounter:** `bossN` tokens and ENCOUNTER_START containers. Check whether the meter's session types change
   inside an encounter.
6. **Interrupt known answer:** at least 3 Earth Shock interrupts on casting mobs, plus 1 deliberately late (cast already
   finished). That decides the damage-meter type 5 signal and fills `verify:interrupt-attribution`.
7. **isActive / isOnGCD flips:** cast a totem, then Lightning Shield, then a shock back to back, and cast once while a shock
   is cooling. That checks the 1.0 s / 1.5 s GCD known answers live and the shared shock cooldown.
8. **Tooltip second sample:** stay in combat at least 20 s after the last shock (all shocks ready) so the in-combat knowledge
   pass samples them ready. That decides the extra-line hypothesis.
9. **Ring verify:** after the run, `fdump.py analyze ... --history run5=...` must show the verify ring as source **live**
   (not replay), 0 refuted, and no known-answer mismatch lead.
10. Keep the file log running until after FD_Logs OFF (run 5 lost one heal at 00:03:50, after the log stopped).
