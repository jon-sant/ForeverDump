-- ForeverDump v2.2.25 - aura PRESENCE probe (data collection; user idea 2026-10-10). v2.2.26 additions:
--   (a) a nil / secret answer while aura access is restricted (combat, BG/arena, or the player's own GetAuraSlots not
--       clear this tick) is state U = unknown, never A = absent (runs 19-21: every combat 'absent' was present);
--   (b) tracked list = curated AP.SPELLS + Data/AuraSeed.lua (mined from runs 19-21) + auras learned out of combat
--       (ForeverDumpDB.auraLearned, persists), capped at AP.MAX_SPELLS;
--   (c) out of combat: per unit full AuraData (stacks, duration, expiration, points/values, source) change-only tape;
--   (d) totems: GetTotemInfo per slot on PLAYER_TOTEM_UPDATE and each tick, coded per env tag, change-only tape;
--   (e) own clear UNIT_SPELLCAST_SUCCEEDED spellID -> expected aura(s) on target / self with the cached duration
--       (AuraSeed.cast, learned durations), tape + state D (derived) where the live read is U;
--   (f) ADDON_RESTRICTION_STATE_CHANGED type/state counted per env tag and combat flag (also in Restrictions);
--   (4) health context: UnitHealth / UnitPower codes with UnitIsPVP / FFA / group / friend / self / restriction.
-- Question: while unit aura access is restricted (BG, arena, combat ...), is the PRESENCE of one known aura readable?
-- Per the 70245 API inventory: C_UnitAuras.GetUnitAuraBySpellID(unit, spellID) is AllowedWhenTainted +
-- SecretWhenUnitAuraRestricted (+ RequiresNonSecretAura); AuraIsBigDefensive(spellID) and GetAuraCasterGUID(unit,
-- auraInstanceID) take secret arguments when tainted; GetAuraSlots needs unit aura access (also probed, 'HELPFUL|PLAYER').
-- Every result is coded per environment x combat x phase (ns.EnvTag): N nil (absent), S secret value, K/T table
-- (present; fields coded per field), C clear scalar, E error (first message kept), held (circuit breaker).
-- Change-only tape (unit name, spell, state) is scored offline against the combat log's aura applications
-- (tools/fdump/aurapresence.py). Capture level lab only; budget: a few units per second.
local _, ns = ...
local AP = {}
ns.AuraPresence = AP

-- Curated from the included runs' combat logs (SPELL_AURA_APPLIED counts, caster class from log truth, healer flag
-- from the KTH replay truth). role: H healer signature, D dps signature (counter-evidence), M my own spells.
AP.SPELLS = {
    -- SHAMAN
    { 408510, "Water Shield", "SHAMAN", "H" }, { 16177, "Ancestral Fortitude", "SHAMAN", "H" },
    { 16188, "Nature's Swiftness", "SHAMAN", "H" },
    { 408505, "Maelstrom Weapon", "SHAMAN", "D" }, { 1238931, "Improved Stormstrike", "SHAMAN", "D" },
    { 16257, "Flurry", "SHAMAN", "D" },
    -- DRUID
    { 774, "Rejuvenation", "DRUID", "H" }, { 1430, "Rejuvenation", "DRUID", "H" }, { 2090, "Rejuvenation", "DRUID", "H" },
    { 2091, "Rejuvenation", "DRUID", "H" }, { 8938, "Regrowth", "DRUID", "H" }, { 8939, "Regrowth", "DRUID", "H" },
    { 8940, "Regrowth", "DRUID", "H" }, { 17116, "Nature's Swiftness", "DRUID", "H" }, { 740, "Tranquility", "DRUID", "H" },
    { 408255, "Eclipse", "DRUID", "D" }, { 768, "Cat Form", "DRUID", "D" }, { 5487, "Bear Form", "DRUID", "D" },
    -- PRIEST
    { 139, "Renew", "PRIEST", "H" }, { 6074, "Renew", "PRIEST", "H" }, { 6076, "Renew", "PRIEST", "H" },
    { 17, "Power Word: Shield", "PRIEST", "H" }, { 3747, "Power Word: Shield", "PRIEST", "H" },
    { 6065, "Power Word: Shield", "PRIEST", "H" }, { 6788, "Weakened Soul", "PRIEST", "H" },
    { 14751, "Inner Focus", "PRIEST", "H" }, { 27828, "Focused Casting", "PRIEST", "H" },
    { 15271, "Spirit Tap", "PRIEST", "D" }, { 15473, "Shadowform", "PRIEST", "D" },
    -- PALADIN
    { 20216, "Divine Favor", "PALADIN", "H" }, { 437063, "Infusion of Light", "PALADIN", "H" },
    { 19746, "Concentration Aura", "PALADIN", "H" },
    { 10298, "Retribution Aura", "PALADIN", "D" }, { 7294, "Retribution Aura", "PALADIN", "D" },
    { 20915, "Seal of Command", "PALADIN", "D" }, { 20375, "Seal of Command", "PALADIN", "D" },
    { 20050, "Vengeance", "PALADIN", "D" },
    -- my own (Uglaz, enhancement shaman): self buffs + debuffs I put on targets
    { 905, "Lightning Shield", "SHAMAN", "M" }, { 1238640, "Ghost Wolf", "SHAMAN", "M" },
    { 8056, "Frost Shock", "SHAMAN", "M" }, { 17364, "Stormstrike", "SHAMAN", "M" }, { 8052, "Flame Shock", "SHAMAN", "M" },
    { 422621, "Preparation", "-", "M" },
}
AP.FIELDS = { "spellId", "auraInstanceID", "sourceUnit", "duration", "expirationTime", "applications",
    "isFromPlayerOrPlayerPet", "name" }
AP.MAX_SPELLS = 160      -- curated + seed + learned (budget: ~7 units x 160 calls per second, dev budget <= 10 %)
AP.LEARN_MAX = 256       -- learned spell IDs kept in ForeverDumpDB.auraLearned
AP.DETAIL_MAX = 20000
AP.TOTEM_MAX = 4000
AP.DERIVE_MAX = 8000
AP.HCTX_MAX = 3000
AP.PERIOD = 1.0          -- s
AP.ROTATE = 3            -- rotating units per tick (target / focus / mouseover / player every tick)
AP.TAPE_MAX = 40000
AP.FIXED = { "player", "target", "focus", "mouseover" }
AP.ROT = {}
for i = 1, 40 do AP.ROT[#AP.ROT + 1] = "nameplate" .. i end
for i = 1, 5 do AP.ROT[#AP.ROT + 1] = "arena" .. i end
for i = 1, 4 do AP.ROT[#AP.ROT + 1] = "party" .. i end
for i = 1, 40 do AP.ROT[#AP.ROT + 1] = "raid" .. i end

local function g(n) return rawget(_G, n) end
local function now() local f = g("GetTime") return f and f() or 0 end
local function code(v) return ns.ClassifyValue and ns.ClassifyValue(v) or (v == nil and "N" or "C") end
local function clearStr(v) return ns.ClearStr and ns.ClearStr(v) or nil end
local function fam(u) return (u:gsub("%d+$", "N")) end
local function isTrue(v) return ns.IsTrue and ns.IsTrue(v) or false end
local function clearNum(v) return ns.ClearOf and ns.ClearOf(v, "number") or nil end
local function clearBool(v)
    if type(v) ~= "boolean" or code(v) ~= "C" then return nil end
    return v
end
local function b2s(v) if v == nil then return "?" end return v and "1" or "0" end

local function db()
    local log = g("ForeverDumpLogDB")
    if type(log) ~= "table" then return nil end
    local d = log.auraPresence
    if not d then
        d = { v = 1, codes = {}, fields = {}, slots = {}, caster = {}, bigDef = {}, err = {}, tape = {}, last = {},
              units = {}, tapeDropped = 0 }
        log.auraPresence = d
    end
    return d
end
local function inc(t, k, c)
    local x = t[k]
    if not x then x = {} t[k] = x end
    x[c] = (x[c] or 0) + 1
end
local function sub(t, k)
    local x = t[k]
    if not x then x = {} t[k] = x end
    return x
end

-- classify one GetUnitAuraBySpellID result -> state P (present table) / A (absent nil) / S / C / E / H (held)
-- v2.2.26: restricted -> a nil or secret answer is U (unknown): the API hides auras then, it does not report absence
function AP.Classify(held, ok, v, restricted)
    if held then return "H", "held" end
    if not ok then return "E", "E" end
    local c = code(v)
    if restricted and (c == "N" or c == "S") then return "U", c end
    if c == "N" then return "A", c end
    if c == "K" or c == "T" then return "P", c end
    return c == "S" and "S" or "C", c
end

-- learned auras (persist across sessions): ForeverDumpDB.auraLearned[spellID] = { n, name, dur, last }
local function learned()
    local db0 = ns.db
    if type(db0) ~= "table" then return nil end
    db0.auraLearned = db0.auraLearned or {}
    return db0.auraLearned
end
function AP.Learn(sid, name, dur)
    local L = learned()
    if not L or type(sid) ~= "number" then return end
    local r = L[sid]
    if not r then
        local n = 0
        for _ in pairs(L) do n = n + 1 end
        if n >= AP.LEARN_MAX then return end
        r = { n = 0 }
        L[sid] = r
        if not AP.inList or not AP.inList[sid] then AP.listDirty = true end
    end
    r.n = r.n + 1
    if type(name) == "string" then r.name = name end
    if type(dur) == "number" and dur > 0 then r.dur = dur end
    r.last = ns.Build and ns.Build() or nil
end

-- (b) the tracked list: curated, then the mined seed, then learned (most seen first); deduplicated, capped
function AP.List()
    if AP.LIST and not AP.listDirty then return AP.LIST end
    local list, seen = {}, {}
    local function add(sid, name, src)
        if type(sid) == "number" and not seen[sid] and #list < AP.MAX_SPELLS then
            seen[sid] = src
            list[#list + 1] = { sid, name, src }
        end
    end
    for _, s in ipairs(AP.SPELLS) do add(s[1], s[2], "curated") end
    local S = ns.AuraSeed
    if type(S) == "table" and type(S.spells) == "table" then
        for _, s in ipairs(S.spells) do add(s[1], s[3], "seed") end
    end
    local L = learned()
    if L then
        local arr = {}
        for sid, r in pairs(L) do if type(sid) == "number" and type(r) == "table" then arr[#arr + 1] = { sid, r } end end
        table.sort(arr, function(a, b) return (a[2].n or 0) > (b[2].n or 0) end)
        for _, e in ipairs(arr) do add(e[1], e[2].name, "learned") end
    end
    AP.LIST, AP.inList, AP.listDirty = list, seen, false
    local d = db()
    if d then
        local src = {}
        for _, s in ipairs(list) do src[s[3]] = (src[s[3]] or 0) + 1 end
        d.list = { n = #list, bySource = src }
    end
    return list
end

-- cached duration of an aura: learned out of combat (AuraData.duration) first, then the mined seed median
function AP.Duration(sid, fallback)
    local L = learned()
    local r = L and L[sid]
    if r and type(r.dur) == "number" then return r.dur, "learned" end
    if type(fallback) == "number" then return fallback, "seed" end
    return nil, nil
end

-- (e) derived auras: key (guid or token) | spellID -> expiry (GetTime)
AP.derived = {}
function AP.DerivedActive(who, sid)
    local e = AP.derived[who .. "|" .. sid]
    return e and e > now() or false
end
function AP.OnOwnCast(spellID)
    local sid = clearNum(spellID)
    if not sid then return end
    local S = ns.AuraSeed
    local map = type(S) == "table" and type(S.cast) == "table" and S.cast[sid] or nil
    if not map then return end
    local d = db()
    if not d then return end
    d.derived = d.derived or {}
    local tag = ns.EnvTag and ns.EnvTag() or "?"
    for _, m in ipairs(map) do
        local aid, who, sdur = m[1], m[2], m[3]
        local dur, dsrc = AP.Duration(aid, sdur)
        local tok = who == "self" and "player" or "target"
        local okG, guid = pcall(g("UnitGUID") or error, tok)
        guid = okG and clearStr(guid) or nil
        if dur then
            AP.derived[(guid or tok) .. "|" .. aid] = now() + dur
            if guid then AP.derived[tok .. "|" .. aid] = now() + dur end
        end
        if #d.derived < AP.DERIVE_MAX then
            d.derived[#d.derived + 1] = string.format("%.2f|%d|%d|%s|%s|%s|%s|%s", now(), sid, aid, tok, guid or "",
                dur and string.format("%.1f", dur) or "", dsrc or "", tag)
        end
    end
end

-- aura access restricted right now? combat, BG/arena, or the player's own aura slots not clear this tick
function AP.Restricted(slotsClear)
    if ns.InCombat and ns.InCombat() then return true, "combat" end
    local e = ns.Env and ns.Env() or {}
    if e.env == "bg" or e.env == "arena" then return true, e.env end
    if slotsClear == false then return true, "slots" end
    return false, nil
end

local function restrictionVector()
    local R = ns.Restrictions
    if not (R and R.States) then return "" end
    local ok, st = pcall(R.States)
    if not ok or type(st) ~= "table" then return "?" end
    local parts = {}
    for k, v in pairs(st) do if type(v) == "number" and v > 0 then parts[#parts + 1] = k .. "=" .. v end end
    table.sort(parts)
    return table.concat(parts, ",")
end
AP.RestrictionVector = restrictionVector

local function unitName(u)
    local f = g("UnitName")
    if type(f) ~= "function" then return "" end
    local ok, n, r = pcall(f, u)
    if not ok then return "" end
    local s = clearStr(n)
    if not s then return "" end
    local rs = clearStr(r)
    if rs and rs ~= "" then s = s .. "-" .. rs end
    return s
end

function AP.ProbeUnit(d, u, tag, restricted)
    local Aur = g("C_UnitAuras")
    if type(Aur) ~= "table" then return 0 end
    local okE, ex = pcall(g("UnitExists") or error, u)
    if not (okE and isTrue(ex)) then return 0 end
    local okP, isP = pcall(g("UnitIsPlayer") or error, u)
    local f = fam(u)
    if not (okP and isTrue(isP)) and u ~= "target" and u ~= "focus" then return 0 end
    if ns.Derive and ns.Derive.UnitKey then pcall(ns.Derive.UnitKey, u) end   -- full name for the exact join
    local name = unitName(u)
    local okG, guid = pcall(g("UnitGUID") or error, u)
    guid = okG and clearStr(guid) or ""
    local AG = ns.AuraGate
    local tc = sub(d.codes, tag)
    local fc = sub(tc, f)
    local n = 0
    local fn = Aur.GetUnitAuraBySpellID
    if type(fn) == "function" then
        for _, s in ipairs(AP.List()) do
            local sid = s[1]
            local held, ok, v
            if AG and AG.Call then held, ok, v = AG.Call("GetUnitAuraBySpellID", f, fn, u, sid)
            else held, ok, v = false, pcall(fn, u, sid) end
            n = n + 1
            local st, c = AP.Classify(held, ok, v, restricted)
            if st == "U" and (AP.DerivedActive(guid ~= "" and guid or u, sid) or AP.DerivedActive(u, sid)) then
                st = "D"   -- (e) expected from my own clear cast, live read unknown
            end
            inc(fc, sid, c)
            if st == "E" then
                local et = sub(d.err, tag)
                if not et.GetUnitAuraBySpellID then et.GetUnitAuraBySpellID = tostring(v):sub(1, 160) end
            end
            if st == "P" then
                local flds = sub(d.fields, tag)
                local iid
                for _, fld in ipairs(AP.FIELDS) do
                    local okF, fv = pcall(function() return v[fld] end)
                    local fcode = okF and code(fv) or "E"
                    inc(flds, fld, fcode)
                    if fld == "auraInstanceID" and fcode == "C" then iid = fv end
                end
                -- caster GUID for a clear instance ID (needs unit aura access; secret when restricted)
                local gc = Aur.GetAuraCasterGUID
                if iid and type(gc) == "function" then
                    local hC, okC, cg = false
                    if AG and AG.Call then hC, okC, cg = AG.Call("GetAuraCasterGUID", f, gc, u, iid)
                    else okC, cg = pcall(gc, u, iid) end
                    inc(d.caster, tag, hC and "held" or (okC and code(cg) or "E"))
                end
            end
            -- change-only tape keyed by (unit name or token, spell)
            local who = name ~= "" and name or u
            local lk = who .. "|" .. sid
            if d.last[lk] ~= st then
                d.last[lk] = st
                if #d.tape < AP.TAPE_MAX then
                    d.tape[#d.tape + 1] = string.format("%.2f|%s|%s|%s|%d|%s|%s", now(), u, name, guid, sid, st, tag)
                else
                    d.tapeDropped = d.tapeDropped + 1
                end
            end
        end
    end
    -- GetAuraSlots(unit, 'HELPFUL|PLAYER'): needs unit aura access
    local gs = Aur.GetAuraSlots
    if type(gs) == "function" then
        local held, ok, a1, a2
        if AG and AG.Call then held, ok, a1, a2 = AG.Call("GetAuraSlots", f, gs, u, "HELPFUL|PLAYER")
        else held, ok, a1, a2 = false, pcall(gs, u, "HELPFUL|PLAYER") end
        inc(sub(d.slots, tag), f, held and "held" or (ok and (code(a1) .. "/" .. code(a2)) or "E"))
        if not held and not ok then
            local et = sub(d.err, tag)
            if not et.GetAuraSlots then et.GetAuraSlots = tostring(a1):sub(1, 160) end
        end
    end
    inc(d.units, tag, f)
    if not restricted then pcall(AP.Detail, d, u, name, guid, tag) end
    pcall(AP.HealthContext, d, u, f, tag, restricted)
    return n
end

-- (c) out of combat: every aura on the unit with stacks / duration / expiration / points (values) / source;
-- change-only per (unit, spell, instance); every clear spellID is learned for the tracked list
function AP.Detail(d, u, name, guid, tag)
    local Aur = g("C_UnitAuras")
    local fn = type(Aur) == "table" and Aur.GetAuraDataByIndex or nil
    if type(fn) ~= "function" then return end
    d.detail = d.detail or {}
    d.detailLast = d.detailLast or {}
    local who = name ~= "" and name or u
    for _, filter in ipairs({ "HELPFUL", "HARMFUL" }) do
        for i = 1, 40 do
            local ok, a = pcall(fn, u, i, filter)
            if not ok or code(a) == "N" or type(a) ~= "table" then break end
            local sid = clearNum(a.spellId)
            if not sid then inc(sub(d, "detailCodes"), tag, "spellId:" .. code(a.spellId)) break end
            local apps, dur, exp = clearNum(a.applications), clearNum(a.duration), clearNum(a.expirationTime)
            local iid = clearNum(a.auraInstanceID)
            local pts = {}
            local okP, P = pcall(function() return a.points end)
            if okP and type(P) == "table" and code(P) ~= "S" then
                for k = 1, 8 do
                    local okV, pv = pcall(function() return P[k] end)
                    if not okV or pv == nil then break end
                    local cv = clearNum(pv)
                    pts[#pts + 1] = cv and tostring(cv) or code(pv)
                end
            end
            local src = clearStr(a.sourceUnit) or ""
            local mine = clearBool(a.isFromPlayerOrPlayerPet)
            local aname = clearStr(a.name)
            AP.Learn(sid, aname, dur)
            local key = who .. "|" .. sid .. "|" .. tostring(iid)
            local sig = string.format("%s|%s|%s|%s", tostring(apps), tostring(dur), exp and string.format("%.1f", exp) or "",
                table.concat(pts, ";"))
            if d.detailLast[key] ~= sig then
                d.detailLast[key] = sig
                if #d.detail < AP.DETAIL_MAX then
                    d.detail[#d.detail + 1] = string.format("%.2f|%s|%s|%s|%d|%s|%s|%s|%s|%s|%s|%s",
                        now(), u, name, guid, sid, sig, src, b2s(mine), filter, aname or "", tostring(iid), tag)
                else
                    d.detailDropped = (d.detailDropped or 0) + 1
                end
            end
        end
    end
end

-- (4) health / power readability with the unit's PvP flag, group, friendliness and the restriction vector
function AP.HealthContext(d, u, f, tag, restricted)
    local function call(name, ...)
        local fn = g(name)
        if type(fn) ~= "function" then return "-", nil end
        local ok, v = pcall(fn, ...)
        if not ok then return "E", nil end
        return code(v), v
    end
    local hc = call("UnitHealth", u)
    local pc = call("UnitPower", u)
    local pvpC, pvp = call("UnitIsPVP", u)
    local ffaC, ffa = call("UnitIsPVPFreeForAll", u)
    local _, inP = call("UnitInParty", u)
    local _, inR = call("UnitInRaid", u)
    local _, fr = call("UnitIsFriend", "player", u)
    local _, me = call("UnitIsUnit", u, "player")
    local key = string.format("%s|pvp=%s|ffa=%s|grp=%s|friend=%s|self=%s|restr=%s|%s", f,
        pvpC == "C" and b2s(clearBool(pvp)) or pvpC, ffaC == "C" and b2s(clearBool(ffa)) or ffaC,
        (isTrue(inP) or clearNum(inR)) and "1" or "0", b2s(clearBool(fr)), b2s(clearBool(me)), restricted and "1" or "0",
        restrictionVector())
    local t = sub(sub(d, "hctx"), tag)
    local x = t[key]
    if not x then x = {} t[key] = x end
    x["health:" .. hc] = (x["health:" .. hc] or 0) + 1
    x["power:" .. pc] = (x["power:" .. pc] or 0) + 1
end

-- (d) totems: GetTotemInfo(slot) -> haveTotem, name, startTime, duration, icon, modRate, spellID; coded per env tag
function AP.Totems(d, tag, why, only)
    local fn = g("GetTotemInfo")
    if type(fn) ~= "function" then return end
    d.totems = d.totems or {}
    d.totemCodes = d.totemCodes or {}
    d.totemLast = d.totemLast or {}
    local tc = sub(d.totemCodes, tag)
    for slot = only or 1, only or 4 do
        local r = { pcall(fn, slot) }
        local ok = table.remove(r, 1)
        local codes = {}
        if not ok then codes[1] = "E" else
            for i = 1, 7 do codes[i] = code(r[i]) end
        end
        local cs = table.concat(codes, "")
        inc(tc, why .. ":" .. slot, cs)
        local have = ok and clearBool(r[1])
        local sig = string.format("%s|%s|%s|%s|%s|%s", cs, b2s(have), ok and (clearStr(r[2]) or "") or "",
            ok and (clearNum(r[3]) and string.format("%.1f", r[3]) or "") or "", ok and tostring(clearNum(r[4]) or "") or "",
            ok and tostring(clearNum(r[7]) or "") or "")
        if d.totemLast[slot] ~= sig or why == "event" then
            d.totemLast[slot] = sig
            if #d.totems < AP.TOTEM_MAX then
                d.totems[#d.totems + 1] = string.format("%.2f|%d|%s|%s|%s", now(), slot, why, sig, tag)
            end
        end
    end
end

-- (f) restriction flips per env tag (type:state, combat flag at dispatch)
function AP.OnRestriction(rtype, rstate)
    local d = db()
    if not d then return end
    local tag = ns.EnvTag and ns.EnvTag() or "?"
    local t = code(rtype) == "C" and tostring(rtype) or code(rtype)
    local s = code(rstate) == "C" and tostring(rstate) or code(rstate)
    inc(sub(d, "restrict"), tag, t .. ":" .. s .. ":" .. ((ns.InCombat and ns.InCombat()) and "combat" or "ooc"))
end

-- AuraIsBigDefensive(spellID): static per spell; once per env tag
function AP.BigDefensive(d, tag)
    local Aur = g("C_UnitAuras")
    local fn = type(Aur) == "table" and Aur.AuraIsBigDefensive or nil
    if type(fn) ~= "function" then return end
    local t = sub(d.bigDef, tag)
    if t.done then return end
    t.done = true
    for _, s in ipairs(AP.List()) do
        local ok, v = pcall(fn, s[1])
        local c = ok and code(v) or "E"
        t[s[1]] = c == "C" and (v and "true" or "false") or c
    end
end

local rot = 0
function AP.Active()
    return ns.LabActive and ns.LabActive() and ns.db and ns.db.logs and ns.db.logs.on and true or false
end
function AP.Tick()
    local d = db()
    if not d then return end
    local tag = ns.EnvTag and ns.EnvTag() or "?"
    if not d.anchor then
        -- time audit 2026-10-10: a bare time() is whole seconds, so the run 20 anchor sat up to 1 s early (offline fit
        -- +1.000 s). Core.TimeAnchor refines epochTick/gameTimeTick on the next second edge and adds utcOffset.
        local tf = g("time")
        d.anchor = ns.TimeAnchor and ns.TimeAnchor() or { gameTime = now(), epoch = type(tf) == "function" and tf() or nil }
    end
    d.v = 2
    AP.BigDefensive(d, tag)
    -- is aura access open this tick? the player's own GetAuraSlots must answer clear (it errors when restricted)
    local slotsClear
    local Aur = g("C_UnitAuras")
    if type(Aur) == "table" and type(Aur.GetAuraSlots) == "function" then
        local AG = ns.AuraGate
        local held, ok, a1
        if AG and AG.Call then held, ok, a1 = AG.Call("GetAuraSlots", "player", Aur.GetAuraSlots, "player", "HELPFUL")
        else held, ok, a1 = false, pcall(Aur.GetAuraSlots, "player", "HELPFUL") end
        slotsClear = (not held) and ok and code(a1) ~= "S" or false
    end
    local restricted, why = AP.Restricted(slotsClear)
    inc(sub(d, "restricted"), tag, restricted and ("yes:" .. why) or "no")
    pcall(AP.Totems, d, tag, "tick")
    local done = {}
    for _, u in ipairs(AP.FIXED) do AP.ProbeUnit(d, u, tag, restricted) done[u] = true end
    local tried, probed = 0, 0
    while probed < AP.ROTATE and tried < #AP.ROT do
        rot = rot + 1
        if rot > #AP.ROT then rot = 1 end
        tried = tried + 1
        local u = AP.ROT[rot]
        if not done[u] and AP.ProbeUnit(d, u, tag, restricted) > 0 then probed = probed + 1 end
    end
end

local ticker, evFrame
local function onEvent(_, event, a1, a2, a3)
    if not AP.Active() then return end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        if a1 == "player" then pcall(AP.OnOwnCast, a3) end
    elseif event == "PLAYER_TOTEM_UPDATE" then
        local d = db()
        local slot = clearNum(a1)
        if d then pcall(AP.Totems, d, ns.EnvTag and ns.EnvTag() or "?", "event", slot) end
    elseif event == "ADDON_RESTRICTION_STATE_CHANGED" then
        pcall(AP.OnRestriction, a1, a2)
    end
end
function AP.Start()
    local ct = g("C_Timer")
    if not (type(ct) == "table" and type(ct.NewTicker) == "function") then return false end
    if ticker then return true end
    if not AP.Active() then return false end
    local log = g("ForeverDumpLogDB")
    if type(log) == "table" then log.auraPresence = nil end   -- fresh per capture
    local d = db()
    if not d then return false end
    rot = 0
    AP.listDirty, AP.derived = true, {}
    AP.List()
    local cf = g("CreateFrame")
    if not evFrame and type(cf) == "function" then
        local okF, fr = pcall(cf, "Frame")
        if okF and fr then
            evFrame = fr
            fr:SetScript("OnEvent", onEvent)
        end
    end
    if evFrame then
        if not pcall(evFrame.RegisterUnitEvent, evFrame, "UNIT_SPELLCAST_SUCCEEDED", "player") then
            pcall(evFrame.RegisterEvent, evFrame, "UNIT_SPELLCAST_SUCCEEDED")
        end
        pcall(evFrame.RegisterEvent, evFrame, "PLAYER_TOTEM_UPDATE")
        pcall(evFrame.RegisterEvent, evFrame, "ADDON_RESTRICTION_STATE_CHANGED")
    end
    ticker = ct.NewTicker(AP.PERIOD, function()
        if not AP.Active() then return end
        if ns.Perf then ns.Perf.Run("AuraPresence.tick", AP.Tick) else pcall(AP.Tick) end
    end)
    return true
end
function AP.Stop()
    if ticker and ticker.Cancel then ticker:Cancel() end
    ticker = nil
    if evFrame and evFrame.UnregisterAllEvents then pcall(evFrame.UnregisterAllEvents, evFrame) end
    local d = g("ForeverDumpLogDB") and ForeverDumpLogDB.auraPresence
    if not d then return nil end
    d.last, d.detailLast, d.totemLast = nil, nil, nil   -- transient (reset next capture)
    return #d.tape
end

ns.captureModules = ns.captureModules or {}
ns.captureModules[#ns.captureModules + 1] = { name = "aura presence probe (v2.2.26)",
    start = function() return AP.Start() end,
    stop = function()
        local n = AP.Stop()
        return n and string.format("aura presence: %d tape entries", n) or nil
    end }
