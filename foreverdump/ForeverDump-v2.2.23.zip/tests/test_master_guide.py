"""v2.2.10 master secrets guide regression (docs/SECRETS-GUIDE.html + .md + docs/secrets-guide-state.json).

Fails when the committed guide is stale: it differs byte for byte from `python3 tools/fdump.py master-guide` output for
the runs under real/, or a guide file is older than the newest run input (SV, analysis/coverage JSON, FINDINGS.md).
Also: no raw GUIDs / player names in any guide file, sane structure (rows x families x contexts, statuses, tally,
HTML and Markdown carry the same rows), every curated FINDINGS claim still resolves, and the staleness check itself
detects an edited or outdated guide (negative controls on a scratch copy). Without the private captures (real/ absent,
e.g. in a release zip) only the placeholder and structure checks on whatever guide is present run."""
import json
import os
import re
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from fdump import master_guide as mg  # noqa: E402

HAVE_RUNS = bool(mg.list_runs(ROOT))
DOCS = {rel: os.path.join(ROOT, rel) for rel in mg.OUTPUTS}
HAVE_DOCS = all(os.path.exists(p) for p in DOCS.values())


def _read(rel):
    with open(DOCS[rel], encoding="utf-8") as f:
        return f.read()


@unittest.skipUnless(HAVE_DOCS or HAVE_RUNS, "no master guide and no private captures")
class Fresh(unittest.TestCase):
    @unittest.skipUnless(HAVE_RUNS, "private captures (real/) absent")
    def test_guide_is_fresh(self):
        probs = mg.check(ROOT)
        self.assertEqual(probs, [], "stale master guide; run `python3 tools/fdump.py master-guide`: %s" % probs)

    @unittest.skipUnless(HAVE_RUNS, "private captures (real/) absent")
    def test_claims_resolve(self):
        st = json.loads(_read("docs/secrets-guide-state.json"))
        self.assertEqual(st["droppedClaims"], [], "FINDINGS claim quote no longer found")
        self.assertGreaterEqual(st["claimsUsed"], 20)
        self.assertEqual(st["newestRun"], mg.list_runs(ROOT)[-1])


@unittest.skipUnless(HAVE_DOCS, "master guide not generated")
class Content(unittest.TestCase):
    def test_no_placeholders(self):
        # v2.2.21 (raw identity): no privacy gate; the guide must not carry redaction placeholders either
        for rel in mg.OUTPUTS:
            text = _read(rel)
            self.assertNotIn(":redacted", text, rel)
            self.assertNotIn("<redacted>", text, rel)

    def test_structure(self):
        st = json.loads(_read("docs/secrets-guide-state.json"))
        rows = st["rows"]
        self.assertEqual(st["schema"], mg.SCHEMA)
        self.assertEqual(len(rows), st["rowCount"])
        self.assertGreaterEqual(len(rows), 150)
        self.assertEqual(len({r["id"] for r in rows}), len(rows))
        self.assertEqual(sum(st["tally"].values()), len(rows))
        for r in rows:
            self.assertIn(r["status"], mg.STATUSES, r["id"])
            self.assertEqual(set(r["read"]), set(mg.CTXS), r["id"])
            self.assertIn(r["family"], mg.FAMILIES, r["id"])
        # every requested value family is covered
        ids = {r["id"].split("/")[0] for r in rows}
        for need in ("health", "healthMax", "power", "casting", "spellid", "castbar", "aura-event", "aura-payload", "aura-details",
                     "guid", "name", "unit-combat", "unit-died", "threat", "range", "cooldown", "meter"):
            self.assertIn(need, ids)
        fams = {r["family"] for r in rows if r["id"].startswith("health/")}
        self.assertEqual(fams, set(mg.ALL8))
        # HTML and Markdown carry the same rows and the same tally
        html = _read("docs/SECRETS-GUIDE.html")
        md = _read("docs/SECRETS-GUIDE.md")
        self.assertEqual(len(re.findall(r'<tr id="', html)), len(rows))
        data_rows = 0
        for sec in re.split(r"\n## ", md):
            if sec.startswith("| value | family | ooc |") or "\n| value | family | ooc |" in sec:
                data_rows += len([ln for ln in sec.splitlines() if ln.startswith("| ") and not ln.startswith("| value |")])
        self.assertEqual(data_rows, len(rows))
        for s, n in st["tally"].items():
            self.assertIn("| %s | %d |" % (s, n), md)
        self.assertIn("Changed since last run", md)
        self.assertIn("Changed since last run", html)

    def test_raw_allowed(self):
        # v2.2.21 (raw identity): GUIDs and character names pass unchanged - no privacy gate
        self.assertIsNone(mg.assert_private("x Player-1234-0ABCDEF0 y", ROOT))
        names = sorted(mg.forbidden_names(ROOT))
        if names:
            self.assertIsNone(mg.assert_private("row about %s here" % names[0], ROOT))


@unittest.skipUnless(HAVE_RUNS and HAVE_DOCS, "private captures absent")
class StaleDetection(unittest.TestCase):
    """negative controls: the check must flag an edited guide and a guide older than the run data"""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="fd_mg_")
        os.symlink(os.path.join(ROOT, "real"), os.path.join(self.tmp, "real"))
        os.makedirs(os.path.join(self.tmp, "tools", "fdump"))
        shutil.copy(os.path.join(ROOT, "tools", "fdump", "characters.json"), os.path.join(self.tmp, "tools", "fdump"))
        os.makedirs(os.path.join(self.tmp, "docs"))
        for rel in mg.OUTPUTS:
            shutil.copy2(DOCS[rel], os.path.join(self.tmp, rel))

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_copy_is_fresh(self):
        self.assertEqual(mg.check(self.tmp), [])

    def test_edit_detected(self):
        p = os.path.join(self.tmp, "docs", "SECRETS-GUIDE.md")
        st = os.stat(p)
        with open(p, "a", encoding="utf-8") as f:
            f.write("hand edit\n")
        os.utime(p, (st.st_atime, st.st_mtime))
        self.assertTrue(any("does not match" in x for x in mg.check(self.tmp)))

    def test_older_than_data_detected(self):
        p = os.path.join(self.tmp, "docs", "SECRETS-GUIDE.html")
        os.utime(p, (1, 1))
        self.assertTrue(any("older than the newest run data" in x for x in mg.check(self.tmp)))


if __name__ == "__main__":
    r = unittest.main(exit=False, verbosity=1).result
    print("master guide: %s (%d tests, %d skipped)" % ("OK" if r.wasSuccessful() else "FAILED", r.testsRun, len(r.skipped)))
    sys.exit(0 if r.wasSuccessful() else 1)
