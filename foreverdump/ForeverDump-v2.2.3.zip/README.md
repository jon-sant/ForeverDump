# ForeverDump v2.2.3 bundle

- `SECRETS-GUIDE.html`: the Forever secret-values guide (single file; open in a browser). Built from the run-4 capture
  (shaman, 2026-10-07) with `tools/fdump.py guide`; includes the "Partial secrets and containers" section.
- `ForeverDump/`: the addon. Copy it to `World of Warcraft\_classic_beta_\Interface\AddOns\`. See `ADDON-USAGE.md`.
- `ADDON-USAGE.md`: install, slash commands and run order, the FD_Logs macro, where SavedVariables land, privacy.
- `INSTRUCTIONS-console.md`: console, CVar and log instructions. `SELF-HOSTING.md`: self-hosting and community sources.
- `tools/`: converter (`tools/README.md`), guide generator (`tools/guide/`), packaging (`tools/package.py`) and `tools/refresh/` (refresh scripts).
- `tests/`: mock client, addon smoke test, converter tests, sample addon, deliberate legacy addon (`tests/legacy_addon`) and **synthetic** log fixtures.
- `fixtures/forever-70245/`: an **anonymized** real Forever capture (API surface, environment, documented secrets map, combat/taint log). See its README.
- `fixtures/baselines/70245/`: the stored baseline signature (run 2), used by `fdump.py drift` / `all`, and `containers.json` (run-3 container schema, used by `fdump.py containers`).
- `CHANGES.md`: what changed from v1, v2.0, v2.1, v2.2, v2.2.1, v2.2.2 and v2.2.3.
- `PERFORMANCE.md`: the standing performance rule:
  - under 1% framerate impact
  - no idle OnUpdate
  - O(1) per event
  - dirty-only throttled redraws
  - heavy work out of combat or offline
  - every perf test run finishes within 2 minutes

  It also describes how the test runner enforces the rule.

**Not included (too large):** `data/` (≈215 MB extracted client data) and every `.cache/` folder (≈900 MB, e.g.
`tools/refresh/.cache`), plus `ref/` (reference API docs used by the smoke test) and `tests/out/` (generated). Re-create
them with `tools/refresh/refresh_all.sh` (see SELF-HOSTING.md).

Status: v2.1 ran in-game on Forever 70245 (runs 1-2), v2.2.1 ran in run 3 and v2.2.2 ran in run 4 (shaman, 2026-10-07). See
`real/2026-10-07-run4/out/FINDINGS.md`. The v2.2.3 fixes pass the mock client, the perf gate and the run-4 data offline, but
**have not run in game yet**:
- the frame-rate drop (cached project info, dirty-only HSM redraws, O(1) per-event paths)
- the self-perf monitor
- live HSM verification
- the HSM layout
