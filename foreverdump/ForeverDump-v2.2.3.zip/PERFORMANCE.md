# Performance requirements (standing rule)

This rule applies to everything in this repository: the ForeverDump addon, every module added to it, the converter's
generated code (mocks, specs, fixtures) and any addon ported with `fdump.py migrate`. It is enforced by the default test
runner (`tests/run_converter_tests.sh`), so a build that breaks it fails.

## The rule

1. **No measurable framerate impact: under 1%.** All of the addon's handler time together must be under 1% of wall time
   during a capture (that is, under 0.17 ms per frame at 60 fps), including in long combat sessions.
2. **No idle OnUpdate.** A frame has an OnUpdate script only while it has pending work. Install the script when something
   becomes dirty and remove it (`SetScript("OnUpdate", nil)`) or hide the frame once nothing is pending. Hidden windows
   have no OnUpdate and no UI event registrations.
3. **O(1) per-event cost.** The cost of handling one event must not depend on how long the session has run, or on how many
   casts, auras, units or predictions have been seen. Use bounded ring buffers or amortised trims (never
   `table.remove(t, 1)` on a large list), incremental counters instead of re-walking history, and caches keyed by a version
   number.
4. **Dirty-only, throttled redraws.** UI text and bars are rebuilt only when their data changed (a dirty flag or version
   counter), at most 5-10 Hz, and only while visible. Countdowns may tick at 1 Hz.
5. **Heavy work out of combat or offline.** Walks of `_G` (52k globals on Forever 70245, about 17 ms each), full API sweeps,
   documentation scans and sorting of large tables happen in chunked out-of-combat jobs, once per session (cached), or in
   the offline converter. They never run from an event handler, OnUpdate or redraw path. Container/combat probes run once
   per context or unit class, not on every event.

## Every perf test run finishes within 2 minutes

Every performance test run must finish within **2 minutes of total wall time**. This applies to the default runner, CI and
manual runs alike.

- `tests/perf_bench.lua` uses reasonable cast counts by default: checkpoints at 25/50/100 casts, then an "aged session"
  checkpoint after 2000 more casts pushed through the handlers.
- A hard wall-clock cap (`--cap`, default 100 s) aborts the run and prints the trend measured so far.
- The test runner adds `timeout 120` as a backstop.
- To compare an old build that is slow, use checkpoints (`--marks 1,2,4,8,16 --win 1`) and the cap. Do not use long runs.

## How it is enforced

| check | where | fails when |
|---|---|---|
| runtime benchmark | `lua5.1 tests/perf_bench.lua ForeverDump --assert` (default runner) | per-event cost at the aged checkpoint > 2x the 25-cast cost (+0.05 ms); per-frame cost > 2x (+0.01 ms); impact >= 1% at any checkpoint; any OnUpdate still installed after 700 s of idle; no self-perf data recorded; run longer than the cap |
| static perf lint | `python3 tools/fdump.py perfcheck ForeverDump --strict` (default runner) | an unthrottled OnUpdate that never removes itself, a throttled one never removed, `pairs(_G)` outside an annotated cached or dump-only function, a handler reaching a `_G` walk or an expensive client API, `table.sort` or `table.remove(t, 1)` in a handler, string building in an unthrottled OnUpdate, `RegisterAllEvents`, or a `NewTicker` that is never cancelled |
| HSM / UI unit checks | `tests/hsm.lua` | project info re-walked, unbounded push, Appliers not cached, stale unit state kept, an OnUpdate left installed when idle or hidden |
| ported addons | `fdump.py migrate` writes a "Performance (PERFORMANCE.md)" section into MIGRATION.md | the same lint, reported per call site |
| generated code | `fdump.py mocks` ships `perf_guard.lua` and `spec/perf_spec.lua` | per-event cost grows across the 25/50/100 checkpoints, an idle OnUpdate remains, or the run exceeds the 2-minute cap |

A justified exception is annotated in the code with `-- perf-ok: <reason>` on the same line or the line above. Examples are
the dump-only `_G` walks in the chunked job runner and the once-per-session project scan.

## Measuring in game: the self-perf monitor

Every FD_Logs capture records its own cost in `ForeverDumpLogDB.perf` (Perf.lua, `perf.enabled`, on by default). It keeps
numbers only:

- per-handler call counts, total, max and 15 s windows
- 5 s samples of the Lua heap, the framerate, the C_AddOnProfiler application/overall/own metrics and the sizes of the
  addon's growing tables

Inspect it in two ways:

- `/fdump perf` in game shows the top handlers and the percentage of wall time.
- `python3 tools/fdump.py perf ForeverDump.lua` writes PERF.md and perf.json. They flag:
  - impact >= 1%
  - handlers whose cost per call grows with session length (last third > 2x first third)
  - tables that are still growing at the end

For pre-2.2.3 SVs, PERF.md falls back to the FD_Logs profile snapshots (capture:on vs capture:off).

## Why (run 4, v2.2.2)

The frame rate fell as the user cast more abilities. Causes:

- `ns.Meta()` walked all 52,517 globals on every call (about 17 ms).
- It was reached from the HSM window redraw (once per text line at 5 Hz, and the number of lines grew with predictions),
  from every UNIT_AURA (container DB lookup) and from every combat-probe read in lockdown.

Measured cost:

- In game: the application frame time rose from 20.7 to 59.3 ms during the 86 s capture.
- In the benchmark: the per-frame cost grew 1.5 -> 2.6 -> 5.2 -> 9.5 ms over the first 1/2/4/8 casts, reaching 57-64% frame
  impact.

After the fixes (v2.2.3), the same benchmark shows 0.004-0.009 ms per frame (0.04-0.08%), flat through an aged session of
2,110 casts, and no idle OnUpdate.
