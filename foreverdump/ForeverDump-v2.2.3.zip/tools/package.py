#!/usr/bin/env python3
"""Build ForeverDump-v<version>.zip: addon, converter, guide generator, tests, anonymized fixtures, docs, and
SECRETS-GUIDE.html at the zip root (regenerate it first with `fdump.py guide ... -o real/<run>/out/guide`).
Excludes real/ (user captures), ref/, data/, .cache/, tests/out/, __pycache__ and any guide samples/ (synthetic).
Personal data: character names and GUIDs from tools/fdump/characters.json (and --scrub words) are replaced in every text file of
the zip by consistent placeholders (so the shipped tests stay coherent); the build fails if any of them is still present."""
import argparse
import json
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INCLUDE = ["ForeverDump", "tools", "tests", "fixtures", "README.md", "ADDON-USAGE.md", "CHANGES.md",
           "INSTRUCTIONS-console.md", "SELF-HOSTING.md", "PERFORMANCE.md", ".luacheckrc"]
SKIP_DIRS = {"__pycache__", ".cache", "out", "samples", ".venv", "shots"}
SKIP_TOP = {"real", "ref", "data"}


def version():
    m = re.search(r'ns\.VERSION = "([^"]+)"', open(os.path.join(ROOT, "ForeverDump", "Core.lua")).read())
    return m.group(1)


TEXT = (".lua", ".py", ".md", ".json", ".toc", ".txt", ".sh", ".tsv", ".html", ".xml", ".luacheckrc", ".cfg")
PLACE_NAMES = ["Grukk", "Stonefist", "Healy", "Belzy", "Namea", "Nameb", "Namec", "Named"]
PLACE_HEX = ["0000F00D", "0000BEEF", "0000CAFE", "0000D00D"]


def scrub_map(extra=()):
    """personal words -> placeholders, from tools/fdump/characters.json (first/last names, combat-log names, GUID tails)."""
    words, hexes = [], []
    try:
        with open(os.path.join(ROOT, "tools", "fdump", "characters.json"), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    chars = data.get("characters", data) if isinstance(data, dict) else data
    for c in chars if isinstance(chars, list) else []:
        if not isinstance(c, dict):
            continue
        for k in ("display", "combatLogName", "first", "last", "name"):
            for w in re.split(r"[\s-]+", str(c.get(k) or "")):
                if len(w) >= 4 and w[0].isupper() and w not in words:
                    words.append(w)
        g = str(c.get("guid") or "")
        if g.startswith("Player-") and g.split("-")[-1] not in hexes:
            hexes.append(g.split("-")[-1])
    words += [w for w in extra if w and w not in words]
    m = {}
    for i, w in enumerate(words):
        rep = PLACE_NAMES[i] if i < len(PLACE_NAMES) else "Name%d" % i
        m[w], m[w.lower()], m[w.upper()] = rep, rep.lower(), rep.upper()
    for i, h in enumerate(hexes):
        m[h] = PLACE_HEX[i % len(PLACE_HEX)]
    return m


def scrub(data, m):
    if not m:
        return data
    text = data.decode("utf-8")
    rx = re.compile("|".join(re.escape(k) for k in sorted(m, key=len, reverse=True)))
    return rx.sub(lambda mm: m[mm.group(0)], text).encode("utf-8")


def main():
    v = version()
    short = v[:-2] if v.endswith(".0") else v   # 2.2.0 -> v2.2, 2.2.1 -> v2.2.1
    p = argparse.ArgumentParser()
    p.add_argument("--guide", default=os.path.join(ROOT, "real", "2026-10-07-run4", "out", "guide", "SECRETS-GUIDE.html"))
    p.add_argument("-o", "--out", default=os.path.join(ROOT, "ForeverDump-v%s.zip" % short))
    p.add_argument("--scrub", default="", help="extra comma-separated personal words to replace in the zip")
    a = p.parse_args()
    m = scrub_map([w.strip() for w in a.scrub.split(",")])
    if not os.path.exists(a.guide):
        sys.exit("missing %s: run fdump.py guide first" % a.guide)
    n = 0
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED) as z:
        for top in INCLUDE:
            path = os.path.join(ROOT, top)
            if os.path.isfile(path):
                add(z, path, top, m)
                n += 1
                continue
            for dp, dns, fns in os.walk(path):
                dns[:] = sorted(d for d in dns if d not in SKIP_DIRS and not (dp == path and d in SKIP_TOP))
                for fn in sorted(fns):
                    if fn.endswith((".pyc", ".zip")) or fn == "SECRETS-GUIDE.html":
                        continue
                    full = os.path.join(dp, fn)
                    add(z, full, os.path.relpath(full, ROOT), m)
                    n += 1
        add(z, a.guide, "SECRETS-GUIDE.html", m)
        n += 1
    # leak check: no personal word may survive in any file of the zip
    leaks = []
    with zipfile.ZipFile(a.out) as z:
        for info in z.infolist():
            body = z.read(info.filename)
            for w in m:
                if w.encode("utf-8") in body:
                    leaks.append((info.filename, w))
    if leaks:
        os.remove(a.out)
        sys.exit("personal data left in the zip: %s" % leaks[:10])
    print("wrote %s (%d files, %d KB); scrubbed %d personal word variant(s), leak check clean" % (
        a.out, n, os.path.getsize(a.out) // 1024, len({v for v in m.values()})))


def add(z, path, arc, m):
    if path.endswith(TEXT) or os.path.basename(path).startswith("."):
        with open(path, "rb") as f:
            data = f.read()
        try:
            z.writestr(arc, scrub(data, m))
            return
        except UnicodeDecodeError:
            pass
    z.write(path, arc)


if __name__ == "__main__":
    main()
