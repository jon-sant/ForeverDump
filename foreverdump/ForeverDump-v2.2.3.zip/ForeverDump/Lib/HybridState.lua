-- HybridState-1.0: a reusable "hybrid state machine" for addons on secret-value clients (WoW Forever 1.60+).
-- Predicts and tracks combat state from READABLE inputs only:
--   * UNIT_SPELLCAST_* events (event timing always arrives; spellID only when the client reports it non-secret)
--   * UNIT_AURA updateInfo (auraInstanceIDs / counts / fields when non-secret)
--   * readable aura counts (e.g. GetAuraSlots(unit, "HELPFUL|PLAYER") when the count is not secret)
--   * restriction state, and spell knowledge cached while readable (durations, cooldowns, tooltip ranges)
-- It never reads secrets, never parses secret text, never uses the combat log (CLEU) and never derives numbers from
-- rendered widgets. Every inference carries the rule that produced it and a confidence tag.
--
-- Usage (any addon; no ForeverDump dependency):
--   local HS = HybridState.New({ now = GetTime, onPredict = fn, onInfer = fn, onContradiction = fn })
--   HS:Learn(spellID, { aura = { duration = 30, helpful = true }, cooldown = 8, amount = { min = 10, max = 12, kind = "damage" } })
--   HS:OnCast(event, unitKey, spellID|nil, isPlayer, targetKey)      -- from UNIT_SPELLCAST_* (spellID nil when secret)
--   HS:OnAura(unitKey, { full = bool, added = { { iid=, spellId=, fromPlayer=, helpful=, duration=, applications= } },
--                        addedCount = n, removed = { iid, ... }, removedCount = n })  -- unreadable fields = nil
--   HS:OnCount(unitKey, filter, count)                                   -- readable aura count for a filter
--   HS:Tick()                                                            -- expire predicted auras/cooldowns
--   HS:UnitState(unitKey), HS:CastState(unitKey), HS:Cooldown(spellID), HS.predictions, HS.inferences, HS.counters
-- Embedding: copy this file into your addon and load it before your code. It registers the global `HybridState`
-- (or returns the table when loaded with a module loader); a newer MINOR replaces an older one.
local MAJOR, MINOR = "HybridState-1.0", 2
local existing = rawget(_G, "HybridState")
if type(existing) == "table" and (existing.MINOR or 0) >= MINOR then return existing end

local Lib = { MAJOR = MAJOR, MINOR = MINOR }
local M = {}
M.__index = M

local function defaultNow()
    local f = rawget(_G, "GetTime")
    return type(f) == "function" and f() or os.clock()
end

local CONF = { observed = 3, high = 2, medium = 1, low = 0 }
Lib.CONF = CONF

function Lib.New(opts)
    opts = opts or {}
    local o = setmetatable({}, M)
    o.now = opts.now or defaultNow
    o.window = opts.window or 0.6           -- s: cast -> aura correlation window
    o.tolerance = opts.tolerance or 1.5     -- s: early-removal tolerance before calling it a contradiction
    o.maxLog = opts.maxLog or 2000
    o.onPredict, o.onInfer, o.onContradiction = opts.onPredict, opts.onInfer, opts.onContradiction
    o.knowledge = {}        -- [spellID] = { aura = { duration, helpful }, cooldown, castTime, amount = { min, max, kind } }
    o.units = {}            -- [unitKey] = { auras = { [key] = aura }, counts = { [filter] = n } }
    o.casts = {}            -- [unitKey] = { active, kind, start, spell, ends }
    o.cooldowns = {}        -- [spellID] = { start, ends }
    o.iidMap = {}           -- [unitKey .. "#" .. iid] = { spell, rule, conf }
    o.recent = {}           -- recent player casts { t, spell, target }
    o.unexplained = {}      -- recent auras with unreadable spellId and no explaining cast yet
    o.predictions, o.inferences, o.contradictions = {}, {}, {}
    o.summons, o.totems = {}, {}
    o.counters = { predictions = 0, inferences = 0, contradictions = 0, casts = 0, auraEvents = 0, unreadable = 0 }
    o.restriction = {}
    o.seq = 0
    o.version = 0           -- bumped on every state change (UIs redraw only when it moved: dirty flag)
    o.kver = 0              -- knowledge version (Appliers cache key)
    o.applCache = {}
    return o
end

-- bounded append, amortised O(1): the list may hold up to max + max/4 entries; when it overflows, the newest max are
-- moved down in one pass (v2.2.3; table.remove(list, 1) shifted the whole list on EVERY insert once full)
local function push(list, rec, max)
    local n = #list + 1
    list[n] = rec
    local slack = math.max(8, math.floor(max / 4))
    if n > max + slack then
        local drop = n - max
        for i = 1, max do list[i] = list[i + drop] end
        for i = max + 1, n do list[i] = nil end
    end
    return rec
end
Lib.push = push

function M:Learn(spellID, k)
    if type(spellID) ~= "number" or type(k) ~= "table" then return end
    local cur = self.knowledge[spellID] or {}
    for key, v in pairs(k) do
        if type(v) == "table" and type(cur[key]) == "table" then for a, b in pairs(v) do cur[key][a] = b end else cur[key] = v end
    end
    self.knowledge[spellID] = cur
    self.kver = self.kver + 1
    self.version = self.version + 1
end

-- spells of the player that apply an aura of the given helpfulness ("single applier" rule input)
function M:Appliers(helpful)
    -- cached per knowledge version (v2.2.3: it was rebuilt + sorted on every aura event)
    local ck = (helpful == nil) and "any" or (helpful and "h" or "d")
    local c = self.applCache[ck]
    if c and c.v == self.kver then return c.list end
    local out = {}
    for id, k in pairs(self.knowledge) do
        if k.aura and (helpful == nil or k.aura.helpful == nil or k.aura.helpful == helpful) then out[#out + 1] = id end
    end
    table.sort(out)
    self.applCache[ck] = { v = self.kver, list = out }
    return out
end

function M:unit(key)
    local u = self.units[key]
    if not u then u = { auras = {}, counts = {} } self.units[key] = u end
    return u
end

function M:infer(rec)
    self.seq = self.seq + 1
    rec.id, rec.t = self.seq, rec.t or self.now()
    self.counters.inferences = self.counters.inferences + 1
    self.version = self.version + 1
    push(self.inferences, rec, self.maxLog)
    if self.onInfer then pcall(self.onInfer, rec) end
    return rec
end

function M:contradict(rec)
    rec.t = rec.t or self.now()
    self.counters.contradictions = self.counters.contradictions + 1
    self.version = self.version + 1
    push(self.contradictions, rec, 200)
    if self.onContradiction then pcall(self.onContradiction, rec) end
end

function M:SetRestriction(rtype, state) self.restriction[rtype] = state end

----------------------------------------------------------------------------
-- casts
----------------------------------------------------------------------------
local START = { UNIT_SPELLCAST_START = "cast", UNIT_SPELLCAST_CHANNEL_START = "channel", UNIT_SPELLCAST_EMPOWER_START = "empower" }
local STOP = { UNIT_SPELLCAST_STOP = "stop", UNIT_SPELLCAST_CHANNEL_STOP = "stop", UNIT_SPELLCAST_EMPOWER_STOP = "stop",
    UNIT_SPELLCAST_SUCCEEDED = "succeeded", UNIT_SPELLCAST_INTERRUPTED = "interrupted", UNIT_SPELLCAST_FAILED = "failed" }
Lib.START, Lib.STOP = START, STOP

function M:OnCast(event, unitKey, spellID, isPlayer, targetKey)
    local now = self.now()
    self.counters.casts = self.counters.casts + 1
    self.version = self.version + 1
    if spellID == nil then self.counters.unreadable = self.counters.unreadable + 1 end
    local c = self.casts[unitKey]
    if START[event] then
        local k = spellID and self.knowledge[spellID]
        self.casts[unitKey] = { active = true, kind = START[event], start = now, spell = spellID,
            ends = k and k.castTime and k.castTime > 0 and (now + k.castTime) or nil }
        self:infer({ rule = "cast-pair", kind = "cast-start", unit = unitKey, spell = spellID, conf = "observed" })
    elseif STOP[event] then
        if c and c.active then
            c.active = false
            self:infer({ rule = "cast-pair", kind = "cast-end", unit = unitKey, spell = spellID or c.spell, outcome = STOP[event],
                started = c.start, conf = "observed" })
        end
        if event == "UNIT_SPELLCAST_SUCCEEDED" and isPlayer and spellID then self:predict(spellID, targetKey, now) end
    end
end

function M:CastState(unitKey) return self.casts[unitKey] end

-- one prediction per successful player cast: aura (+duration), amount range, cooldown end
function M:predict(spellID, targetKey, now)
    local k = self.knowledge[spellID] or {}
    local p = { t = now, spell = spellID, unit = targetKey, known = next(k) ~= nil }
    -- retro correlation: an unexplained aura added within the window BEFORE this cast (UNIT_AURA can precede
    -- UNIT_SPELLCAST_SUCCEEDED) on the cast's aura unit
    if k.aura then
        local aunit = (k.aura.self and "player") or targetKey
        for i = #self.unexplained, 1, -1 do
            local x = self.unexplained[i]
            if now - x.t <= self.window and (aunit == nil or x.unit == aunit)
                and (x.helpful == nil or k.aura.helpful == nil or x.helpful == k.aura.helpful) then
                table.remove(self.unexplained, i)
                local appl = self:Appliers(k.aura.helpful)
                local rule = (#appl == 1) and "single-applier" or "cast-correlation"
                local conf = (#appl == 1 or x.fromPlayer == true) and "high" or "medium"
                local u = self:unit(x.unit)
                local a = u.auras["i" .. tostring(x.iid)]
                if a then
                    a.spell, a.rule, a.conf, a.source = spellID, rule, conf, "inferred"
                    a.duration = a.duration or k.aura.duration
                    a.expires = a.duration and (x.t + a.duration) or nil
                end
                self.iidMap[x.unit .. "#" .. tostring(x.iid)] = { spell = spellID, rule = rule, conf = conf }
                self:infer({ rule = rule, kind = "applied", unit = x.unit, spell = spellID, iid = x.iid, conf = conf,
                    expires = a and a.expires, retro = true, t = x.t })
                p.outcome = "aura seen (" .. rule .. ")"
                break
            end
        end
    end
    if k.aura then
        local aunit = (k.aura.self and "player") or targetKey
        p.aura = { unit = aunit, duration = k.aura.duration, expires = k.aura.duration and (now + k.aura.duration) or nil,
            helpful = k.aura.helpful }
    end
    if k.amount then p.amount = { min = k.amount.min, max = k.amount.max, kind = k.amount.kind } end
    -- v2.2.2: totems are summons (a creature with a lifetime), not auras on the target; verified live by
    -- PLAYER_TOTEM_UPDATE/GetTotemInfo when readable (OnTotem), offline by SPELL_SUMMON -> UNIT_DIED/DESTROYED
    if k.summon then
        p.unit = "player"
        p.summon = { name = k.summon.name, duration = k.summon.duration, expires = k.summon.duration and (now + k.summon.duration) or nil }
        self.summons[#self.summons + 1] = { spell = spellID, t = now, pred = p, name = k.summon.name }
        if #self.summons > 8 then table.remove(self.summons, 1) end
    end
    if k.dispel then p.dispel = true end   -- no live truth without CLEU; offline: SPELL_DISPEL/_FAILED/STOLEN
    if k.cooldown and k.cooldown > 1.5 then
        p.cooldownEnds = now + k.cooldown
        self.cooldowns[spellID] = { start = now, ends = p.cooldownEnds, source = "predicted" }
    end
    self.seq = self.seq + 1
    p.id = self.seq
    self.counters.predictions = self.counters.predictions + 1
    self.version = self.version + 1
    push(self.predictions, p, self.maxLog)
    push(self.recent, { t = now, spell = spellID, target = targetKey, pred = p }, 16)
    if self.onPredict then pcall(self.onPredict, p) end
    return p
end

function M:Cooldown(spellID)
    local c = self.cooldowns[spellID]
    if c and c.ends and c.ends <= self.now() then self.cooldowns[spellID] = nil return nil end
    return c
end

----------------------------------------------------------------------------
-- auras
----------------------------------------------------------------------------
-- the player cast that best explains an aura appearing on unitKey now (within the window)
function M:explain(unitKey, helpful, now)
    local best
    for i = #self.recent, 1, -1 do
        local r = self.recent[i]
        if now - r.t > self.window then break end
        local k = self.knowledge[r.spell]
        if k and k.aura and (helpful == nil or k.aura.helpful == nil or k.aura.helpful == helpful) then
            local au = r.pred and r.pred.aura and r.pred.aura.unit
            if au == nil or au == unitKey or unitKey == nil then best = r break end
        end
    end
    return best
end

function M:addAura(unitKey, key, a)
    local u = self:unit(unitKey)
    local prev = u.auras[key]
    u.auras[key] = a
    self.version = self.version + 1
    if prev and a.refresh == nil then a.refresh = true end
    return a
end

function M:OnAura(unitKey, info)
    if type(info) ~= "table" then return end
    local now = self.now()
    self.counters.auraEvents = self.counters.auraEvents + 1
    local u = self:unit(unitKey)
    if info.addedSecret then self:verifyTiming(unitKey, now) end
    if info.full then
        -- full update: keep inferred auras (they may still exist), drop observed ones we can no longer confirm
        for key, a in pairs(u.auras) do if a.source == "observed" then u.auras[key] = nil end end
    end
    for _, ad in ipairs(info.added or {}) do
        local spell, rule, conf = ad.spellId, nil, nil
        if spell then rule, conf = "observed", "observed"
        else
            local r = self:explain(unitKey, ad.helpful, now)
            if r then
                local appl = self:Appliers(ad.helpful)
                rule = (#appl == 1) and "single-applier" or "cast-correlation"
                conf = (#appl == 1 or ad.fromPlayer == true) and "high" or "medium"
                spell = r.spell
            end
        end
        if not spell and ad.iid then   -- may be explained by a SUCCEEDED that arrives just after the aura (log order)
            push(self.unexplained, { t = now, unit = unitKey, iid = ad.iid, helpful = ad.helpful, fromPlayer = ad.fromPlayer }, 32)
        end
        local k = spell and self.knowledge[spell]
        local dur = ad.duration or (k and k.aura and k.aura.duration)
        local a = { spell = spell, iid = ad.iid, since = now, duration = dur, expires = dur and dur > 0 and (now + dur) or nil,
            applications = ad.applications, source = (rule == "observed") and "observed" or (rule and "inferred" or "unknown"),
            rule = rule or "none", conf = conf or "low", fromPlayer = ad.fromPlayer }
        self:addAura(unitKey, ad.iid and ("i" .. tostring(ad.iid)) or ("n" .. now), a)
        if ad.iid and spell then self.iidMap[unitKey .. "#" .. tostring(ad.iid)] = { spell = spell, rule = rule, conf = conf } end
        if spell then self:verify(spell, unitKey, rule) end
        if rule and rule ~= "observed" then
            self:infer({ rule = rule, kind = "applied", unit = unitKey, spell = spell, iid = ad.iid, conf = conf, expires = a.expires })
        elseif rule == "observed" then
            self:infer({ rule = "observed", kind = "applied", unit = unitKey, spell = spell, iid = ad.iid, conf = "observed", expires = a.expires })
        end
    end
    for _, iid in ipairs(info.removed or {}) do
        local key = "i" .. tostring(iid)
        local a = u.auras[key]
        local m = self.iidMap[unitKey .. "#" .. tostring(iid)]
        if a or m then
            local spell = (a and a.spell) or (m and m.spell)
            self:infer({ rule = "iid-map", kind = "removed", unit = unitKey, spell = spell, iid = iid,
                conf = (m and m.conf) or (a and a.conf) or "low" })
            if a and a.expires and now < a.expires - self.tolerance then
                self:contradict({ kind = "aura-gone-early", unit = unitKey, spell = spell, early = a.expires - now, rule = a.rule })
                if a.pred then a.pred.outcome = "contradicted" end
            end
            u.auras[key] = nil
            self.iidMap[unitKey .. "#" .. tostring(iid)] = nil
        end
    end
end

-- readable count deltas: +n after my cast -> inferred application(s) of that cast's aura
function M:OnCount(unitKey, filter, count)
    if type(count) ~= "number" then self.counters.unreadable = self.counters.unreadable + 1 return end
    local now = self.now()
    local u = self:unit(unitKey)
    local prev = u.counts[filter]
    u.counts[filter] = count
    if prev == nil or count == prev then return end
    local helpful = filter:find("HELPFUL") ~= nil
    if count > prev and filter:find("PLAYER") then
        local r = self:explain(unitKey, helpful, now)
        if r then
            local appl = self:Appliers(helpful)
            local k = self.knowledge[r.spell]
            local dur = k and k.aura and k.aura.duration
            local rule = (#appl == 1) and "single-applier" or "count-delta"
            local a = { spell = r.spell, since = now, duration = dur, expires = dur and (now + dur) or nil, source = "inferred",
                rule = rule, conf = (#appl == 1) and "high" or "medium" }
            self:addAura(unitKey, "c" .. tostring(r.spell), a)
            self:infer({ rule = rule, kind = "applied", unit = unitKey, spell = r.spell, conf = a.conf, expires = a.expires, delta = count - prev })
            self:verify(r.spell, unitKey, rule)
        end
    elseif count < prev then
        self:infer({ rule = "count-delta", kind = "removed", unit = unitKey, conf = "medium", delta = count - prev, filter = filter })
    end
end

-- live verification: the newest open prediction for this spell (and unit when known) gets the rule that confirmed it
function M:verify(spell, unitKey, rule)
    local now = self.now()
    for i = #self.recent, 1, -1 do
        local r = self.recent[i]
        if now - r.t > self.window * 4 then break end
        local p = r.pred
        local unitOk = (p and p.aura and (p.aura.unit == nil or p.aura.unit == unitKey))
            or (p and not p.aura and rule == "observed" and (p.unit == nil or p.unit == unitKey or unitKey == "player"))
        if p and p.spell == spell and p.outcome == nil and unitOk then
            -- v2.2.3: a prediction without aura knowledge (Ghost Wolf, run 4) is confirmed by an observed aura with the
            -- same clear spellId; the aura becomes knowledge (duration 0 = until cancelled)
            p.outcome = "aura seen (" .. tostring(rule) .. ")"
            self.version = self.version + 1
            local u = self.units[unitKey]
            if u then for _, a in pairs(u.auras) do if a.spell == spell and a.since >= p.t then a.pred = p end end end
            return p
        end
    end
end

-- v2.2.3: in combat UNIT_AURA's addedAuras is a wholly secret list or nil (run 3/4). "secret" vs nil is itself a clear
-- yes/no, so an added-aura event on the predicted unit inside the window confirms the newest open aura prediction by
-- event timing only (no field is read). Weaker than "observed": outcome says so, conf medium.
function M:verifyTiming(unitKey, now)
    for i = #self.recent, 1, -1 do
        local r = self.recent[i]
        if now - r.t > self.window * 4 then break end
        local p = r.pred
        if p and p.aura and p.outcome == nil and (p.aura.unit == nil or p.aura.unit == unitKey) then
            p.outcome = "aura event seen (secret payload, timing)"
            p.timingOnly = true
            self:infer({ rule = "secret-timing", kind = "applied", unit = unitKey, spell = p.spell, conf = "medium",
                expires = p.aura.expires })
            return p
        end
    end
end

function M:Tick()
    local now = self.now()
    for i = #self.recent, 1, -1 do
        local p = self.recent[i].pred
        if p and p.aura and p.outcome == nil and now - p.t > self.window * 4 then p.outcome = "no aura seen" end
    end
    for unitKey, u in pairs(self.units) do
        local any = false
        for key, a in pairs(u.auras) do
            if a.expires and now > a.expires + self.tolerance and a.source ~= "observed" then
                u.auras[key] = nil
                self:infer({ rule = "predicted-expiry", kind = "expired", unit = unitKey, spell = a.spell, conf = a.conf })
            elseif not a.expires and a.source ~= "observed" and now - (a.since or now) > (self.unknownTTL or 300) then
                u.auras[key] = nil   -- v2.2.3: unknown-duration auras no longer accumulate forever
                self.version = self.version + 1
            else any = true end
        end
        -- v2.2.3: drop empty per-unit state (one entry per GUID seen used to stay for the whole session)
        if not any and unitKey ~= "player" and not (self.casts[unitKey] and self.casts[unitKey].active) then
            self.units[unitKey] = nil
            self.casts[unitKey] = nil
        end
    end
    for id, c in pairs(self.cooldowns) do if c.ends and c.ends <= now then self.cooldowns[id] = nil self.version = self.version + 1 end end
end

function M:UnitState(unitKey) return self.units[unitKey] end

-- PLAYER_TOTEM_UPDATE(slot) + GetTotemInfo(slot): have/name/start/duration, each nil when unreadable (secret).
-- A new totem verifies the newest open summon prediction (name match when readable, else the newest within the window);
-- a readable engine duration is compared with the predicted lifetime.
function M:OnTotem(slot, have, name, duration)
    local now = self.now()
    self.version = self.version + 1
    local prev = self.totems[slot]
    if have == true then
        if prev and prev.pred and prev.pred.summon then prev.pred.summon.endedAt = now - prev.pred.t end
        if prev then self:infer({ rule = "totem-update", kind = "summon-replaced", unit = "player", spell = prev.spell, slot = slot, conf = "high" }) end
        local best
        for i = #self.summons, 1, -1 do
            local s = self.summons[i]
            if s.pred.outcome == nil and now - s.t <= self.window * 4 and (name == nil or s.name == nil or s.name == name) then best = s break end
        end
        self.totems[slot] = { since = now, name = name, duration = duration, spell = best and best.spell, pred = best and best.pred }
        if best then
            local p = best.pred
            p.outcome = "totem seen (GetTotemInfo)"
            if type(duration) == "number" and duration > 0 then
                p.summon.engineDuration = duration
                if p.summon.duration and math.abs(p.summon.duration - duration) > self.tolerance then
                    self:contradict({ kind = "summon-duration", spell = best.spell, predicted = p.summon.duration, engine = duration })
                end
            end
            self:infer({ rule = "totem-update", kind = "summoned", unit = "player", spell = best.spell, slot = slot, conf = "high",
                expires = p.summon.expires })
        else
            self:infer({ rule = "totem-update", kind = "summoned", unit = "player", slot = slot, conf = "low" })
        end
    elseif have == false and prev then
        local p = prev.pred
        local early = p and p.summon and p.summon.expires and (p.summon.expires - now) or nil
        if p and p.summon then p.summon.endedAt = now - p.t end
        self:infer({ rule = "totem-update", kind = (early and early > self.tolerance) and "summon-ended-early" or "summon-ended",
            unit = "player", spell = prev.spell, slot = slot, conf = "high", early = early })
        self.totems[slot] = nil
    end
end

-- compact, SavedVariables-safe export (numbers/strings/booleans only)
function M:Export()
    return { predictions = self.predictions, inferences = self.inferences, contradictions = self.contradictions,
        counters = self.counters, knowledgeSpells = (function() local n = 0 for _ in pairs(self.knowledge) do n = n + 1 end return n end)() }
end

_G.HybridState = Lib
return Lib
