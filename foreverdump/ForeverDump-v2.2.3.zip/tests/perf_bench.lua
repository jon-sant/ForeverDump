-- ForeverDump performance benchmark / regression test (v2.2.3, run 4: "frame rate drops the more I cast").
-- Loads the addon in the mock client with a realistic global table (52,517 globals, as on Forever 70245 with a
-- normal addon set), starts an FD_Logs capture, enters combat and simulates N casts (UNIT_SPELLCAST_SUCCEEDED +
-- UNIT_AURA + UNIT_HEALTH/POWER per cast, 1.5 s apart, 60 frames/s of OnUpdate for SHOWN frames, C_Timer timers and
-- 1 s tickers). Only ForeverDump's handlers are timed (os.clock around the OnEvent/OnUpdate calls; the mock's
-- dispatch is excluded).
-- Reports per window of 25 casts ending at N = 50 / 200 / 1000: mean cost per event, per frame, ms per simulated
-- second and the share of wall time (= frame-time impact). Then 700 s idle: number of OnUpdate scripts still running.
-- usage: lua5.1 tests/perf_bench.lua ADDON_DIR [--assert] [--json FILE] [--casts 100] [--aged 2000] [--cap 100] [--fps 60]
-- Defaults keep every run under the 2-minute rule (PERFORMANCE.md): checkpoints at 25 / 50 / 100 casts (10-cast windows),
-- then an "aged" checkpoint: --aged more casts are pushed through the event handlers without frames (session state of a
-- ~2,100-cast session in about a second) and one more 10-cast window is measured. --cap is a hard wall-clock limit in
-- seconds (default 100): the run aborts, prints the trend measured so far and, with --assert, fails if the cap was hit.
-- --assert enforces PERFORMANCE.md: per-event and per-frame cost O(1) in session length (aged <= 2x the 25-cast cost +
-- slack), impact < 1 % of wall time at every checkpoint, no idle OnUpdate, run finished inside the cap.
package.path = "./tests/?.lua;" .. package.path
local addonDir = arg[1] or "ForeverDump"
local opts = { casts = 100, fps = 60, aged = 2000, cap = 100 }
local wall0 = os.time()
do local i = 2 while arg[i] do
    if arg[i] == "--assert" then opts.assert = true
    elseif arg[i] == "--json" then opts.json = arg[i + 1] i = i + 1
    elseif arg[i] == "--casts" then opts.casts = tonumber(arg[i + 1]) i = i + 1
    elseif arg[i] == "--keys" then opts.keys = true
    elseif arg[i] == "--marks" then opts.marks = arg[i + 1] i = i + 1
    elseif arg[i] == "--win" then opts.win = tonumber(arg[i + 1]) i = i + 1
    elseif arg[i] == "--aged" then opts.aged = tonumber(arg[i + 1]) i = i + 1
    elseif arg[i] == "--cap" then opts.cap = tonumber(arg[i + 1]) i = i + 1
    elseif arg[i] == "--fps" then opts.fps = tonumber(arg[i + 1]) i = i + 1 end
    i = i + 1 end end

local W = require("wowenv")
local S, SECRET = W.state, W.SECRET
-- realistic _G size (the run-4 SV counted 52,517 globals)
local nG = 0
for k in pairs(_G) do if k then nG = nG + 1 end end
for i = 1, 52517 - nG do
    local m = i % 3
    _G["BenchGlobal_" .. i] = (m == 0 and {}) or (m == 1 and function() end) or i
end
-- tickers (missing in the mock): chained per simulated second
local tickers = {}
C_Timer.NewTicker = function(sec, fn)
    local t = { sec = sec, fn = fn, next = S.time + sec }
    t.Cancel = function() t.cancelled = true end
    tickers[#tickers + 1] = t
    return t
end
UnitExists = function(u) return u == "player" or u == "target" or u == "nameplate1" end
UnitCanAttack = function(_, u) return u == "target" or u == "nameplate1" end
UnitIsUnit = function(u1, u2) return u1 == u2 or (S.combat and SECRET or false) end
UnitIsPlayer = function(u) return u == "player" end
UnitHealthMax = function() return 1345 end
UnitHealth = function() return SECRET end
UnitGUID = function(u) if u == "player" then return "Player-1234-0ABCDEF0" end if u == "target" then return "Creature-0-1-2-3-3100-0000AAAA" end return SECRET end
C_UnitAuras.GetAuraSlots = function() if S.combat then error("Auras cannot be accessed when secret while tainted by 'ForeverDump'") end return nil end
C_UnitAuras.GetAuraDataByIndex = function() if S.combat then error("Auras cannot be accessed when secret while tainted by 'ForeverDump'") end end
local SPELLS = { 905, 8052, 8044, 403, 8160, 1238640 }
local DESC = { [905] = "The caster is surrounded by 3 balls of lightning. Lasts 10 min.",
    [8052] = "Instantly sears the target with fire, causing 38 Fire damage immediately and 32 Fire damage over 12 sec.",
    [8044] = "Instantly shocks the target with concussive force, causing 35 to 38 Nature damage.",
    [403] = "Casts a bolt of lightning at the target for 15 to 17 Nature damage.",
    [8160] = "Summons a Strength of Earth Totem with 5 health at the feet of the caster for 2 min.",
    [1238640] = "Turns the Shaman into a Ghost Wolf, increasing speed by 40%." }
C_Spell.GetSpellDescription = function(id) if S.combat then return SECRET end return DESC[id] or "Does something." end
C_Spell.GetSpellInfo = function(id) return { name = "Spell" .. id, iconID = 1, castTime = id == 403 and 2000 or 0, minRange = 0, maxRange = 30, spellID = id } end
GetSpellBaseCooldown = function(id) return (id == 8052 or id == 8044) and 6000 or 0, 1500 end
C_Spell.IsSpellHelpful = function(id) return id == 905 or id == 1238640 or id == 8160 end
C_Spell.IsSpellHarmful = function(id) return id == 8052 or id == 8044 or id == 403 end

local function tocFiles(dir)
    local files = {}
    for line in io.lines(dir .. "/ForeverDump.toc") do
        if line:match("%.lua%s*$") then files[#files + 1] = line:match("^%s*(.-)%s*$") end
    end
    return files
end
local ns = W.loadAddon(addonDir, tocFiles(addonDir), "ForeverDump")
W.fire("ADDON_LOADED", "ForeverDump")
W.fire("PLAYER_LOGIN")
W.fire("PLAYER_ENTERING_WORLD", true, false)
ns.config.logs.fullDump = false
ns.config.logs.autoReload = false
ns.config.probe.spells = SPELLS
if ns.config.knowledge then ns.config.knowledge.maxSpells = 20 end
-- spell list for the knowledge pass
if ns.Knowledge then ns.Knowledge.SpellList = function() return SPELLS end end
-- C_Timer.After with real delays (the mock runs every timer on the next tick, which would make the 5 s perf sampler
-- run every frame here)
local delayed = {}
C_Timer.After = function(sec, fn) delayed[#delayed + 1] = { at = S.time + (tonumber(sec) or 0), fn = fn } end
local function runDelayed()
    local due, keep = {}, {}
    for _, d in ipairs(delayed) do if d.at <= S.time then due[#due + 1] = d else keep[#keep + 1] = d end end
    delayed = keep
    table.sort(due, function(x, y) return x.at < y.at end)
    for _, d in ipairs(due) do d.fn() end
end
W.slash("logs on")
for _ = 1, 60 do S.time = S.time + 0.05 runDelayed() W.tick(1) end

-- timing helpers: only ForeverDump's handlers
local clock = os.clock
local evMs, evN, frMs, frN = 0, 0, 0, 0
local function handlersFor(event)
    local list = {}
    for _, f in ipairs(S.frames) do
        if (f.__all or (f.__events and f.__events[event])) and f.__scripts and f.__scripts.OnEvent then list[#list + 1] = f end
    end
    return list
end
local hcache, hcacheGen = {}, 0
local function fire(event, ...)
    local list = hcache[event]
    if not list or hcacheGen ~= #S.frames then hcache = {} hcacheGen = #S.frames list = handlersFor(event) hcache[event] = list end
    local t0 = clock()
    for i = 1, #list do local f = list[i] if f.__events and (f.__events[event] or f.__all) then f.__scripts.OnEvent(f, event, ...) end end
    evMs = evMs + (clock() - t0) * 1000
    evN = evN + 1
end
local function shown(f)
    while f do if f.__shown == false then return false end f = rawget(f, "__parent") end
    return true
end
local function activeOnUpdates()
    local n, names = 0, {}
    for f, fn in pairs(S.onUpdate) do
        if f.__scripts and f.__scripts.OnUpdate == fn and shown(f) then n = n + 1 names[#names + 1] = tostring(rawget(f, "__name") or "?") end
    end
    return n, names
end
local function frame(dt)
    S.time = S.time + dt
    local t0 = clock()
    for f, fn in pairs(S.onUpdate) do
        if f.__scripts and f.__scripts.OnUpdate == fn then
            if shown(f) then fn(f, dt) end   -- the real client runs OnUpdate only for shown frames
        else S.onUpdate[f] = nil end
    end
    local timers = S.timers
    S.timers = {}
    for _, fn in ipairs(timers) do fn() end
    runDelayed()
    for _, t in ipairs(tickers) do
        if not t.cancelled and S.time >= t.next then t.next = t.next + t.sec t.fn() end
    end
    frMs = frMs + (clock() - t0) * 1000
    frN = frN + 1
end

-- combat
S.combat = true
fire("PLAYER_REGEN_DISABLED")
fire("ADDON_RESTRICTION_STATE_CHANGED", 0, 2)
for _ = 1, 120 do frame(1 / opts.fps) end
local WIN = opts.win or 10
local marks = {}
if opts.marks then
    for m in opts.marks:gmatch("%d+") do marks[tonumber(m)] = true opts.casts = math.max(tonumber(m), opts.casts) end
else
    for _, m in ipairs({ 25, 50, 100 }) do if m <= opts.casts then marks[m] = true end end
    marks[opts.casts] = true
end
local results, win = {}, {}
local aborted
local function resetWin() evMs, evN, frMs, frN = 0, 0, 0, 0 win.t0 = S.time end
local function overCap() return os.time() - wall0 >= opts.cap end
local function castEvents(n)
    local sid = SPELLS[(n - 1) % #SPELLS + 1]
    fire("UNIT_SPELLCAST_SUCCEEDED", "player", "Cast-" .. n, sid)
    fire("UNIT_AURA", "target", { isFullUpdate = SECRET, addedAuras = SECRET })
    fire("UNIT_AURA", "player", { isFullUpdate = SECRET, updatedAuraInstanceIDs = SECRET })
    for _ = 1, 3 do fire("UNIT_HEALTH", "target") fire("UNIT_POWER_FREQUENT", "player", "MANA") end
    fire("SPELL_UPDATE_COOLDOWN")
end
local function mark(label, n)
    local simS = math.max(S.time - win.t0, 1e-6)
    local tot = evMs + frMs
    results[#results + 1] = { label = label, casts = n, perEventMs = evMs / math.max(evN, 1), perFrameMs = frMs / math.max(frN, 1),
        msPerSec = tot / simS, impactPct = tot / simS / 10, events = evN, frames = frN,
        predictions = ns.Inference.hs and #ns.Inference.hs.predictions or 0, wall = os.time() - wall0 }
    io.stdout:write(string.format("  checkpoint %-6s casts=%-5d %.4f ms/event %.4f ms/frame  (%ds wall)\n", label, n,
        results[#results].perEventMs, results[#results].perFrameMs, os.time() - wall0))
    io.stdout:flush()
end
resetWin()
local n = 0
while n < opts.casts do
    n = n + 1
    if marks[n + WIN - 1] or n == 1 then resetWin() end
    castEvents(n)
    for _ = 1, math.floor(1.5 * opts.fps + 0.5) do frame(1 / opts.fps) end
    if marks[n] then mark(tostring(n), n) end
    if overCap() then aborted = n break end
end
-- aged session: push opts.aged casts through the handlers (events + one Tick per cast, no frames), then measure again
if not aborted and (opts.aged or 0) > 0 then
    local per = math.floor(1.5 * opts.fps + 0.5)
    for _ = 1, opts.aged do
        n = n + 1
        castEvents(n)
        S.time = S.time + 1.5
        frame(1 / opts.fps)
        if overCap() then aborted = n break end
    end
    if not aborted then
        resetWin()
        for _ = 1, WIN do n = n + 1 castEvents(n) for _ = 1, per do frame(1 / opts.fps) end end
        mark("aged", n)
    end
end
if aborted then print(string.format("ABORTED by the %d s cap after %d casts; trend measured so far is reported below", opts.cap, aborted)) end
-- idle: combat ends, no events for 700 s (countdowns run out); the HSM window stays open
S.combat = false
fire("PLAYER_REGEN_ENABLED")
fire("ADDON_RESTRICTION_STATE_CHANGED", 0, 0)
if not aborted then for _ = 1, 7000 do frame(0.1) if overCap() then aborted = aborted or -1 break end end end
local idleN, idleNames = activeOnUpdates()
local hsmShown = ns.HSMUI and ns.HSMUI.IsShown()
W.slash("logs off")
for _ = 1, 30 do S.time = S.time + 0.05 runDelayed() W.tick(1) end
local perf = ForeverDumpLogDB.perf
local psess = perf and perf.sessions and perf.sessions[#perf.sessions]

print(string.format("ForeverDump %s perf bench (%s, %d globals, %d fps)", tostring(ns.VERSION), addonDir, 52517, opts.fps))
print(string.format("%-6s %8s %12s %12s %12s %10s %6s", "point", "casts", "ms/event", "ms/frame", "ms/sim-s", "impact%", "preds"))
for _, r in ipairs(results) do
    print(string.format("%-6s %8d %12.4f %12.4f %12.3f %10.3f %6d", r.label, r.casts, r.perEventMs, r.perFrameMs, r.msPerSec, r.impactPct, r.predictions))
end
print(string.format("wall time %d s (cap %d s)", os.time() - wall0, opts.cap))
print(string.format("idle after 700 s (HSM window %s): %d OnUpdate script(s) running %s", hsmShown and "open" or "closed", idleN,
    idleN > 0 and ("(" .. table.concat(idleNames, ",") .. ")") or ""))
if psess then print(string.format("self-perf monitor: %d handler keys, %d samples", (function() local k = 0 for _ in pairs(psess.handlers) do k = k + 1 end return k end)(), #psess.samples)) end

-- per-handler growth from the self-perf monitor's 15 s windows (first vs last window with calls)
if psess and opts.keys then
    local rows = {}
    for key, h in pairs(psess.handlers) do
        local wins = {}
        for wi, w in pairs(h.w) do wins[#wins + 1] = { wi, w[1], w[2] } end
        table.sort(wins, function(x, y) return x[1] < y[1] end)
        local f, l = wins[1], wins[#wins]
        rows[#rows + 1] = { key = key, ms = h.ms, n = h.n, first = f and f[3] / math.max(f[2], 1) or 0, last = l and l[3] / math.max(l[2], 1) or 0 }
    end
    table.sort(rows, function(x, y) return x.ms > y.ms end)
    for i = 1, math.min(12, #rows) do local r = rows[i]
        print(string.format("  %-36s %7d calls %9.2f ms  first %.4f  last %.4f ms/call", r.key, r.n, r.ms, r.first, r.last)) end
end
if opts.json then
    local f = assert(io.open(opts.json, "w"))
    local parts = {}
    for _, r in ipairs(results) do
        parts[#parts + 1] = string.format('{"point":"%s","casts":%d,"perEventMs":%.6f,"perFrameMs":%.6f,"msPerSec":%.4f,"impactPct":%.4f,"predictions":%d,"wall":%d}',
            r.label, r.casts, r.perEventMs, r.perFrameMs, r.msPerSec, r.impactPct, r.predictions, r.wall)
    end
    f:write(string.format('{"version":"%s","globals":52517,"fps":%d,"results":[%s],"idleOnUpdates":%d,"aborted":%s,"wall":%d,"cap":%d}\n',
        tostring(ns.VERSION), opts.fps, table.concat(parts, ","), idleN, aborted and tostring(aborted) or "null", os.time() - wall0, opts.cap))
    f:close()
end

if opts.assert then
    local fails = 0
    local function check(c, m) if c then print("  ok   " .. m) else fails = fails + 1 print("  FAIL " .. m) end end
    check(not aborted, string.format("finished inside the %d s cap (%d s)", opts.cap, os.time() - wall0))
    local a, z = results[1], results[#results]
    if not (a and z) then print("PERF FAILED (no checkpoint)") os.exit(1) end
    check(z.perEventMs <= 2 * a.perEventMs + 0.05, string.format("O(1) per event: %.4f ms at %d casts vs %.4f ms at %d", z.perEventMs, z.casts, a.perEventMs, a.casts))
    check(z.perFrameMs <= 2 * a.perFrameMs + 0.01, string.format("O(1) per frame: %.4f ms at %d casts vs %.4f ms at %d", z.perFrameMs, z.casts, a.perFrameMs, a.casts))
    for _, r in ipairs(results) do check(r.impactPct < 1, string.format("frame-time impact %.3f%% < 1%% at %d casts", r.impactPct, r.casts)) end
    check(idleN == 0, "no idle OnUpdate (HSM window open, nothing to draw)")
    check(psess and psess.handlers and next(psess.handlers) ~= nil and #psess.samples >= 1, "self-perf monitor recorded handlers + samples")
    print(fails == 0 and "PERF OK" or ("PERF FAILED (" .. fails .. ")"))
    os.exit(fails == 0 and 0 or 1)
end
