# K.T.H. Forever: port notes and diff list (1.0.0-kth-forever.3)

This is a private port of **K.T.H. (Kill The Healer) 1.0.0-kth** to **WoW Forever 1.60.1** (build 70334, toc 16001,
WOW_PROJECT_ID 18). Credits: K.T.H. by Scone, built on H.H.T.D. by John Wellesz. **All Rights Reserved**: the port is for
private use only. Do not redistribute it.

The code, structure, design and four-condition healer logic are K.T.H.'s own. Every change is tagged `[Forever]` in
the source. The full patch against the untouched original is in `FOREVER-PORT.diff` (`original/KTH` holds the original).
Evidence comes from the user's baseline battleground run (original K.T.H. with only the TOC changed, plus the
KTH_ForeverDiag probe) on 2026-10-09 between 23:51 and 00:13 ET. It is backed by the ForeverDump captures of runs
10 to 16.

## What the baseline diag measured (per-value reads, C = clear, S = secret, N = nil; counts per phase)
See `docs/diag-tables.md` for the full per-field × per-phase tables. Summary:
- **Branch**: `MN=false`, `WOWC=true`, project 18, toc 16001, `canaccessvalue` present, `CombatLogGetCurrentEventInfo`
  absent, `C_CombatLogInternal` absent. K.T.H. printed nothing (kthPrints = 0), and 0 Lua errors were logged.
- **Blocked action**: one `ADDON_ACTION_FORBIDDEN`, `AceEvent30Frame:RegisterEvent()`, at 23:51:53 ET. That was the
  second K.T.H. load (a login or reload inside the BG). The cause is `Core.lua:1035`
  `self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")` on the non-MN branch. It is the only event K.T.H. registers on
  that branch that Forever restricts. ForeverDump's EVENT_DENYLIST documents the same popup for CLEU. The Forever mock
  reproduces it: baseline gives 1 restricted registration (CLEU), the port gives 0. The diag's blocked list is reset on
  each load, so the first load at 23:51:29 probably raised the same block.
- **C_PvP.GetScoreInfo**: the table itself is clear in every phase (prep 150/150, ooc 2849, combat 1050, post 60).
  `name` ("First Surname"), `classToken`, `className` and `faction` are clear in every phase. `talentSpec`,
  `roleAssigned`, `guid`, `healingDone`, `damageDone`, `killingBlows`, `deaths`, `honor*` and `rating` are secret in
  prep, ooc and combat, and clear post-match. `race` and `bgRating` are nil.
- **GetBattlefieldScore** layout from raw rows: 1 name, 6 faction (0/1), 7 race, 8 localized class, 9 classToken.
  These are clear in every phase. 2-5, 10-13 and 15-17 are secret in-match and clear post-match. 14 is nil.
  The layout is retail-like.
- **Enemy nameplates** (750 reads, ooc + combat): UnitName clear and **first-name-only** (13 names, none with a space
  or realm). UnitClass is secret (all 3 returns, 750/750). UnitGUID and UnitHealthMax are secret. UnitPowerType,
  UnitCanAttack and UnitIsFriend are clear. **No friendly nameplates** were seen.
- **spellIDs** (UNIT_SPELLCAST_SUCCEEDED): nameplate 20/20 secret, arena 12/12, party 194/194, target 7/7. raid is
  secret except when the raid token is the player. The player's own spellIDs are clear.

## Diff list
| # | Change | Status | Evidence |
|---|---|---|---|
| D1 | TOC `## Interface: 16001`, title suffix "Forever", version `1.0.0-kth-forever.3`, 3 new files | measured | the client only loads toc 16001 (baseline loaded) |
| D2 | `HHTD_C.MN = true` on Forever (Midnight path) | measured | diag MN=false, then classic branch, then CLEU RegisterEvent and ADDON_ACTION_FORBIDDEN popup; no CLEU getter on Forever. The MN branch registers no CLEU (C_CombatLogInternal absent, so only UNIT_SPELLCAST_*) |
| D3 | All K.T.H. `Print`/`Printf` (core + modules, incl. SafePrint banner) go to K.T.H.'s own frame `KTH_ForeverMessageFrame` (`/kthlog`); `/hhtd` opens the options window instead of AceConfigCmd chat output | user rule (no Blizzard chat writes) | code path: the MN branch prints the login banner and slash replies through HHTD:Print, which goes to DEFAULT_CHAT_FRAME. Mock: 0 Blizzard chat lines, all output on the own frame |
| D4 | Order `canaccessvalue(x)` before any truth test of scoreboard fields (talentSpec, roleAssigned, faction, guid), the spellcast spellID/guid/name and canAttack | measured secrecy; the change itself is semantics-preserving | diag: these fields are secret in-match and nameplate spellIDs are secret. No behaviour change when values are clear |
| D5 | Class for an enemy plate from the scoreboard roster (first name + side, duplicate first names never joined); `MN_HealersByName` keyed by the first word when unique | measured | enemy UnitClass S 750/750; plate names first-name-only; GetScoreInfo name/classToken/faction clear in every phase |
| D6 | Scoreboard Method 3: healingDone ≥ damageDone (>0) means healer | measured (post-match only) | healingDone/damageDone clear only post-match (60/60). The WOWC spec→role table is empty and roleAssigned is secret in-match |
| D7 | Heal evidence (cast + same-frame UNIT_COMBAT HEAL on a teammate) confirms a specific player and stands in for the SPELL check; it registers through K.T.H.'s RegisterHealer | measured need, scored | spellIDs secret (nameplate 20/20). Replay: friendly 6/9 healers, 50% precision; enemy 0/8 (enemy casts are almost never delivered: 3 to 9 per BG) |
| D8 | Treat PRIEST/DRUID as ambiguous (DPS also on mana) | measured, **not applied** | DPS priests and caster DPS druids are MANA-only in runs 10-16. But applying it drops enemy plate recall from 6/7 to 0/7. K.T.H.'s original rule is kept |
| D5b | (forever.3) Exact join: the plate's `UnitName` 2nd return ("realm") is the scoreboard surname, so the key is `name.." "..realm` + side; the first-name join with its duplicate guard is only the fallback when no realm is returned. Evidence records are keyed the same way | measured | ForeverDump runs 17+18: name-realm == scoreboard "First Surname" 59/59 (runs 16-18 by the FD executor: 45/45); realm clear (C) on nameplate/mouseover/target/raid hostile-player. Run 16 had two "Johnny" (Snowden/Morningwind) that the first-name join could not use. `bgdiag3/realm_surname_check.txt` |
| F1 | (forever.3) `AceGUIWidget-CheckBox.lua`: `local SetDesaturation = SetDesaturation or <Texture:SetDesaturated shim>` | measured | user error `CheckBox.lua:130: attempt to call a nil value` from /kthg; `SetDesaturation` absent from ForeverDump's static global list (10970 names), `Texture:SetDesaturated` present. All other AceGUI widgets + AceConfigDialog scanned (tests/api_scan_test.py, mock strictness): no other missing function that is not already guarded |
| F3 | (forever.3) Mouse-over / target alerts: `HHTD:TestUnit` resolves an enemy whose GUID is secret by its exact name (D5b) to K.T.H.'s registry record, or, when the nameplate rule marks it, to a record for that unit; then K.T.H.'s own flow continues (HHTD_HEALER_MOUSE_OVER / HHTD_TARGET_LOCKED, Announcer sounds). UnitIsDead/UnitIsUnit truth tests made secret-safe. Announcer: class colour from clear UnitClass, else roster class, else red (UnitClass secret would error in GetClassHexColor); UnitSex secret-safe | measured | ForeverDump runs 16-18: mouseover/target hostile-player UnitGUID = S, UnitClass = S, UnitName (both returns), UnitCanAttack, UnitIsDeadOrGhost, UnitIsPlayer = C. forever.2 replays: 0/337 healer hovers alerted (the user's report); forever.3: 337/337 |
| F4 | (forever.3) `/kthsound`: plays K.T.H.'s 5 alert sounds 2 s apart and writes each `willPlay` to K.T.H.'s frame | diagnostic, no behaviour change | PlaySound/PlaySoundFile exist on Forever (static list); the kit IDs 8959/8174/8960 and file IDs 567458/567482 are not in the static data: **unmeasured**, this measures them |
| F5 | (forever.3) New BG/arena: clear `MN_HealersByName/ByGUID/ByClassSpec` | code-proven | K.T.H. never clears them; with D6 the previous BG's post-match healers would mark every enemy of their classes (CLASS+SCORE) in the next BG |
| F6 | (forever.3) Plate verdict log: in an active zone, every 2 s, each enemy plate's verdict when it changes `{t, who, v, pwr, cls, icon, tok}` into `HHTD_SavedVariables.global.ForeverPlateLog` (last 800); in arenas also one readability record per arenaN token | diagnostic, no behaviour change | the forever.2 diag had no per-plate verdict, so the in-game flicker could only be analysed by replay |
| F7 | (forever.3) Zones: roster join (D5/D5b) and D6 only in battlegrounds; heal evidence (D7) active in BG, arena, open world, and party/raid/scenario when K.T.H.'s own `Pve` option is on; roster/evidence reset when kind+instance id changes. Elsewhere K.T.H.'s original paths run unchanged (UnitClass when clear) | user directive + measured scope | the only measured scoreboard is the BG one; arena `faction` is the team index on retail and no arena/world capture exists, so arena/world enemy UnitClass readability is **unmeasured** (both models tested, R7) |
| T | `HHTD.MN_CheckUnitIsHealer = CheckUnitIsHealer`, `HHTD.MN_PlateIconShown` | test/diag hooks, no behaviour | used by tests/replay_score.lua and F6 |

### forever.3 variants scored and dropped
- **F2 druid form veto** (once a druid's plate shows RAGE/ENERGY, stop CLASS+PWR marks unless heal evidence): refuted. It
  loses the only enemy healer of run 13 (resto druid Korsica) and does not remove the run-18 flicker (the first mark
  happens in caster form before any form is seen). `tests/results/variants/*.port3veto.json`.

### Intermittent nameplate icon: root cause (forever.3)
- Icon machinery is not the cause: with K.T.H.'s real 1 s ticker running in the replay, icon state equals the verdict in
  all 7 runs (plate log healerNoIcon 0, iconNoHealer 0, R5). Plate recycling, parenting, the duplicate guard and secret
  bail-outs do not hide icons (no CHECK/TICKER errors; index ≤ 10).
- The verdict itself flips: run 18 (the forever.2 BG): Joff Wild (feral druid) 25 flips and Tatusera Reloca (feral druid)
  19 flips, MANA in caster form (marked) vs RAGE/ENERGY in forms (unmarked). That is K.T.H.'s own CLASS+PWR rule for
  druids. The three enemy priest healers (Ank, Karen, Randess) stay marked while their plate exists (Ank's 2 flips are a
  replay attribution artefact: a RAGE update on a priest). Paladin Torvian is never marked (ambiguous class, no
  confirmation in-match). Icons also only exist while the plate exists (range/visibility).
- So: "sometimes shows" = feral druids flickering by design, plus plates coming and going. Kept as K.T.H. designed it
  (F2 refuted). The F6 log measures it in game next time.

### Earlier draft diffs, now dropped (refuted, or Forever behaves like retail, so original code kept)
- GetBattlefieldScore "classic layout" (faction 6 / rank 7 / class 9-10): **refuted**. The layout is retail-like, and the
  fallback is unreachable because the GetScoreInfo table is clear. K.T.H. reads faction at position 7 (race) there; that
  is an original K.T.H. bug, identical on retail, and was left alone.
- GetScoreInfo "secret table" guard: **refuted**. The table is clear in all phases (the old claim was a ForeverDump
  probe flaw).
- UnitHealthMax('player') guard in UpdateHealThresholds: **refuted**. The 50 s timer ran through the whole BG with
  0 errors.
- MAX_CLASSES loop bound: **refuted**. Loading had 0 errors.
- AddToBlizOptions pcall: **not needed**. Forever ships the Settings UI (SettingsInbound in ForeverDump globals).
  The original code is kept, but this path is untested in-game because K.T.H. skips it when MN=false.
- TestUnit GUID/name fallback and Announcer UnitClass guards: dropped. Retail Midnight BG GUIDs are secret too, so this
  is retail behaviour and the original is kept.
- `MN_MyTeam` via GetBattlefieldArenaFaction: dropped. faction (0/1) is clear, and K.T.H.'s PLAYER_FACTION rule matches
  it (player Horde = faction 0 in the diag).
- RaidWarningFrame / UIErrorsFrame rerouting: dropped. These are not chat frames, and the original is kept.
  `/hhtdp` (ChatPlacard → SendChatMessage) stays as in the original. It only runs when you type it, or when the
  opt-in "ChatWarning" option is on (default off).

## Replay scores (tests/results/SCORES.md, forever.3 harness)
Seven ForeverDump BG captures (runs 10, 11, 12, 13, 16, 17, 18) replayed through each variant loaded in the Forever
mock: orig = original K.T.H. (Midnight path), port2 = forever.2, port3 = forever.3. Truth: heal on others ≥ 30% of
(damage + heal on others) and ≥ 5 direct heals on others (combat log). Plates in these captures are enemy-only.
forever.3 harness changes: UnitName returns the surname as realm (D5b) only for real boards; K.T.H.'s C_Timer tickers
really run (the 1 s plate scan); primary power types only; every enemy plate is hovered each sweep (mouse-over alert) and
clicked once alerted (target lock, regress fixture); verdict flips and the F6 plate log are recorded.
**Data note:** runs 10-16 were exported with a placeholder surname ("Synth") in place of the real scoreboard surname, so
D5b cannot be scored there (first-name join only). Only runs 17 and 18 carry the real board. The healer truth (from the combat
log) is unaffected.

| variant | run | plate marks | plate TP | enemy healers seen on plates | evidence claims | claim TP | truth healers | mouse-over alerts / healer-verdict hovers (not target) | verdict flips healer/non-healer | plate log healerNoIcon/iconNoHealer |
|---|---|---|---|---|---|---|---|---|---|---|
| orig | run10 (synth surname) | 0 | 0 | 1 | 0 | 0 | 4 | 0/0 | 0/0 | 0/0 |
| orig | run11 (synth surname) | 0 | 0 | 0 | 0 | 0 | 2 | 0/0 | 0/0 | 0/0 |
| orig | run12 (synth surname) | 0 | 0 | 2 | 0 | 0 | 3 | 0/0 | 0/0 | 0/0 |
| orig | run13 (synth surname) | 0 | 0 | 1 | 0 | 0 | 1 | 0/0 | 0/0 | 0/0 |
| orig | run16 (synth surname) | 0 | 0 | 3 | 0 | 0 | 7 | 0/0 | 0/0 | 0/0 |
| orig | run17 (real board) | 0 | 0 | 3 | 0 | 0 | 4 | 0/0 | 0/0 | 0/0 |
| orig | run18 (real board) | 0 | 0 | 3 | 0 | 0 | 6 | 0/0 | 0/0 | 0/0 |
| port2 | run10 (synth surname) | 5 | 1 | 1 | 3 | 2 | 4 | 0/61 | 0/50 | 0/0 |
| port2 | run11 (synth surname) | 1 | 0 | 0 | 4 | 1 | 2 | 0/17 | 0/0 | 0/0 |
| port2 | run12 (synth surname) | 2 | 1 | 2 | 0 | 0 | 3 | 0/29 | 0/0 | 0/0 |
| port2 | run13 (synth surname) | 1 | 1 | 1 | 2 | 0 | 1 | 0/6 | 2/0 | 0/0 |
| port2 | run16 (synth surname) | 3 | 3 | 3 | 3 | 3 | 7 | 0/60 | 1/0 | 0/0 |
| port2 | run17 (real board) | 2 | 2 | 3 | 4 | 1 | 4 | 0/44 | 0/0 | 0/0 |
| port2 | run18 (real board) | 5 | 3 | 3 | 3 | 3 | 6 | 0/120 | 2/44 | 0/0 |
| port3 | run10 (synth surname) | 5 | 1 | 1 | 3 | 2 | 4 | 61/61 | 0/50 | 0/0 |
| port3 | run11 (synth surname) | 1 | 0 | 0 | 4 | 1 | 2 | 17/17 | 0/0 | 0/0 |
| port3 | run12 (synth surname) | 2 | 1 | 2 | 0 | 0 | 3 | 29/29 | 0/0 | 0/0 |
| port3 | run13 (synth surname) | 1 | 1 | 1 | 2 | 0 | 1 | 6/6 | 2/0 | 0/0 |
| port3 | run16 (synth surname) | 3 | 3 | 3 | 3 | 3 | 7 | 60/60 | 1/0 | 0/0 |
| port3 | run17 (real board) | 2 | 2 | 3 | 4 | 1 | 4 | 44/44 | 0/0 | 0/0 |
| port3 | run18 (real board) | 5 | 3 | 3 | 3 | 3 | 6 | 120/120 | 2/44 | 0/0 |

| variant | plate precision | plate recall (enemy healers seen) | plate TTI median s | claim precision | claim recall all | claim recall F | claim recall E | claim TTI median s | mouse-over alert rate |
|---|---|---|---|---|---|---|---|---|---|
| orig | 0/0 | 0/13 = 0% | None | 0/0 | 0/27 = 0% | 0/13 = 0% | 0/14 = 0% | None | 0/0 |
| port2 | 11/19 = 58% | 11/13 = 85% | 0.0 | 10/19 = 53% | 10/27 = 37% | 10/13 = 77% | 0/14 = 0% | 371.6 | 0/337 = 0% |
| port3 | 11/19 = 58% | 11/13 = 85% | 0.0 | 10/19 = 53% | 10/27 = 37% | 10/13 = 77% | 0/14 = 0% | 371.6 | 337/337 = 100% |

