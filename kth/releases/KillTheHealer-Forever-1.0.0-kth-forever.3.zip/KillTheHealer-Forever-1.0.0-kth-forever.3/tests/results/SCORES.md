| variant | run | plate marks | plate TP | enemy healers seen on plates | evidence claims | claim TP | truth healers | mouse-over alerts / healer-verdict hovers (not target) | verdict flips healer/non-healer | plate log healerNoIcon/iconNoHealer |
|---|---|---|---|---|---|---|---|---|---|---|
| orig | run10 (synth surname) | 0 | 0 | 1 | 0 | 0 | 4 | 0/0 | 0/0 | 0/0 |
| orig | run11 (synth surname) | 0 | 0 | 0 | 0 | 0 | 2 | 0/0 | 0/0 | 0/0 |
| orig | run12 (synth surname) | 0 | 0 | 2 | 0 | 0 | 3 | 0/0 | 0/0 | 0/0 |
| orig | run13 (synth surname) | 0 | 0 | 1 | 0 | 0 | 1 | 0/0 | 0/0 | 0/0 |
| orig | run16 (synth surname) | 0 | 0 | 3 | 0 | 0 | 7 | 0/0 | 0/0 | 0/0 |
| orig | run17 (real board) | 0 | 0 | 3 | 0 | 0 | 4 | 0/0 | 0/0 | 0/0 |
| orig | run18 (real board) | 0 | 0 | 3 | 0 | 0 | 6 | 0/0 | 0/0 | 0/0 |
| port2 | run10 (synth surname) | 5 | 1 | 1 | 3 | 2 | 4 | 0/61 | 0/50 | 0/0 |
| port2 | run11 (synth surname) | 1 | 0 | 0 | 4 | 1 | 2 | 0/17 | 0/0 | 0/0 |
| port2 | run12 (synth surname) | 2 | 1 | 2 | 0 | 0 | 3 | 0/29 | 0/0 | 0/0 |
| port2 | run13 (synth surname) | 1 | 1 | 1 | 2 | 0 | 1 | 0/6 | 2/0 | 0/0 |
| port2 | run16 (synth surname) | 3 | 3 | 3 | 3 | 3 | 7 | 0/60 | 1/0 | 0/0 |
| port2 | run17 (real board) | 2 | 2 | 3 | 4 | 1 | 4 | 0/44 | 0/0 | 0/0 |
| port2 | run18 (real board) | 5 | 3 | 3 | 3 | 3 | 6 | 0/120 | 2/44 | 0/0 |
| port3 | run10 (synth surname) | 5 | 1 | 1 | 3 | 2 | 4 | 61/61 | 0/50 | 0/0 |
| port3 | run11 (synth surname) | 1 | 0 | 0 | 4 | 1 | 2 | 17/17 | 0/0 | 0/0 |
| port3 | run12 (synth surname) | 2 | 1 | 2 | 0 | 0 | 3 | 29/29 | 0/0 | 0/0 |
| port3 | run13 (synth surname) | 1 | 1 | 1 | 2 | 0 | 1 | 6/6 | 2/0 | 0/0 |
| port3 | run16 (synth surname) | 3 | 3 | 3 | 3 | 3 | 7 | 60/60 | 1/0 | 0/0 |
| port3 | run17 (real board) | 2 | 2 | 3 | 4 | 1 | 4 | 44/44 | 0/0 | 0/0 |
| port3 | run18 (real board) | 5 | 3 | 3 | 3 | 3 | 6 | 120/120 | 2/44 | 0/0 |

| variant | plate precision | plate recall (enemy healers seen) | plate TTI median s | claim precision | claim recall all | claim recall F | claim recall E | claim TTI median s | mouse-over alert rate |
|---|---|---|---|---|---|---|---|---|---|
| orig | 0/0 | 0/13 = 0% | None | 0/0 | 0/27 = 0% | 0/13 = 0% | 0/14 = 0% | None | 0/0 |
| port2 | 11/19 = 58% | 11/13 = 85% | 0.0 | 10/19 = 53% | 10/27 = 37% | 10/13 = 77% | 0/14 = 0% | 371.6 | 0/337 = 0% |
| port3 | 11/19 = 58% | 11/13 = 85% | 0.0 | 10/19 = 53% | 10/27 = 37% | 10/13 = 77% | 0/14 = 0% | 371.6 | 337/337 = 100% |
