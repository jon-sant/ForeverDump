#!/bin/sh
# forever.3 regressions. Exit 1 on any failure.
set -e
cd /workspace/kth
fail=0
# R1 (F1): /kthg, /hhtd, /hhtdg open the AceConfig dialogs with no Lua error under Forever API strictness
out=$(lua5.1 tests/load_smoke.lua port/KTH/KTH.toc 2>&1 || true)
if echo "$out" | grep -q "^errors:.0$" && echo "$out" | grep -q "^blizzChat lines:.0$" && echo "$out" | grep -q "^options UIs opened:.3$"; then echo "R1 ok: /kthg /hhtd /hhtdg open, 0 errors, 0 Blizzard chat lines"; else echo "R1 FAIL"; echo "$out" | tail -8; fail=1; fi
# R2 (D5b): duplicate first names joined exactly by name+realm(surname)
KTH_TARGET_TEST=1 lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/dupfirst_stream.lua /tmp/regress_dup.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/regress_dup.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
ok = set(m)=={'1'} and not d['errors']
print('R2', 'ok' if ok else 'FAIL', 'marks', sorted(m), 'errors', len(d['errors']))
mo=d['mouseover']; ok2 = mo['alerted']>0 and mo['alertedNoVerdict']==0 and mo['missed']==0 and mo.get('targetLocked',0)==mo['alerted']
print('R3', 'ok' if ok2 else 'FAIL', 'mouse-over on the healer plays the announcer sound, clicking it plays the target-lock sound:', mo)
sys.exit(0 if ok and ok2 else 1)
PY
# R4 (F3): on every real replay the mouse-over alert fires for every healer-verdict hover (not on target);
# R5 (F2/F6): icon state == verdict in the plate log
for r in tests/replay/*-bg.lua; do
  lua5.1 tests/replay_score.lua port/KTH/KTH.toc $r /tmp/regress_r.json port >/dev/null
  python3 - "$r" <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/regress_r.json')); mo=d['mouseover']; pl=d['platelog']
ok = mo['missed']==0 and mo['alertedNoVerdict']==0 and pl['healerNoIcon']==0 and pl['iconNoHealer']==0 and not d['errors']
print('R4/R5', 'ok' if ok else 'FAIL', sys.argv[1].split('/')[-1], 'mo', mo, 'platelog', pl, 'errors', len(d['errors']))
sys.exit(0 if ok else 1)
PY
done
# R7 (F7): non-BG zones. Same real event stream (run18) replayed as arena / open world / party, enemy UnitClass
# secret (as measured in BGs) and clear (world/arena readability not captured yet): no Lua error anywhere, no
# scoreboard join outside BGs, K.T.H.'s own CLASS+PWR path when the class is clear, evidence engine off in party when
# K.T.H.'s Pve option is off.
for z in arena none party; do for c in secret clear; do
  KTH_ZONE=$z KTH_ENEMY_CLASS=$c lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/replay/2026-10-10-run18-bg.lua /tmp/r7.json port >/dev/null
  python3 - $z $c <<'PY' || fail=1
import json,sys
z,c=sys.argv[1:3]; d=json.load(open('/tmp/r7.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
meth={x['method'] for x in m.values()}
ok = not d['errors'] and d['rosterSize']==0 and (len(m)>0 and meth<={'CLASS+PWR','HEAL'} if c=='clear' else meth<={'HEAL'}) and d['mouseover']['missed']==0
print('R7', 'ok' if ok else 'FAIL', z, 'enemyClass='+c, 'marks', len(m), sorted(meth), 'roster', d['rosterSize'], 'errors', len(d['errors']), 'mo', d['mouseover'])
sys.exit(0 if ok else 1)
PY
done; done
KTH_ZONE=party KTH_PVE=off lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/replay/2026-10-10-run18-bg.lua /tmp/r7.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r7.json')); n=len(d['recs']) if isinstance(d['recs'],dict) else 0
print('R7', 'ok' if n==0 and not d['errors'] else 'FAIL', 'party with Pve off: evidence records', n)
sys.exit(0 if n==0 and not d['errors'] else 1)
PY
# R6 (F1 static): every global function the addon calls exists on Forever or is guarded
python3 tests/api_scan_test.py || fail=1
exit $fail
