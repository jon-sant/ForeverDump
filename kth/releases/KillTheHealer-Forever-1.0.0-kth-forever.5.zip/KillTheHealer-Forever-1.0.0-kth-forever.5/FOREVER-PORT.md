# K.T.H. Forever: port notes and diff list (1.0.0-kth-forever.5)

This is a private port of **K.T.H. (Kill The Healer) 1.0.0-kth** to **WoW Forever 1.60.1** (build 70334, toc 16001,
WOW_PROJECT_ID 18). Credits: K.T.H. by Scone, built on H.H.T.D. by John Wellesz. **All Rights Reserved**: the port is for
private use only. Do not redistribute it.

The code, structure, design and four-condition healer logic are K.T.H.'s own. Every change is tagged `[Forever]` in
the source. The full patch against the untouched original is in `FOREVER-PORT.diff` (`original/KTH` holds the original).
Evidence comes from the user's baseline battleground run (original K.T.H. with only the TOC changed, plus the
KTH_ForeverDiag probe) on 2026-10-09 between 23:51 and 00:13 ET. It is backed by the ForeverDump captures of runs
10 to 16.

## What the baseline diag measured (per-value reads, C = clear, S = secret, N = nil; counts per phase)
See `docs/diag-tables.md` for the full per-field × per-phase tables. Summary:
- **Branch**: `MN=false`, `WOWC=true`, project 18, toc 16001, `canaccessvalue` present, `CombatLogGetCurrentEventInfo`
  absent, `C_CombatLogInternal` absent. K.T.H. printed nothing (kthPrints = 0), and 0 Lua errors were logged.
- **Blocked action**: one `ADDON_ACTION_FORBIDDEN`, `AceEvent30Frame:RegisterEvent()`, at 23:51:53 ET. That was the
  second K.T.H. load (a login or reload inside the BG). The cause is `Core.lua:1035`
  `self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")` on the non-MN branch. It is the only event K.T.H. registers on
  that branch that Forever restricts. ForeverDump's EVENT_DENYLIST documents the same popup for CLEU. The Forever mock
  reproduces it: baseline gives 1 restricted registration (CLEU), the port gives 0. The diag's blocked list is reset on
  each load, so the first load at 23:51:29 probably raised the same block.
- **C_PvP.GetScoreInfo**: the table itself is clear in every phase (prep 150/150, ooc 2849, combat 1050, post 60).
  `name` ("First Surname"), `classToken`, `className` and `faction` are clear in every phase. `talentSpec`,
  `roleAssigned`, `guid`, `healingDone`, `damageDone`, `killingBlows`, `deaths`, `honor*` and `rating` are secret in
  prep, ooc and combat, and clear post-match. `race` and `bgRating` are nil.
- **GetBattlefieldScore** layout from raw rows: 1 name, 6 faction (0/1), 7 race, 8 localized class, 9 classToken.
  These are clear in every phase. 2-5, 10-13 and 15-17 are secret in-match and clear post-match. 14 is nil.
  The layout is retail-like.
- **Enemy nameplates** (750 reads, ooc + combat): UnitName clear and **first-name-only** (13 names, none with a space
  or realm). UnitClass is secret (all 3 returns, 750/750). UnitGUID and UnitHealthMax are secret. UnitPowerType,
  UnitCanAttack and UnitIsFriend are clear. **No friendly nameplates** were seen.
- **spellIDs** (UNIT_SPELLCAST_SUCCEEDED): nameplate 20/20 secret, arena 12/12, party 194/194, target 7/7. raid is
  secret except when the raid token is the player. The player's own spellIDs are clear.

## Diff list
| # | Change | Status | Evidence |
|---|---|---|---|
| D1 | TOC `## Interface: 16001`, title suffix "Forever", version `1.0.0-kth-forever.5`, 3 new files | measured | the client only loads toc 16001 (baseline loaded) |
| D2 | `HHTD_C.MN = true` on Forever (Midnight path) | measured | diag MN=false, then classic branch, then CLEU RegisterEvent and ADDON_ACTION_FORBIDDEN popup; no CLEU getter on Forever. The MN branch registers no CLEU (C_CombatLogInternal absent, so only UNIT_SPELLCAST_*) |
| D3 | All K.T.H. `Print`/`Printf` (core + modules, incl. SafePrint banner) go to K.T.H.'s own frame `KTH_ForeverMessageFrame` (`/kthlog`); `/hhtd` opens the options window instead of AceConfigCmd chat output | user rule (no Blizzard chat writes) | code path: the MN branch prints the login banner and slash replies through HHTD:Print, which goes to DEFAULT_CHAT_FRAME. Mock: 0 Blizzard chat lines, all output on the own frame |
| D4 | Order `canaccessvalue(x)` before any truth test of scoreboard fields (talentSpec, roleAssigned, faction, guid), the spellcast spellID/guid/name and canAttack | measured secrecy; the change itself is semantics-preserving | diag: these fields are secret in-match and nameplate spellIDs are secret. No behaviour change when values are clear |
| D5 | Class for an enemy plate from the scoreboard roster (first name + side, duplicate first names never joined); `MN_HealersByName` keyed by the first word when unique | measured | enemy UnitClass S 750/750; plate names first-name-only; GetScoreInfo name/classToken/faction clear in every phase |
| D6 | Scoreboard Method 3: healingDone ≥ damageDone (>0) means healer | measured (post-match only) | healingDone/damageDone clear only post-match (60/60). The WOWC spec→role table is empty and roleAssigned is secret in-match |
| D7 | Heal evidence (cast + same-frame UNIT_COMBAT HEAL on a teammate) confirms a specific player and stands in for the SPELL check; it registers through K.T.H.'s RegisterHealer | measured need, scored | spellIDs secret (nameplate 20/20). Replay: friendly 6/9 healers, 50% precision; enemy 0/8 (enemy casts are almost never delivered: 3 to 9 per BG) |
| D8 | Treat PRIEST/DRUID as ambiguous (DPS also on mana) | measured, **superseded by D9 (forever.5)** | DPS priests and caster DPS druids are MANA-only in runs 10-16. But applying it drops enemy plate recall from 6/7 to 0/7. K.T.H.'s original rule is kept |
| D5b | (forever.3) Exact join: the plate's `UnitName` 2nd return ("realm") is the scoreboard surname, so the key is `name.." "..realm` + side; the first-name join with its duplicate guard is only the fallback when no realm is returned. Evidence records are keyed the same way | measured | ForeverDump runs 17+18: name-realm == scoreboard "First Surname" 59/59 (runs 16-18 by the FD executor: 45/45); realm clear (C) on nameplate/mouseover/target/raid hostile-player. Run 16 had two "Johnny" (Snowden/Morningwind) that the first-name join could not use. `bgdiag3/realm_surname_check.txt` |
| D9 | (forever.5, user decision) Healer verdict = healing output, not class + mana. On Forever an enemy (and friendly) plate is marked only when that player's observed output is mostly healing (≥ 60%) or their healing is ≥ 6× the group median; class is only a can-heal prerequisite. CLASS+PWR, CLASS+SCORE and the single-spell SPELL mark are not used on Forever (a clear healer-only spellID is one heal action). Sources: frame-joined heal/damage links (D7) and C_DamageMeter Current-session HealingDone vs DamageDone, read on PLAYER_REGEN_ENABLED. Hysteresis: on at 60%, off only below 35% with ≥ 6 links or ≥ 2000 meter output; a decisive meter vote outranks link counts | user decision + measured + tuned on real runs 16-18 | user: "heal and feral druids both have mana. having mana does not make one a healer ... balance druids have mana too". Meter readability measured in FD runs 16-18 (table below). Replay: plate precision 5/5, 0 DPS druids marked, 0 icon on→off flips (forever.3: 8/10, 2/2 DPS druids marked, 23 flips on non-healers) |
| F1 | (forever.3) `AceGUIWidget-CheckBox.lua`: `local SetDesaturation = SetDesaturation or <Texture:SetDesaturated shim>` | measured | user error `CheckBox.lua:130: attempt to call a nil value` from /kthg; `SetDesaturation` absent from ForeverDump's static global list (10970 names), `Texture:SetDesaturated` present. All other AceGUI widgets + AceConfigDialog scanned (tests/api_scan_test.py, mock strictness): no other missing function that is not already guarded |
| F3 | (forever.3) Mouse-over / target alerts: `HHTD:TestUnit` resolves an enemy whose GUID is secret by its exact name (D5b) to K.T.H.'s registry record, or, when the nameplate rule marks it, to a record for that unit; then K.T.H.'s own flow continues (HHTD_HEALER_MOUSE_OVER / HHTD_TARGET_LOCKED, Announcer sounds). UnitIsDead/UnitIsUnit truth tests made secret-safe. Announcer: class colour from clear UnitClass, else roster class, else red (UnitClass secret would error in GetClassHexColor); UnitSex secret-safe | measured | ForeverDump runs 16-18: mouseover/target hostile-player UnitGUID = S, UnitClass = S, UnitName (both returns), UnitCanAttack, UnitIsDeadOrGhost, UnitIsPlayer = C. forever.2 replays (runs 16-18): 0/224 healer hovers alerted (the user's report); forever.3: 224/224 |
| F4 | (forever.3) `/kthsound`: plays K.T.H.'s 5 alert sounds 2 s apart and writes each `willPlay` to K.T.H.'s frame | diagnostic, no behaviour change | PlaySound/PlaySoundFile exist on Forever (static list); the kit IDs 8959/8174/8960 and file IDs 567458/567482 are not in the static data: **unmeasured**, this measures them |
| F5 | (forever.3) New BG/arena: clear `MN_HealersByName/ByGUID/ByClassSpec` | code-proven | K.T.H. never clears them; with D6 the previous BG's post-match healers would mark every enemy of their classes (CLASS+SCORE) in the next BG |
| F6 | (forever.3) Plate verdict log: in an active zone, every 2 s, each enemy plate's verdict when it changes `{t, who, v, pwr, cls, icon, tok}` into `HHTD_SavedVariables.global.ForeverPlateLog` (last 800); in arenas also one readability record per arenaN token | diagnostic, no behaviour change | the forever.2 diag had no per-plate verdict, so the in-game flicker could only be analysed by replay |
| F7 | (forever.3) Zones: roster join (D5/D5b) and D6 only in battlegrounds; heal evidence (D7) active in BG, arena, open world, and party/raid/scenario when K.T.H.'s own `Pve` option is on; roster/evidence reset when kind+instance id changes. Elsewhere K.T.H.'s original paths run unchanged (UnitClass when clear) | user directive + measured scope | the only measured scoreboard is the BG one; arena `faction` is the team index on retail and no arena/world capture exists, so arena/world enemy UnitClass readability is **unmeasured** (both models tested, R7) |
| T | `HHTD.MN_CheckUnitIsHealer = CheckUnitIsHealer`, `HHTD.MN_PlateIconShown` | test/diag hooks, no behaviour | used by tests/replay_score.lua and F6 |

### forever.3 variants scored and dropped
- **F2 druid form veto** (once a druid's plate shows RAGE/ENERGY, stop CLASS+PWR marks unless heal evidence). In
  forever.3 it was dropped because it lost run 13's enemy resto druid Korsica. **forever.4 re-check on real data only
  (runs 16-18):** run 13 is now out of all scores (board-less). On runs 16-18 the veto keeps the same first marks
  (precision 8/10, recall 8/9, resto druid Invictusap still marked). It cuts the feral-druid flicker in run 18 from
  Joff 25 / Tatusera 19 verdict flips to 1 / 1 (healer-verdict hovers 154 to 106).
  `tests/results/variants/forever4-real/*.druidVeto.json`. The run-13 case is still real in its combat log, but it
  can no longer be replayed with real data. **Not applied: the addon code is unchanged in forever.4. This needs the
  user's decision.** → **Resolved in forever.5 by the user's decision: D9 (healing output) replaces class + mana, so no form rule is needed.**
- **D8 re-check on real data (runs 16-18):** still refuted, enemy plate recall 0/9.

### Intermittent nameplate icon: root cause (forever.3)
- Icon machinery is not the cause: with K.T.H.'s real 1 s ticker running in the replay, icon state equals the verdict in
  all 7 runs (plate log healerNoIcon 0, iconNoHealer 0, R5). Plate recycling, parenting, the duplicate guard and secret
  bail-outs do not hide icons (no CHECK/TICKER errors; index ≤ 10).
- The verdict itself flips: run 18 (the forever.2 BG): Joff Wild (feral druid) 25 flips and Tatusera Reloca (feral druid)
  19 flips, MANA in caster form (marked) vs RAGE/ENERGY in forms (unmarked). That is K.T.H.'s own CLASS+PWR rule for
  druids. The three enemy priest healers (Ank, Karen, Randess) stay marked while their plate exists (Ank's 2 flips are a
  replay attribution artefact: a RAGE update on a priest). Paladin Torvian is never marked (ambiguous class, no
  confirmation in-match). Icons also only exist while the plate exists (range/visibility).
- So: "sometimes shows" = feral druids flickering by design, plus plates coming and going. Kept as K.T.H. designed it
  (F2 refuted). The F6 log measures it in game next time.

### Earlier draft diffs, now dropped (refuted, or Forever behaves like retail, so original code kept)
- GetBattlefieldScore "classic layout" (faction 6 / rank 7 / class 9-10): **refuted**. The layout is retail-like, and the
  fallback is unreachable because the GetScoreInfo table is clear. K.T.H. reads faction at position 7 (race) there; that
  is an original K.T.H. bug, identical on retail, and was left alone.
- GetScoreInfo "secret table" guard: **refuted**. The table is clear in all phases (the old claim was a ForeverDump
  probe flaw).
- UnitHealthMax('player') guard in UpdateHealThresholds: **refuted**. The 50 s timer ran through the whole BG with
  0 errors.
- MAX_CLASSES loop bound: **refuted**. Loading had 0 errors.
- AddToBlizOptions pcall: **not needed**. Forever ships the Settings UI (SettingsInbound in ForeverDump globals).
  The original code is kept, but this path is untested in-game because K.T.H. skips it when MN=false.
- TestUnit GUID/name fallback and Announcer UnitClass guards: dropped. Retail Midnight BG GUIDs are secret too, so this
  is retail behaviour and the original is kept.
- `MN_MyTeam` via GetBattlefieldArenaFaction: dropped. faction (0/1) is clear, and K.T.H.'s PLAYER_FACTION rule matches
  it (player Horde = faction 0 in the diag).
- RaidWarningFrame / UIErrorsFrame rerouting: dropped. These are not chat frames, and the original is kept.
  `/hhtdp` (ChatPlacard → SendChatMessage) stays as in the original. It only runs when you type it, or when the
  opt-in "ChatWarning" option is on (default off).

## forever.5: healing-output verdict (D9)

**User decision** (replaces the druid-form question): "heal and feral druids both have mana. having mana does not make
one a healer. furthermore balance druids have mana too and are not a healer. it's total healing done being
significantly higher than the average or when considering all actions the majority % of actions are healing output
vs dps output."

**What can be read, per source (measured; nothing below is assumed):**

| source | where | friendly | enemy | used |
|---|---|---|---|---|
| D7 frame join: cast + same-frame UNIT_COMBAT HEAL on a teammate / WOUND on an opponent | all zones (F7) | many links | very few (enemy casts reach the client 3-9 times per BG) | yes, action counts |
| C_DamageMeter `GetCombatSessionFromType(Current, HealingDone / DamageDone)` rows | everywhere the meter runs | `name` ("First Surname"), `sourceGUID`, `classFilename`, `totalAmount` clear out of combat | `name`/`sourceGUID` **secret**, `classFilename`, `specIconID` (class icon), `sourceDisplayType` (0/2) and `totalAmount` clear out of combat | yes, amounts; enemy rows joined to the BG scoreboard by class |
| same rows in combat | | `totalAmount`, `name`, `sourceGUID` secret (27/27) | secret | no (read on PLAYER_REGEN_ENABLED, as FD did) |
| scoreboard `healingDone`/`damageDone` | BG | clear post-match only (60/60) | clear post-match only | not for in-match marks (D6 stays post-match) |
| clear spellIDs (healer-only list) | open world / PvE where clear; nameplate spellIDs secret in BGs (20/20) | | | yes, one heal action each |
| target-of-target at heal-cast time | | not captured by any probe so far | | **not implemented** (unmeasured) |
| arena `arenaN` + C_PvP arena info | arena | not captured yet (F6 logs it) | | no new arena logic |

FD field counts (run 18 SV, `field:DamageMeterCombatSource.*`, ooc/combat reads): `totalAmount` 28 clear / 27 secret,
`name` and `sourceGUID` ooc 28 reads of which 13 secret (the enemy rows), combat 27/27 secret, `classFilename` and
`specIconID` always clear. Enemy rows: `sourceDisplayType` 2 (with the enemy `factionGroup`) or 0; friendly rows 1.
Matching the rows to the combat log over the session window (`tools/dm_match.py`): amounts are exact (e.g. run 18
enemy paladin 1377 = Torvian 1377 in the log), and type 0/2 rows are enemies (runs 16-18: 630 type 0/2 rows matched an enemy,
8 a friendly, 4 both; the rest fell outside the approximate session window).

**Rule and thresholds (tuned on real runs 16-18, `tools/dm_rules.py`, truth = combat log):**
- meter, one player (friendly by name; enemy when the class is unique on the enemy scoreboard): healer when heal ≥ 1000
  and (heal share of heal+damage ≥ 60% or heal ≥ 6× the median healing row of the session). Grid: share 0.55-0.75 and
  6×-10× median all give 8 of 9 such players with 0 false; 5× also 0 false; 4× gives 3 false (run 17 friendly DPS
  paladin/druids with heavy self-healing at 4.3-4.9×, share 0.43-0.49). 6× chosen for margin. The one miss is run 16's
  friendly druid Furbreezze (log heals on others 31%, meter share 26-28%): a hybrid, not a healer by the user's
  definition. Note: the meter's HealingDone includes self-healing, which is why the share threshold is 60, not 50.
- meter, several enemies of one class (names secret, rows cannot be told apart): every one of the n players is marked
  only when n rows are ≥ 1000 and ≥ 6× median; class-level "not a healer" when all n did ≥ 2000 damage and none healed
  ≥ 1000. Runs 16-17 (2 priests, both healers): marked; run 18 (3 priests, rows show 2 far above the group and 1 low):
  no mark, as the 2 cannot be told from the 3rd.
- actions (D7 links): healer at ≥ 60% heal links with ≥ 2 links (3 when the class is unknown).
- hysteresis / minimum evidence: unknown (no mark) until a rule fires; a mark is withdrawn only on contrary evidence
  (meter share < 35% with ≥ 2000 output, or < 35% heal links with ≥ 6 links). A decisive meter vote outranks link
  counts (run 17: two friendly DPS with 2-6 coincidental heal links and meter heal share 9-18% were claimed by links
  alone; with the meter first, 0 false claims).

**Scores (real data only: runs 16-18, real scoreboards, real meter snapshots, combat-log truth; `tools/score5.py`,
`tests/results/SCORES-forever.5.md`):**

| variant | plate precision | plate recall (enemy healers seen) | plate recall, user definition (heal share ≥ 50%) | plate TTI median s | icon on→off flips healers / non-healers | DPS druids marked | resto druids missed | claim precision | claim recall F / E |
|---|---|---|---|---|---|---|---|---|---|
| original K.T.H. | 0/0 | 0/9 | 0/8 | — | 0 / 0 | 0/2 | 1/1 | 0/0 | 0/8 / 0/9 |
| forever.3 (class + mana) | 8/10 | 8/9 | 7/8 | 0 | 2 / 23 | 2/2 | 0/1 | 7/10 | 7/8 / 0/9 |
| forever.5 without meter | 0/0 | 0/9 | 0/8 | — | 0 / 0 | 0/2 | 1/1 | 7/10 | 7/8 / 0/9 |
| **forever.5** | **5/5** | **5/9** | **5/8** | 205 | **0 / 0** | **0/2** | **0/1** | **12/12** | 7/8 / 5/9 |

Run 13 (board-less, out of the scores) as a sanity case from the combat log without names: its only enemy druid in the
log, Korsica, heals others for 48% of her output (a hybrid by the 50% definition, a healer by the 30% one). The run's
meter rows for the enemy DRUID class reach heal 1931 / damage 490 (share 80%) at 805 s, so D9 would mark her then **if**
the scoreboard showed one enemy druid; run 13 has no real scoreboard, so that join is unverified. The board-less replay
(D7 only) marks nobody.

**Limits (honest):**
- Enemy healing is hard to see in a BG: D7 enemy links are almost nil (forever.5 without meter: 0 of 9 enemy healers).
  Enemy identification comes from the meter, out of combat only, joined by class.
- By phase (enemy healers seen on plates, first marked, match time): 0-2 min 0, 2-5 min 0, 5-10 min 3, 10 min+ 2,
  never 4 (forever.3: 0 / 3 / 5 / 0, never 1, but 2 DPS druids marked and 23 flips). Claims (no plate needed): run 17
  priests at 230 s, run 16 resto druid at 391 s, run 16 priests at 657 s.
- These times are **upper bounds from the data, not the addon**: ForeverDump kept only the last 21 meter snapshots per
  run, so the first one available is at 381 s (run 16), 230 s (run 17) and 593 s (run 18). Earlier regen events had
  readable meters in the live client, but there is no data for them, and none was invented.
- Never marked: run 18's three enemy priests (the meter shows 2 of the 3 far above the group; which 2 is secret), run
  17's enemy holy paladin Gorrotar (1 of 3 enemy paladins; log share 59%). Randess (run 18) heals others for 39% only:
  not a healer by the 50% definition.
- Outside BGs enemy meter rows cannot be joined (no scoreboard); friendly meter rows still work by name.
- Arena and target-of-target readability is not captured; not used.

## Replay scores (tests/results/SCORES.md, forever.4: real data only)
Variants: orig = original K.T.H. (Midnight path), port2 = forever.2, port3 = forever.3/forever.4 (same addon code).
Truth: heal on others ≥ 30% of (damage + heal on others) and ≥ 5 direct heals on others (combat log).

**Data (forever.4 cleanup, user rule: no fabricated or inconsistent data in test files).** Older exports gave every
roster row the placeholder surname "Synth". `tools/realnames.py` now recovers real "First Surname" names from each
run's own ForeverDump SV: guid-linked damage-meter/identity records (G), FD scoreboard records and plate name-realm (S),
and a scoreboard row matched on first name + class when two players share a first name (S2).
- Run 16: re-exported with real names, 31/31 (G 15, S 15, S2 1: the enemy rogue "Johnny Snowden", while the friendly
  shaman "Johnny Morningwind" is guid-linked). The scoreboard class agrees with the log-voted class 31/31. Events are
  byte-identical to the previous export.
- Runs 17, 18: already real (KTH diag board). The resolver reproduces them 30/30 and 29/29. Run 18's "Shadow Synth"
  is a real player (GUID Player-4619-00720C89 in the combat log, damage meter and plate UnitName).
- Runs 10-13: no real full name in their SVs (0/33, 0/30, 0/29, 0/29). Re-exported board-less: no full names, no
  classes, first names as logged only, no scoreboard in the harness. Every score depends on the scoreboard, so they
  are **dropped from all scores and from R4/R5**. The files stay as cleaned real data.
- R8 (`tests/replay_provenance_test.py`) fails if a replay has the placeholder pattern, a partial board, or any name
  the run's SV does not back. It fails on the old run-16 export. Synthetic unit fixtures live only in
  `tests/regress/` and carry `synthetic = true` (R2).

| variant | run | plate marks | plate TP | enemy healers seen on plates | evidence claims | claim TP | truth healers | mouse-over alerts / healer-verdict hovers (not target) | verdict flips healer/non-healer | plate log healerNoIcon/iconNoHealer |
|---|---|---|---|---|---|---|---|---|---|---|
| orig | run16 | 0 | 0 | 3 | 0 | 0 | 7 | 0/0 | 0/0 | 0/0 |
| orig | run17 | 0 | 0 | 3 | 0 | 0 | 4 | 0/0 | 0/0 | 0/0 |
| orig | run18 | 0 | 0 | 3 | 0 | 0 | 6 | 0/0 | 0/0 | 0/0 |
| port2 | run16 | 3 | 3 | 3 | 3 | 3 | 7 | 0/60 | 1/0 | 0/0 |
| port2 | run17 | 2 | 2 | 3 | 4 | 1 | 4 | 0/44 | 0/0 | 0/0 |
| port2 | run18 | 5 | 3 | 3 | 3 | 3 | 6 | 0/120 | 2/44 | 0/0 |
| port3 | run16 | 3 | 3 | 3 | 3 | 3 | 7 | 60/60 | 1/0 | 0/0 |
| port3 | run17 | 2 | 2 | 3 | 4 | 1 | 4 | 44/44 | 0/0 | 0/0 |
| port3 | run18 | 5 | 3 | 3 | 3 | 3 | 6 | 120/120 | 2/44 | 0/0 |

| variant | plate precision | plate recall (enemy healers seen) | plate TTI median s | claim precision | claim recall all | claim recall F | claim recall E | claim TTI median s | mouse-over alert rate |
|---|---|---|---|---|---|---|---|---|---|
| orig | 0/0 | 0/9 = 0% | None | 0/0 | 0/17 = 0% | 0/8 = 0% | 0/9 = 0% | None | 0/0 |
| port2 | 8/10 = 80% | 8/9 = 89% | 0.0 | 7/10 = 70% | 7/17 = 41% | 7/8 = 88% | 0/9 = 0% | 324.2 | 0/224 = 0% |
| port3 | 8/10 = 80% | 8/9 = 89% | 0.0 | 7/10 = 70% | 7/17 = 41% | 7/8 = 88% | 0/9 = 0% | 324.2 | 224/224 = 100% |

