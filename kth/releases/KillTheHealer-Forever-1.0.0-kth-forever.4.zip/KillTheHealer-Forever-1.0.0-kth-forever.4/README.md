# K.T.H. Forever 1.0.0-kth-forever.4 (addon code = forever.3; test data cleaned)

K.T.H. (Kill The Healer) by Scone, built on H.H.T.D. by John Wellesz, ported to WoW Forever 1.60.1 (toc 16001).
**All Rights Reserved. This is a private port for personal use. Do not redistribute it.**

## Install
1. Close WoW Forever.
2. In `World of Warcraft/_forever_/Interface/AddOns/`, delete the old `KTH` folder (the baseline build).
3. Copy `AddOns/KTH` there.
4. Optional: copy `AddOns/KTH_ForeverDiag` (the same probe as in the baseline). It writes only to its own frame and
   SavedVariables. Keep it for one more BG if you want a second measurement with the port. Otherwise leave it out.
5. Start the client.

## In game
- `/kthg`: settings window (K.T.H.'s own panel). `/hhtd` opens the H.H.T.D. options window. On Forever, nothing is
  printed to chat.
- K.T.H. messages appear in its own small frame, top-left (`KTH_ForeverMessageFrame`). `/kthlog` shows or hides it.
- Enemy healer markers: in BGs the class comes from the scoreboard (exact "First Surname" + team: on Forever a
  plate's realm is the player's surname), and the mana check is K.T.H.'s own. Feral druids in caster form get marked
  and lose the mark in cat or bear form. That is K.T.H.'s rule and the cause of the icon that "sometimes shows".
  Priests and druids on mana are marked straight away. Paladins and shamans need confirmation, either from the
  scoreboard (post-match) or from heal evidence.
- Mouse-over an enemy healer: K.T.H.'s alarm sound and "is a healer" message; click it: the target-lock sound
  (forever.3 fix: enemy GUIDs are secret on Forever, the unit is now found by its full name).
- `/kthsound` plays K.T.H.'s five alert sounds 2 s apart and shows whether the client played each one
  (`willPlay`) in K.T.H.'s frame. Please run it once and send the result: the sound IDs are unverified on Forever.
- Arena, world, dungeons and raids: K.T.H.'s normal checks run there. The scoreboard join is used only in BGs. Heal
  evidence runs in arenas and the open world, and in dungeons and raids when K.T.H.'s PvE option is on. Arena and
  world readability has not been captured yet, so expect fewer enemy marks there if enemy classes are secret.
- K.T.H. logs each enemy plate's verdict changes to its SavedVariables (`ForeverPlateLog`). Send
  `WTF/Account/<acct>/SavedVariables/KTH.lua` after a BG or an arena match.
- `/hhtdp` posts K.T.H.'s healer placard to BG chat. This is K.T.H.'s original feature and only runs when you type it.

## What to expect (replays of 3 captured BGs with the real scoreboard: runs 16, 17, 18)
- Enemy healers seen on nameplates: 8 of 9 marked on first sight. 8 of 10 marks are right; the rest are DPS
  druids or priests on mana.
- Mouse-over alert: 224 of 224 hovers over a marked enemy (not your target) play the sound. forever.2 played 0.
- Friendly healers (heal evidence): 7 of 8 found, median about 5 minutes in, at 70% precision.
- No "blocked from an action only available to the Blizzard UI" popup: the port never registers COMBAT_LOG_EVENT_UNFILTERED.

See `FOREVER-PORT.md` for every change and its evidence, `KTH-REVIEW.md` for the comparison with our own tools,
`tests/` for the harness, and `original/KTH` for the untouched original.
