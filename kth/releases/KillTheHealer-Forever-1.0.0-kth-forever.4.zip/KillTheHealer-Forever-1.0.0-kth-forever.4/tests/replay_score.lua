-- Replay a ForeverDump BG stream (tests/replay/<run>.lua) through K.T.H. Forever loaded in the Forever mock and
-- record, per scoreboard player, the first time K.T.H.'s own nameplate verdict (CheckUnitIsHealer) marks them.
-- usage: lua5.1 replay_score.lua <KTH.toc> <stream.lua> <out.json> [mode]   mode: port (default) | original-mn
-- Unit model follows the baseline BG diag (2026-10-10): enemy UnitClass/UnitGUID/UnitHealthMax SECRET, UnitName clear
-- first-name-only, UnitPowerType clear, UnitCanAttack clear; GetScoreInfo table clear with name/classToken/faction
-- clear and talentSpec/roleAssigned/guid/healingDone/damageDone SECRET (in-match).
package.path = "/workspace/foreverdump/tests/?.lua;/workspace/kth/tests/?.lua;" .. package.path
local W = dofile("/workspace/foreverdump/tests/wowenv.lua"); _G.__W = W
local TF = require("tocfiles")
dofile("/workspace/kth/tests/mockextra.lua")
local SECRET = W.SECRET
local tocPath, streamPath, outPath, mode = arg[1], arg[2], arg[3], arg[4] or "port"
local D = dofile(streamPath)
local errors = {}
seterrorhandler(function(m) errors[#errors + 1] = tostring(m) end)

if mode == "original-mn" then
    -- original K.T.H. on Forever data, Midnight path forced (what retail K.T.H. logic would do with Forever's values)
    GetBuildInfo = function() return "12.0.1", "70334", "", 120001, "", "", 120001 end
end

-- ---------------------------------------------------------------- unit model
local ZONE = os.getenv("KTH_ZONE") or "pvp"
local ENEMY_CLASS_CLEAR = os.getenv("KTH_ENEMY_CLASS") == "clear"
local roster = D.roster
local U, POWER = {}, {}           -- token -> roster index (0 = player); roster index -> power token
local PT = { MANA = 0, RAGE = 1, FOCUS = 2, ENERGY = 3, HAPPINESS = 4 }
-- forever.3: UNIT_POWER_UPDATE also reports secondary powers (COMBO_POINTS, HOLY_POWER, ...); only primary types
-- can be a UnitPowerType. (A form-shifted druid's MANA ticks still look like MANA: known model limit.)
local PRIMARY = { MANA = true, RAGE = true, FOCUS = true, ENERGY = true, RUNIC_POWER = true }
local function R(tok) local i = U[tok] if i and i > 0 then return roster[i], i end end
UnitExists = function(u) return u == "player" or U[u] ~= nil end
UnitIsPlayer = function(u) return u == "player" or R(u) ~= nil end
-- forever.4: UnitName's 2nd return is the scoreboard surname on Forever (D5b, measured runs 17+18 59/59). A replay
-- carries real full names (meta.board = true: run 16 via tools/realnames.py, runs 17/18 from the KTH diag board) or
-- none at all (meta.board = false: runs 10-13, first names as logged, no scoreboard, no classes). Nothing synthetic.
local BOARD = (D.meta.board ~= false)
for _, r in ipairs(roster) do if r.full == nil then BOARD = false end end
local function surname(r) if not BOARD or not r.full then return nil end return r.full:match("^%S+ (.+)$") end
UnitName = function(u) if u == "player" then return "Owner", nil end local r = R(u) if r then return r.first, surname(r) end end
UnitGUID = function(u) if u == "player" then return "Player-1-OWNER" end if R(u) then return SECRET end end
UnitCanAttack = function(a, b) local r = R(b) if r then return r.side == "E" end return false end
UnitIsFriend = function(a, b) local r = R(b) if r then return r.side == "F" end return true end
UnitIsEnemy = function(a, b) local r = R(b) return r and r.side == "E" or false end
UnitClass = function(u)
    local r = R(u)
    if not r then return "Shaman", "SHAMAN", 7 end
    if r.side == "E" and not ENEMY_CLASS_CLEAR then return SECRET, SECRET, SECRET end -- measured in BGs: 750/750 secret
    return r.class, r.class, 1                                        -- friendly: not measured (no friendly plates seen)
end
UnitPowerType = function(u) local _, i = R(u) if not i then return 0, "MANA" end local p = POWER[i] or "MANA" return PT[p] or 0, p end
UnitIsUnit = function(a, b) return U[a] ~= nil and U[a] == U[b] end
UnitIsDead = function() return false end
UnitHealthMax = function(u) if u == "player" then return 4000 end return SECRET end
UnitFactionGroup = function() return "Horde", "Horde" end
-- forever.3 F7: non-BG scenarios. KTH_ZONE = pvp (default) | arena | none (open world) | party ; KTH_ENEMY_CLASS =
-- secret (default, measured in BGs) | clear (world/arena readability is NOT measured: both models are tested)
IsInInstance = function() if ZONE == "none" then return false, "none" end return true, ZONE end
GetInstanceInfo = function() return "Zone", ZONE, 0, "", 5, 0, false, (ZONE == "none") and 0 or 1234 end
local plates = {}
C_NamePlate = C_NamePlate or {}
C_NamePlate.GetNamePlateForUnit = function(u)
    if not U[u] or not u:match("^nameplate") then return nil end
    plates[u] = plates[u] or CreateFrame("Frame", nil, UIParent)
    return plates[u]
end
C_NamePlate.GetNamePlates = function() local t = {} for _, p in pairs(plates) do t[#t + 1] = p end return t end
GetNumBattlefieldScores = function() if not BOARD or ZONE == "none" or ZONE == "party" then return 0 end return #roster end -- no scoreboard outside BG/arena, none for board-less runs
C_PvP = C_PvP or {}
C_PvP.GetScoreInfo = function(i)
    local r = BOARD and roster[i]
    if not r then return nil end
    return { name = r.full, classToken = r.class, className = r.class, faction = (r.side == "F") and 0 or 1,
             talentSpec = SECRET, roleAssigned = SECRET, guid = SECRET, healingDone = SECRET, damageDone = SECRET,
             killingBlows = SECRET, deaths = SECRET }
end
GetBattlefieldScore = function(i)
    local r = BOARD and roster[i]
    if not r then return nil end
    return r.full, SECRET, SECRET, SECRET, SECRET, (r.side == "F") and 0 or 1, "Race", r.class, r.class,
        SECRET, SECRET, SECRET, SECRET, nil, SECRET, SECRET, SECRET
end
RequestBattlefieldScoreData = function() end

-- forever.3: real tickers (K.T.H.'s 1 s nameplate scan and the scoreboard scanner run on C_Timer.NewTicker; a
-- no-op ticker left icons stale in the replay). Run in stream time by runTickers().
local TICKERS = {}
C_Timer.NewTicker = function(sec, fn, n)
    local tk = { sec = sec, fn = fn, n = n, next = GetTime() + sec }
    tk.Cancel = function() tk.dead = true end
    tk.IsCancelled = function() return tk.dead end
    TICKERS[#TICKERS + 1] = tk
    return tk
end
local function runTickers()
    local now = GetTime()
    for _, tk in ipairs(TICKERS) do
        local guard = 0
        while not tk.dead and tk.next <= now and guard < 5 do
            guard = guard + 1; tk.next = tk.next + tk.sec
            local ok, e = pcall(tk.fn, tk)
            if not ok then errors[#errors + 1] = "TICKER " .. tostring(e) end
            if tk.n then tk.n = tk.n - 1; if tk.n <= 0 then tk.dead = true end end
        end
        if tk.next <= now then tk.next = now + tk.sec end
    end
end

-- forever.3: sound hook installed before load (Announcer captures PlaySoundFile as an upvalue)
local moSound, moStats = 0, { hovers = 0, verdictTrue = 0, alerted = 0, alertedNoVerdict = 0, missed = 0 }
local _PSF = PlaySoundFile
local tlSound = 0
PlaySoundFile = function(id, ...) if id == 567458 then moSound = moSound + 1 end if id == 567482 then tlSound = tlSound + 1 end if _PSF then return _PSF(id, ...) end return true end

-- ---------------------------------------------------------------- load
local ns = {}
for _, f in ipairs(TF.files(tocPath)) do
    local chunk, err = loadfile(f)
    if not chunk then errors[#errors + 1] = "COMPILE " .. err
    else local ok, e = pcall(chunk, "KTH", ns) if not ok then errors[#errors + 1] = "LOAD " .. f .. ": " .. tostring(e) end end
end
local function fire(...) local ok, e = pcall(W.fire, ...) if not ok then errors[#errors + 1] = "FIRE " .. tostring(e) end end
fire("ADDON_LOADED", "KTH")
IsLoggedIn = function() return true end
fire("PLAYER_LOGIN")
local A = LibStub("AceAddon-3.0"):GetAddon("K.T.H.")
local check = A.MN_CheckUnitIsHealer
if os.getenv("KTH_PVE") == "off" and A.db then A.db.global.Pve = false end -- forever.3 F7: K.T.H.'s own Pve option

-- ---------------------------------------------------------------- replay
local ev = D.ev
local t0 = ev[1][1]
W.state.time = 1000
fire("PLAYER_ENTERING_WORLD", false, false)
fire("UPDATE_BATTLEFIELD_SCORE")
local marks, seen, wrongMarks = {}, {}, {}
-- forever.3 F3 regression: every sweep, hover each enemy plate (mouseover = that unit) and record K.T.H.'s announcer
-- reaction (HHTD_HEALER_MOUSE_OVER -> PlaySoundFile(567458)); compare with the nameplate verdict for that unit.
local moAlertedPlayers, moMissedPlayers = {}, {}
local last, flips, flipWhy = {}, {}, {}
local nextSweep = 0
local function sweep(t)
    for tok, i in pairs(U) do
        if i and i > 0 and tok:match("^nameplate%d+$") then
            if not seen[i] then seen[i] = t end
            local ok, isHealer, isFriend, method = pcall(check, tok)
            if ok and isHealer and not marks[i] then marks[i] = { t = t, method = method } end
            -- flip tracking (forever.3): verdict changes for the same player while their plate stays up
            local key = tok .. "#" .. i
            local v = (ok and isHealer) and true or false
            if last[key] ~= nil and last[key] ~= v then flips[i] = (flips[i] or 0) + 1; flipWhy[i] = flipWhy[i] or {}; flipWhy[i][#flipWhy[i] + 1] = (v and "on:" or "off:") .. tostring(POWER[i]) end
            last[key] = v
            if not ok then errors[#errors + 1] = "CHECK " .. tostring(isHealer) end
            if U[tok] and roster[i].side == "E" then
                U["mouseover"] = i
                local before = moSound
                fire("UPDATE_MOUSEOVER_UNIT")
                local alerted = moSound > before
                moStats.hovers = moStats.hovers + 1
                if v then moStats.verdictTrue = moStats.verdictTrue + 1 end
                if alerted then moStats.alerted = moStats.alerted + 1; moAlertedPlayers[i] = true
                    -- then click it: K.T.H. plays the target-lock sound when the hovered healer becomes the target
                    if os.getenv("KTH_TARGET_TEST") then
                        local oldT, tb = U["target"], tlSound
                        U["target"] = i; fire("PLAYER_TARGET_CHANGED")
                        moStats.targetLocked = (moStats.targetLocked or 0) + ((tlSound > tb) and 1 or 0)
                        U["target"] = oldT
                    end
                end
                if alerted and not v then moStats.alertedNoVerdict = moStats.alertedNoVerdict + 1 end
                local isTarget = U["target"] == i -- K.T.H. design: no mouse-over alert on the current target (TARGET_LOCKED path)
                if v and not alerted and isTarget then moStats.onTarget = (moStats.onTarget or 0) + 1
                elseif v and not alerted then moStats.missed = moStats.missed + 1; moMissedPlayers[i] = true end
                U["mouseover"] = nil
            end
        end
    end
end
local counts = { C = 0, U = 0, A = 0 }
for _, e in ipairs(ev) do
    local t, k, tok, gi, a = e[1], e[2], e[3], e[4], e[5]
    W.state.time = 1000 + (t - t0)
    runTickers()
    if t - t0 >= nextSweep then
        if A.ForeverEvidence then A.ForeverEvidence.flush() end
        sweep(t); nextSweep = (t - t0) + 1
        if A.ForeverEvidence and A.ForeverEvidence.plateLogTick then A.ForeverEvidence.updateZone(); A.ForeverEvidence.plateLogTick() end
    end
    if k == "S" then fire("UPDATE_BATTLEFIELD_SCORE")
    elseif k == "T" then -- target change: nothing to model
    elseif tok then
        if k == "R" then
            fire("NAME_PLATE_UNIT_REMOVED", tok); U[tok] = nil
        else
            U[tok] = gi
            if k == "A" then fire("NAME_PLATE_UNIT_ADDED", tok); counts.A = counts.A + 1
            elseif k == "P" then if gi and a and PRIMARY[a] then POWER[gi] = a end
            elseif k == "C" then counts.C = counts.C + 1; fire("UNIT_SPELLCAST_SUCCEEDED", tok, "Cast-x", (a == "SECRET" or a == nil) and SECRET or a)
            elseif k == "U" then counts.U = counts.U + 1; fire("UNIT_COMBAT", tok, a, "", SECRET, 1) end
        end
    end
end
if A.ForeverEvidence then A.ForeverEvidence.flush() end
sweep(ev[#ev][1])

local out = { mode = mode, errors = errors, counts = counts, marks = {}, seen = {}, t0 = t0, t1 = ev[#ev][1],
              stats = A.ForeverEvidence and A.ForeverEvidence.stats or nil }
out.recs = {}
if A.ForeverEvidence then for k, r in pairs(A.ForeverEvidence.R) do out.recs[k] = { heal = r.heal, dmg = r.dmg, casts = r.casts, claim = r.claim, claimT = r.claimT, contradicted = r.contradicted } end end
out.mouseover = moStats
out.zone = ZONE
out.board = BOARD
out.rosterSize = 0
if A.ForeverEvidence then for _ in pairs(A.ForeverEvidence.roster) do out.rosterSize = out.rosterSize + 1 end end
-- forever.3 F2/F6 regression: icon state vs verdict in the plate log (a healer verdict with no icon = intermittent icon)
local plog = A.db and A.db.global.ForeverPlateLog or {}
local pl = { changes = #plog, healerNoIcon = 0, iconNoHealer = 0 }
for _, e in ipairs(plog) do
    local h = e.v ~= "no" and e.v ~= "err"
    if h and not e.icon then pl.healerNoIcon = pl.healerNoIcon + 1 end
    if e.icon and not h then pl.iconNoHealer = pl.iconNoHealer + 1 end
end
out.platelog = pl
out.platelogRows = {}
for k, e in ipairs(plog) do out.platelogRows[k] = string.format("%.1f %s %s %s %s icon=%s %s", e.t - t0, e.who, e.v, tostring(e.pwr), tostring(e.cls), tostring(e.icon), e.tok) end
print("platelog changes/healerNoIcon/iconNoHealer", pl.changes, pl.healerNoIcon, pl.iconNoHealer)
out.moAlerted, out.moMissed = {}, {}
for i in pairs(moAlertedPlayers) do out.moAlerted[#out.moAlerted + 1] = i end
for i in pairs(moMissedPlayers) do out.moMissed[#out.moMissed + 1] = i end
out.flips = {}
for i, n in pairs(flips) do out.flips[tostring(i)] = { n = n, why = table.concat(flipWhy[i], ","):sub(1, 200) } end
for i, m in pairs(marks) do out.marks[tostring(i)] = m end
for i, t in pairs(seen) do out.seen[tostring(i)] = t end
-- minimal JSON writer
local function J(v)
    local tv = type(v)
    if tv == "table" then
        local isArr = #v > 0 or next(v) == nil
        local parts = {}
        if isArr then for _, x in ipairs(v) do parts[#parts + 1] = J(x) end return "[" .. table.concat(parts, ",") .. "]" end
        for kk, x in pairs(v) do parts[#parts + 1] = string.format("%q", tostring(kk)) .. ":" .. J(x) end
        return "{" .. table.concat(parts, ",") .. "}"
    elseif tv == "string" then return string.format("%q", v)
    elseif tv == "number" or tv == "boolean" then return tostring(v) end
    return "null"
end
local f = io.open(outPath, "w") f:write(J(out)) f:close()
print(mode, streamPath:match("[^/]+$"), "errors", #errors, "marks", (function() local n = 0 for _ in pairs(marks) do n = n + 1 end return n end)(),
    "mouseover hovers/verdict/alerted/missed/onTarget/alertNoVerdict", moStats.hovers, moStats.verdictTrue, moStats.alerted, moStats.missed, moStats.onTarget or 0, moStats.alertedNoVerdict)
for i = 1, math.min(5, #errors) do print("  ERR " .. errors[i]:sub(1, 200)) end
