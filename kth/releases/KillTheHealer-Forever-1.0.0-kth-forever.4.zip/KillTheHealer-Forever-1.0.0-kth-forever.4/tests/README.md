# Tests
- `load_smoke.lua <KTH.toc>`: loads the addon in ForeverDump's Forever mock (needs /workspace/foreverdump/tests/wowenv.lua)
  and reports errors, Blizzard chat lines and restricted event registrations. baseline: 1 (CLEU); port: 0.
- `replay_score.lua <KTH.toc> <replay/run.lua> <out.json> [port|original-mn]`: replays a captured BG through K.T.H.'s own
  nameplate verdict; unit model per the baseline diag.
- `../tools/score.py orig port strictD8`: precision / recall / time-to-identify vs combat-log truth → results/SCORES.md.
- `replay/*.lua|*.truth.json`: exported by tools/export_replay.py from the raw ForeverDump captures + combat logs.

## forever.3
- `sh tests/regress/run_regress.sh`: R1 /kthg /hhtd /hhtdg open with no error and no Blizzard chat line (Forever API
  strictness); R2 duplicate first names joined exactly (name + realm = surname); R3 mouse-over plays the announcer
  sound and clicking plays target-lock; R4/R5 every real replay: alert on every healer-verdict hover, icon == verdict;
  R6 static Forever API scan; R7 arena / open world / party (enemy class secret and clear; Pve off); R8 replay
  provenance (forever.4).
  Results: `tests/results/REGRESS-forever.4.txt` (all ok) and `REGRESS-against-forever.2.txt` (R1-R5 and R7 fail on
  forever.2, matching the field report).
- `tests/regress/dupfirst_stream.lua` is a SYNTHETIC unit-test fixture, not a capture.
- `python3 tools/score.py` writes `tests/results/SCORES.md` (orig / port2 / port3).
- The harness loads the ForeverDump mock from `/workspace/foreverdump/tests/wowenv.lua`, and paths are those of the build box.

## forever.4 (test data cleanup)
- Replays carry only real data. Run 16 was re-exported with real full names from its own FD SV (`tools/realnames.py`,
  31/31). Runs 17/18 were already real. Runs 10-13 are board-less (no names, no classes, no scoreboard in the harness)
  and are excluded from scores and from R4/R5. `tests/replay/realnames-report.json` shows how each name was found.
- `python3 tests/replay_provenance_test.py` (R8) fails on the placeholder pattern, a partial board, or any name not
  backed by the run's SV.
- Result files computed on the old placeholder replays (forever.2/.3 harness) are not shipped. `tests/results/variants/forever4-real/`
  holds the D8 and druid-veto variants re-scored on runs 16-18.
