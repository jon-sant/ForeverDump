-- forever.7 R11 fixture (SYNTHETIC unit-test input, not a capture). No capture has a clear spellID for another unit
-- (FD runs 6-18: always secret), so this models the case K.T.H. handles if a client ever returns one: an enemy paladin
-- casts Holy Shock (1311605, verified healer-only on runs 1-18) once -> marked at once; an enemy priest casts Penance
-- (402289, NOT healer-only: a DPS priest cast it in run 15) -> not marked; an enemy druid casts nothing -> not marked.
return {
 meta = { run = "regress-healonly-spell", synthetic = true },
 roster = {
  { first = "Shock", full = "Shock Holy", side = "E", class = "PALADIN" },
  { first = "Pen", full = "Pen Ance", side = "E", class = "PRIEST" },
  { first = "Quiet", full = "Quiet Druid", side = "E", class = "DRUID" },
 },
 ev = {
  {100.0, "A", "nameplate1", 1, nil}, {100.0, "P", "nameplate1", 1, "MANA"},
  {100.0, "A", "nameplate2", 2, nil}, {100.0, "P", "nameplate2", 2, "MANA"},
  {100.0, "A", "nameplate3", 3, nil}, {100.0, "P", "nameplate3", 3, "MANA"},
  {110.0, "C", "nameplate1", 1, 1311605},
  {111.0, "C", "nameplate2", 2, 402289},
  {113.0, "P", "nameplate1", 1, "MANA"}, {114.0, "P", "nameplate2", 2, "MANA"}, {115.0, "P", "nameplate3", 3, "MANA"},
  {130.0, "P", "nameplate1", 1, "MANA"},
 },
}
