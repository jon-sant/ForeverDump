#!/bin/sh
# forever.3 regressions. Exit 1 on any failure.
set -e
cd /workspace/kth
fail=0
# R1 (F1): /kthg, /hhtd, /hhtdg open the AceConfig dialogs with no Lua error under Forever API strictness
out=$(lua5.1 tests/load_smoke.lua port/KTH/KTH.toc 2>&1 || true)
if echo "$out" | grep -q "^errors:.0$" && echo "$out" | grep -q "^blizzChat lines:.0$" && echo "$out" | grep -q "^options UIs opened:.3$"; then echo "R1 ok: /kthg /hhtd /hhtdg open, 0 errors, 0 Blizzard chat lines"; else echo "R1 FAIL"; echo "$out" | tail -8; fail=1; fi
# R2 (D5b): duplicate first names joined exactly by name+realm(surname)
KTH_TARGET_TEST=1 lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/dupfirst_stream.lua /tmp/regress_dup.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/regress_dup.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
ok = set(m)=={'1'} and not d['errors']
print('R2', 'ok' if ok else 'FAIL', 'marks', sorted(m), 'errors', len(d['errors']))
mo=d['mouseover']; ok2 = mo['alerted']>0 and mo['alertedNoVerdict']==0 and mo['missed']==0 and mo.get('targetLocked',0)==mo['alerted']
print('R3', 'ok' if ok2 else 'FAIL', 'mouse-over on the healer plays the announcer sound, clicking it plays the target-lock sound:', mo)
sys.exit(0 if ok and ok2 else 1)
PY
# R4 (F3): on every real replay the mouse-over alert fires for every healer-verdict hover (not on target);
# R5 (F2/F6): icon state == verdict in the plate log
# real-board replays only (runs 10-13 are board-less, see R8)
for r in tests/replay/2026-10-09-run16-bg.lua tests/replay/2026-10-10-run17-bg.lua tests/replay/2026-10-10-run18-bg.lua; do
  lua5.1 tests/replay_score.lua port/KTH/KTH.toc $r /tmp/regress_r.json port >/dev/null
  python3 - "$r" <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/regress_r.json')); mo=d['mouseover']; pl=d['platelog']
ok = mo['missed']==0 and mo['alertedNoVerdict']==0 and pl['healerNoIcon']==0 and pl['iconNoHealer']==0 and not d['errors']
print('R4/R5', 'ok' if ok else 'FAIL', sys.argv[1].split('/')[-1], 'mo', mo, 'platelog', pl, 'errors', len(d['errors']))
sys.exit(0 if ok else 1)
PY
done
# R9 (forever.5, user decision "having mana does not make one a healer"): two enemy DPS druids on MANA with damage only
# are never marked - BG with meter rows, and with the class clear in arena / open world; a healing druid (control) is.
for z in pvp arena none; do
  KTH_ZONE=$z KTH_ENEMY_CLASS=clear lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/druid_mana_dps_stream.lua /tmp/r9.json port >/dev/null
  python3 - $z <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r9.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
ok = not m and not d['errors'] and d['mouseover']['alerted']==0
print('R9', 'ok' if ok else 'FAIL', 'zone', sys.argv[1], 'DPS druids on MANA marked:', len(m), 'alerts', d['mouseover']['alerted'], 'errors', len(d['errors']))
sys.exit(0 if ok else 1)
PY
done
lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/druid_resto_stream.lua /tmp/r9c.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r9c.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
ok = set(m)=={'1'} and not d['errors']
print('R9', 'ok' if ok else 'FAIL', 'control: healing druid marked:', sorted(m))
sys.exit(0 if ok else 1)
PY
# R9b (real data): on runs 16-18 no enemy druid without healing output is ever marked (run 18: Joff, Tatusera show MANA)
for r in 2026-10-09-run16-bg 2026-10-10-run17-bg 2026-10-10-run18-bg; do
  lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/replay/$r.lua /tmp/r9b.json port >/dev/null
  python3 - $r <<'PY' || fail=1
import json,sys
r=sys.argv[1]; d=json.load(open('/tmp/r9b.json')); tr=json.load(open(f'tests/replay/{r}.truth.json'))['roster']
m=d['marks'] if isinstance(d['marks'],dict) else {}
bad=[tr[int(i)-1]['first'] for i in m if (tr[int(i)-1].get('cls') or tr[int(i)-1].get('cls_log'))=='DRUID' and not tr[int(i)-1]['healer']]
dr=[x['first'] for x in tr if x['side']=='E' and (x.get('cls') or x.get('cls_log'))=='DRUID' and not x['healer']]
print('R9b', 'ok' if not bad else 'FAIL', r, 'non-healer enemy druids', dr, 'marked', bad)
sys.exit(0 if not bad else 1)
PY
done
# R10 (forever.6, real data, named cases): every enemy healer of runs 16-18 is marked on its plate with no on->off
# flip; every earlier false mark (forever.3: Joff, Tatusera) and false friendly claim (forever.3: Ganon, Romsly, Vale)
# stays unmarked/unclaimed; Torvian (ret paladin, self-heals; early-read simulation risk) stays unmarked.
for r in 2026-10-09-run16-bg 2026-10-10-run17-bg 2026-10-10-run18-bg; do
  lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/replay/$r.lua /tmp/r10.json port >/dev/null
  python3 - $r <<'PY' || fail=1
import json,sys
r=sys.argv[1]; d=json.load(open('/tmp/r10.json')); tr=json.load(open(f'tests/replay/{r}.truth.json'))['roster']
HEAL={'run16':['Bleep','Frobby','Invictusap'],'run17':['Gorrotar','Aerie','Brocky'],'run18':['Randess','Ank','Karen']}
NOMARK={'run17':[],'run16':[],'run18':['Joff','Tatusera','Torvian']}
NOCLAIM={'run17':['Ganon','Romsly','Vale'],'run16':[],'run18':['Joff','Tatusera','Torvian']}
run=[k for k in HEAL if k in r][0]
m=d['marks'] if isinstance(d['marks'],dict) else {}
fl=d['flips'] if isinstance(d['flips'],dict) else {}
recs=d['recs'] if isinstance(d['recs'],dict) else {}
idx={x['first']:i+1 for i,x in enumerate(tr)}
ok=True
# forever.7: time-to-mark ceilings (s from capture start) = forever.6's plate-mark times on the same replays: no healer
# may be marked later than forever.6 marked them
MAXT={'Bleep':749,'Frobby':530,'Invictusap':584,'Gorrotar':1106,'Aerie':359,'Brocky':459,'Randess':715,'Ank':1052,'Karen':1036}
g0=json.load(open(f'tests/replay/{r}.truth.json'))['meta']['g0']
for n in HEAL[run]:
    i=str(idx[n]); tm = (m[i]['t']-g0) if i in m else None
    good = i in m and (fl.get(i,{}).get('off',0)==0) and tm <= MAXT[n] + 0.5
    print('R10', 'ok' if good else 'FAIL', run, 'healer', n, ('marked at %.0f s (ceiling %d s)' % (tm, MAXT[n])) if i in m else 'NOT marked', 'offFlips', fl.get(i,{}).get('off',0)); ok&=good
for n in NOMARK[run]:
    i=str(idx[n]); good = i not in m
    print('R10', 'ok' if good else 'FAIL', run, 'not-healer', n, 'unmarked' if good else 'MARKED'); ok&=good
for n in NOCLAIM[run]:
    x=tr[idx[n]-1]; k=('F:' if x['side']=='F' else 'E:')
    c=[v for kk,v in recs.items() if kk in (k+x['full'],k+x['first']) and v.get('firstClaimT')]
    print('R10', 'ok' if not c else 'FAIL', run, 'never claimed', n, 'claims', len(c)); ok&=not c
sys.exit(0 if ok else 1)
PY
done
# R11 (forever.7, SYNTHETIC): one cast of a verified healer-only spell (Holy Shock 1311605) marks within 2 s in open
# world and arena (class clear or secret); Penance (402289, a DPS priest cast it in run 15) does not; no cast, no mark.
for z in none arena pvp; do for c in secret clear; do
  KTH_ZONE=$z KTH_ENEMY_CLASS=$c lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/healonly_spell_stream.lua /tmp/r11.json port >/dev/null
  python3 - $z $c <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r11.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
ok = set(m)=={'1'} and m['1']['t'] <= 112 and not d['errors']
print('R11', 'ok' if ok else 'FAIL', sys.argv[1], 'class', sys.argv[2], 'marked', sorted(m), 'at', [round(v['t']-110,1) for v in m.values()], 's after the cast')
sys.exit(0 if ok else 1)
PY
done; done
# R12 (forever.7, SYNTHETIC): a level-22 healer with no healer-only spell is still marked by the meter layer; absence of
# healer-only casts is never evidence against
lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/lowlevel_healer_stream.lua /tmp/r12.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r12.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}; rec=d['recs'].get('E:Novice Mender',{})
ok = set(m)=={'1'} and rec.get('spec') is None and (rec.get('why') or '').startswith('meter') and not d['errors']
print('R12', 'ok' if ok else 'FAIL', 'low-level healer without healer-only spells marked by', rec.get('why'))
sys.exit(0 if ok else 1)
PY
# R13 (forever.7, SYNTHETIC): spec shortcut. Arena opponent spec 105 (Restoration) -> marked within 2 s; spec 71 and no
# spec -> not marked by spec; friendly group role HEALER -> claimed at once, DAMAGER role -> nothing against anyone
KTH_ZONE=arena lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/spec_arena_stream.lua /tmp/r13.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r13.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
ok = set(m)=={'1'} and m['1']['t'] <= 102 and not d['errors'] and all(v.get('spec')!='DPS' for v in d['recs'].values())
print('R13', 'ok' if ok else 'FAIL', 'arena spec: marked', sorted(m), 'recs', {k:v.get('spec') for k,v in d['recs'].items()})
sys.exit(0 if ok else 1)
PY
lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/regress/spec_role_stream.lua /tmp/r13b.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r13b.json')); r=d['recs']
ok = (r.get('F:Mend Well') or {}).get('claim')=='HEALER' and not (r.get('F:Stab Back') or {}).get('claim') and not d['errors']
print('R13', 'ok' if ok else 'FAIL', 'group role HEALER claimed:', (r.get('F:Mend Well') or {}).get('why'))
sys.exit(0 if ok else 1)
PY
# R7 (F7): non-BG zones. Same real event stream (run18) replayed as arena / open world / party, enemy UnitClass
# secret (as measured in BGs) and clear (world/arena readability not captured yet): no Lua error anywhere, no
# scoreboard join outside BGs, no class-based mark even when the class is clear (forever.5: healing-output verdict
# only), evidence engine off in party when K.T.H.'s Pve option is off.
for z in arena none party; do for c in secret clear; do
  KTH_ZONE=$z KTH_ENEMY_CLASS=$c lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/replay/2026-10-10-run18-bg.lua /tmp/r7.json port >/dev/null
  python3 - $z $c <<'PY' || fail=1
import json,sys
z,c=sys.argv[1:3]; d=json.load(open('/tmp/r7.json')); m=d['marks'] if isinstance(d['marks'],dict) else {}
meth={x['method'] for x in m.values()}
ok = not d['errors'] and d['rosterSize']==0 and meth<={'HEAL'} and d['mouseover']['missed']==0
print('R7', 'ok' if ok else 'FAIL', z, 'enemyClass='+c, 'marks', len(m), sorted(meth), 'roster', d['rosterSize'], 'errors', len(d['errors']), 'mo', d['mouseover'])
sys.exit(0 if ok else 1)
PY
done; done
KTH_ZONE=party KTH_PVE=off lua5.1 tests/replay_score.lua port/KTH/KTH.toc tests/replay/2026-10-10-run18-bg.lua /tmp/r7.json port >/dev/null
python3 - <<'PY' || fail=1
import json,sys
d=json.load(open('/tmp/r7.json')); n=len(d['recs']) if isinstance(d['recs'],dict) else 0
print('R7', 'ok' if n==0 and not d['errors'] else 'FAIL', 'party with Pve off: evidence records', n)
sys.exit(0 if n==0 and not d['errors'] else 1)
PY
# R8 (forever.4): replay provenance: no placeholder or SV-unbacked name in any replay; synthetic fixtures labelled
python3 tests/replay_provenance_test.py || fail=1
# R6 (F1 static): every global function the addon calls exists on Forever or is guarded
python3 tests/api_scan_test.py || fail=1
exit $fail
