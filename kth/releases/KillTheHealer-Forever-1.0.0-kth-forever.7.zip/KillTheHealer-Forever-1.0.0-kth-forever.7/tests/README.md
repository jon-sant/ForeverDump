# Tests
- `load_smoke.lua <KTH.toc>`: loads the addon in ForeverDump's Forever mock (needs /workspace/foreverdump/tests/wowenv.lua)
  and reports errors, Blizzard chat lines and restricted event registrations. baseline: 1 (CLEU); port: 0.
- `replay_score.lua <KTH.toc> <replay/run.lua> <out.json> [port|original-mn]`: replays a captured BG (+ its .dm.lua meter snapshots when present) through K.T.H.'s own
  nameplate verdict; unit model per the baseline diag.
- `../tools/score.py orig port strictD8`: precision / recall / time-to-identify vs combat-log truth → results/SCORES.md.
- `replay/*.lua|*.truth.json`: exported by tools/export_replay.py from the raw ForeverDump captures + combat logs.

## forever.3
- `sh tests/regress/run_regress.sh`: R1 /kthg /hhtd /hhtdg open with no error and no Blizzard chat line (Forever API
  strictness); R2 duplicate first names joined exactly (name + realm = surname); R3 mouse-over plays the announcer
  sound and clicking plays target-lock; R4/R5 every real replay: alert on every healer-verdict hover, icon == verdict;
  R6 static Forever API scan; R7 arena / open world / party (enemy class secret and clear; Pve off); R8 replay
  provenance (forever.4).
  Results: `tests/results/REGRESS-forever.4.txt` (all ok) and `REGRESS-against-forever.2.txt` (R1-R5 and R7 fail on
  forever.2, matching the field report).
- `tests/regress/dupfirst_stream.lua` is a SYNTHETIC unit-test fixture, not a capture.
- `python3 tools/score.py` writes `tests/results/SCORES.md` (orig / port2 / port3).
- The harness loads the ForeverDump mock from `/workspace/foreverdump/tests/wowenv.lua`, and paths are those of the build box.

## forever.4 (test data cleanup)
- Replays carry only real data. Run 16 was re-exported with real full names from its own FD SV (`tools/realnames.py`,
  31/31). Runs 17/18 were already real. Runs 10-13 are board-less (no names, no classes, no scoreboard in the harness)
  and are excluded from scores and from R4/R5. `tests/replay/realnames-report.json` shows how each name was found.
- `python3 tests/replay_provenance_test.py` (R8) fails on the placeholder pattern, a partial board, or any name not
  backed by the run's SV.
- Result files computed on the old placeholder replays (forever.2/.3 harness) are not shipped. `tests/results/variants/forever4-real/`
  holds the D8 and druid-veto variants re-scored on runs 16-18.

## forever.5 (healer verdict = healing output)
- `replay/<run>.dm.lua` (runs 16-18): the run's own C_DamageMeter snapshots exported raw from its FD SV by
  `tools/export_dm.py` (via `tools/dm_extract.lua`); `"<secret>"` = the value was secret when FD read it. The harness
  serves each snapshot from PLAYER_REGEN_ENABLED at its GetTime(); before the first kept snapshot there is no meter
  data (FD keeps 21). `KTH_NO_METER=1` replays without it. R8 checks each file is byte-identical to a fresh export.
  Run 13 gets no meter file (board-less: its friendly rows would bring names into a run without real names).
- `tools/dm_match.py`, `tools/dm_rules.py`: meter rows vs combat log (row sides, amounts) and threshold tuning.
- `tools/rescore5.sh` then `python3 tools/score5.py > tests/results/SCORES-forever.5.md`: original / forever.3 /
  forever.5 without meter / forever.5 on runs 16-18 (plate precision/recall, TTI, on→off flips, DPS druids marked,
  resto druids missed, user-definition recall, claims, phase table).
- R9 (`tests/regress/druid_mana_dps_stream.lua` + `.dm.lua`, SYNTHETIC): two enemy DPS druids on MANA with damage only
  are never marked (BG with meter, arena and open world with the class clear); control
  `druid_resto_stream.lua` + `.dm.lua` (SYNTHETIC): a healing druid is marked. R9b: on real runs 16-18 no enemy druid
  without healing is marked. `dupfirst_stream.dm.lua` (SYNTHETIC) gives R2 its meter rows.
- Results: `tests/results/REGRESS-forever.5.txt` (all ok).

## forever.6 (class-group meter rules, user: recall of forever.3 with the precision of forever.5)
- `tools/forensics6.py` (per player: plate sightings, power, casts, links, forever.3/forever.5 marks and claims) and
  `tools/forensics6_meter.py` (per enemy class group: raw heal/damage rows and the forever.6 verdict at each snapshot).
- `tools/rescore6.sh` then `python3 tools/score5.py orig port3 port5 f6a-grp60 f6b-grp63 f6c-grp70 f6d-weak2
  f6e-weak1-nocap port6`: variants via `KTH_CFG="key=value,..."` (thresholds only; replay data untouched).
- `tools/earlysim6.py` -> `tests/results/EARLYSIM-forever.6.txt`: OPTIMISTIC estimate of earlier meter reads rebuilt
  from the combat log (FD kept only 21 snapshots). Flagged; never used in scores or tests.
- R10: named real-data cases. All 9 enemy healers of runs 16-18 must be marked with 0 on->off flips (Bleep, Frobby,
  Invictusap, Gorrotar, Aerie, Brocky, Randess, Ank, Karen). Joff, Tatusera and Torvian must never be marked or
  claimed. Ganon, Romsly and Vale must never be claimed. Against forever.5, R10 fails 4 cases (Gorrotar, Randess,
  Ank, Karen), as expected.
- Results: `tests/results/SCORES-forever.6.md`, `tests/results/REGRESS-forever.6.txt` (all ok).

## forever.7 (spec shortcut, healer-only spells, time-to-mark)
- R10 now also asserts a time-to-mark ceiling per real healer (forever.6's mark time on the same replay; no slower).
- R11 `healonly_spell_stream.lua` (synthetic): Holy Shock cast → marked ≤ 2 s (zones none/arena/pvp × class secret/clear); Penance (dropped from the list) and no cast → no mark.
- R12 `lowlevel_healer_stream.lua` (+`.dm.lua`, synthetic): level-22 priest without healer-only spells is marked by the meter; spec stays unknown.
- R13 `spec_arena_stream.lua`, `spec_role_stream.lua` (synthetic): arena spec 105 → mark; spec 71 / 0 → nothing; group role HEALER → claim, DAMAGER → nothing.
- Synthetic fixtures model API returns whose readability is unmeasured on Forever (arena specs, roles); the scoreboard mock keeps talentSpec secret as measured.
