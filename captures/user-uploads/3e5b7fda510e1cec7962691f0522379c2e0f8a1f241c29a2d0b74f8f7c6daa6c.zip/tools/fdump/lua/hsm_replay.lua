-- Offline HSM replay: feeds a Forever-observable event stream into the SAME library the addon uses
-- (ForeverDump/Lib/HybridState.lua) and prints predictions / inferences / contradictions as JSON.
-- usage: lua5.1 hsm_replay.lua <HybridState.lua> <events.lua>   (events.lua returns { events = { ... } })
--   { t=, k="cast", ev="UNIT_SPELLCAST_SUCCEEDED", unit="player"|key, spell=id|nil, player=true, target=key }
--   { t=, k="aura", unit=key, added={ {iid=, spellId=, fromPlayer=, helpful=, duration=} }, removed={iid...} }
--   { t=, k="count", unit=key, filter="HELPFUL|PLAYER", count=n }
--   { t=, k="learn", spell=id, aura={duration=, helpful=, self=}, cooldown=s, amount={min=,max=,kind=} }
--   { t=, k="tick" }
local libPath, evPath = arg[1], arg[2]
_G.HybridState = nil
local Lib = dofile(libPath)
local data = dofile(evPath)
local now = 0
local hs = Lib.New({ now = function() return now end, window = data.window or 0.6 })
for _, e in ipairs(data.events) do
    now = e.t
    if e.k == "cast" then hs:OnCast(e.ev, e.unit, e.spell, e.player, e.target)
    elseif e.k == "aura" then hs:OnAura(e.unit, { added = e.added or {}, removed = e.removed or {}, full = e.full })
    elseif e.k == "count" then hs:OnCount(e.unit, e.filter, e.count)
    elseif e.k == "learn" then
        local k = {}
        for key, v in pairs(e) do if key ~= "t" and key ~= "k" and key ~= "spell" then k[key] = v end end
        hs:Learn(e.spell, k)
    elseif e.k == "tick" then hs:Tick() end
end
hs:Tick()

local function enc(v, depth)
    depth = depth or 0
    local t = type(v)
    if t == "nil" then return "null" end
    if t == "boolean" then return tostring(v) end
    if t == "number" then if v ~= v or v == math.huge or v == -math.huge then return "null" end return string.format("%.17g", v) end
    if t == "string" then return '"' .. v:gsub('[%c"\\]', function(c) return string.format("\\u%04x", c:byte()) end) .. '"' end
    if t == "table" and depth < 8 then
        local n = #v
        if n > 0 or next(v) == nil then
            local parts = {}
            for i = 1, n do parts[i] = enc(v[i], depth + 1) end
            return "[" .. table.concat(parts, ",") .. "]"
        end
        local parts = {}
        for k, x in pairs(v) do
            if type(x) ~= "function" and type(x) ~= "table" or (type(x) == "table" and k ~= "pred") then
                parts[#parts + 1] = enc(tostring(k)) .. ":" .. enc(x, depth + 1)
            end
        end
        return "{" .. table.concat(parts, ",") .. "}"
    end
    return "null"
end
local ex = hs:Export()
io.write(enc({ predictions = ex.predictions, inferences = ex.inferences, contradictions = ex.contradictions, counters = ex.counters }))
