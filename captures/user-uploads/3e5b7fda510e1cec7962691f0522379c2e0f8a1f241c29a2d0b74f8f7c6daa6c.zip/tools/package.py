#!/usr/bin/env python3
"""Build ForeverDump-v<version>.zip: addon, converter, guide generator, tests, anonymized fixtures, docs, and
SECRETS-GUIDE.html at the zip root (regenerate it first with `fdump.py guide ... -o real/<run>/out/guide`).
Excludes real/ (user captures), ref/, data/, .cache/, tests/out/, __pycache__ and any guide samples/ (synthetic)."""
import argparse
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INCLUDE = ["ForeverDump", "tools", "tests", "fixtures", "README.md", "ADDON-USAGE.md", "CHANGES.md",
           "INSTRUCTIONS-console.md", "SELF-HOSTING.md", ".luacheckrc"]
SKIP_DIRS = {"__pycache__", ".cache", "out", "samples", ".venv", "shots"}
SKIP_TOP = {"real", "ref", "data"}


def version():
    m = re.search(r'ns\.VERSION = "([^"]+)"', open(os.path.join(ROOT, "ForeverDump", "Core.lua")).read())
    return m.group(1)


def main():
    v = version()
    short = ".".join(v.split(".")[:2])
    p = argparse.ArgumentParser()
    p.add_argument("--guide", default=os.path.join(ROOT, "real", "2026-10-07-run2", "out", "guide", "SECRETS-GUIDE.html"))
    p.add_argument("-o", "--out", default=os.path.join(ROOT, "ForeverDump-v%s.zip" % short))
    a = p.parse_args()
    if not os.path.exists(a.guide):
        sys.exit("missing %s: run fdump.py guide first" % a.guide)
    n = 0
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED) as z:
        for top in INCLUDE:
            path = os.path.join(ROOT, top)
            if os.path.isfile(path):
                z.write(path, top)
                n += 1
                continue
            for dp, dns, fns in os.walk(path):
                dns[:] = sorted(d for d in dns if d not in SKIP_DIRS and not (dp == path and d in SKIP_TOP))
                for fn in sorted(fns):
                    if fn.endswith((".pyc", ".zip")) or fn == "SECRETS-GUIDE.html":
                        continue
                    full = os.path.join(dp, fn)
                    z.write(full, os.path.relpath(full, ROOT))
                    n += 1
        z.write(a.guide, "SECRETS-GUIDE.html")
        n += 1
    print("wrote %s (%d files, %d KB)" % (a.out, n, os.path.getsize(a.out) // 1024))


if __name__ == "__main__":
    main()
