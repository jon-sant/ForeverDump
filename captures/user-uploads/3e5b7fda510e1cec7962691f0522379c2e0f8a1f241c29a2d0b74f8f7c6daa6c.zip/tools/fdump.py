#!/usr/bin/env python3
"""ForeverDump converter CLI. Run `python3 tools/fdump.py -h` for subcommands.
DUMP may be a SavedVariables ForeverDump.lua (parsed safely, never executed), a dump.json written by
`fdump.py json`, or the folder containing that dump.json."""
import argparse
import json
import os
import datetime
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fdump import probes, drift as driftmod, inference as infmod, guidejson  # noqa: E402
from fdump import apicheck, combatlog, diff as diffmod, export_json, ketho, luacheck_gen, luals, mocks, secrets as secretsmod, taintlog, xref as xrefmod, migrate as migratemod, anonymize, restrictions as restrmod, clientlog, svsize, verify22  # noqa: E402
from fdump.expect import Inventory  # noqa: E402
from fdump.dump import Dump  # noqa: E402
from fdump.luasv import as_list  # noqa: E402


def _write(path, text):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def info(dump):
    m = dump.meta()
    consts = m.get("projectConstants") or {}
    names = [k for k, v in consts.items() if v == m.get("projectID") and k != "WOW_PROJECT_ID"]
    lines = ["build:     %s" % dump.build_label(),
             "project:   WOW_PROJECT_ID=%s (%s)" % (m.get("projectID"), m.get("projectName") or ",".join(names) or "unknown"),
             "constants: %s" % ", ".join("%s=%s" % kv for kv in sorted(consts.items())),
             "scriptsDisallowedForBeta: %s" % m.get("scriptsDisallowedForBeta"),
             "locale:    %s, dumped %s" % (m.get("locale"), m.get("date")),
             "sections:  %s" % ", ".join(sorted(dump.sections)),
             "docs:      %s systems" % len(dump.doc_systems()),
             "strings:   %d" % len(dump.strings),
             "recorder:  %d session(s); combat log: %d session(s)" % (
                 len(as_list(dump.record.get("sessions"))), len(as_list(dump.combatlog.get("sessions")))),
             "errors:    %d unique, %d blocked/forbidden/warnings" % (
                 len(as_list(dump.log.get("errors"))), len(as_list(dump.log.get("blocked"))))]
    return "\n".join(lines)


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _latest_baseline(exclude_source=None, folder=None):
    folder = folder or os.path.join(ROOT, "fixtures", "baselines")
    if not os.path.isdir(folder):
        return None
    builds = sorted((d for d in os.listdir(folder) if os.path.exists(os.path.join(folder, d, "baseline.json"))),
                    key=lambda d: int(d) if d.isdigit() else 0)
    return os.path.join(folder, builds[-1], "baseline.json") if builds else None


def _combat(dump, out, inv):
    res = probes.combat(dump, inv)
    export_json.write_json(os.path.join(out, "combat-matrix.json"), probes.combat_json(res))
    export_json.write_json(os.path.join(out, "combat.json"),
                           guidejson.combat(dump, guidejson.build_label(dump), guidejson.captured(dump)))
    _write(os.path.join(out, "COMBAT-SECRETS.md"), probes.combat_markdown(res))
    print("combat: %d item(s), %d detectability context(s); wrote combat.json (guide --combat), combat-matrix.json, "
          "COMBAT-SECRETS.md to %s" % (len(res["matrix"]), len(res["detectability"]), out))
    return res


def _tokens(dump, out):
    res = probes.tokens(dump)
    export_json.write_json(os.path.join(out, "tokens.json"), res)
    _write(os.path.join(out, "UNIT-TOKENS.md"), probes.tokens_markdown(res))
    print("tokens: %d famil(ies); wrote tokens.json + UNIT-TOKENS.md to %s" % (len(res["families"]), out))
    return res


def _resolve_player(fx, player, logfile):
    if player and player.startswith("Player-"):
        return player, None
    if player and logfile:
        rx = re.compile(r'(Player-[0-9A-F-]+),"%s(?:-[^"]*)?"' % re.escape(player.split("-")[0]))
        with open(logfile, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                m = rx.search(line)
                if m:
                    return m.group(1), None
    g, name = infmod.owner_guid(fx) if fx else (None, None)
    note = ("%r not in the file log; " % player if player else "") + ("using the log owner %s (%s, flags 0x511)" % (g, name) if g else "no owner found")
    return g, note


def _inference(dump, out, logfile, player, year, utc_offset):
    fx = combatlog.parse_file(logfile, year=year, utc_offset_sec=None if utc_offset is None else utc_offset * 3600) if logfile else None
    guid, note = _resolve_player(fx, player, logfile)
    if note:
        print(note)
    res = infmod.analyze(dump, fx, guid)
    res["playerNote"] = note
    export_json.write_json(os.path.join(out, "inference.json"), res)
    _write(os.path.join(out, "INFERENCE.md"), infmod.inference_markdown(res))
    _write(os.path.join(out, "HSM.md"), infmod.hsm_markdown(res))
    hj = infmod.hsm_guide_json(res, guidejson.build_label(dump), guidejson.captured(dump))
    export_json.write_json(os.path.join(out, "hsm.json"), hj)
    print("inference: addon data %s, replay modes %s, %d guide rule row(s); wrote inference.json, INFERENCE.md, hsm.json "
          "(guide --hsm), HSM.md to %s" % (bool(res.get("addon")), ",".join(res.get("replay") or {}) or "-", len(hj["rules"]), out))
    return res, hj


def _guide(dump, a):
    import subprocess
    gen = os.path.join(ROOT, "tools", "guide", "build_guide.py")
    os.makedirs(a.out, exist_ok=True)
    export_json.write_json(os.path.join(a.out, "lab.json"), guidejson.lab(dump))
    _combat(dump, a.out, Inventory())
    _tokens(dump, a.out)
    _inference(dump, a.out, a.file, a.player, a.year, None)
    smap = secretsmod.build(dump)
    inv = Inventory()
    rep = verify22.reconcile(dump, inv) if inv else secretsmod.verify_report(smap)
    export_json.write_json(os.path.join(a.out, "verify.json"), rep)
    html = a.html or os.path.join(a.out, "SECRETS-GUIDE.html")
    helptext = subprocess.run([sys.executable, gen, "-h"], capture_output=True, text=True).stdout
    cmd = [sys.executable, gen, "--inventory", os.path.join(ROOT, "tools", "fdump", "data", "api-secrecy-inventory-forever-70245.tsv"),
           "--research", os.path.join(ROOT, "tools", "guide", "secrets-research.md"), "--verify", os.path.join(a.out, "verify.json"),
           "--lab", os.path.join(a.out, "lab.json"), "--combat", os.path.join(a.out, "combat.json"),
           "--hsm", os.path.join(a.out, "hsm.json"), "--out", html]
    for flag, fn in (("--tokens", "tokens.json"), ("--inference", "inference.json")):
        if flag in helptext:   # newer generators may accept these directly
            cmd += [flag, os.path.join(a.out, fn)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    sys.stdout.write(r.stdout[-2000:])
    if r.returncode != 0:
        sys.stderr.write(r.stderr[-2000:])
        raise SystemExit("guide generator failed")
    print("wrote", html)


def main(argv=None):
    p = argparse.ArgumentParser(prog="fdump.py", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name, help_, dump=True, out=None):
        sp = sub.add_parser(name, help=help_)
        if dump:
            sp.add_argument("dump")
        if out:
            sp.add_argument("-o", "--out", default=out)
        return sp

    add("info", "print build / project / what the dump contains")
    add("json", "(1) JSON per section", out="out/json")
    add("luals", "(2) LuaLS ---@meta annotation stubs", out="out/luals")
    sp = add("luacheck", "(3) luacheck config with std 'forever'", out="out/.luacheckrc")
    sp.add_argument("--std", default="forever")
    add("mocks", "(4) busted mocks + replay helper + fixtures", out="out/mocks")
    sp = add("check", "(5) API-check an addon folder against the dump")
    sp.add_argument("addon")
    sp.add_argument("--json", help="also write findings as JSON")
    sp.add_argument("--strict", action="store_true", help="exit non-zero on warnings too")
    sp = add("diff", "(6) diff two dumps (OLD NEW)", dump=False, out=None)
    sp.add_argument("old")
    sp.add_argument("new")
    sp.add_argument("-o", "--out", help="markdown output (default stdout)")
    sp.add_argument("--json", help="also write JSON")
    add("all", "json + luals + luacheck + mocks into one folder", out="out")
    sp = add("combatlog", "parse Logs/WoWCombatLog*.txt into CLEU replay fixtures (.json and/or .lua)", dump=False)
    sp.add_argument("logfile")
    sp.add_argument("-o", "--out", default="out/combatlog_file.json", help=".json or .lua (Lua fixture for replay.lua)")
    sp.add_argument("--year", type=int, help="year for logs whose timestamps lack one")
    sp.add_argument("--utc-offset", type=float, help="hours east of UTC for timestamps without a zone (default: box zone)")
    sp.add_argument("--shape", choices=["cleu", "raw"], default="cleu")
    sp.add_argument("--limit", type=int)
    sp.add_argument("--subevents", help="comma-separated subevent filter")
    sp.add_argument("--forever-player", metavar="GUID",
                    help="also synthesize Forever-style events (UNIT_SPELLCAST_*, UNIT_COMBAT, PLAYER_SWING) for this player GUID")
    sp = add("cl-compare", "cross-check a parsed file fixture against a /fdump cl session in DUMP", dump=False)
    sp.add_argument("fixture")
    sp.add_argument("dump")
    sp.add_argument("--session", type=int, default=0, help="1-based session index (default: last)")
    sp.add_argument("--json")
    sp.add_argument("--player", help="player GUID: match UNIT_COMBAT(player) against file damage/heal when the session has no CLEU")
    sp = add("taint", "parse Logs/taint.log", dump=False)
    sp.add_argument("logfile")
    sp.add_argument("-o", "--out", help="JSON output")
    sp = add("errors", "summarize captured Lua errors / blocked actions in DUMP")
    sp.add_argument("--json")
    sp = add("ketho", "optional: compare against Ketho/BlizzardInterfaceResources (forever branch)")
    sp.add_argument("--ref", help="local checkout of the Resources folder (default: download from GitHub)")
    sp.add_argument("--branch", default="forever")
    sp.add_argument("--ui-source", help="wow-ui-source Interface dir: drop dump-only names that are Lua-defined there")
    sp.add_argument("--json")

    add("secrets", "secrets map: secrets.json + SECRETS.md (documented secrecy + runtime observations)", out="out/secrets")
    sp = add("migrate", "scan a legacy addon: per call site status, replacement, secrecy; TOC, events, taint patterns -> MIGRATION.md")
    sp.add_argument("addon")
    sp.add_argument("-o", "--out", default="out/migrate")
    sp = add("fixtures", "write an ANONYMIZED, shareable fixture pack (api surface, env, combat/taint log, secrets map)")
    sp.add_argument("-o", "--out", default="fixtures/forever")
    sp.add_argument("--file", help="WoWCombatLog*.txt to anonymize")
    sp.add_argument("--taint", help="taint.log to anonymize")
    sp.add_argument("--max-lines", type=int, default=2000)
    sp.add_argument("--forbid", default="", help="comma list of words that must not appear (character names, account); fails if found")
    sp = add("migrate-db", "rebuild tools/fdump/data/migration_shims.json from Blizzard_Deprecated* sources", dump=False)
    sp.add_argument("dirs", nargs="+", help="BRANCH=path/to/Interface/AddOns (e.g. forever=.cache/wus-forever/Interface/AddOns)")
    sp = add("verify", "secrets verifier: reconcile expected secrecy (70245 inventory) with observations -> verify.json + VERIFY.md",
             out="out/verify")
    sp.add_argument("--inventory", help="api-secrecy inventory TSV (default tools/fdump/data/api-secrecy-inventory-forever-70245.tsv)")
    sp.add_argument("--legacy", action="store_true", help="v2.1 verifier (dump docs, nil counted as clear)")
    sp = add("xref", "merge addon event log, CL sessions, verifier data and WoWCombatLog into timeline.jsonl + TIMELINE.md",
             out="out/xref")
    sp.add_argument("--file", help="Logs/WoWCombatLog*.txt (optional)")
    sp.add_argument("--player", help="your character GUID (Player-...) for damage-on-player / own-cast matching")
    sp.add_argument("--window-ms", type=int, default=750)
    sp.add_argument("--year", type=int)
    sp.add_argument("--client-log", help="Logs/Client.log: add client Lua errors to the timeline")
    add("restrictions", "addon restriction flips + context + flip probe deltas -> restrictions.json + RESTRICTIONS.md", out="out/restrictions")
    sp = add("clientlog", "parse Logs/Client.log: Lua errors by call site, warnings, addon lines (DUMP optional: capture windows)",
             dump=False, out="out/clientlog")
    sp.add_argument("logfile")
    sp.add_argument("--dump", help="ForeverDump.lua: split errors inside/outside FD_Logs capture windows")
    sp.add_argument("--year", type=int)
    sp = add("size", "SavedVariables size per section (estimated bytes per subtree)")
    sp.add_argument("--depth", type=int, default=3)
    sp.add_argument("-o", "--out", help="text output file")

    add("ops", "operations matrix 'what you can do with a secret' -> ops.json + OPS.md", out="out/ops")
    add("lab", "workarounds lab -> lab.json + LAB.md (incl. 'Porting patterns for secret values')", out="out/lab")
    sp = add("combat", "combat probe set + detectability -> combat.json (guide --combat) + COMBAT-SECRETS.md", out="out/combat")
    sp.add_argument("--inventory")
    add("tokens", "unit token survey -> tokens.json + UNIT-TOKENS.md", out="out/tokens")
    add("knowledge", "spell knowledge per build -> knowledge.json + KNOWLEDGE.md", out="out/knowledge")
    sp = add("inference", "inference rules + hybrid state machine vs the file combat log -> inference.json, INFERENCE.md, hsm.json "
             "(guide --hsm), HSM.md", out="out/inference")
    sp.add_argument("--file", help="Logs/WoWCombatLog*.txt (ground truth; also used for the offline HSM replay)")
    sp.add_argument("--player", help="player GUID or character name (default: the log owner, unit flags 0x511)")
    sp.add_argument("--year", type=int)
    sp.add_argument("--utc-offset", type=float, help="hours east of UTC for the file timestamps (default: box zone)")
    sp = add("drift", "drift between two baselines / SVs (OLD NEW) -> DRIFT.md + drift.json", dump=False)
    sp.add_argument("old")
    sp.add_argument("new")
    sp.add_argument("-o", "--out", default="out/drift")
    sp = add("baseline", "write the baseline signature of DUMP to fixtures/baselines/<build>/baseline.json")
    sp.add_argument("-o", "--out", default="fixtures/baselines")
    sp = add("guide", "regenerate SECRETS-GUIDE.html from the converted SV (lab/verify/combat/hsm/tokens/inference JSON)",
             out="out/guide")
    sp.add_argument("--file", help="WoWCombatLog for the --hsm JSON (inference scoring / replay)")
    sp.add_argument("--player")
    sp.add_argument("--year", type=int)
    sp.add_argument("--html", help="output HTML (default <out>/SECRETS-GUIDE.html)")

    a = p.parse_args(argv)

    if a.cmd == "drift":
        old, new = driftmod.load(a.old), driftmod.load(a.new)
        r = driftmod.compare(old, new)
        os.makedirs(a.out, exist_ok=True)
        export_json.write_json(os.path.join(a.out, "drift.json"), r)
        _write(os.path.join(a.out, "DRIFT.md"), driftmod.markdown(r))
        print(json.dumps({k: (len(v) if isinstance(v, list) else v) for k, v in r.items() if k not in ("old", "new", "coverage")}, indent=1))
        print("wrote drift.json + DRIFT.md to", a.out)
        return 0

    if a.cmd == "diff":
        r = diffmod.diff(Dump.load(a.old), Dump.load(a.new))
        md = diffmod.markdown(r)
        if a.out:
            _write(a.out, md)
            print("wrote", a.out)
        else:
            print(md)
        if a.json:
            export_json.write_json(a.json, r)
        return 0
    if a.cmd == "combatlog":
        fx = combatlog.parse_file(a.logfile, year=a.year,
                                  utc_offset_sec=None if a.utc_offset is None else a.utc_offset * 3600,
                                  shape=a.shape, limit=a.limit,
                                  subevents=set(a.subevents.split(",")) if a.subevents else None)
        if a.forever_player:
            fx = combatlog.synthesize_forever(fx, a.forever_player)
        if a.out.endswith(".lua"):
            mocks.write_lua(a.out, "WoWCombatLog fixture from %s" % os.path.basename(a.logfile), fx)
        else:
            export_json.write_json(a.out, fx)
        print("wrote %s: %d CLEU events (%s), %d non-CLEU lines, header %s" % (
            a.out, fx["total"], ", ".join("%s=%d" % kv for kv in sorted(fx["counts"].items(), key=lambda x: -x[1])[:8]),
            len(fx["events"]) - fx["total"], fx["header"]))
        return 0
    if a.cmd == "cl-compare":
        with open(a.fixture, encoding="utf-8") as f:
            fx = json.load(f)
        d = Dump.load(a.dump)
        sessions = as_list(d.combatlog.get("sessions"))
        if not sessions:
            print("no /fdump cl sessions in", a.dump)
            return 2
        if a.session:
            sess = sessions[a.session - 1]
        else:  # newest session with legacy CLEU entries, else the newest session
            with_cleu = [s_ for s_ in sessions if (s_.get("cleuTotal") or 0) > 0]
            sess = (with_cleu or sessions)[-1]
        if (sess.get("cleuTotal") or 0) == 0:
            if not a.player:
                print("session has no legacy CLEU entries; pass --player GUID to match UNIT_COMBAT against the file")
                return 2
            r = combatlog.compare_forever(fx, sess, a.player)
            print("forever mode: %(addonUnitCombat)d addon UNIT_COMBAT(player), %(fileDamageHealOnPlayer)d file damage/heal "
                  "on player, matched %(matched)d (%(secretAmounts)d secret amounts), addon-only %(addonOnly)d, "
                  "file-only %(fileOnly)d" % r)
            if a.json:
                export_json.write_json(a.json, r)
            return 0
        r = combatlog.compare(fx, sess)
        print("matched %d, addon-only %d, file-only %d" % (r["matched"], r["addonOnly"], r["fileOnly"]))
        for subev, d_ in r["arityMismatch"].items():
            print("  arity %s: %s" % (subev, d_))
        for fd in r["fieldDiffs"][:20]:
            print("  diff %s arg %d: addon=%r file=%r" % (fd["sub"], fd["pos"], fd["addon"], fd["file"]))
        if a.json:
            export_json.write_json(a.json, r)
        return 0
    if a.cmd == "migrate-db":
        dirs = [tuple(d.split("=", 1)) for d in a.dirs]
        db = migratemod.build_shim_db(dirs)
        path = os.path.join(migratemod.DATA, "migration_shims.json")
        export_json.write_json(path, {"_about": "parsed from Blizzard_Deprecated* (%s)" % ", ".join(b for b, _ in dirs), "functions": db})
        print("wrote %d shim entries to %s" % (len(db), path))
        return 0
    if a.cmd == "taint":
        r = taintlog.parse(a.logfile)
        print(taintlog.text_summary(r))
        if a.out:
            export_json.write_json(a.out, r)
            print("wrote", a.out)
        return 0

    dump = Dump.load(a.dump)
    if a.cmd == "info":
        print(info(dump))
    elif a.cmd == "json":
        files = export_json.export(dump, a.out)
        print("wrote %d JSON files to %s" % (len(files), a.out))
    elif a.cmd == "luals":
        files = luals.generate(dump, a.out)
        print("wrote %d LuaLS stub files to %s (add it to workspace.library; see .luarc.json.example)" % (len(files), a.out))
    elif a.cmd == "luacheck":
        _write(a.out, luacheck_gen.generate(dump, std_name=a.std))
        print("wrote", a.out)
    elif a.cmd == "mocks":
        files = mocks.generate(dump, a.out)
        print("wrote %d mock files to %s" % (len(files), a.out))
    elif a.cmd == "all":
        print(info(dump))
        export_json.export(dump, os.path.join(a.out, "json"))
        luals.generate(dump, os.path.join(a.out, "luals"))
        _write(os.path.join(a.out, ".luacheckrc"), luacheck_gen.generate(dump))
        mocks.generate(dump, os.path.join(a.out, "mocks"))
        smap = secretsmod.build(dump)
        export_json.write_json(os.path.join(a.out, "secrets", "secrets.json"), smap)
        _write(os.path.join(a.out, "secrets", "SECRETS.md"), secretsmod.to_markdown(smap))
        print("wrote json/, luals/, .luacheckrc, mocks/, secrets/ under", a.out)
        # v2.2 reports + automatic drift against the newest stored baseline (fixtures/baselines/<build>/)
        rows = probes.ops(dump)
        _write(os.path.join(a.out, "ops", "OPS.md"), probes.ops_markdown(rows))
        export_json.write_json(os.path.join(a.out, "lab", "lab.json"), guidejson.lab(dump))
        _write(os.path.join(a.out, "lab", "LAB.md"), probes.lab_markdown(probes.lab(dump)))
        _combat(dump, os.path.join(a.out, "combat"), Inventory())
        _tokens(dump, os.path.join(a.out, "tokens"))
        kres = probes.knowledge(dump)
        export_json.write_json(os.path.join(a.out, "knowledge", "knowledge.json"), kres)
        _write(os.path.join(a.out, "knowledge", "KNOWLEDGE.md"), probes.knowledge_markdown(kres))
        new = driftmod.from_dump(dump)
        ref = _latest_baseline(exclude_source=None)
        if ref:
            r = driftmod.compare(driftmod.load(ref), new)
            export_json.write_json(os.path.join(a.out, "drift", "drift.json"), r)
            _write(os.path.join(a.out, "drift", "DRIFT.md"), driftmod.markdown(r))
            print("drift vs %s: build bump %s, newly secret %d, newly clear %d, APIs +%d/-%d -> %s" % (
                ref, r["buildBump"], len(r["newlySecret"]), len(r["newlyClear"]), len(r["apisAdded"]), len(r["apisRemoved"]),
                os.path.join(a.out, "drift", "DRIFT.md")))
        else:
            print("drift: no stored baseline under fixtures/baselines/ (fdump.py baseline DUMP)")
    elif a.cmd == "ops":
        rows = probes.ops(dump)
        export_json.write_json(os.path.join(a.out, "ops.json"), rows)
        _write(os.path.join(a.out, "OPS.md"), probes.ops_markdown(rows))
        print("ops matrix: %d row(s); wrote ops.json + OPS.md to %s" % (len(rows), a.out))
    elif a.cmd == "lab":
        items = probes.lab(dump)
        export_json.write_json(os.path.join(a.out, "lab.json"), guidejson.lab(dump))
        _write(os.path.join(a.out, "LAB.md"), probes.lab_markdown(items))
        print("lab: %d approach(es); wrote lab.json + LAB.md to %s" % (len(items), a.out))
    elif a.cmd == "combat":
        _combat(dump, a.out, Inventory(a.inventory) if a.inventory else Inventory())
    elif a.cmd == "tokens":
        _tokens(dump, a.out)
    elif a.cmd == "knowledge":
        res = probes.knowledge(dump)
        export_json.write_json(os.path.join(a.out, "knowledge.json"), res)
        _write(os.path.join(a.out, "KNOWLEDGE.md"), probes.knowledge_markdown(res))
        print("knowledge: %d build(s); wrote knowledge.json + KNOWLEDGE.md to %s" % (len(res), a.out))
    elif a.cmd == "inference":
        _inference(dump, a.out, a.file, a.player, a.year, getattr(a, "utc_offset", None))
    elif a.cmd == "baseline":
        base = driftmod.from_dump(dump)
        path = driftmod.save(base, os.path.join(a.out, str(base.get("build"))))
        print("baseline for build %s (docs %s, %d secrecy keys, %d present APIs) -> %s" % (
            base.get("build"), (base.get("docs") or {}).get("hash"), len(base["secrecy"]), len(base["present"]), path))
    elif a.cmd == "guide":
        _guide(dump, a)
    elif a.cmd == "check":
        r = apicheck.run(dump, a.addon)
        print(apicheck.text(r))
        if a.json:
            export_json.write_json(a.json, r)
        if r["counts"]["error"] or (a.strict and r["counts"]["warn"]):
            return 1
    elif a.cmd == "errors":
        errs, blocked = as_list(dump.log.get("errors")), as_list(dump.log.get("blocked"))
        addon_re = re.compile(r"[Ii]nterface[/\\][Aa]dd[Oo]ns[/\\]([^/\\]+)[/\\]")

        def attribute(e):
            # skip ForeverDump's own handler frames (v2.0 recorded them as the culprit)
            for text in (e.get("message"), e.get("stack")):
                for name in addon_re.findall(str(text or "")):
                    if name != "ForeverDump":
                        return name
            return e.get("addon")

        for e in sorted(errs, key=lambda e: -(e.get("count") or 0)):
            e["attributedAddon"] = attribute(e)
            note = "  (addon %s)" % e["attributedAddon"] if e.get("attributedAddon") else ""
            if e.get("addon") and e.get("addon") != e.get("attributedAddon"):
                note += "  [dump said %s: its own handler frames, fixed in 2.1]" % e["addon"]
            print("[%dx] %s%s" % (e.get("count", 1), e.get("message"), note))
            tr = re.search(r"\[C\]: \?\n\[C\]: in function [`'](\w+)'", str(e.get("stack") or ""))
            if tr and "attempt to call a nil value" in str(e.get("message")):
                e["class"] = "c-trampoline-nil-call"
                print("    class: nil call raised inside the C function %s (hooksecurefunc trampoline; see CHANGES 2.2)" % tr.group(1))
            if e.get("duringCapture") or e.get("taintLog"):
                print("    during capture: %s, taintLog=%s" % (e.get("duringCapture"), e.get("taintLog")))
            if e.get("origins"):
                print("    origins (%d):" % len(e["origins"]))
                for o, n in sorted(e["origins"].items(), key=lambda x: -x[1]):
                    print("      %4dx %s" % (n, o))
            if e.get("stack"):
                print("    " + str(e["stack"]).replace("\n", "\n    "))
        for b in blocked:
            ts = b.get("time")
            when = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S") if isinstance(ts, (int, float)) else ts
            print("%s %s %s%s" % (when, b.get("event"), b.get("args"), " (in combat)" if b.get("inCombat") else ""))
        per = {}
        for e in errs:
            per.setdefault(e.get("attributedAddon") or "?", [0, 0])[0] += e.get("count") or 1
        for b in blocked:
            if "_ACTION_" in str(b.get("event")):
                per.setdefault((b.get("args") or {}).get("addon") or "?", [0, 0])[1] += 1
        print("per addon (errors, blocked actions): " + ", ".join("%s %d/%d" % (k, v[0], v[1]) for k, v in sorted(per.items())))
        print("%d unique errors, %d blocked/forbidden/warning events" % (len(errs), len(blocked)))
        if a.json:
            export_json.write_json(a.json, {"errors": errs, "blocked": blocked, "perAddon": per})
    elif a.cmd == "secrets":
        smap = secretsmod.build(dump)
        export_json.write_json(os.path.join(a.out, "secrets.json"), smap)
        _write(os.path.join(a.out, "SECRETS.md"), secretsmod.to_markdown(smap))
        print(json.dumps(smap["headline"], indent=1))
        print("wrote secrets.json + SECRETS.md to", a.out)
    elif a.cmd == "fixtures":
        os.makedirs(a.out, exist_ok=True)
        anon = anonymize.Anonymizer()
        written = []
        env = anonymize.environment(dump)
        anonymize.write_json(os.path.join(a.out, "environment.json"), env)
        anonymize.write_json(os.path.join(a.out, "api-surface.json"), anonymize.api_surface(dump))
        smap = secretsmod.build(dump)
        for k in ("observations", "liveContradictions", "sessions", "fieldVerify"):
            smap.pop(k, None)  # runtime data can carry unit/context info: keep the documented map only
        def _interesting(e):
            e.pop("verify", None)
            if e.get("secrecy") not in (None, "unspecified") or e.get("restrictions") or e.get("conditions"):
                return True
            if e.get("secretArguments") == "NotAllowed" or any(x.get("secrecy") not in (None, "unspecified")
                                                                for x in (e.get("returns") or []) + (e.get("payload") or [])):
                return True
            return any(k not in ("SecretArguments",) for k in (e.get("flags") or {}))
        dropped = {}
        for sect in ("functions", "widgetMethods", "events"):
            tab = smap.get(sect) or {}
            keep = {k: v for k, v in tab.items() if isinstance(v, dict) and _interesting(v)}
            dropped[sect] = len(tab) - len(keep)
            smap[sect] = keep
        smap["fixtureNote"] = "secrecy-relevant entries only; dropped (no secrecy/restriction data): %s" % dropped
        with open(os.path.join(a.out, "secrets-documented.json"), "w", encoding="utf-8") as f:
            json.dump(smap, f, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        written += ["environment.json", "api-surface.json", "secrets-documented.json"]
        if a.file:
            _, nl = anonymize.combat_log(a.file, os.path.join(a.out, "WoWCombatLog-anon.txt"), a.max_lines, anon)
            fx = combatlog.parse_file(os.path.join(a.out, "WoWCombatLog-anon.txt"))
            mocks.write_lua(os.path.join(a.out, "combatlog_file.lua"), "anonymized WoWCombatLog fixture (%s)" % dump.build_label(), fx)
            written += ["WoWCombatLog-anon.txt (%d lines)" % nl, "combatlog_file.lua (%d CLEU events)" % fx["total"]]
        if a.taint:
            anonymize.taint_log(a.taint, os.path.join(a.out, "taint-anon.log"), anon)
            written.append("taint-anon.log")
        hits = anonymize.leak_scan(a.out, [w.strip() for w in a.forbid.split(",") if w.strip()])
        anonymize.write_json(os.path.join(a.out, "anonymization.json"), {
            "mapped": anon.mapping_summary(), "build": dump.build_label(), "files": written,
            "rules": "player GUIDs -> Player-0000-NNNNNNNN, player names -> PlayerN (realm kept), player pets -> Pet-0-0000-0-0-<npc>-N / PetN; "
                     "NPCs, spells, zones kept; api surface keeps names only; secrets map keeps documentation-derived data only",
            "leakScan": {"hits": len(hits)}})
        print("wrote", ", ".join(written), "to", a.out, "| mapped", anon.mapping_summary(), "| leak hits", len(hits))
        if hits:
            for h in hits[:20]:
                print("LEAK", *h)
            return 3
    elif a.cmd == "migrate":
        rep = migratemod.Migrator(dump).scan(a.addon)
        export_json.write_json(os.path.join(a.out, "migration.json"), rep)
        _write(os.path.join(a.out, "MIGRATION.md"), migratemod.markdown(rep))
        print(json.dumps({k: rep[k] for k in ("apiCounts", "callSiteCounts", "eventCounts")}, indent=1))
        print("TOC findings %d, taint patterns %d, secret-flow findings %d" % (len(rep["toc"]), len(rep["taint"]), len(rep["secretFlow"])))
        print("wrote migration.json + MIGRATION.md to", a.out)
    elif a.cmd == "verify":
        smap = secretsmod.build(dump)
        legacy = secretsmod.verify_report(smap)
        inv = Inventory(a.inventory) if a.inventory else Inventory()
        if a.legacy or not inv:
            rep = legacy
            export_json.write_json(os.path.join(a.out, "verify.json"), rep)
            _write(os.path.join(a.out, "VERIFY.md"), secretsmod.verify_markdown(rep))
        else:
            rep = verify22.reconcile(dump, inv)
            rep["legacyStatusCounts"] = legacy["statusCounts"]
            export_json.write_json(os.path.join(a.out, "verify.json"), rep)
            _write(os.path.join(a.out, "VERIFY.md"), verify22.markdown(rep, before=legacy["statusCounts"]))
        print(json.dumps({"statusCounts": rep["statusCounts"], "legacyVerifier": legacy["statusCounts"], "coverage": rep["coverage"],
                          "liveContradictions": len(rep["liveContradictions"])}, indent=1))
        print("wrote verify.json + VERIFY.md to", a.out)
    elif a.cmd == "xref":
        fx = combatlog.parse_file(a.file, year=a.year) if a.file else None
        guid = a.player
        note = None
        if guid and not guid.startswith("Player-"):
            # a character name: resolve through the file log, else fall back to the dump's playerGUID
            found = None
            if a.file:
                rx = re.compile(r'(Player-[0-9A-F-]+),"%s(?:-[^"]*)?"' % re.escape(guid.split("-")[0]))
                with open(a.file, encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        m = rx.search(line)
                        if m:
                            found = m.group(1)
                            break
            if not found:
                note = "name %r not found in the file log; using the dump's playerGUID" % guid
            guid = found
        client = clientlog.parse(a.client_log, year=a.year) if a.client_log else None
        if not guid:
            for sess in as_list(dump.combatlog.get("sessions")):
                guid = guid or sess.get("playerGUID") or (sess.get("meta") or {}).get("playerGUID")
        res = xrefmod.build(dump, fx, guid, a.window_ms, client=client)
        if note:
            res["playerNote"] = note
            print(note, "->", guid)
        os.makedirs(a.out, exist_ok=True)
        xrefmod.write_jsonl(os.path.join(a.out, "timeline.jsonl"), res)
        _write(os.path.join(a.out, "TIMELINE.md"), xrefmod.markdown(res))
        print(json.dumps({"bySource": res["bySource"], "matches": res["stats"], "segments": len(res["segments"]),
                          "player": guid}, indent=1))
        print("wrote timeline.jsonl + TIMELINE.md to", a.out)
    elif a.cmd == "restrictions":
        r = restrmod.summarize(dump)
        off = None
        for sess in as_list(dump.combatlog.get("sessions")) + as_list(dump.record.get("sessions")):
            if isinstance(sess.get("anchor"), dict):
                off = sess["anchor"].get("utcOffset")
                break
        os.makedirs(a.out, exist_ok=True)
        export_json.write_json(os.path.join(a.out, "restrictions.json"), {k: v for k, v in r.items() if k not in ("items", "markerItems")})
        _write(os.path.join(a.out, "RESTRICTIONS.md"), restrmod.markdown(r, off))
        print(json.dumps({"origin": r["origin"], "flips": r["flips"], "byType": {k: {"flips": v["flips"], "states": v["states"],
                          "activeSec": v["activeSec"]} for k, v in r["byType"].items()}, "markers": r["markers"],
                          "probeDeltas": len(r["probeDeltas"])}, indent=1, default=str))
    elif a.cmd == "clientlog":
        entries = clientlog.parse(a.logfile, year=a.year)
        d = Dump.load(a.dump) if a.dump else None
        s2 = clientlog.summarize(entries, clientlog.capture_windows(d))
        os.makedirs(a.out, exist_ok=True)
        export_json.write_json(os.path.join(a.out, "clientlog.json"), s2)
        _write(os.path.join(a.out, "CLIENTLOG.md"), clientlog.markdown(s2))
        print(json.dumps({k: s2[k] for k in ("lines", "first", "last", "kinds", "luaErrors", "cTrampolineNilCalls")}, indent=1))
        print("wrote clientlog.json + CLIENTLOG.md to", a.out)
    elif a.cmd == "size":
        r = svsize.breakdown(dump.raw, a.dump, depth=a.depth)
        t = svsize.text(r)
        print(t)
        if a.out:
            _write(a.out, t + "\n")
    elif a.cmd == "ketho":
        r = ketho.compare(dump, ref=a.ref, branch=a.branch, ui_source=a.ui_source)
        print(ketho.text(r))
        if a.json:
            export_json.write_json(a.json, r)
    return 0


if __name__ == "__main__":
    sys.exit(main())
