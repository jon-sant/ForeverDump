# ForeverDump: changes

v1 (`ForeverDump.lua`, 333 lines; one SavedVariable `ForeverDumpDB`) collected the APIs (`C_*` functions), events,
enums and CVars in one pass and showed them in a copy window via `/fdump` and `/foreverdump`. **All of that still
works:** plain `/fdump` runs the same quick dump into the same `ForeverDumpDB` fields.

## v2.2.0 (2026-10-07/08, after the second real run)
**Fixes from run 2**
- **Bug B (Blizzard UI errors while FD_Logs was ON).** v2.1 post-hooked `EventRegistry.TriggerEvent` with
  `hooksecurefunc`. On Forever 70245 the hook trampoline breaks secure-dispatched `TriggerEvent` calls: Client.log had 405
  `attempt to call a nil value` errors raised by `[C]: in function 'TriggerEvent'` (GlobalCallbackRegistry,
  MainActionBarFrame, tooltips, ...), all inside the capture window. v2.2 installs **no hooks at all**. EventRegistry callbacks
  are opt-in (`record.callbacks`) through `EventRegistry:RegisterCallback`. `tests/regress.lua b-v21` reproduces the bug
  with the v2.1 code and `b-v22` proves zero errors. `/fdump health` checks for hooks and foreign wraps.
- The MoneyFrame "arithmetic on a secret value" taint in run 2 came from **TweaksForever** (`UI/Spellbook.lua:402`), not
  ForeverDump.

**Addon**
- **Verifier v2.2.** Five-state classifier: nil / secret / container with secrets / container clear / clear. Duration objects
  use `:HasSecretValues()`. SecretWhen* is expanded per field, and same-frame `C_Secrets.Should*BeSecret` predicates decide
  contradictions. Against the run-2 data the verifier now reports 0 CONTRADICTED and 0 UNDOCUMENTED-SECRET (v2.1 said 7 and 5,
  all classifier artefacts), plus 4 INCONCLUSIVE and 481 CONFIRMED.
- **Restrictions tracker** (`/fdump restrictions`). `C_RestrictedActions` state per type (Combat, Encounter,
  ChallengeMode, PvPMatch, Map, Chat), each flip stamped on the common timebase, a flip probe set at the event and on the
  next frame, and the always-on checks (combat log, addon chat).
- **Controls and ops matrix** (`/fdump secrets controls`) record what addon code can do with a secret (arithmetic,
  compare, tostring, concat, # ...): booleans and error texts only. The forced-restriction CVar sweep is opt-in and always
  restores the original values.
- **Workarounds lab** (`/fdump lab`). Sanctioned secret-value paths (StatusBar/FontString sinks, curves, duration
  objects), checked at the boundary, never extracted.
- **Every FD_Logs capture runs the probes automatically** through `ns.captureModules` (start at ON, stop at OFF, pcall-isolated):
  - **Combat probe set** (`CombatProbe.lua`, `/fdump combat`). Health, power, casting, movement, identity, threat, range,
    markers and auras (6 filters, slots, by-instance, duration objects, dispel colour) per unit class
    (target/focus/party/nameplate/player, hostile/friendly, NPC/player) and context (ooc/combat/restricted/encounter). Includes
    event payload codes, cast time left (derived vs duration object), the ops matrix per category, and the
    **detectability answers**: casting? which spell? any aura? MY aura? what aura? stacks/duration? dispellable?
    Each answer is yes/partial/no with evidence. Bounded and throttled; triggered by ON, combat start, restriction flips,
    and target/focus changes.
  - **Unit token survey** (`Tokens.lua`, `/fdump tokens`). Once per context per capture: 26 token families (player ... nameplate1-40,
    soft targets, compound chains) × UnitExists/GUID/Name/IsUnit/CanAttack/IsPlayer/Health/HealthMax/CanCompareUnitTokens/
    ShouldUnitIdentityBeSecret, split by resolved vs not.
  - **Spell knowledge** (`Knowledge.lua`, `/fdump knowledge`). The player's spellbook (≤150 spells, chunked): GetSpellInfo,
    description, base cooldown, power cost, charges, the secrecy functions, and tooltip lines with per-line codes. Durations
    and damage/heal ranges are parsed from clear text only. Stored per build, classified out of combat and in combat.
    Class/spec are recorded too.
  - **Inference engine + hybrid state machine** (`Inference.lua`, the reusable library `Lib/HybridState.lua`). Pure logic over
    values the API reports as non-secret plus event timing; no CLEU, no pixels, no parsing of secret text. Rules:
    cast-pair, observed, single-applier, cast-correlation (incl. retro correlation within the window), iid-map, count-delta,
    predicted-expiry. Each inference carries a rule and a confidence. Predictions cover aura + duration, damage/heal range
    and cooldown end for the player's casts, with live verification and contradictions. Rule-input readability is logged
    per context.
  - **HSM window** (`HSMUI.lua`, `/fdump hsm`). Movable, resizable and scrollable; Escape closes it; position saved; plain
    frames only (no secure templates, no Blizzard hooks). Shows restriction states, cast state (yellow predicted bar vs the
    engine bar through `SetTimerDuration`), per-unit auras (source, stacks, remaining, confidence), cooldown prediction vs
    `SetCooldownFromDurationObject`, the last predictions with outcomes, and counters. Secrets are shown only through engine
    passthrough widgets labelled "secret (engine-displayed)". Green observed, yellow inferred, grey unknown, red
    contradiction. Throttled to 0.2 s. FD_Logs ON opens it (`hsm.autoShow`) and OFF closes it. There is also an [HSM] button
    on the secrets panel.
  - **Baseline signature** (`Baseline.lua`, `/fdump baseline`). Docs hash (FNV-1a, identical in Lua and Python), secrecy per
    API position and context, ops, restriction timing, lab, combat, tokens, knowledge and frame types. Stored per build
    (keeps 6). After a build change a one-line **drift alert** prints in chat.
- Macro audit: every generated macro body and every `/run` snippet in the docs is ≤255 characters (`tests/regress.lua macro`,
  `tests/test_v22.py`).

**Converter**
- New: `restrictions`, `clientlog`, `size`, `ops` (OPS.md), `lab` (LAB.md + "Porting patterns for secret values"), `combat`
  (COMBAT-SECRETS.md + combat.json for the guide), `tokens` (UNIT-TOKENS.md), `knowledge` (KNOWLEDGE.md), `inference`
  (INFERENCE.md + HSM.md + hsm.json; scores the addon's inferences/predictions against the file combat log and replays the log
  through `Lib/HybridState.lua` offline in clear / secret / secret-pretrained modes), `drift OLD NEW` (DRIFT.md), `baseline`
  (fixtures/baselines/<build>/baseline.json; run 2 is the first), `guide` (regenerates SECRETS-GUIDE.html).
- `verify` uses the inventory TSV as ground truth (v2.2 classifier rules). `all` also writes ops/lab/combat/tokens/knowledge and runs
  **drift automatically** against the newest stored baseline.
- `xref --player` accepts a character name. `inference` defaults to the log owner (unit flags 0x511).
- **SECRETS-GUIDE.html** (generator in `tools/guide/`) is built from the converted SV and shipped at the zip root.
- Tests: `tests/regress.lua` (bug B before/after, restrictions, classifier, forced sweep, macros), `tests/hsm.lua` (51 checks:
  library, combat probe, tokens, knowledge, inference, HSM window, baseline, no secrets in SV, zero accidental secret touches),
  and `tests/test_v22.py` (guide JSON schemas, reports, drift, Barrens replay, guide build, Lua/Python hash parity, /run audit).

## v2.1.0 (2026-10-07, after the first real Forever 70245 run)
**Addon**
- **FD_Logs = capture everything.** One click starts all client logs plus the event recorder, combat recorder, error
  capture, secrets verifier and getter sweep, and probe and profiler snapshots. It queues `/fdump all` if the build has no
  full dump yet, and takes an automatic in-combat probe at the first combat. The second click stops everything, copies
  BugGrabber errors and runs `/reload` (synchronous OFF, so SavedVariables are written). `/stopmacro [combat]` guard.
  Capture resumes after `/reload`/relog. Running sessions are saved at logout.
- **Compact SavedVariables by default** (about half the size); `/fdump all full` or `set dump.full true` for the v2.0
  full dump. UTF-8-safe truncation (the v2.0 SV contained cut multi-byte characters).
- **Secrets verifier** (`Secrets.lua`, section `secrets`). Live `issecretvalue`/`canaccessvalue` tallies per event, API
  and struct field position, with context buckets (ooc/combat/encounter, instance type, self/other). Throttled sweep of
  documented conditionally secret getters. Live contradictions against the documentation. `/fdump secrets` live
  panel, `state` and `sweep` subcommands. Bounded counters only (`secrets.maxKeys/maxCtx/maxLive`).
- **Common timebase.** Session IDs and anchors (GetTime, time(), GetServerTime, UTC offset; refined at a time() tick) on
  capture, recorder and combat sessions. `sid/t/epoch/server` on probes, errors, blocked actions and contradictions.
  Everything persists to SavedVariables.
- **BugGrabber/BugSack coexistence.** Uses BugGrabber callbacks (`BugGrabber_BugGrabbed`) when it is loaded, polls `GetDB()`
  as a fallback, and chains the previous handler otherwise. `/fdump errors bg` and FD_Logs OFF copy BugGrabber session
  errors. `## OptionalDeps: !BugGrabber, BugSack`.
- Error attribution to the addon that raised it; CLEU is still never registered by default.

**Converter**
- `secrets` (secrets map: every documented flag; SECRETS.md), `verify` (CONFIRMED / CONTRADICTED / UNOBSERVED /
  UNDOCUMENTED-SECRET, coverage), `xref` (merged timeline with match quality), `migrate` + `migrate-db` (legacy addon
  migration report; 109 curated + 373 Blizzard_Deprecated shim mappings), `fixtures` (anonymized fixture pack).
- `check` gained the `secret-op` rule (arithmetic, comparison, length or boolean tests on documented/observed secret values,
  with guard detection). LuaLS stubs carry secrecy annotations marked `[verified]`/`[unverified]`/`[CONTRADICTED]`.
  Mocks return secret sentinels per documented/verified secrecy (`wow.secretMode`, per-field struct secrets, secret
  event payloads).
- Fixes from the real run: invalid UTF-8 in SV broke JSON export; combat log v22 ENVIRONMENTAL_* advanced-block order,
  ST/AOE scope marker, isOffHand padding; Ketho comparison scoping; `cl-compare` Forever mode.
- Tests: BugGrabber paths (`tests/buggrabber.lua`), verifier with deliberate contradictions (smoke), `tests/test_xref.py`
  (synthetic file log), `tests/test_migrate.py` (deliberate legacy addon), `tests/spec/forever_fixture_spec.lua`
  (anonymized real capture).

## v2.0.0

New in v2 compared to v1:
- **Structure:** 19 Lua files; `.toc` Interface 16001, Version 2.0.0; 6 SavedVariables (DB, DocsDB, StringsDB,
  RecordDB, LogDB, CombatLogDB) so large data stays separate; `schemaVersion` plus a meta header (build, locale,
  `WOW_PROJECT_ID` and **every** `WOW_PROJECT_*` constant, with Forever = 18 / CAMELOT, never assumed mainline;
  `C_AddOns.GetScriptsDisallowedForBeta()`).
- **Sections** (`/fdump all` or one at a time): full APIDocumentation walk with documented/present cross-check;
  C_ namespaces; global tables, functions (secure/insecure), constants and Enum; all global strings; widget API
  (methods per type, inheritance; `risky` option); XML templates; named frames; addons; CVars and console commands;
  protected info (issecurevariable plus doc restriction and secret flags); extras (bindings, slash commands, settings,
  fonts, SOUNDKIT, maps, classes, spells, talents, currencies); opt-in getters; profiling snapshot.
- **Recorders:** event recorder registers documented events individually (no RegisterAllEvents) and saves the
  skipped restricted/SecureOnly events with reasons. The Forever-safe combat recorder (`/fdump cl`) records
  UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING with swing range, COMBAT_TEXT_UPDATE with the C_CombatText getter,
  encounter and regen context with restriction states, and post-combat C_DamageMeter snapshots. Legacy CLEU is
  opt-in only (`cl cleu-force`, guarded). Probe (tooltips and getters, now or next combat).
- **Diagnostics:** chained Lua error handler (stack and locals); ADDON_ACTION_BLOCKED/FORBIDDEN, MACRO_ACTION_*,
  LUA_WARNING and ADDON_RESTRICTION_STATE_CHANGED log.
- **FD_Logs:** `/fdump logs` and the single account macro FD_Logs toggle the combat log, chat log,
  advancedCombatLogging, scriptErrors and taintLog together, with state in SavedVariables and a clear chat line.
- **Safety and UX:** refuses heavy work in combat; frame-sliced chunking with `/fdump cancel`; secret-value detection
  everywhere (`<secret>`); per-section toggles, clear and set; capped copy window; status view; /reload reminder.
- **Box-side converter** (`tools/`): SV to JSON, LuaLS stubs, luacheck std, busted mocks and replay, API checker,
  diff, combat log file parser, taint.log parser, error report, Ketho comparison.
