#!/bin/sh
# Full test run: addon smoke test in the mock client (writes tests/out/ForeverDump.lua), then converter e2e.
set -e
cd "$(dirname "$0")/.."
export FORE_DOCS="${FORE_DOCS:-$PWD/ref/wusf/Interface/AddOns}"
luac5.1 -p ForeverDump/*.lua ForeverDump/Lib/*.lua
luacheck ForeverDump tests --no-color -q --exclude-files "tests/legacy_addon/*"
lua5.1 tests/smoke.lua ForeverDump tests/out/ForeverDump.lua | tail -1
lua5.1 tests/hsm.lua ForeverDump | tail -1
python3 tests/test_converter.py
lua5.1 tests/buggrabber.lua ForeverDump | tail -1
python3 tests/test_xref.py
python3 tests/test_migrate.py
lua5.1 tests/regress.lua ForeverDump | tail -1
python3 tests/test_v22.py
