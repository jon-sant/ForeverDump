-- ForeverDump v2.2 - spell knowledge collector (feeds the hybrid state machine and the guide).
-- For the player's known spells: tooltip lines (C_TooltipInfo.GetSpellByID: leftText/rightText + per-line secrecy),
-- C_Spell.GetSpellDescription, C_Spell.GetSpellInfo (castTime/minRange/maxRange), GetSpellBaseCooldown,
-- C_Spell.GetSpellPowerCost, C_Spell.GetSpellCharges, C_Spell.IsSpellHelpful/Harmful and the C_Secrets secrecy levels.
-- Collected out of combat (clear text kept, numbers parsed from CLEAR text only) and re-checked in combat
-- (classification only) so the per-field secrecy across contexts is part of the answer. Stored per build in
-- ForeverDumpDB.knowledge[build]; chunked over frames (spellsPerTick) so it never spikes.
local _, ns = ...
local K = {}
ns.Knowledge = K

local function g(n) return rawget(_G, n) end
local function code(v) return ns.ClassifyValue(v) end
local function clear(v) local c = code(v) return (c == "C" or c == "K") and v or nil end
local function fn(path) local f = ns.Resolve(path) return type(f) == "function" and f or nil end
local function call(path, ...)
    local f = fn(path)
    if not f then return "absent" end
    return ns.Pack(pcall(f, ...))
end
local function ctxName()
    if ns.Secrets and ns.Secrets.InEncounter and ns.Secrets.InEncounter() then return "enc" end
    return ns.InCombat() and "combat" or "ooc"
end
local function cfg() return (ns.config and ns.config.knowledge) or {} end

function K.Build()
    local m = ns.Meta and ns.Meta() or {}
    return tostring(m.build or "?")
end
function K.DB()
    local db = ns.db
    if type(db) ~= "table" then return nil end
    db.knowledge = db.knowledge or {}
    local b = K.Build()
    db.knowledge[b] = db.knowledge[b] or { spells = {}, player = {}, v = 1 }
    return db.knowledge[b]
end

-- numbers from CLEAR description/tooltip text (never touched when secret)
function K.Parse(text)
    if type(text) ~= "string" or ns.IsSecret(text) then return nil end
    local t = text:gsub(",", "")
    local p = {}
    local a, b, kind = t:match("(%d+)%s+to%s+(%d+)%s+([%a]+)%s+damage")
    if a then p.amountMin, p.amountMax, p.amountKind, p.school = tonumber(a), tonumber(b), "damage", kind end
    if not a then
        a, b = t:match("(%d+)%s+to%s+(%d+)%s+damage")
        if a then p.amountMin, p.amountMax, p.amountKind = tonumber(a), tonumber(b), "damage" end
    end
    if not p.amountMin then
        a, b = t:match("[Hh]eals?[^%d]-(%d+)%s+to%s+(%d+)")
        if a then p.amountMin, p.amountMax, p.amountKind = tonumber(a), tonumber(b), "heal" end
    end
    if not p.amountMin then
        a = t:match("(%d+)%s+[%a]*%s*damage") or t:match("[Hh]eals?[^%d]-(%d+)")
        if a then p.amountMin, p.amountMax, p.amountKind = tonumber(a), tonumber(a), t:find("[Hh]eal") and "heal" or "damage" end
    end
    local over = t:match("over%s+(%d+%.?%d*)%s+sec")
    if over then p.overTime = tonumber(over) end
    local dur = t:match("for%s+(%d+%.?%d*)%s+sec") or over or t:match("[Ll]asts%s+(%d+%.?%d*)%s+sec")
    if dur then p.auraDuration = tonumber(dur) end
    local mins = t:match("for%s+(%d+%.?%d*)%s+min") or t:match("[Ll]asts%s+(%d+%.?%d*)%s+min")
    if mins and not p.auraDuration then p.auraDuration = tonumber(mins) * 60 end
    if next(p) == nil then return nil end
    return p
end

-- the player's spells: spellbook (C_SpellBook) when present, else the configured probe spells
function K.SpellList()
    local out, seen = {}, {}
    local maxN = tonumber(cfg().maxSpells) or 150
    local sb = g("C_SpellBook")
    local bank = (g("Enum") and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player) or 0
    if type(sb) == "table" and type(sb.GetNumSpellBookSkillLines) == "function" then
        local okN, n = pcall(sb.GetNumSpellBookSkillLines)
        if okN and type(n) == "number" and not ns.IsSecret(n) then
            for i = 1, math.min(n, 12) do
                local okI, info = pcall(sb.GetSpellBookSkillLineInfo, i)
                if okI and type(info) == "table" and not info.shouldHide then
                    local off, num = clear(info.itemIndexOffset), clear(info.numSpellBookItems)
                    for idx = (off or 0) + 1, (off or 0) + (num or 0) do
                        local okT, _, _, sid = pcall(sb.GetSpellBookItemType, idx, bank)
                        if okT and type(clear(sid)) == "number" and not seen[sid] and #out < maxN then
                            seen[sid] = true out[#out + 1] = sid
                        end
                    end
                end
            end
        end
    end
    if #out == 0 then for _, s in ipairs((ns.config.probe and ns.config.probe.spells) or {}) do out[#out + 1] = s end end
    return out
end

local function playerInfo()
    local p = {}
    local r = call("UnitClass", "player")
    if type(r) == "table" and r[1] then p.className, p.class, p.classID = clear(r[2]), clear(r[3]), clear(r[4]) end
    r = call("UnitLevel", "player") if type(r) == "table" and r[1] then p.level = clear(r[2]) end
    r = call("UnitRace", "player") if type(r) == "table" and r[1] then p.race = clear(r[3]) end
    r = call("C_SpecializationInfo.GetSpecialization")
    if type(r) == "table" and r[1] then
        p.specIndex = clear(r[2])
        if type(p.specIndex) == "number" then
            local s = call("C_SpecializationInfo.GetSpecializationInfo", p.specIndex)
            if type(s) == "table" and s[1] then p.specID, p.specName, p.role = clear(s[2]), clear(s[3]), clear(s[6]) end
        end
    else p.specIndex = "absent" end
    return p
end

-- one spell: per-field five-state codes (stored for every context) + clear data (stored out of combat)
function K.Collect(id, withData)
    local codes, data = {}, withData and {} or nil
    local function rec(field, v, keep)
        codes[field] = code(v)
        if data and keep and codes[field] == "C" then
            if type(v) == "string" and #v > 300 then v = v:sub(1, 300) end
            data[field] = v
        end
    end
    local r = call("C_Spell.GetSpellInfo", id)
    if r == "absent" then codes.info = "absent"
    elseif r[1] and type(r[2]) == "table" and code(r[2]) == "K" then
        for _, f in ipairs({ "name", "iconID", "castTime", "minRange", "maxRange" }) do rec("info." .. f, r[2][f], true) end
    else codes.info = r[1] and code(r[2]) or "E" end
    r = call("C_Spell.GetSpellDescription", id)
    if r ~= "absent" then rec("description", r[1] and r[2] or nil, true) else codes.description = "absent" end
    r = call("GetSpellBaseCooldown", id)
    if r ~= "absent" then rec("baseCooldown", r[1] and r[2] or nil, true) rec("baseGCD", r[1] and r[3] or nil, true) else codes.baseCooldown = "absent" end
    r = call("C_Spell.GetSpellPowerCost", id)
    if r ~= "absent" then
        codes.powerCost = r[1] and code(r[2]) or "E"
        if data and r[1] and type(r[2]) == "table" and codes.powerCost == "K" then
            local c1 = r[2][1]
            if type(c1) == "table" then data.cost = clear(c1.cost) data.costType = clear(c1.type) codes["powerCost.cost"] = code(c1.cost) end
        end
    end
    r = call("C_Spell.GetSpellCharges", id)
    if r ~= "absent" then
        codes.charges = r[1] and code(r[2]) or "E"
        if r[1] and type(r[2]) == "table" and codes.charges ~= "S" then
            rec("charges.max", r[2].maxCharges, true) rec("charges.current", r[2].currentCharges, false)
        end
    end
    for _, h in ipairs({ "IsSpellHelpful", "IsSpellHarmful" }) do
        r = call("C_Spell." .. h, id)
        if r ~= "absent" then rec(h, r[1] and r[2] or nil, true) end
    end
    for _, s in ipairs({ "GetSpellAuraSecrecy", "GetSpellCastSecrecy", "GetSpellCooldownSecrecy", "ShouldSpellAuraBeSecret" }) do
        r = call("C_Secrets." .. s, id)
        if r ~= "absent" then rec("secrecy." .. s, r[1] and r[2] or nil, true) end
    end
    r = call("C_TooltipInfo.GetSpellByID", id)
    if r ~= "absent" then
        codes.tooltip = r[1] and code(r[2]) or "E"
        if r[1] and type(r[2]) == "table" and codes.tooltip ~= "S" then
            local lines = r[2].lines
            if type(lines) == "table" and code(lines) ~= "S" then
                local ls, n = {}, 0
                for i = 1, math.min(#lines, 12) do
                    local ln = lines[i]
                    if type(ln) == "table" then
                        n = n + 1
                        local lc, rc = code(ln.leftText), code(ln.rightText)
                        ls[#ls + 1] = lc .. rc
                        if data then
                            data.tooltip = data.tooltip or {}
                            data.tooltip[i] = { l = (lc == "C") and ln.leftText or nil, r = (rc == "C") and ln.rightText or nil }
                        end
                    end
                end
                codes.tooltipLines = table.concat(ls, ",")
            end
        end
    end
    if data then
        local parsed = K.Parse(data.description)
        if not parsed and data.tooltip then
            for _, ln in pairs(data.tooltip) do parsed = parsed or K.Parse(ln.l) end
        end
        data.parsed = parsed
    end
    return codes, data
end

-- HybridState knowledge from the stored data
function K.ToHSM(entry)
    local d = entry and entry.data
    if not d then return nil end
    local p = d.parsed or {}
    local k = {}
    if p.auraDuration then k.aura = { duration = p.auraDuration, helpful = (d.IsSpellHelpful == true) or nil } end
    if entry.learned and entry.learned.auraDuration then
        k.aura = k.aura or {}
        k.aura.duration = entry.learned.auraDuration
        if entry.learned.helpful ~= nil then k.aura.helpful = entry.learned.helpful end
        if entry.learned.self then k.aura.self = true end
    end
    if type(d.baseCooldown) == "number" and d.baseCooldown > 0 then k.cooldown = d.baseCooldown / 1000 end
    if type(d["info.castTime"]) == "number" then k.castTime = d["info.castTime"] / 1000 end
    if p.amountMin then k.amount = { min = p.amountMin, max = p.amountMax, kind = p.amountKind } end
    return next(k) and k or nil
end

local queue, running
local function tick()
    local db = K.DB()
    if not db or not queue then running = false return end
    local per = tonumber(cfg().spellsPerTick) or 8
    for _ = 1, per do
        local job = table.remove(queue, 1)
        if not job then break end
        local e = db.spells[job.id] or { ctx = {} }
        db.spells[job.id] = e
        local okC, codes, data = pcall(K.Collect, job.id, job.ctx == "ooc")
        if okC then
            e.ctx[job.ctx] = codes
            if data then e.data = data end
        else e.err = tostring(codes):sub(1, 160) ns.NoteSelfError("Knowledge.Collect", codes) end
    end
    if #queue > 0 and not (ns.SelfThrottled and ns.SelfThrottled()) then C_Timer.After(0.05, tick)
    else
        running, queue = false, nil
        db.lastRun = ns.Stamp({ ctx = db.lastCtx })
        if K.onDone then pcall(K.onDone, db) end
    end
end

-- queue a pass over the spell list for the current context (chunked)
function K.Run(reason)
    if running or not ns.db then return false end
    if cfg().enabled == false then return false end
    local db = K.DB()
    local ctx = ctxName()
    db.player = playerInfo()
    db.runs = db.runs or {}
    db.runs[#db.runs + 1] = ns.Stamp({ reason = reason, ctx = ctx })
    while #db.runs > 20 do table.remove(db.runs, 1) end
    db.lastCtx = ctx
    queue = {}
    for _, id in ipairs(K.SpellList()) do queue[#queue + 1] = { id = id, ctx = ctx } end
    db.listed = #queue
    running = true
    if type(g("C_Timer")) == "table" then C_Timer.After(0, tick) else tick() end
    return true
end
function K.Running() return running == true end
function K.RunSync(reason) -- tests / slash: whole pass now
    if not K.Run(reason) then return false end
    while running and queue and #queue > 0 do
        local per = cfg().spellsPerTick
        ns.config.knowledge.spellsPerTick = 10000
        tick()
        ns.config.knowledge.spellsPerTick = per
    end
    return true
end

-- learned facts from the live HSM (readable aura applications after own casts)
function K.Learn(spellID, facts)
    local db = K.DB()
    if not db or type(spellID) ~= "number" then return end
    local e = db.spells[spellID] or { ctx = {} }
    db.spells[spellID] = e
    e.learned = e.learned or {}
    for k, v in pairs(facts) do e.learned[k] = v end
end

-- spells that apply auras (parsed or learned), split by helpful/harmful: input of the "single applier" rule
function K.Appliers()
    local db = K.DB()
    local out = { helpful = {}, harmful = {}, unknown = {} }
    for id, e in pairs((db and db.spells) or {}) do
        local k = K.ToHSM(e)
        if k and k.aura then
            local h = k.aura.helpful
            if h == nil and e.data then h = (e.data.IsSpellHarmful == true) and false or nil end
            local list = (h == true and out.helpful) or (h == false and out.harmful) or out.unknown
            list[#list + 1] = id
        end
    end
    for _, l in pairs(out) do table.sort(l) end
    return out
end
