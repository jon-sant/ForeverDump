-- ForeverDump v2.2 - unit token survey. Once per capture context (ooc / combat / restricted / enc) per FD_Logs capture:
-- for every token family (player, target, focus, mouseover, pet, vehicle, npc, softenemy/softfriend/softinteract,
-- party1-4, partypet1-4, raid1-40, raidpet1-40, arena1-5, boss1-8, nameplate1-40, and compound chains) the five-state
-- code of UnitExists, UnitGUID, UnitName, UnitIsUnit(t,'player'), UnitIsUnit(t,'target'), UnitCanAttack, UnitIsPlayer,
-- UnitHealth, UnitHealthMax, C_Secrets.CanCompareUnitTokens, C_Secrets.ShouldUnitIdentityBeSecret, and whether the
-- token resolved (existing unit). Stored aggregated PER FAMILY (counts per code, split by existing / not existing).
local _, ns = ...
local T = {}
ns.Tokens = T

local function fn(path) local f = ns.Resolve(path) return type(f) == "function" and f or nil end
local function code(v) return ns.ClassifyValue(v) end

local FAMILIES = {
    { "player", { "player" } }, { "target", { "target" } }, { "focus", { "focus" } }, { "mouseover", { "mouseover" } },
    { "pet", { "pet" } }, { "vehicle", { "vehicle" } }, { "npc", { "npc" } },
    { "softenemy", { "softenemy" } }, { "softfriend", { "softfriend" } }, { "softinteract", { "softinteract" } },
    { "party", "party", 4 }, { "partypet", "partypet", 4 }, { "raid", "raid", 40 }, { "raidpet", "raidpet", 40 },
    { "arena", "arena", 5 }, { "boss", "boss", 8 }, { "nameplate", "nameplate", 40 },
    { "targettarget", { "targettarget" } }, { "targettargettarget", { "targettargettarget" } }, { "focustarget", { "focustarget" } },
    { "focustargettarget", { "focustargettarget" } }, { "party1target", { "party1target" } }, { "raid1target", { "raid1target" } },
    { "arena1target", { "arena1target" } }, { "pettarget", { "pettarget" } }, { "mouseovertarget", { "mouseovertarget" } },
}
T.FAMILIES = FAMILIES

local CHECKS = {
    { "UnitExists", "UnitExists", function(t) return t end },
    { "UnitGUID", "UnitGUID", function(t) return t end },
    { "UnitName", "UnitName", function(t) return t end },
    { "UnitIsUnit(player)", "UnitIsUnit", function(t) return t, "player" end },
    { "UnitIsUnit(target)", "UnitIsUnit", function(t) return t, "target" end },
    { "UnitCanAttack", "UnitCanAttack", function(t) return "player", t end },
    { "UnitIsPlayer", "UnitIsPlayer", function(t) return t end },
    { "UnitHealth", "UnitHealth", function(t) return t end },
    { "UnitHealthMax", "UnitHealthMax", function(t) return t end },
    { "CanCompareUnitTokens", "C_Secrets.CanCompareUnitTokens", function(t) return t, "player" end },
    { "ShouldUnitIdentityBeSecret", "C_Secrets.ShouldUnitIdentityBeSecret", function(t) return t end },
}
T.CHECKS = CHECKS

local function tokens(fam)
    if type(fam[2]) == "table" then return fam[2] end
    local out = {}
    for i = 1, fam[3] do out[#out + 1] = fam[2] .. i end
    return out
end

local function db()
    local log = rawget(_G, "ForeverDumpLogDB")
    if type(log) ~= "table" then return nil end
    log.tokens = log.tokens or { v = 1, ctx = {}, absent = {} }
    return log.tokens
end
T.DB = db

local function docOK(path)
    local docs = rawget(_G, "ForeverDumpDocsDB")
    if type(docs) ~= "table" or type(docs.systems) ~= "table" or #docs.systems == 0 then return true end
    return ns.Secrets and ns.Secrets.DocRow and ns.Secrets.DocRow("api:" .. path) ~= nil
end

-- one survey for the current context; skipped when this capture already surveyed it (force = re-run)
function T.Survey(reason, force)
    if ns.SelfThrottled and ns.SelfThrottled() then return nil end
    local d = db()
    if not d then return nil end
    local ctx = ns.CombatProbe and ns.CombatProbe.Context() or (ns.InCombat() and "combat" or "ooc")
    local sid = ns.db and ns.db.logs and ns.db.logs.session and ns.db.logs.session.sid
    d.done = d.done or {}
    if not force and d.done[ctx] and d.done[ctx] == sid then return nil end
    d.done[ctx] = sid
    local fns = {}
    for _, c in ipairs(CHECKS) do
        local f = fn(c[2])
        if f and docOK(c[2]) then fns[c[1]] = f else d.absent[c[1]] = f and "undocumented" or "runtime" end
    end
    local out = { reason = reason, families = {} }
    for _, fam in ipairs(FAMILIES) do
        local r = { tokens = 0, exist = 0, notExist = 0, existSecret = 0, errors = 0, checks = {} }
        for _, tok in ipairs(tokens(fam)) do
            r.tokens = r.tokens + 1
            local okE, ex = pcall(fns.UnitExists or function() return nil end, tok)
            local split
            if not okE then r.errors = r.errors + 1 split = "err"
            elseif ns.IsSecret(ex) then r.existSecret = r.existSecret + 1 split = "exist?"
            elseif ex then r.exist = r.exist + 1 split = "exist"
            else r.notExist = r.notExist + 1 split = "none" end
            -- non-existent tokens: sample only the first index per family (they all behave alike)
            if split ~= "none" or r.notExist == 1 then
                for _, c in ipairs(CHECKS) do
                    local f = fns[c[1]]
                    if f then
                        local res = ns.Pack(pcall(f, c[3](tok)))
                        local st = res[1] and code(res[2]) or "E"
                        r.checks[c[1]] = r.checks[c[1]] or {}
                        local b = r.checks[c[1]]
                        b[split] = b[split] or {}
                        b[split][st] = (b[split][st] or 0) + 1
                    end
                end
            end
        end
        out.families[fam[1]] = r
    end
    ns.Stamp(out)
    d.ctx[ctx] = out
    return out
end

local frame
function T.Start()
    if ns.config.tokens and ns.config.tokens.enabled == false then return false end
    local d = db()
    if d then d.done = {} end
    if not frame then
        frame = CreateFrame("Frame")
        frame:SetScript("OnEvent", function()
            local after = rawget(_G, "C_Timer") and C_Timer.After
            local run = function() local ok, err = pcall(T.Survey, "event") if not ok then ns.NoteSelfError("Tokens.Survey", err) end end
            if after then after(1.5, run) else run() end
        end)
    end
    for _, ev in ipairs({ "PLAYER_REGEN_DISABLED", "ADDON_RESTRICTION_STATE_CHANGED", "ENCOUNTER_START" }) do
        pcall(frame.RegisterEvent, frame, ev)
    end
    pcall(T.Survey, "capture:on")
    return true
end
function T.Stop()
    if frame then pcall(frame.UnregisterAllEvents, frame) end
    local d = db()
    local n = 0
    for _ in pairs((d and d.ctx) or {}) do n = n + 1 end
    return n
end

ns.captureModules = ns.captureModules or {}
ns.captureModules[#ns.captureModules + 1] = { name = "unit token survey", start = function() return T.Start() end,
    stop = function() return string.format("token survey %d context(s)", T.Stop()) end }
