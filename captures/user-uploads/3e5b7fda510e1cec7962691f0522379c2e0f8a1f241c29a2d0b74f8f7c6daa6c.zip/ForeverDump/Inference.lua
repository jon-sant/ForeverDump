-- ForeverDump v2.2 - inference layer + live hybrid state machine (HSM) during an FD_Logs capture.
-- Inputs (live, readable only): the player's and probed units' UNIT_SPELLCAST_* events, UNIT_AURA updateInfo
-- (auraInstanceIDs / fields only when non-secret), readable aura counts (GetAuraSlots), restriction state and the
-- spell knowledge cached while readable (Knowledge.lua). No CLEU (forbidden live), no side channels, no parsing of
-- secret text. The HSM (Lib/HybridState.lua, reusable) predicts each player cast (aura + duration, amount range,
-- cooldown end) and tracks per-unit state; this module logs the readable signals, the rule-input readability per
-- context, every prediction/inference (with rule + confidence) and live contradictions, so the converter can replay
-- and score them against the WoWCombatLog file offline (fdump.py inference / hsm).
local _, ns = ...
local I = {}
ns.Inference = I

local function g(n) return rawget(_G, n) end
local function code(v) return ns.ClassifyValue(v) end
local function clear(v) local c = code(v) return (c == "C" or c == "K") and v or nil end
local function now() return (g("GetTime") or os.clock)() end
local function cfg() return (ns.config and ns.config.hsm) or {} end
local function capturing() return ns.db and ns.db.logs and ns.db.logs.on and ns.db.logs.session ~= nil end

local UNITS = { player = true, target = true, focus = true, party1 = true, party2 = true, party3 = true, party4 = true, pet = true }
I.UNITS = UNITS

local function db()
    local log = g("ForeverDumpLogDB")
    if type(log) ~= "table" then return nil end
    log.inference = log.inference or { v = 1 }
    return log.inference
end
I.DB = db

local function ctxName() return ns.CombatProbe and ns.CombatProbe.Context() or (ns.InCombat() and "combat" or "ooc") end

-- rule-input readability per context
local function seen(sig, readable)
    local d = db()
    if not d then return end
    local ctx = ctxName()
    d.inputs = d.inputs or {}
    d.inputs[ctx] = d.inputs[ctx] or {}
    local r = d.inputs[ctx][sig]
    if not r then r = { r = 0, u = 0 } d.inputs[ctx][sig] = r end
    if readable then r.r = r.r + 1 else r.u = r.u + 1 end
end
I.Seen = seen

local function guidOf(unit)
    local f = g("UnitGUID")
    if type(f) ~= "function" then return nil end
    local ok, v = pcall(f, unit)
    return ok and clear(v) or nil
end
-- HSM unit key: GUID when readable, else the token
local function keyOf(unit) if unit == "player" then return "player" end return guidOf(unit) or unit end
I.KeyOf = keyOf

local function signal(rec)
    local d = db()
    if not d or cfg().signals == false then return end
    d.signals = d.signals or {}
    if #d.signals >= (tonumber(cfg().maxSignals) or 3000) then d.signalsDropped = (d.signalsDropped or 0) + 1 return end
    rec.t = now()
    d.signals[#d.signals + 1] = rec
end

----------------------------------------------------------------------------
-- HSM instance
----------------------------------------------------------------------------
function I.NewHSM()
    local Lib = g("HybridState")
    if type(Lib) ~= "table" then return nil end
    local hs = Lib.New({ now = now, window = tonumber(cfg().window) or 0.6,
        onContradiction = function(c) local d = db() if d then d.live = d.live or {} if #d.live < 200 then d.live[#d.live + 1] = c end end end })
    if ns.Knowledge then
        local kdb = ns.Knowledge.DB()
        for id, e in pairs((kdb and kdb.spells) or {}) do
            local k = ns.Knowledge.ToHSM(e)
            if k then hs:Learn(id, k) end
        end
    end
    return hs
end

----------------------------------------------------------------------------
-- event handlers
----------------------------------------------------------------------------
local function onCast(event, unit, castGUID, spellID)
    if not UNITS[unit] and not (type(unit) == "string" and unit:find("^nameplate")) then return end
    local sid = clear(spellID)
    local isPlayer = unit == "player"
    seen((isPlayer and "playerCast" or "unitCast") .. ".event", true)
    seen((isPlayer and "playerCast" or "unitCast") .. ".spellID", sid ~= nil)
    seen((isPlayer and "playerCast" or "unitCast") .. ".castGUID", clear(castGUID) ~= nil)
    local target
    if isPlayer and event == "UNIT_SPELLCAST_SUCCEEDED" then
        local ue = g("UnitExists")
        local okE, ex = pcall(ue or function() return nil end, "target")
        local k = sid and I.hs and I.hs.knowledge[sid]
        target = (k and k.aura and k.aura.self) and "player" or ((okE and ex == true) and keyOf("target") or "player")
    end
    signal({ e = "cast", ev = event:gsub("^UNIT_SPELLCAST_", ""), unit = unit, guid = guidOf(unit), sid = sid,
        sidState = code(spellID), target = target })
    if I.hs then I.hs:OnCast(event, keyOf(unit), sid, isPlayer, target) end
end

local function auraSummary(_unit, info)
    local s = { added = {}, removed = {} }
    if type(info) ~= "table" or code(info) == "S" then seen("aura.updateInfo", false) return nil end
    seen("aura.updateInfo", true)
    local full = clear(info.isFullUpdate)
    s.full = full == true
    local added = info.addedAuras
    if type(added) == "table" and code(added) ~= "S" then
        s.addedCount = #added
        for i = 1, math.min(#added, 16) do
            local a = added[i]
            if type(a) == "table" and code(a) ~= "S" then
                local iid, spell, fromP = clear(a.auraInstanceID), clear(a.spellId), clear(a.isFromPlayerOrPlayerPet)
                local helpful = clear(a.isHelpful)
                if helpful == nil and clear(a.isHarmful) ~= nil then helpful = not a.isHarmful end
                seen("aura.auraInstanceID", iid ~= nil) seen("aura.spellId", spell ~= nil) seen("aura.fromPlayer", fromP ~= nil)
                local dur, appl = clear(a.duration), clear(a.applications)
                seen("aura.duration", dur ~= nil) seen("aura.applications", appl ~= nil)
                s.added[#s.added + 1] = { iid = iid, spellId = spell, fromPlayer = fromP, helpful = helpful, duration = dur, applications = appl }
            else seen("aura.added", false) end
        end
    elseif added ~= nil then seen("aura.addedAuras", false) end
    local rem = info.removedAuraInstanceIDs
    if type(rem) == "table" and code(rem) ~= "S" then
        s.removedCount = #rem
        for i = 1, math.min(#rem, 32) do local iid = clear(rem[i]) seen("aura.removedID", iid ~= nil) if iid then s.removed[#s.removed + 1] = iid end end
    end
    return s
end

local function counts(unit)
    local ua = g("C_UnitAuras")
    if type(ua) ~= "table" or type(ua.GetAuraSlots) ~= "function" then return nil end
    local out = {}
    for _, filter in ipairs({ "HELPFUL|PLAYER", "HARMFUL|PLAYER" }) do
        local res = ns.Pack(pcall(ua.GetAuraSlots, unit, filter))
        local readable = res[1]
        for i = 2, res.n do if not clear(res[i]) and res[i] ~= nil then readable = false end end
        seen("aura.count", readable and true or false)
        out[filter] = readable and math.max(res.n - 2, 0) or nil   -- returns: continuationToken, slot...
    end
    return out
end

local function onAura(unit, info)
    if not UNITS[unit] then return end
    local s = auraSummary(unit, info)
    local key = keyOf(unit)
    local c = counts(unit)
    signal({ e = "aura", unit = unit, guid = guidOf(unit), full = s and s.full or nil, add = s and s.addedCount or nil,
        rem = s and s.removedCount or nil, adds = s and #s.added > 0 and s.added or nil, rems = s and #s.removed > 0 and s.removed or nil,
        cH = c and c["HELPFUL|PLAYER"], cD = c and c["HARMFUL|PLAYER"] })
    if not I.hs then return end
    if s then I.hs:OnAura(key, s) end
    if c then
        for f, n in pairs(c) do I.hs:OnCount(key, f, n) end
    end
    -- learn while readable: my aura with clear spellId + duration -> knowledge (per build)
    if s and ns.Knowledge then
        for _, a in ipairs(s.added) do
            if a.spellId and a.fromPlayer == true and type(a.duration) == "number" and a.duration > 0 then
                local facts = { auraDuration = a.duration, helpful = a.helpful, self = (unit == "player") or nil }
                ns.Knowledge.Learn(a.spellId, facts)
                I.hs:Learn(a.spellId, { aura = { duration = a.duration, helpful = a.helpful, self = facts.self } })
            end
        end
    end
end

local frame, ticker
local CAST_EVENTS = { "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_INTERRUPTED",
    "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_STOP", "UNIT_SPELLCAST_EMPOWER_START",
    "UNIT_SPELLCAST_EMPOWER_STOP" }
I.CAST_EVENTS = CAST_EVENTS
function I.OnEvent(event, ...)
    if event == "UNIT_AURA" then onAura(...)
    elseif event == "ADDON_RESTRICTION_STATE_CHANGED" then
        local rt, st = ...
        if I.hs then I.hs:SetRestriction(clear(rt), clear(st)) end
        signal({ e = "restriction", rtype = clear(rt), state = clear(st) })
    elseif event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then signal({ e = event == "PLAYER_REGEN_DISABLED" and "combat" or "ooc" })
    elseif event == "PLAYER_TARGET_CHANGED" then signal({ e = "target", guid = guidOf("target") })
    else onCast(event, ...) end
end

function I.Start()
    if cfg().enabled == false then return false end
    local d = db()
    for k in pairs(d) do if k ~= "v" then d[k] = nil end end
    d.sid = ns.SessionId()
    d.anchor = ns.TimeAnchor()
    d.ctx0 = ctxName()
    d.player = { guid = guidOf("player") }
    if ns.Knowledge then
        local kdb = ns.Knowledge.DB()
        d.player.info = kdb and kdb.player
        d.appliers = ns.Knowledge.Appliers()
    end
    I.hs = I.NewHSM()
    if not frame then
        frame = CreateFrame("Frame")
        frame:SetScript("OnEvent", function(_, event, ...)
            local ok, err = pcall(I.OnEvent, event, ...)
            if not ok then ns.NoteSelfError("Inference." .. event, err) end
        end)
    end
    for _, ev in ipairs(CAST_EVENTS) do pcall(frame.RegisterEvent, frame, ev) end
    for _, ev in ipairs({ "UNIT_AURA", "ADDON_RESTRICTION_STATE_CHANGED", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "PLAYER_TARGET_CHANGED" }) do
        pcall(frame.RegisterEvent, frame, ev)
    end
    I.running = true
    if type(g("C_Timer")) == "table" and C_Timer.NewTicker then
        ticker = C_Timer.NewTicker(1, function() if I.hs then pcall(I.hs.Tick, I.hs) end end)
    end
    return true
end

function I.Stop()
    I.running = false
    if frame then pcall(frame.UnregisterAllEvents, frame) end
    if ticker and ticker.Cancel then ticker:Cancel() end
    ticker = nil
    local d = db()
    if not (d and I.hs) then return nil end
    local ex = I.hs:Export()
    d.predictions, d.inferences, d.contradictions, d.counters = ex.predictions, ex.inferences, ex.contradictions, ex.counters
    d.knowledgeSpells = ex.knowledgeSpells
    d.appliersHSM = { helpful = I.hs:Appliers(true), harmful = I.hs:Appliers(false) }
    return ex.counters
end

-- knowledge pass at ON (out of combat, full data) and in the first combat (classification only)
local function startKnowledge()
    if ns.Knowledge and (ns.config.knowledge == nil or ns.config.knowledge.enabled ~= false) then pcall(ns.Knowledge.Run, "capture:on") end
end
local kCombatSid
ns.On("PLAYER_REGEN_DISABLED", function()
    if not capturing() or not ns.Knowledge then return end
    local sid = ns.db.logs.session.sid
    if kCombatSid == sid then return end
    kCombatSid = sid
    if type(g("C_Timer")) == "table" then C_Timer.After(2, function() pcall(ns.Knowledge.Run, "combat") end) end
end)

ns.captureModules = ns.captureModules or {}
ns.captureModules[#ns.captureModules + 1] = { name = "spell knowledge + HSM inference",
    start = function() startKnowledge() return I.Start() end,
    stop = function()
        local c = I.Stop()
        return c and string.format("HSM %d prediction(s), %d inference(s), %d live contradiction(s)", c.predictions, c.inferences, c.contradictions)
    end }
