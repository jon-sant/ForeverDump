-- ForeverDump v2.2 - FD_Logs: ONE macro that captures everything.  /fdump logs [on|off|status|macro]
--
-- Click ON  (out of combat): client logging (combat log, chat log, advancedCombatLogging, scriptErrors, taintLog),
--           event recorder, combat recorder, error capture, out-of-combat probe, profiler snapshot; queues
--           /fdump all if this build has no full dump yet. The first PLAYER_REGEN_DISABLED of each recording
--           session takes an in-combat probe automatically. Survives /reload: recording resumes after login.
-- Click OFF (out of combat): stops the recorders (combat recorder takes its damage meter snapshot), final
--           probe + profiler snapshot, logging off (CVars restored, taintLog 0), summary - ALL synchronously,
--           because the macro's last line is /reload, which saves SavedVariables right after this handler.
--
-- Macro body (rewritten by the addon after every click, out of combat; EditMacro is refused in combat):
--   /fdump logs
--   /stopmacro [combat]      <- secure command; in combat nothing below runs (addon also refuses in combat)
--   /combatlog               <- only if the combat log is not yet in the target state (Blizzard toggle)
--   /chatlog                 <- only if the chat log is not yet in the target state (Blizzard toggle)
--   /reload                  <- only while capture is ON, i.e. on the OFF click
-- The addon never calls LoggingCombat/LoggingChat itself by default (protection unverified on Forever; a blocked
-- call shows a popup). /combatlog and /chatlog run in Blizzard's handlers on a human click. No /run is used,
-- so GetScriptsDisallowedForBeta() does not matter.  /stopmacro, /reload, /combatlog, /chatlog verified in
-- Blizzard_ChatFrameBase/Shared/SlashCommands.lua (forever branch, build 70245).
local _, ns = ...
local Logs = {}
ns.Logs = Logs

local MACRO_NAME = "FD_Logs"
local MACRO_ICON = "INV_Misc_Note_01"
local MAX_MACRO_CHARS = 255
local pendingMacro = false
local combatProbed = false

local function cfg() return ns.config.logs end
local function state()
    if type(ns.db.logs) ~= "table" then ns.db.logs = { on = false } end
    return ns.db.logs
end
local function now() return time and time() or nil end

local function cvarGet(name)
    local C = rawget(_G, "C_CVar")
    local f = (type(C) == "table" and C.GetCVar) or rawget(_G, "GetCVar")
    if type(f) ~= "function" then return nil end
    local ok, v = pcall(f, name)
    if ok and not ns.IsSecret(v) then return v end
end

local function cvarSet(name, value)
    local C = rawget(_G, "C_CVar")
    local f = (type(C) == "table" and C.SetCVar) or rawget(_G, "SetCVar")
    if type(f) ~= "function" then return false, "SetCVar missing" end
    local ok, res = pcall(f, name, tostring(value))
    if ok and res == false then return false, "SetCVar returned false" end
    return ok, res
end

-- Current client logging state; nil when not readable (never calls LoggingCombat/LoggingChat unless allowed).
function Logs.ClientState()
    local C = rawget(_G, "C_ChatInfo")
    local combat, chat
    if type(C) == "table" and type(C.IsLoggingCombat) == "function" then
        local ok, v = pcall(C.IsLoggingCombat)
        if ok and not ns.IsSecret(v) then combat = v end
    end
    if type(C) == "table" and type(C.IsLoggingChat) == "function" then
        local ok, v = pcall(C.IsLoggingChat)
        if ok and not ns.IsSecret(v) then chat = v end
    end
    if cfg().callLogging then
        local lc, lch = rawget(_G, "LoggingCombat"), rawget(_G, "LoggingChat")
        if combat == nil and type(lc) == "function" then
            local ok, v = pcall(lc) if ok then combat = v end
        end
        if chat == nil and type(lch) == "function" then
            local ok, v = pcall(lch) if ok then chat = v end
        end
    end
    return combat, chat
end

-- Macro body for the NEXT click (target = not state().on).
function Logs.MacroBody(target)
    if target == nil then target = not state().on end
    local combat, chat = Logs.ClientState()
    local lines = { "/fdump logs", "/stopmacro [combat]" }
    if not cfg().callLogging then
        if combat == nil or combat ~= target then lines[#lines + 1] = "/combatlog" end
        if cfg().chat and (chat == nil or chat ~= target) then lines[#lines + 1] = "/chatlog" end
    end
    if not target and cfg().autoReload then lines[#lines + 1] = "/reload" end
    local body = table.concat(lines, "\n")
    assert(#body <= MAX_MACRO_CHARS)
    return body
end

local function maxAccountMacros()
    local v = rawget(_G, "MAX_ACCOUNT_MACROS")
    if type(v) ~= "number" and type(rawget(_G, "Constants")) == "table" and type(Constants.MacroConsts) == "table" then
        v = Constants.MacroConsts.MAX_ACCOUNT_MACROS
    end
    return type(v) == "number" and v or 120
end

-- Create or update FD_Logs. onlyUpdate: never create (used at login). Out of combat only.
function Logs.EnsureMacro(silent, onlyUpdate)
    local getIndex, create, edit, num = rawget(_G, "GetMacroIndexByName"), rawget(_G, "CreateMacro"),
        rawget(_G, "EditMacro"), rawget(_G, "GetNumMacros")
    if type(getIndex) ~= "function" or type(create) ~= "function" or type(edit) ~= "function" then
        ns.db.macro = { ok = false, err = "macro API missing", time = now() }
        if not silent then ns.Print("FD_Logs: macro API missing on this client.") end
        return false, "macro API missing"
    end
    local okI, index = pcall(getIndex, MACRO_NAME)
    index = okI and tonumber(index) or 0
    if onlyUpdate and index == 0 then return false, "no macro" end
    local rec = { time = now() }
    ns.db.macro = rec
    if ns.InCombat() then
        pendingMacro = true
        rec.ok, rec.err = false, "in combat (deferred until PLAYER_REGEN_ENABLED)"
        if not silent then ns.Print("FD_Logs: can't edit macros in combat; will update after combat.") end
        return false, rec.err
    end
    local body = Logs.MacroBody()
    rec.body, rec.chars = body, #body
    if index > 0 then
        local ok, res = pcall(edit, index, MACRO_NAME, MACRO_ICON, body)
        rec.ok, rec.action, rec.index = ok, "updated", ok and res or index
        if not ok then rec.err = tostring(res) end
    else
        local numAccount = 0
        if type(num) == "function" then
            local okN, a = pcall(num)
            numAccount = okN and tonumber(a) or 0
        end
        local max = maxAccountMacros()
        rec.slots = { used = numAccount, max = max }
        if numAccount >= max then
            rec.ok, rec.err = false, string.format("no free account macro slot (%d/%d)", numAccount, max)
            ns.Print("FD_Logs: " .. rec.err .. ". Delete a general macro and try again.")
            return false, rec.err
        end
        local ok, res = pcall(create, MACRO_NAME, MACRO_ICON, body, nil) -- nil = account-wide (General tab)
        rec.ok, rec.action, rec.index = ok and res ~= nil, "created", res
        if not ok then rec.err = tostring(res) elseif res == nil then rec.err = "CreateMacro returned nil" end
    end
    pendingMacro = not rec.ok
    if not silent or not rec.ok then
        ns.Print(string.format("FD_Logs macro %s%s. Drag it from /macro (General tab) to a bar: click = capture everything, "
            .. "click again = stop, save and /reload.", rec.ok and (rec.action or "ok") or "FAILED", rec.err and (": " .. rec.err) or ""))
    end
    return rec.ok, rec.err
end

local function setCVars(target, changes)
    local s, c = state(), cfg()
    local function setCVar(name, value)
        local before = cvarGet(name)
        if before == nil then changes[#changes + 1] = name .. " missing" return end
        if tostring(before) == tostring(value) then return before end
        local ok, err = cvarSet(name, value)
        local after = cvarGet(name)
        if ok and tostring(after) == tostring(value) then
            changes[#changes + 1] = string.format("%s %s->%s", name, tostring(before), tostring(value))
        else
            changes[#changes + 1] = string.format("|cffff5555%s not set (%s)|r", name, tostring(err or after))
        end
        return before
    end
    if target then
        local fresh = s.saved == nil -- keep the pre-ON values if ON is requested twice
        s.saved = s.saved or {}
        if c.advanced then
            local before = setCVar("advancedCombatLogging", 1)
            if fresh then s.saved.advancedCombatLogging = before end
        end
        if c.scriptErrors then
            local before = setCVar("scriptErrors", 1)
            if fresh then s.saved.scriptErrors = before end
        end
        local debugOn = ns.Controls and ns.Controls.DebugOn()
        if c.taintLog and c.taintLog > 0 and not debugOn then
            local before = setCVar("taintLog", c.taintLog)
            if fresh then s.saved.taintLog = before end
        end
    else
        local saved = s.saved or {}
        if c.advanced then setCVar("advancedCombatLogging", saved.advancedCombatLogging or "0") end
        if c.scriptErrors then setCVar("scriptErrors", saved.scriptErrors or "0") end
        if not (ns.Controls and ns.Controls.DebugOn()) then setCVar("taintLog", saved.taintLog or 0) end
        s.saved = nil
    end
    if c.callLogging then
        local lc, lch = rawget(_G, "LoggingCombat"), rawget(_G, "LoggingChat")
        if type(lc) == "function" then
            local ok, err = pcall(lc, target)
            if not ok then changes[#changes + 1] = "|cffff5555LoggingCombat failed: " .. tostring(err) .. "|r" end
        end
        if c.chat and type(lch) == "function" then
            local ok, err = pcall(lch, target)
            if not ok then changes[#changes + 1] = "|cffff5555LoggingChat failed: " .. tostring(err) .. "|r" end
        end
    end
end

-- Is there a full dump (docs + api sections) for the running build?
function Logs.HaveFullDump()
    local secs = ns.db.sections or {}
    local build = ns.Meta().build
    for _, name in ipairs({ "docs", "api", "globals", "widgets" }) do
        local sct = secs[name]
        if type(sct) ~= "table" or type(sct.meta) ~= "table" or sct.meta.build ~= build then return false end
    end
    return true
end

-- start every recorder that is not running yet; returns list of what was started
local function startCapture(why)
    local c, started = cfg(), {}
    combatProbed = false
    if c.errors and ns.Errors then
        ns.config.errors.enabled = true
        if not ns.Errors.IsInstalled() then ns.Errors.Install() end
        started[#started + 1] = "error capture"
    end
    if c.recorder and ns.Recorder and not ns.Recorder.IsActive() then
        ns.Recorder.Start()
        if ns.Recorder.IsActive() then started[#started + 1] = "event recorder" end
    end
    if c.combat and ns.CombatLog and not ns.CombatLog.IsActive() then
        ns.CombatLog.Start({})
        if ns.CombatLog.IsActive() then started[#started + 1] = "combat recorder" end
    end
    if c.sweep and ns.Secrets and ns.config.secrets.sweep and not ns.Secrets.IsSweeping() then
        if ns.Secrets.StartSweep() then started[#started + 1] = "secrets verifier sweep" end
    end
    if why == "on" and ns.Restrictions and ns.config.restrictions and ns.config.restrictions.enabled ~= false then
        local okR = pcall(ns.Restrictions.Begin, ns.db.logs and ns.db.logs.session and ns.db.logs.session.sid)
        if okR then started[#started + 1] = "restrictions tracker" end
    end
    if why == "on" and ns.Controls and ns.config.secrets.controls ~= false then
        local okC = pcall(ns.Controls.Run, "capture:on")
        if okC then started[#started + 1] = "secrets controls" end
    end
    if why == "on" and ns.Lab and ns.config.lab.auto ~= false then
        local okL = pcall(ns.Lab.Run, "capture:on")
        if okL then started[#started + 1] = "workarounds lab" end
    end
    if why == "on" then
        -- v2.2 capture modules (combat probe set, token survey, knowledge + HSM inference, HSM window): always on
        for _, m in ipairs(ns.captureModules or {}) do
            local okM, res = pcall(m.start, why)
            if okM and res then started[#started + 1] = m.name
            elseif not okM then ns.NoteSelfError("capture:" .. m.name, res) end
        end
    end
    if ns.Lab and ns.config.lab.poll and not ns.Lab.Polling() then
        ns.Lab.StartPoll()
        started[#started + 1] = "secrecy polling " .. tostring(ns.config.lab.pollInterval) .. "s"
    end
    if why == "on" then
        if c.probe and ns.Probe then
            local ok = pcall(ns.Probe.Run, "capture:on", "outOfCombat", true)
            if ok then started[#started + 1] = "probe (out of combat)" end
        end
        if c.profile and ns.Profiler then
            local ok = pcall(ns.Profiler.Snapshot, "capture:on")
            if ok then started[#started + 1] = "profiler snapshot" end
        end
    end
    return started
end

local function lastSession(db)
    local list = db and db.sessions
    return type(list) == "table" and list[#list] or nil
end

-- running totals over all segments of one capture (a /reload splits a capture into several sessions)
local function addTotals(key, n)
    local sess = ns.db.logs and ns.db.logs.session
    if not sess then return end
    sess.totals = sess.totals or {}
    sess.totals[key] = (sess.totals[key] or 0) + (n or 0)
end

local function stopCapture(reason)
    local c, out = cfg(), {}
    if ns.CombatLog and ns.CombatLog.IsActive() then
        ns.CombatLog.Stop()  -- includes the post-combat C_DamageMeter snapshot when out of combat
        local cs = lastSession(ForeverDumpCombatLogDB)
        if cs then
            cs.endedBy = reason
            addTotals("combatEvents", cs.total) addTotals("unitEvents", cs.combatEvents)
            addTotals("secretEntries", cs.secretEntries) addTotals("combatSessions", 1)
            addTotals("damageMeter", cs.damageMeter and #cs.damageMeter or 0)
            out.combat = string.format("combat recorder %d events (%d UNIT_COMBAT/UNIT_SPELLCAST, %d with secrets, %d damage meter snapshot(s))",
                cs.total or 0, cs.combatEvents or 0, cs.secretEntries or 0, cs.damageMeter and #cs.damageMeter or 0)
        end
    end
    if ns.Recorder and ns.Recorder.IsActive() then
        ns.Recorder.Stop()
        local rs = lastSession(ForeverDumpRecordDB)
        if rs then
            rs.endedBy = reason
            addTotals("recordEvents", rs.total) addTotals("recordSessions", 1)
            out.record = string.format("event recorder %d events (%d kept)", rs.total or 0, rs.kept or 0)
        end
    end
    if ns.Secrets and ns.Secrets.IsSweeping() then
        local n = ns.Secrets.StopSweep()
        out.sweep = string.format("secrets sweep %d getter calls", n or 0)
    end
    if ns.Lab and ns.Lab.Polling() then ns.Lab.StopPoll() end
    if reason == "off" and ns.Controls and ns.config.secrets.controls ~= false then pcall(ns.Controls.Run, "capture:off") end
    for _, m in ipairs(ns.captureModules or {}) do
        local okM, res = pcall(m.stop, reason)
        if okM and type(res) == "string" then out["module:" .. m.name] = res end
    end
    if ns.Baseline then
        local okB, sig = pcall(ns.Baseline.Capture, reason)
        if okB and sig then out.baseline = string.format("baseline signature v%d for build %s", sig.v, tostring(sig.build)) end
    end
    if reason == "off" and ns.Restrictions then
        local okR, rs = pcall(ns.Restrictions.End)
        if okR and rs then out.restrictions = string.format("restrictions %d flip(s), %d context marker(s)", rs.flips or 0, rs.markers or 0) end
        local okH, h = pcall(ns.Restrictions.Health)
        if okH then out.health = h end
    end
    if reason == "off" then
        if c.probe and ns.Probe then pcall(ns.Probe.Run, "capture:off", "outOfCombatEnd", true) end
        if c.profile and ns.Profiler then pcall(ns.Profiler.Snapshot, "capture:off") end
        if ns.Errors and ns.Errors.BugGrabber() then
            local okBG, r = pcall(ns.Errors.ImportBugGrabber, "capture:off")
            if okBG and r then out.bugGrabber = string.format("BugGrabber %d session error(s) copied", #r.errors) end
        end
    end
    return out
end

local function errorCounts()
    local log = ForeverDumpLogDB or {}
    local unique, total, mine = 0, 0, 0
    for _, e in ipairs(log.errors or {}) do
        unique, total = unique + 1, total + (e.count or 1)
        if e.addon == ns.ADDON then mine = mine + 1 end
    end
    return unique, total, #(log.blocked or {}), mine
end

local function onOff(v) if v == nil then return "unknown" end return v and "ON" or "OFF" end

function Logs.Set(target, source)
    local s, c = state(), cfg()
    if ns.InCombat() then
        s.lastRefused = { time = now(), target = target, source = source }
        ns.Print(string.format("|cffff5555FD_Logs: in combat - capture stays %s.|r The macro stops before its log toggles%s; "
            .. "click FD_Logs again after combat.", onOff(s.on), target and "" or " and /reload"))
        return false
    end
    local changes = {}
    setCVars(target, changes)
    if target then
        s.on = true
        s.session = { startedAt = now(), date = date and date("%Y-%m-%d %H:%M:%S") or nil, build = ns.Meta().build,
            resumes = 0, combatProbes = 0, sid = ns.NewSessionId("cap"), anchor = ns.TimeAnchor(), anchors = {} }
        local started = startCapture("on")
        local queued = false
        if c.fullDump and not Logs.HaveFullDump() then
            if ns.IsBusy() then queued = "already running" else ns.RunAll() queued = true end
        end
        s.lastToggle = { time = now(), source = source, target = true, changes = changes, started = started, fullDump = queued }
        ns.Print(string.format("|cff33ff99ForeverDump logging: ON|r - %s%s", table.concat(started, ", "),
            (#changes > 0) and ("; " .. table.concat(changes, ", ")) or ""))
        if queued == true then
            ns.Print("no full dump for build " .. tostring(ns.Meta().build) .. " yet: /fdump all is running in the background (chunked, pauses in combat).")
        end
        ns.Print("Play normally (combat, buffs, whatever you are testing), then click FD_Logs again to stop, save and reload.")
        -- the macro's /combatlog and /chatlog lines run right after this: verify, then rewrite the macro for OFF
        local after = rawget(_G, "C_Timer") and C_Timer.After
        local function verify()
            local combat, chat = Logs.ClientState()
            s.client = { combat = combat, chat = chat, checked = now() }
            local bad = {}
            if combat == false then bad[#bad + 1] = "combat log is OFF (type /combatlog once)" end
            if c.chat and chat == false then bad[#bad + 1] = "chat log is OFF (type /chatlog once)" end
            s.mismatch = #bad > 0 or nil
            ns.Print(string.format("ForeverDump logging: combat log %s -> Logs/WoWCombatLog*.txt%s%s", onOff(combat),
                c.chat and (", chat log " .. onOff(chat)) or "", #bad > 0 and (" |cffff5555" .. table.concat(bad, "; ") .. "|r") or ""))
            Logs.EnsureMacro(true)
        end
        if type(after) == "function" then after(0.3, verify) else verify() end
    else
        -- everything below is synchronous: the macro's next lines may be /combatlog, /chatlog and /reload
        local wasOn = s.on
        local stoppedOut = stopCapture("off")
        s.on = false
        local t = (s.session and s.session.totals) or {}
        local stopped = {
            combat = string.format("combat recorder %d events in %d session(s) (%d UNIT_COMBAT/UNIT_SPELLCAST, %d with secrets, "
                .. "%d damage meter snapshot(s))", t.combatEvents or 0, t.combatSessions or 0, t.unitEvents or 0,
                t.secretEntries or 0, t.damageMeter or 0),
            record = string.format("event recorder %d events in %d session(s)", t.recordEvents or 0, t.recordSessions or 0),
        }
        local unique, total, blocked, mine = errorCounts()
        local combat, chat = Logs.ClientState()
        local body = ns.db.macro and ns.db.macro.body or ""
        local fromMacro = source == "toggle" and body:find("/reload", 1, true) ~= nil
        local sess = s.session or {}
        local summary = {
            time = now(), source = source, changes = changes, combatProbes = sess.combatProbes, resumes = sess.resumes,
            totals = t, errors = unique, errorTotal = total, blocked = blocked,
            ownErrors = mine, combatLog = combat, chatLog = chat, reloading = fromMacro,
            durationSec = sess.startedAt and now() and (now() - sess.startedAt) or nil,
            sid = sess.sid, health = stoppedOut.health, restrictions = stoppedOut.restrictions,
        }
        s.lastSession, s.session = summary, nil
        s.lastToggle = { time = now(), source = source, target = false, changes = changes }
        s.verifyAfterLogin = true
        ns.Print(string.format("|cff33ff99ForeverDump logging: OFF|r%s - %s; %s; %d Lua error(s) (%d unique, %d from ForeverDump), "
            .. "%d blocked/warning event(s); in-combat probes %d%s",
            wasOn and "" or " (was already off)", stopped.combat, stopped.record, total, unique, mine, blocked, sess.combatProbes or 0,
            (#changes > 0) and ("; " .. table.concat(changes, ", ")) or ""))
        if stoppedOut.restrictions then ns.Print(stoppedOut.restrictions) end
        if ns.Restrictions then local okT, ht = pcall(ns.Restrictions.HealthText) if okT then ns.Print(ht) end end
        stopped.bugGrabber = stoppedOut.bugGrabber
        if stopped.bugGrabber then ns.Print(stopped.bugGrabber .. " into ForeverDumpLogDB.bugGrabber") summary.bugGrabber = stopped.bugGrabber end
        local fileNote = (combat and (body:find("/combatlog", 1, true) and source == "toggle")) and "being switched OFF by FD_Logs"
            or onOff(combat)
        ns.Print(string.format("combat log file: %s (Logs\\WoWCombatLog*.txt is complete once the client flushes it on toggle/logout)%s",
            fileNote, (chat and not body:find("/chatlog", 1, true)) and "; chat log still ON (type /chatlog)" or ""))
        if fromMacro then
            ns.Print("|cff33ff99Saving: FD_Logs reloads the UI now.|r Then send WTF\\...\\SavedVariables\\ForeverDump.lua and the Logs folder files.")
        else
            ns.Print("|cffffff00Type /reload (or log out) now|r so the client writes SavedVariables\\ForeverDump.lua.")
        end
        -- if no reload follows (typed command), rewrite the macro a moment later
        local after = rawget(_G, "C_Timer") and C_Timer.After
        if type(after) == "function" then after(0.3, function() Logs.EnsureMacro(true, true) end) end
    end
    return true
end

function Logs.Toggle(source) return Logs.Set(not state().on, source or "toggle") end

function Logs.Status()
    local s = state()
    local combat, chat = Logs.ClientState()
    local m = ns.db.macro or {}
    ns.Print(string.format("capture: %s%s; client combat log %s, chat log %s; advancedCombatLogging=%s scriptErrors=%s taintLog=%s; "
        .. "event recorder %s, combat recorder %s; macro FD_Logs: %s",
        s.on and "ON" or "OFF", (s.session and s.session.resumes and s.session.resumes > 0) and (" (resumed " .. s.session.resumes .. "x)") or "",
        onOff(combat), onOff(chat), tostring(cvarGet("advancedCombatLogging")), tostring(cvarGet("scriptErrors")),
        tostring(cvarGet("taintLog")), onOff(ns.Recorder and ns.Recorder.IsActive()), onOff(ns.CombatLog and ns.CombatLog.IsActive()),
        m.ok and (m.action or "ok") or (m.err or "not created")))
end

function Logs.Command(rest)
    local sub = string.lower(rest[1] or "")
    if sub == "" or sub == "toggle" then Logs.Toggle("toggle")
    elseif sub == "on" then Logs.Set(true, "slash")
    elseif sub == "off" then Logs.Set(false, "slash")
    elseif sub == "macro" or sub == "macros" then Logs.EnsureMacro()
    else Logs.Status() end
end

-- in-combat probe at the first combat of each recording session
ns.On("PLAYER_REGEN_DISABLED", function()
    local s = ns.db and ns.db.logs
    if not (s and s.on and cfg().combatProbe and ns.Probe) or combatProbed then return end
    combatProbed = true
    if s.session then s.session.combatProbes = (s.session.combatProbes or 0) + 1 end
    local after = rawget(_G, "C_Timer") and C_Timer.After
    local function run() if ns.InCombat() then pcall(ns.Probe.Run, "capture:combat", "inCombat", true) end end
    if type(after) == "function" then after(1, run) else run() end
end)

ns.On("PLAYER_REGEN_ENABLED", function()
    if pendingMacro then Logs.EnsureMacro(true) end
end)

-- /reload or logout: save running recorder sessions (they would otherwise be lost)
ns.On("PLAYER_LOGOUT", function()
    if not ns.db then return end
    stopCapture("logout")
end)

-- login / after reload: resume capture if it was ON, verify an OFF, refresh the macro body
ns.On("PLAYER_LOGIN", function()
    if not ns.db then return end
    local s = state()
    if s.on then
        s.session = s.session or { startedAt = now(), resumes = 0, combatProbes = 0 }
        s.session.resumes = (s.session.resumes or 0) + 1
        s.session.anchors = s.session.anchors or {}
        if #s.session.anchors < 50 then s.session.anchors[#s.session.anchors + 1] = ns.TimeAnchor() end
        local started = startCapture("resume")
        ns.Print(string.format("|cff33ff99ForeverDump capture is still ON|r (resumed after reload: %s). Click FD_Logs to stop, save and reload.",
            table.concat(started, ", ")))
    elseif s.verifyAfterLogin then
        s.verifyAfterLogin = nil
        local combat, chat = Logs.ClientState()
        local bad = {}
        if combat then bad[#bad + 1] = "combat log still ON (type /combatlog)" end
        if cfg().chat and chat then bad[#bad + 1] = "chat log still ON (type /chatlog)" end
        ns.Print(string.format("ForeverDump: capture OFF, files saved (combat log %s, chat log %s)%s", onOff(combat), onOff(chat),
            #bad > 0 and (" |cffff5555" .. table.concat(bad, "; ") .. "|r") or ". Send SavedVariables\\ForeverDump.lua + Logs\\ files."))
    end
    local after = rawget(_G, "C_Timer") and C_Timer.After
    if type(after) == "function" then after(2, function() Logs.EnsureMacro(true, true) end) else Logs.EnsureMacro(true, true) end
end)
