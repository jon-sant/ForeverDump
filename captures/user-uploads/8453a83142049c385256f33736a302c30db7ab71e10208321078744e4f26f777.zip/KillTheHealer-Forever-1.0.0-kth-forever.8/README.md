# K.T.H. Forever 1.0.0-kth-forever.6 (healer verdict = healing output, class-group meter rules)

K.T.H. (Kill The Healer) by Scone, built on H.H.T.D. by John Wellesz, ported to WoW Forever 1.60.1 (toc 16001).
**All Rights Reserved. This is a private port for personal use. Do not redistribute it.**

## Install
1. Close WoW Forever.
2. In `World of Warcraft/_forever_/Interface/AddOns/`, delete the old `KTH` folder (the baseline build).
3. Copy `AddOns/KTH` there.
4. Optional: copy `AddOns/KTH_ForeverDiag` (the same probe as in the baseline). It writes only to its own frame and
   SavedVariables. Keep it for one more BG if you want a second measurement with the port. Otherwise leave it out.
5. Start the client.

## In game
- `/kthg`: settings window (K.T.H.'s own panel). `/hhtd` opens the H.H.T.D. options window. On Forever, nothing is
  printed to chat.
- K.T.H. messages appear in its own small frame, top-left (`KTH_ForeverMessageFrame`). `/kthlog` shows or hides it.
- Healer markers (forever.5, your rule): a player is marked only when most of what they do is healing (60% or more
  of their output) or their healing is far above everyone else's (6x the group's median). Mana and class no longer mark
  anyone: feral, balance and resto druids all show mana. Class only rules out classes that cannot heal.
- Where the evidence comes from: the damage meter (healing done vs damage done), read each time you leave combat;
  and casts of a player that heal a teammate in the same moment. Enemy names are secret in the meter, so in a BG an
  enemy is matched by class through the scoreboard: exact when they are the only enemy of that class. With several of
  one class (forever.6): all are marked when the class as a whole is mostly healing (63% or more of that class's
  combined output, with a heal row for each of them); none are marked when every one of them did real damage and no
  heal row could be a healer's; in between, a player of that class whose own casts healed a teammate (and never hit an
  enemy) is marked while fewer than 3 enemies are marked as healers (no logged BG had more than 3 enemy healers).
- A mark stays until there is clear contrary evidence (healing under 35% of output), so the icon does not flicker.
  No mark until there is enough evidence: expect enemy healers to appear after the first fights, not on first sight.
- Mouse-over an enemy healer: K.T.H.'s alarm sound and "is a healer" message; click it: the target-lock sound
  (forever.3 fix: enemy GUIDs are secret on Forever, the unit is now found by its full name).
- `/kthsound` plays K.T.H.'s five alert sounds 2 s apart and shows whether the client played each one
  (`willPlay`) in K.T.H.'s frame. Please run it once and send the result: the sound IDs are unverified on Forever.
- Arena, world, dungeons and raids: the same healing-output rule. The scoreboard join is used only in BGs, so enemy
  meter rows cannot be matched outside BGs; friendly meter rows (names readable) and cast evidence still work. Heal
  evidence runs in arenas and the open world, and in dungeons and raids when K.T.H.'s PvE option is on. Arena and
  world readability has not been captured yet, so expect few enemy marks there.
- K.T.H. logs each enemy plate's verdict changes to its SavedVariables (`ForeverPlateLog`). Send
  `WTF/Account/<acct>/SavedVariables/KTH.lua` after a BG or an arena match.
- `/hhtdp` posts K.T.H.'s healer placard to BG chat. This is K.T.H.'s original feature and only runs when you type it.

## What to expect (replays of 3 captured BGs with the real scoreboard and real damage-meter reads: runs 16, 17, 18)
- Enemy marks: 5 of 5 right (forever.3: 8 of 10), 0 DPS druids marked (forever.3: both), 0 icon on/off flicker
  (forever.3: 23 on non-healers). The resto druid in run 16 is found.
- Found: 5 of 9 enemy healers (forever.3: 8 of 9, but by class). Not found: run 18's three priests (the meter shows
  two of them healing far above the group, but enemy names are secret, so which two is unknown) and run 17's holy
  paladin (one of three enemy paladins).
- When: enemy healers were identified 4 to 11 minutes in; the icon showed the next time their plate was on screen
  (6 to 12.5 minutes). In these recordings the damage-meter data starts late (the
  recorder kept only its last 21 reads), so live it can be earlier.
- Friendly healers: 7 of 8 found, 12 of 12 claims right.
- Mouse-over alert: plays for every marked enemy you hover (72 of 72).
- No "blocked from an action only available to the Blizzard UI" popup: the port never registers COMBAT_LOG_EVENT_UNFILTERED.

See `FOREVER-PORT.md` for every change and its evidence, `KTH-REVIEW.md` for the comparison with our own tools,
`tests/` for the harness, and `original/KTH` for the untouched original.

## forever.7
- Spec shortcut: when a healer spec is readable (arena opponent spec, HEALER group role, post-match scoreboard spec) or an enemy casts Swiftmend / Holy Shock where the spell ID is readable, the player is marked at once. Missing spec or spells never counts against anyone.
- In battlegrounds Forever hides enemy spell IDs and specs during the match, so marks still come from the out-of-combat meter (typically several minutes after a healer starts healing).
- `/kthdebug on|off|clear`: records meter reads and mark/revoke decisions to SavedVariables (HHTD.db.global.ForeverDebug, last 5 sessions) for later analysis. Local only.

## forever.8
- Instant healer flags use your list: Penance, Power Infusion (Discipline priest), Prayer of Mending (Holy priest), Light's Vigil (Holy paladin), Wild Growth (Restoration druid), Riptide (Restoration shaman). Swiftmend and Holy Shock no longer flag instantly.
- They only fire where the game shows the enemy's spell ID. Forever hides it in battlegrounds, so BG marks still come from the meter.
