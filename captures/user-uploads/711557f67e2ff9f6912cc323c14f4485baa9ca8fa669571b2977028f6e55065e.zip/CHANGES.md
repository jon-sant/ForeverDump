# ForeverDump: changes from v1 to v2.0.0

v1 (`ForeverDump.lua`, 333 lines; one SavedVariable `ForeverDumpDB`) collected the APIs (`C_*` functions), events,
enums and CVars in one pass and showed them in a copy window via `/fdump` and `/foreverdump`. **All of that still
works:** plain `/fdump` runs the same quick dump into the same `ForeverDumpDB` fields.

## New in v2
- **Structure:** 19 Lua files; `.toc` Interface 16001, Version 2.0.0; 6 SavedVariables (DB, DocsDB, StringsDB,
  RecordDB, LogDB, CombatLogDB) so large data stays separate; `schemaVersion` plus a meta header (build, locale,
  `WOW_PROJECT_ID` and **every** `WOW_PROJECT_*` constant, with Forever = 18 / CAMELOT, never assumed mainline;
  `C_AddOns.GetScriptsDisallowedForBeta()`).
- **Sections** (`/fdump all` or one at a time): full APIDocumentation walk with documented/present cross-check;
  C_ namespaces; global tables, functions (secure/insecure), constants and Enum; all global strings; widget API
  (methods per type, inheritance; `risky` option); XML templates; named frames; addons; CVars and console commands;
  protected info (issecurevariable plus doc restriction and secret flags); extras (bindings, slash commands, settings,
  fonts, SOUNDKIT, maps, classes, spells, talents, currencies); opt-in getters; profiling snapshot.
- **Recorders:** event recorder registers documented events individually (no RegisterAllEvents) and saves the
  skipped restricted/SecureOnly events with reasons. The Forever-safe combat recorder (`/fdump cl`) records
  UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING with swing range, COMBAT_TEXT_UPDATE with the C_CombatText getter,
  encounter and regen context with restriction states, and post-combat C_DamageMeter snapshots. Legacy CLEU is
  opt-in only (`cl cleu-force`, guarded). Probe (tooltips and getters, now or next combat).
- **Diagnostics:** chained Lua error handler (stack and locals); ADDON_ACTION_BLOCKED/FORBIDDEN, MACRO_ACTION_*,
  LUA_WARNING and ADDON_RESTRICTION_STATE_CHANGED log.
- **FD_Logs:** `/fdump logs` and the single account macro FD_Logs toggle the combat log, chat log,
  advancedCombatLogging, scriptErrors and taintLog together, with state in SavedVariables and a clear chat line.
- **Safety and UX:** refuses heavy work in combat; frame-sliced chunking with `/fdump cancel`; secret-value detection
  everywhere (`<secret>`); per-section toggles, clear and set; capped copy window; status view; /reload reminder.
- **Box-side converter** (`tools/`): SV to JSON, LuaLS stubs, luacheck std, busted mocks and replay, API checker,
  diff, combat log file parser, taint.log parser, error report, Ketho comparison.
