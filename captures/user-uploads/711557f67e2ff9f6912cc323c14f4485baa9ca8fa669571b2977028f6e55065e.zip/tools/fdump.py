#!/usr/bin/env python3
"""ForeverDump converter CLI. Run `python3 tools/fdump.py -h` for subcommands.
DUMP may be a SavedVariables ForeverDump.lua (parsed safely, never executed), a dump.json written by
`fdump.py json`, or the folder containing that dump.json."""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fdump import apicheck, combatlog, diff as diffmod, export_json, ketho, luacheck_gen, luals, mocks, taintlog  # noqa: E402
from fdump.dump import Dump  # noqa: E402
from fdump.luasv import as_list  # noqa: E402


def _write(path, text):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def info(dump):
    m = dump.meta()
    consts = m.get("projectConstants") or {}
    names = [k for k, v in consts.items() if v == m.get("projectID") and k != "WOW_PROJECT_ID"]
    lines = ["build:     %s" % dump.build_label(),
             "project:   WOW_PROJECT_ID=%s (%s)" % (m.get("projectID"), m.get("projectName") or ",".join(names) or "unknown"),
             "constants: %s" % ", ".join("%s=%s" % kv for kv in sorted(consts.items())),
             "scriptsDisallowedForBeta: %s" % m.get("scriptsDisallowedForBeta"),
             "locale:    %s, dumped %s" % (m.get("locale"), m.get("date")),
             "sections:  %s" % ", ".join(sorted(dump.sections)),
             "docs:      %s systems" % len(dump.doc_systems()),
             "strings:   %d" % len(dump.strings),
             "recorder:  %d session(s); combat log: %d session(s)" % (
                 len(as_list(dump.record.get("sessions"))), len(as_list(dump.combatlog.get("sessions")))),
             "errors:    %d unique, %d blocked/forbidden/warnings" % (
                 len(as_list(dump.log.get("errors"))), len(as_list(dump.log.get("blocked"))))]
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(prog="fdump.py", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name, help_, dump=True, out=None):
        sp = sub.add_parser(name, help=help_)
        if dump:
            sp.add_argument("dump")
        if out:
            sp.add_argument("-o", "--out", default=out)
        return sp

    add("info", "print build / project / what the dump contains")
    add("json", "(1) JSON per section", out="out/json")
    add("luals", "(2) LuaLS ---@meta annotation stubs", out="out/luals")
    sp = add("luacheck", "(3) luacheck config with std 'forever'", out="out/.luacheckrc")
    sp.add_argument("--std", default="forever")
    add("mocks", "(4) busted mocks + replay helper + fixtures", out="out/mocks")
    sp = add("check", "(5) API-check an addon folder against the dump")
    sp.add_argument("addon")
    sp.add_argument("--json", help="also write findings as JSON")
    sp.add_argument("--strict", action="store_true", help="exit non-zero on warnings too")
    sp = add("diff", "(6) diff two dumps (OLD NEW)", dump=False, out=None)
    sp.add_argument("old")
    sp.add_argument("new")
    sp.add_argument("-o", "--out", help="markdown output (default stdout)")
    sp.add_argument("--json", help="also write JSON")
    add("all", "json + luals + luacheck + mocks into one folder", out="out")
    sp = add("combatlog", "parse Logs/WoWCombatLog*.txt into CLEU replay fixtures (.json and/or .lua)", dump=False)
    sp.add_argument("logfile")
    sp.add_argument("-o", "--out", default="out/combatlog_file.json", help=".json or .lua (Lua fixture for replay.lua)")
    sp.add_argument("--year", type=int, help="year for logs whose timestamps lack one")
    sp.add_argument("--utc-offset", type=float, help="hours east of UTC for timestamps without a zone (default: box zone)")
    sp.add_argument("--shape", choices=["cleu", "raw"], default="cleu")
    sp.add_argument("--limit", type=int)
    sp.add_argument("--subevents", help="comma-separated subevent filter")
    sp.add_argument("--forever-player", metavar="GUID",
                    help="also synthesize Forever-style events (UNIT_SPELLCAST_*, UNIT_COMBAT, PLAYER_SWING) for this player GUID")
    sp = add("cl-compare", "cross-check a parsed file fixture against a /fdump cl session in DUMP", dump=False)
    sp.add_argument("fixture")
    sp.add_argument("dump")
    sp.add_argument("--session", type=int, default=0, help="1-based session index (default: last)")
    sp.add_argument("--json")
    sp = add("taint", "parse Logs/taint.log", dump=False)
    sp.add_argument("logfile")
    sp.add_argument("-o", "--out", help="JSON output")
    sp = add("errors", "summarize captured Lua errors / blocked actions in DUMP")
    sp.add_argument("--json")
    sp = add("ketho", "optional: compare against Ketho/BlizzardInterfaceResources (forever branch)")
    sp.add_argument("--ref", help="local checkout of the Resources folder (default: download from GitHub)")
    sp.add_argument("--branch", default="forever")
    sp.add_argument("--json")

    a = p.parse_args(argv)

    if a.cmd == "diff":
        r = diffmod.diff(Dump.load(a.old), Dump.load(a.new))
        md = diffmod.markdown(r)
        if a.out:
            _write(a.out, md)
            print("wrote", a.out)
        else:
            print(md)
        if a.json:
            export_json.write_json(a.json, r)
        return 0
    if a.cmd == "combatlog":
        fx = combatlog.parse_file(a.logfile, year=a.year,
                                  utc_offset_sec=None if a.utc_offset is None else a.utc_offset * 3600,
                                  shape=a.shape, limit=a.limit,
                                  subevents=set(a.subevents.split(",")) if a.subevents else None)
        if a.forever_player:
            fx = combatlog.synthesize_forever(fx, a.forever_player)
        if a.out.endswith(".lua"):
            mocks.write_lua(a.out, "WoWCombatLog fixture from %s" % os.path.basename(a.logfile), fx)
        else:
            export_json.write_json(a.out, fx)
        print("wrote %s: %d CLEU events (%s), %d non-CLEU lines, header %s" % (
            a.out, fx["total"], ", ".join("%s=%d" % kv for kv in sorted(fx["counts"].items(), key=lambda x: -x[1])[:8]),
            len(fx["events"]) - fx["total"], fx["header"]))
        return 0
    if a.cmd == "cl-compare":
        with open(a.fixture, encoding="utf-8") as f:
            fx = json.load(f)
        d = Dump.load(a.dump)
        sessions = as_list(d.combatlog.get("sessions"))
        if not sessions:
            print("no /fdump cl sessions in", a.dump)
            return 2
        sess = sessions[(a.session - 1) if a.session else -1]
        r = combatlog.compare(fx, sess)
        print("matched %d, addon-only %d, file-only %d" % (r["matched"], r["addonOnly"], r["fileOnly"]))
        for subev, d_ in r["arityMismatch"].items():
            print("  arity %s: %s" % (subev, d_))
        for fd in r["fieldDiffs"][:20]:
            print("  diff %s arg %d: addon=%r file=%r" % (fd["sub"], fd["pos"], fd["addon"], fd["file"]))
        if a.json:
            export_json.write_json(a.json, r)
        return 0
    if a.cmd == "taint":
        r = taintlog.parse(a.logfile)
        print(taintlog.text_summary(r))
        if a.out:
            export_json.write_json(a.out, r)
            print("wrote", a.out)
        return 0

    dump = Dump.load(a.dump)
    if a.cmd == "info":
        print(info(dump))
    elif a.cmd == "json":
        files = export_json.export(dump, a.out)
        print("wrote %d JSON files to %s" % (len(files), a.out))
    elif a.cmd == "luals":
        files = luals.generate(dump, a.out)
        print("wrote %d LuaLS stub files to %s (add it to workspace.library; see .luarc.json.example)" % (len(files), a.out))
    elif a.cmd == "luacheck":
        _write(a.out, luacheck_gen.generate(dump, std_name=a.std))
        print("wrote", a.out)
    elif a.cmd == "mocks":
        files = mocks.generate(dump, a.out)
        print("wrote %d mock files to %s" % (len(files), a.out))
    elif a.cmd == "all":
        print(info(dump))
        export_json.export(dump, os.path.join(a.out, "json"))
        luals.generate(dump, os.path.join(a.out, "luals"))
        _write(os.path.join(a.out, ".luacheckrc"), luacheck_gen.generate(dump))
        mocks.generate(dump, os.path.join(a.out, "mocks"))
        print("wrote json/, luals/, .luacheckrc, mocks/ under", a.out)
    elif a.cmd == "check":
        r = apicheck.run(dump, a.addon)
        print(apicheck.text(r))
        if a.json:
            export_json.write_json(a.json, r)
        if r["counts"]["error"] or (a.strict and r["counts"]["warn"]):
            return 1
    elif a.cmd == "errors":
        errs, blocked = as_list(dump.log.get("errors")), as_list(dump.log.get("blocked"))
        for e in sorted(errs, key=lambda e: -(e.get("count") or 0)):
            print("[%dx] %s%s" % (e.get("count", 1), e.get("message"), ("  (addon %s)" % e["addon"]) if e.get("addon") else ""))
            if e.get("stack"):
                print("    " + str(e["stack"]).replace("\n", "\n    "))
        for b in blocked:
            print("%s %s %s" % (b.get("time"), b.get("event"), b.get("args")))
        print("%d unique errors, %d blocked/forbidden/warning events" % (len(errs), len(blocked)))
        if a.json:
            export_json.write_json(a.json, {"errors": errs, "blocked": blocked})
    elif a.cmd == "ketho":
        r = ketho.compare(dump, ref=a.ref, branch=a.branch)
        print(ketho.text(r))
        if a.json:
            export_json.write_json(a.json, r)
    return 0


if __name__ == "__main__":
    sys.exit(main())
