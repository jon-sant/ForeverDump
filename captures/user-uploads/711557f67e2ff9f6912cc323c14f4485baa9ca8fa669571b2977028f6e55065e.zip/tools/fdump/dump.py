"""Load a ForeverDump dump (SavedVariables .lua, dump.json, or an export dir) and expose views."""
import json
import os

from .luasv import parse_savedvariables, as_list

SV_NAMES = ("ForeverDumpDB", "ForeverDumpDocsDB", "ForeverDumpStringsDB", "ForeverDumpRecordDB",
            "ForeverDumpLogDB", "ForeverDumpCombatLogDB")


def _int_keys(obj):
    """JSON turns int keys into strings; give them back for Lua-ish tables."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, str) and k.isdigit():
                k = int(k)
            out[k] = _int_keys(v)
        return out
    if isinstance(obj, list):
        return [_int_keys(v) for v in obj]
    return obj


def load_raw(path):
    if os.path.isdir(path):
        path = os.path.join(path, "dump.json")
    if path.endswith(".json"):
        with open(path, encoding="utf-8") as f:
            return _int_keys(json.load(f))
    with open(path, encoding="utf-8", errors="surrogateescape") as f:
        text = f.read()
    return parse_savedvariables(text)


class Dump:
    def __init__(self, raw, source=""):
        self.raw = raw
        self.source = source
        self.db = raw.get("ForeverDumpDB") or {}
        self.docs = raw.get("ForeverDumpDocsDB") or {}
        self.strings = (raw.get("ForeverDumpStringsDB") or {}).get("strings") or {}
        self.record = raw.get("ForeverDumpRecordDB") or {}
        self.log = raw.get("ForeverDumpLogDB") or {}
        self.combatlog = raw.get("ForeverDumpCombatLogDB") or {}
        self.sections = self.db.get("sections") or {}
        self._doc_index = None

    @classmethod
    def load(cls, path):
        return cls(load_raw(path), source=path)

    # ------------------------------------------------------------ meta
    def meta(self):
        m = self.db.get("meta") or {}
        if not m:
            for s in self.sections.values():
                if isinstance(s, dict) and s.get("meta"):
                    return s["meta"]
        return m

    def build_label(self):
        m = self.meta()
        return "%s.%s (toc %s)" % (m.get("version", "?"), m.get("build", "?"), m.get("toc", "?"))

    # ------------------------------------------------------------ docs
    def doc_systems(self):
        return as_list(self.docs.get("systems"))

    def doc_tables(self):
        """All documented tables (system + shared): name -> table."""
        out = {}
        for sys in self.doc_systems():
            for t in as_list(sys.get("Tables")):
                if t.get("Name"):
                    out[t["Name"]] = t
        for t in as_list(self.docs.get("sharedTables")):
            if t.get("Name"):
                out[t["Name"]] = t
        return out

    def doc_functions(self):
        """full name -> (system, function). Excludes ScriptObject (widget) systems."""
        if self._doc_index is None:
            idx = {}
            for sys in self.doc_systems():
                if sys.get("Type") == "ScriptObject":
                    continue
                ns = sys.get("Namespace")
                for f in as_list(sys.get("Functions")):
                    name = f.get("Name")
                    if name:
                        idx[(ns + "." + name) if ns else name] = (sys, f)
            self._doc_index = idx
        return self._doc_index

    def doc_events(self):
        out = {}
        for sys in self.doc_systems():
            for e in as_list(sys.get("Events")):
                if e.get("LiteralName"):
                    out[e["LiteralName"]] = (sys, e)
        return out

    def scriptobject_systems(self):
        return [s for s in self.doc_systems() if s.get("Type") == "ScriptObject"]

    # ------------------------------------------------------------ present API
    def namespaces(self):
        """C_ namespace -> {functions: [...], fields: {...}, children: {...}}"""
        return (self.sections.get("api") or {}).get("namespaces") or {}

    def global_functions(self):
        g = (self.sections.get("globals") or {}).get("functions") or {}
        sec = as_list(g.get("secure"))
        if not sec:
            # fall back on the v1 list (secure globals + C_ members)
            sec = [a for a in as_list(self.db.get("apis")) if "." not in a]
        return sec, as_list(g.get("insecure"))

    def present_functions(self):
        out = set()
        sec, _ = self.global_functions()
        out.update(sec)
        for ns, info in self.namespaces().items():
            for f in as_list(info.get("functions")):
                out.add(ns + "." + f)
        if not out:
            out.update(as_list(self.db.get("apis")))
        return out

    def global_tables(self):
        return (self.sections.get("globals") or {}).get("tables") or {}

    def constants(self):
        return (self.sections.get("globals") or {}).get("constants") or {}

    def runtime_enum(self):
        return (self.sections.get("globals") or {}).get("enum") or {}

    def frames(self):
        return (self.sections.get("frames") or {}).get("frames") or {}

    def widget_types(self):
        return (self.sections.get("widgets") or {}).get("types") or {}

    def events(self):
        evs = as_list(self.db.get("events"))
        if not evs:
            evs = sorted(self.doc_events())
        return evs

    def all_global_names(self):
        names = set(self.present_functions())
        names.update(n.split(".")[0] for n in list(names))
        names.update(self.namespaces().keys())
        names.update(self.global_tables().keys())
        names.update(self.constants().keys())
        names.update(self.strings.keys())
        names.update(self.frames().keys())
        _, insecure = self.global_functions()
        names.update(insecure)
        for extra in ("Enum", "Constants", "_G"):
            names.add(extra)
        return names
