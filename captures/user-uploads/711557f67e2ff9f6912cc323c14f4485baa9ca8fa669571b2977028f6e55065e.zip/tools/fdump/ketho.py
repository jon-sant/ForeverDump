"""Optional: compare a dump against Ketho/BlizzardInterfaceResources (branch `forever` by default):
Resources/GlobalAPI.lua and Resources/CVars.lua. Files are parsed as data (never executed)."""
import os
import re
import urllib.request

from .luasv import parse_savedvariables, as_list

BASE = "https://raw.githubusercontent.com/Ketho/BlizzardInterfaceResources/%s/Resources/%s"


def _load(name, ref, branch):
    if ref and os.path.isdir(ref):
        with open(os.path.join(ref, name), encoding="utf-8") as f:
            return f.read()
    url = BASE % (branch, name)
    with urllib.request.urlopen(url, timeout=60) as r:
        return r.read().decode("utf-8")


def _as_data(text):
    text = re.sub(r"^local\s+", "", text, flags=re.M)
    text = re.sub(r"^return\b.*$", "", text, flags=re.M)
    return parse_savedvariables(text)


def compare(dump, ref=None, branch="forever"):
    res = {"source": ref or (BASE % (branch, "")), "branch": branch}
    g = _as_data(_load("GlobalAPI.lua", ref, branch))
    ketho_api = set(as_list(g.get("GlobalAPI")))
    lua_api = set(as_list(g.get("LuaAPI")))
    mine = dump.present_functions()
    res["globalAPI"] = {"ketho": len(ketho_api), "dump": len(mine),
                        "onlyKetho": sorted(ketho_api - mine - lua_api),
                        "onlyDump": sorted(mine - ketho_api)}
    try:
        c = _as_data(_load("CVars.lua", ref, branch))
        kvars = set(((c.get("CVars") or {}).get("var") or {}).keys())
        dvars = set(as_list(dump.db.get("cvarNames")))
        if not dvars:
            for rows in (dump.db.get("cvars") or {}).values():
                if isinstance(rows, dict):
                    dvars.update(rows.keys())
        res["cvars"] = {"ketho": len(kvars), "dump": len(dvars), "onlyKetho": sorted(kvars - dvars),
                        "onlyDump": sorted(dvars - kvars)}
    except Exception as e:  # CVars file optional
        res["cvars"] = {"error": str(e)}
    return res


def text(res, max_items=60):
    out = ["Compared with Ketho/BlizzardInterfaceResources (%s)" % res["branch"]]
    for key in ("globalAPI", "cvars"):
        d = res.get(key) or {}
        if "error" in d:
            out.append("%s: %s" % (key, d["error"]))
            continue
        out.append("%s: ketho %d, dump %d, only in ketho %d, only in dump %d" % (
            key, d["ketho"], d["dump"], len(d["onlyKetho"]), len(d["onlyDump"])))
        for x in d["onlyKetho"][:max_items]:
            out.append("  - ketho only: %s" % x)
        for x in d["onlyDump"][:max_items]:
            out.append("  + dump only:  %s" % x)
    return "\n".join(out)
