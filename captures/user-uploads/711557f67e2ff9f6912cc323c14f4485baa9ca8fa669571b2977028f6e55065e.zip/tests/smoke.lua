-- Smoke test: load ForeverDump into the mock client, run every command path,
-- assert nothing errors / no secret is touched, and write a sample
-- SavedVariables file for the converter tests.
-- usage: FORE_DOCS=.../Interface/AddOns lua5.1 tests/smoke.lua <addonDir> <outSV>
package.path = "./tests/?.lua;" .. package.path
local W = require("wowenv")
local addonDir, outPath = arg[1] or "ForeverDump", arg[2] or "tests/out/ForeverDump.lua"

local files = {}
for line in io.lines(addonDir .. "/ForeverDump.toc") do
    if line:match("%.lua%s*$") then files[#files + 1] = line:match("^%s*(.-)%s*$") end
end
local ns = W.loadAddon(addonDir, files, "ForeverDump")
W.fire("ADDON_LOADED", "Blizzard_DebugTools")
W.fire("ADDON_LOADED", "ForeverDump")
W.fire("PLAYER_LOGIN")

local failures = 0
local function check(cond, msg)
    if cond then print("  ok   " .. msg) else failures = failures + 1; print("  FAIL " .. msg) end
end
local function errorsLogged() return ForeverDumpDB.errors and #ForeverDumpDB.errors or 0 end

print("v1 compatibility")
W.slash("")
check(type(ForeverDumpDB.apis) == "table" and #ForeverDumpDB.apis > 100, "/fdump (v1) wrote apis: " .. #(ForeverDumpDB.apis or {}))
check(type(ForeverDumpDB.events) == "table" and #ForeverDumpDB.events > 100, "v1 events: " .. #(ForeverDumpDB.events or {}))
check(type(ForeverDumpDB.cvars) == "table", "v1 cvars nested")
check(ForeverDumpDB.cvars.Net.accountName.current == "<redacted>", "accountName CVar redacted")
check(_G.ForeverDumpFrame ~= nil, "copy UI created")

print("help / status")
W.slash("help")
W.slash("status")

print("combat refusal")
W.state.combat = true
W.slash("all")
check(not ns.IsBusy(), "/fdump all refused in combat")
W.state.combat = false

print("/fdump all")
W.slash("all")
local ticks = W.runUntilIdle(ns)
check(errorsLogged() == 0, "no job errors (" .. errorsLogged() .. ")" ..
    (ForeverDumpDB.errors and (" first: " .. tostring(ForeverDumpDB.errors[1].err)) or ""))
print("    finished after " .. ticks .. " frames")
for _, s in ipairs({ "docs", "api", "globals", "strings", "widgets", "templates", "frames", "addons", "cvars", "protected", "extras" }) do
    check(ForeverDumpDB.sections[s] ~= nil, "section " .. s)
end
local docs = ForeverDumpDocsDB
check(docs.counts and docs.counts.systems > 300, "docs systems: " .. tostring(docs.counts and docs.counts.systems))
check(docs.counts.functions > 5000, "docs functions: " .. docs.counts.functions)
local foundMissing, foundUndoc = false, false
for _, n in ipairs(docs.missing) do if n == "C_Item.GetItemCooldown" then foundMissing = true end end
for _, n in ipairs(docs.undocumented) do if n == "C_Item.UndocumentedMockFunction" then foundUndoc = true end end
check(foundMissing, "documented-but-missing detected")
check(foundUndoc, "present-but-undocumented detected")
local fn = docs.systems[1].Functions and docs.systems[1].Functions[1]
check(fn == nil or fn.System == nil, "no System back-reference copied")
local flagFound = false
for _, sys in ipairs(docs.systems) do
    for _, f in ipairs(sys.Functions or {}) do if f.SecretArguments then flagFound = true break end end
    if flagFound then break end
end
check(flagFound, "generic flags (SecretArguments) captured")
local w = ForeverDumpDB.sections.widgets
check(w.types.Frame and w.types.Frame.count > 50, "widget Frame methods: " .. tostring(w.types.Frame and w.types.Frame.count))
check(w.failures.Blob ~= nil, "failed widget type recorded (Blob)")
check(w.types["Anim:Alpha"] ~= nil and w.failures["Anim:RadialProgress"] ~= nil, "animation types + failure")
check(ForeverDumpDB.sections.frames.frames.ForbiddenTestFrame.forbidden == true, "forbidden frame flagged")
check(ForeverDumpDB.sections.frames.frames.ProtectedTestButton.protected == true, "protected frame flagged")
check(ForeverDumpStringsDB.strings.ITEM_LEVEL == "Item Level %d", "global strings")
check(ForeverDumpDB.sections.protected.counts.restricted > 0, "protected: restricted functions from docs")
check(ForeverDumpDB.sections.globals.constants.NUM_BAG_SLOTS == 4, "globals constants")
local insecure = false
for _, n in ipairs(ForeverDumpDB.sections.globals.functions.insecure) do if n == "TaintedAddonGlobalFunction" then insecure = true end end
check(insecure, "insecure global function split")
check(ForeverDumpDB.sections.extras.slash.commands.FRAMESTACK ~= nil, "slash commands from SLASH_* strings")

print("widgets risky + getters")
W.slash("widgets risky")
W.runUntilIdle(ns)
W.slash("getters")
W.runUntilIdle(ns)
check(ForeverDumpDB.sections.getters and ForeverDumpDB.sections.getters.counts.called > 50,
    "getters called: " .. tostring(ForeverDumpDB.sections.getters and ForeverDumpDB.sections.getters.counts.called))

print("probe")
W.slash("probe add item 12345")
W.slash("probe list")
W.slash("probe")
local p = ForeverDumpDB.sections.probe
check(p.outOfCombat ~= nil, "probe outOfCombat")
W.slash("probe combat")
W.state.combat = true
W.fire("PLAYER_REGEN_DISABLED")
W.tick(2)
check(p.inCombat ~= nil, "armed probe ran in combat")
local hp = p.inCombat.units.player.UnitHealth
check(hp.values[1] == "<secret>" and hp.secret[1] == 1, "secret return recorded as <secret>")
local auraErr = p.inCombat.auras.target.HELPFUL[1]
check(auraErr.ok == false, "aura access error recorded, not raised")
local pname = p.outOfCombat.units.player.UnitName.values[1]
check(pname == "<player-name>", "player name redacted: " .. tostring(pname))
check(p.outOfCombat.units.player.UnitGUID.values[1] == "Player-<redacted>", "player GUID redacted")

print("recorder")
W.slash("record start")
W.fire("UNIT_HEALTH", "target", W.SECRET)
for _ = 1, 50 do W.fire("UNIT_AURA", "player", { addedAuras = {} }) end
W.fire("CHAT_MSG_WHISPER", "hello", "Someone-Realm")
W.fire("SPELL_UPDATE_COOLDOWN")
EventRegistry:TriggerEvent("MockCallback.Event", 1, "two")
W.state.combat = false
W.slash("record status")
W.slash("record stop")
local sess = ForeverDumpRecordDB.sessions[#ForeverDumpRecordDB.sessions]
check(sess and sess.kept > 0, "recording saved: " .. tostring(sess and sess.kept))
local sawSecret, sawChat, sawCB = false, false, false
for _, e in ipairs(sess.events) do
    if e.e == "UNIT_HEALTH" and e.a[2] == "<secret>" and e.s and e.s[1] == 2 and e.c then sawSecret = true end
    if e.e == "CHAT_MSG_WHISPER" and e.redacted then sawChat = true end
    if e.cb and e.e == "MockCallback.Event" then sawCB = true end
end
check(sawSecret, "secret event arg recorded as <secret> with combat flag")
check(sawChat, "chat event redacted")
check(sawCB, "EventRegistry callback recorded")
check((sess.dropped.UNIT_AURA or 0) > 0, "throttle dropped spam: " .. tostring(sess.dropped.UNIT_AURA))

print("combat recorder (Forever-safe events)")
W.slash("set cl.maxSessions 6") -- keep every session for the converter fixtures
do
    check(next(W.state.restrictedRegistrations) == nil and W.state.registerAllCalls == 0,
        "so far nothing registered COMBAT_LOG_EVENT* or called RegisterAllEvents")
    W.slash("cl start file")
    check(W.state.logging == false and W.state.protectedCalls == 0 and W.CVARS.advancedCombatLogging[1] == "1",
        "cl start file: advancedCombatLogging on, LoggingCombat NOT called by default")
    W.fire("ENCOUNTER_START", 2902, "Mock Boss", 14, 20)
    W.state.combat = true
    W.fire("PLAYER_REGEN_DISABLED")
    W.fire("UNIT_SPELLCAST_SUCCEEDED", "player", "Cast-3-1234-0-0-133-000000000A", 133)
    W.fire("UNIT_COMBAT", "target", "WOUND", "", W.SECRET, 1)
    W.fire("PLAYER_SWING", 2.6, 0)
    W.state.ctInfo = { n = 2, W.SECRET, "Fire" }
    W.fire("COMBAT_TEXT_UPDATE", "DAMAGE")
    W.state.ctInfo = nil
    W.fireCLEU(1791409800.123, "SPELL_DAMAGE", false, "Player-1234-0ABCDEF0", "Mockchar", 0x511, 0,
        "Creature-0-1-2-3-4-5", "Mock Boss", 0x10a48, 0, 133, "Fireball", 4, 1234, -1, 4, nil, nil, nil, true, false, false, false)
    W.fire("ENCOUNTER_END", 2902, "Mock Boss", 14, 20, 1)
    W.state.combat = false
    W.fire("PLAYER_REGEN_ENABLED")
    W.tick(2) -- C_Timer.After -> post-combat damage meter snapshot
    W.slash("cl status")
    W.slash("cl stop")
    check(W.CVARS.advancedCombatLogging[1] == "0", "advanced CVar restored")
    check(next(W.state.restrictedRegistrations) == nil, "default combat recorder never registers COMBAT_LOG_EVENT*")
    local cs = ForeverDumpCombatLogDB.sessions[#ForeverDumpCombatLogDB.sessions]
    check(cs.cleuTotal == 0 and (cs.counts.COMBAT_LOG_EVENT_UNFILTERED or 0) == 0, "CLEU not captured by default")
    check(cs.counts.UNIT_COMBAT == 1 and cs.counts.UNIT_SPELLCAST_SUCCEEDED == 1 and cs.counts.PLAYER_SWING == 1
        and cs.counts.COMBAT_TEXT_UPDATE == 1, "UNIT_COMBAT / UNIT_SPELLCAST_* / PLAYER_SWING / COMBAT_TEXT_UPDATE captured")
    local uc, ct, sw, enc, regen
    for _, e in ipairs(cs.events) do
        if e.e == "UNIT_COMBAT" then uc = e end
        if e.e == "COMBAT_TEXT_UPDATE" then ct = e end
        if e.e == "PLAYER_SWING" then sw = e end
        if e.e == "ENCOUNTER_START" then enc = e end
        if e.e == "PLAYER_REGEN_DISABLED" then regen = e end
    end
    check(uc and uc.a[4] == "<secret>" and uc.s and uc.s[1] == 4 and uc.c, "UNIT_COMBAT secret amount recorded as <secret> + combat flag")
    local g = ct and ct.g and ct.g["C_CombatText.GetCurrentEventInfo"]
    check(g and g.a[1] == "<secret>" and g.a[2] == "Fire" and g.s[1] == 1, "C_CombatText.GetCurrentEventInfo captured with secrets")
    check(sw and sw.range and sw.range.MainHand == true and sw.range.Ranged == false, "PLAYER_SWING + C_SwingTimer range")
    check(enc and enc.ctx and enc.instance and enc.a[2] == "Mock Boss", "ENCOUNTER_START context with instance info")
    check(regen and regen.restricted == true and regen.restrictions and regen.restrictions.Combat == 1, "restriction state at combat start")
    local dm = cs.damageMeter and cs.damageMeter[1]
    check(dm and dm.reason == "PLAYER_REGEN_ENABLED" and dm.byType.DamageDone and dm.byType.DamageDone.totalAmount == 1234,
        "post-combat C_DamageMeter snapshot (not secret)")
    check(cs.skipped == nil and cs.notAvailable ~= nil and cs.registered and #cs.registered > 20, "registered list recorded")
    check(cs.utcOffsetSec ~= nil and cs.fileLogging.error and cs.fileLogging.error:find("FD_Logs", 1, true), "utc offset + file logging skip reason recorded")

    -- in-combat stop: no damage meter read while secret
    W.slash("cl start")
    W.state.combat = true
    W.slash("cl stop")
    W.state.combat = false
    local cs2 = ForeverDumpCombatLogDB.sessions[#ForeverDumpCombatLogDB.sessions]
    check(#cs2.damageMeter == 0, "no C_DamageMeter read while in combat")

    -- ring buffer
    W.slash("set cl.maxEvents 100")
    W.slash("cl start")
    for i = 1, 150 do W.fire("UNIT_SPELLCAST_SUCCEEDED", "player", "Cast-" .. i, 2061) end
    W.slash("cl stop")
    local rs = ForeverDumpCombatLogDB.sessions[#ForeverDumpCombatLogDB.sessions]
    check(#rs.events == 100 and rs.overwritten == 50 and rs.counts.UNIT_SPELLCAST_SUCCEEDED == 150, "ring buffer bounded, counts complete")
    check(rs.events[1].a[2] == "Cast-51", "ring linearized oldest-first")
    W.slash("set cl.maxEvents 20000")
    check(next(W.state.restrictedRegistrations) == nil and W.state.registerAllCalls == 0,
        "still no COMBAT_LOG_EVENT* registration / RegisterAllEvents after recorder + combat recorder")

    -- legacy opt-in: refused without getter or when restricted
    local getter = CombatLogGetCurrentEventInfo
    CombatLogGetCurrentEventInfo = nil
    W.slash("cl cleu-force")
    W.slash("cl stop")
    local r1 = ForeverDumpCombatLogDB.sessions[#ForeverDumpCombatLogDB.sessions]
    check(r1.cleu.refused and r1.cleu.refused:find("CombatLogGetCurrentEventInfo missing", 1, true)
        and next(W.state.restrictedRegistrations) == nil, "cleu-force refused when getter missing (no registration)")
    CombatLogGetCurrentEventInfo = getter
    local restrictedFn = C_CombatLog.IsCombatLogRestricted
    C_CombatLog.IsCombatLogRestricted = function() return true end
    W.slash("cl cleu-force")
    W.slash("cl stop")
    local r2 = ForeverDumpCombatLogDB.sessions[#ForeverDumpCombatLogDB.sessions]
    check(r2.cleu.refused and r2.cleu.refused:find("IsCombatLogRestricted", 1, true) and next(W.state.restrictedRegistrations) == nil,
        "cleu-force refused when combat log restricted")
    C_CombatLog.IsCombatLogRestricted = restrictedFn
    -- unrestricted legacy client: capture full CLEU payloads (for testing older addons)
    W.slash("set cl.redactPlayers true")
    W.slash("cl cleu-force")
    W.state.combat = true
    W.fireCLEU(1791409800.123, "SPELL_DAMAGE", false, "Player-1234-0ABCDEF0", "Mockchar", 0x511, 0,
        "Creature-0-1-2-3-4-5", "Mock Boss", 0x10a48, 0, 133, "Fireball", 4, 1234, -1, 4, nil, nil, nil, true, false, false, false)
    W.fireCLEU(1791409800.5, "SWING_DAMAGE", false, "Creature-0-1-2-3-4-5", W.SECRET, 0xa48, 0,
        "Player-1234-0ABCDEF0", "Mockchar", 0x511, 0, W.SECRET, -1, 1, nil, nil, nil, false, false, false, false)
    W.state.combat = false
    W.slash("cl stop")
    W.slash("set cl.redactPlayers false")
    local lc = ForeverDumpCombatLogDB.sessions[#ForeverDumpCombatLogDB.sessions]
    check(W.state.restrictedRegistrations.COMBAT_LOG_EVENT_UNFILTERED == 1, "cleu-force registers CLEU only when explicitly allowed")
    local dmg, swing
    for _, e in ipairs(lc.events) do
        if e.sub == "SPELL_DAMAGE" then dmg = e end
        if e.sub == "SWING_DAMAGE" then swing = e end
    end
    check(lc.cleuTotal == 2 and dmg and dmg.n == 24 and dmg.a[12] == 133 and dmg.a[15] == 1234 and dmg.a[18] == "<nil>",
        "legacy CLEU payload incl. suffix args and nil placeholders")
    check(dmg and dmg.a[4] == "Player-#1" and dmg.a[5] == "<player>", "cl.redactPlayers redacts player GUID/name")
    check(swing and swing.s and swing.s[1] == 5 and swing.s[2] == 12, "secret CLEU args recorded as <secret>")
    W.state.restrictedRegistrations = {}
end

print("recorder event registration")
do
    W.slash("record start")
    W.slash("record stop")
    local rsess = ForeverDumpRecordDB.sessions[#ForeverDumpRecordDB.sessions]
    check(rsess.registered and rsess.registered > 1000, "recorder registered documented events individually: " .. tostring(rsess.registered))
    check(rsess.skippedEvents and rsess.skippedEvents.COMBAT_LOG_EVENT_UNFILTERED and rsess.skippedEvents.COMBAT_LOG_EVENT,
        "COMBAT_LOG_EVENT* skipped: " .. tostring(rsess.skippedEvents and rsess.skippedEvents.COMBAT_LOG_EVENT_UNFILTERED))
    check(rsess.skippedEvents.MINIMAP_PING == "docs: HasRestrictions", "HasRestrictions events skipped generically")
    check(rsess.skippedEvents.UNIT_PING_PIN_ADDED ~= nil, "SecureOnly-system events skipped: " .. tostring(rsess.skippedEvents.UNIT_PING_PIN_ADDED))
    check(next(W.state.restrictedRegistrations) == nil and W.state.registerAllCalls == 0, "recorder: no restricted registration, no RegisterAllEvents")
end

print("FD_Logs macro + /fdump logs")
do
    local chatStart = #W.chat
    W.slash("logs macro")
    local idx = GetMacroIndexByName("FD_Logs")
    local m = W.state.macros[idx]
    check(idx > 0 and m.body == "/fdump logs\n/combatlog\n/chatlog" and #m.body <= 255 and m.perChar == nil,
        "FD_Logs created account-wide: " .. tostring(m and m.body:gsub("\n", " | ")))
    W.slash("logs macro")
    check(#W.state.macros == 1 and ForeverDumpDB.macro.action == "updated", "second run updates, no duplicate")
    W.clickMacro("FD_Logs")
    W.tick(2)
    check(W.state.logging and W.state.chatLogging and W.CVARS.advancedCombatLogging[1] == "1" and W.CVARS.scriptErrors[1] == "1"
        and W.CVARS.taintLog[1] == "1" and ForeverDumpDB.logs.on == true, "click 1: everything ON")
    check(W.state.protectedCalls == 0, "addon never called LoggingCombat/LoggingChat itself")
    local sawOn = false
    for i = chatStart + 1, #W.chat do if W.chat[i]:find("ForeverDump logging: ON", 1, true) then sawOn = true end end
    check(sawOn, "chat line 'ForeverDump logging: ON' with changes")
    check(W.state.macros[idx].body == "/fdump logs\n/combatlog\n/chatlog", "macro body still toggles both (for OFF)")
    W.clickMacro("FD_Logs")
    W.tick(2)
    check(not W.state.logging and not W.state.chatLogging and W.CVARS.advancedCombatLogging[1] == "0" and W.CVARS.taintLog[1] == "0"
        and W.CVARS.scriptErrors[1] == "1" and ForeverDumpDB.logs.on == false, "click 2: everything OFF, CVars restored, taintLog 0")
    -- external drift: chat log turned on by hand -> next macro body only toggles what is needed
    SlashCmdList.CHATLOG("")
    W.slash("logs macro")
    check(W.state.macros[idx].body == "/fdump logs\n/combatlog", "macro rewritten to only the needed toggles")
    W.clickMacro("FD_Logs")
    W.tick(2)
    check(W.state.logging and W.state.chatLogging and ForeverDumpDB.logs.on, "drifted state converges to ON")
    W.slash("logs off")   -- typed by hand: CVars off, but the addon does not call LoggingCombat
    W.tick(2)
    check(ForeverDumpDB.logs.mismatch == true and W.state.logging == true and W.state.protectedCalls == 0,
        "typed /fdump logs off: mismatch reported, still no protected call")
    W.clickMacro("FD_Logs") -- body now toggles both off again? (state OFF -> next target ON) -> rebuilt
    W.tick(2)
    W.slash("logs status")
    -- combat: macro edits deferred
    W.state.combat = true
    W.slash("logs macro")
    check(ForeverDumpDB.macro.ok == false and ForeverDumpDB.macro.err:find("combat", 1, true), "macro edit refused in combat")
    W.state.combat = false
    W.fire("PLAYER_REGEN_ENABLED")
    check(ForeverDumpDB.macro.ok == true, "deferred macro update after combat")
    -- no free slot
    local saved = W.state.macros
    W.state.macros, W.state.macroSlotsUsed = {}, 120
    W.slash("logs macro")
    check(ForeverDumpDB.macro.ok == false and ForeverDumpDB.macro.err:find("no free account macro slot", 1, true), "free-slot check")
    W.state.macros, W.state.macroSlotsUsed = saved, 3
    -- opt-in direct calls
    W.slash("set logs.callLogging true")
    W.slash("logs on")
    W.tick(2)
    check(W.state.protectedCalls > 0 and W.state.macros[idx] ~= nil, "logs.callLogging=true makes the addon call LoggingCombat (opt-in)")
    W.slash("logs off")
    W.tick(2)
    W.slash("set logs.callLogging false")
    W.state.protectedCalls = 0
end

print("errors / taint events")
do
    check(ns.Errors.IsInstalled() == true, "error handler chained at ADDON_LOADED")
    local shown = W.state.errorsShown or 0
    W.raiseError("Interface/AddOns/Buggy/Buggy.lua:12: attempt to index a nil value")
    W.raiseError("Interface/AddOns/Buggy/Buggy.lua:12: attempt to index a nil value")
    W.raiseError(W.SECRET)
    check((W.state.errorsShown or 0) == shown + 3, "previous handler still called")
    local e1 = ForeverDumpLogDB.errors[1]
    check(e1 and e1.count == 2 and e1.addon == "Buggy" and e1.stack and e1.locals, "error logged with count/addon/stack/locals")
    check(ForeverDumpLogDB.errors[2] and ForeverDumpLogDB.errors[2].message == "<secret>", "secret error message not touched")
    W.fire("ADDON_ACTION_BLOCKED", "Buggy", "CastSpellByName()")
    W.fire("ADDON_ACTION_FORBIDDEN", "Buggy", "UseAction()")
    W.fire("MACRO_ACTION_BLOCKED", "TargetUnit()")
    W.fire("LUA_WARNING", "Mock warning")
    local b = ForeverDumpLogDB.blocked
    check(#b == 4 and b[1].args.addon == "Buggy" and b[1].args["function"] == "CastSpellByName()" and b[1].stack,
        "ADDON_ACTION_BLOCKED etc. logged: " .. #b)
    W.slash("errors status")
    W.slash("errors show")
    W.slash("errors off")
    check(ns.Errors.IsInstalled() == false and geterrorhandler() ~= nil, "errors off restores previous handler")
    W.slash("errors on")
    check(ns.Errors.IsInstalled() == true, "errors on re-installs")
end

print("profile")
W.slash("profile")
W.runUntilIdle(ns)
local prof = ForeverDumpDB.sections.profile
check(prof and prof.latest.profiler.enabled == true and prof.latest.addons.ForeverDump and prof.latest.addons.ForeverDump.memoryKB == 123.5,
    "profile snapshot with C_AddOnProfiler metrics + memory")
check(prof and prof.latest.addons.ForeverDump.metrics and prof.latest.addons.ForeverDump.metrics.PeakTime ~= nil, "per-addon metric by Enum name")

print("ui / clear / set")
for _, v in ipairs({ "status", "apis", "events", "enums", "cvars", "all", "docs", "globals", "widgets" }) do W.slash("show " .. v) end
W.slash("set frameBudgetMs 8")
check(ForeverDumpDB.config.frameBudgetMs == 8, "/fdump set")

check(W.state.touchedSecret == 0, "no secret value was ever touched (" .. W.state.touchedSecret .. ")")
os.execute("mkdir -p " .. outPath:match("^(.*)/"))
W.writeSavedVariables(outPath, { "ForeverDumpDB", "ForeverDumpDocsDB", "ForeverDumpStringsDB", "ForeverDumpRecordDB",
    "ForeverDumpLogDB", "ForeverDumpCombatLogDB" })
local f = io.open(outPath); local size = f:seek("end"); f:close()
print(string.format("wrote %s (%.1f MB)", outPath, size / 1048576))
if os.getenv("SHOW_CHAT") then for _, m in ipairs(W.chat) do print("    chat: " .. m) end end
do
    local m = ForeverDumpDB.meta or (ForeverDumpDB.sections.api and ForeverDumpDB.sections.api.meta)
    check(m and m.projectID == 18 and m.projectName == "WOW_PROJECT_CAMELOT", "meta records Camelot project id/name")
    check(m and m.projectConstants and m.projectConstants.WOW_PROJECT_MAINLINE == 1, "meta records all WOW_PROJECT_* constants")
    check(m and m.scriptsDisallowedForBeta == true, "meta records scriptsDisallowedForBeta")
end
print(failures == 0 and "SMOKE OK" or ("SMOKE FAILED: " .. failures))
os.exit(failures == 0 and 0 or 1)
