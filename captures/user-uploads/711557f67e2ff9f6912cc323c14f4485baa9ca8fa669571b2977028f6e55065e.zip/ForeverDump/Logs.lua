-- ForeverDump v2 - one-click logging toggle: /fdump logs [on|off|status|macro]
--
-- "/fdump logs macro" creates (or updates) ONE account-wide macro, FD_Logs. Clicking it toggles everything:
--   ON : combat log file (/combatlog), chat log (/chatlog), advancedCombatLogging=1, scriptErrors=1, taintLog=<level>
--   OFF: both logs off, advancedCombatLogging/scriptErrors back to the values saved when turned on, taintLog=0
-- State lives in ForeverDumpDB.logs. The addon sets the CVars itself (C_CVar.SetCVar). Whether LoggingCombat
-- and LoggingChat are protected for addons on Forever is unverified, and calling a protected function from an
-- addon shows the "blocked" popup even inside pcall, so by default the addon does NOT call them: the macro body
-- carries "/combatlog" and "/chatlog" lines, which run in Blizzard's secure slash handlers because a human
-- clicked. Both are toggles, so the addon rewrites the macro after every click (out of combat; EditMacro is
-- refused in combat) to contain only the toggles needed to reach the NEXT state, checked against
-- C_ChatInfo.IsLoggingCombat()/IsLoggingChat(). No /run or /script is used, so GetScriptsDisallowedForBeta()
-- does not affect it. Set logs.callLogging=true to let the addon call LoggingCombat/LoggingChat directly.
local _, ns = ...
local Logs = {}
ns.Logs = Logs

local MACRO_NAME = "FD_Logs"
local MACRO_ICON = "INV_Misc_Note_01"
local MAX_MACRO_CHARS = 255
local pendingMacro = false

local function cfg() return ns.config.logs end
local function state()
    if type(ns.db.logs) ~= "table" then ns.db.logs = { on = false } end
    return ns.db.logs
end

local function cvarGet(name)
    local C = rawget(_G, "C_CVar")
    local f = (type(C) == "table" and C.GetCVar) or rawget(_G, "GetCVar")
    if type(f) ~= "function" then return nil end
    local ok, v = pcall(f, name)
    if ok and not ns.IsSecret(v) then return v end
end

local function cvarSet(name, value)
    local C = rawget(_G, "C_CVar")
    local f = (type(C) == "table" and C.SetCVar) or rawget(_G, "SetCVar")
    if type(f) ~= "function" then return false, "SetCVar missing" end
    local ok, res = pcall(f, name, tostring(value))
    if ok and res == false then return false, "SetCVar returned false" end
    return ok, res
end

-- Current client logging state; nil when not readable (never calls LoggingCombat/LoggingChat unless allowed).
function Logs.ClientState()
    local C = rawget(_G, "C_ChatInfo")
    local combat, chat
    if type(C) == "table" and type(C.IsLoggingCombat) == "function" then
        local ok, v = pcall(C.IsLoggingCombat)
        if ok and not ns.IsSecret(v) then combat = v end
    end
    if type(C) == "table" and type(C.IsLoggingChat) == "function" then
        local ok, v = pcall(C.IsLoggingChat)
        if ok and not ns.IsSecret(v) then chat = v end
    end
    if cfg().callLogging then
        local lc, lch = rawget(_G, "LoggingCombat"), rawget(_G, "LoggingChat")
        if combat == nil and type(lc) == "function" then
            local ok, v = pcall(lc) if ok then combat = v end
        end
        if chat == nil and type(lch) == "function" then
            local ok, v = pcall(lch) if ok then chat = v end
        end
    end
    return combat, chat
end

-- Macro body that moves the client to `target` (true = all on) on the next click.
function Logs.MacroBody(target)
    local combat, chat = Logs.ClientState()
    local lines = { "/fdump logs" }
    if not cfg().callLogging then
        -- toggles: only include those whose state differs from the target (unknown state -> include)
        if combat == nil or combat ~= target then lines[#lines + 1] = "/combatlog" end
        if cfg().chat and (chat == nil or chat ~= target) then lines[#lines + 1] = "/chatlog" end
    end
    local body = table.concat(lines, "\n")
    assert(#body <= MAX_MACRO_CHARS)
    return body
end

local function maxAccountMacros()
    local v = rawget(_G, "MAX_ACCOUNT_MACROS")
    if type(v) ~= "number" and type(rawget(_G, "Constants")) == "table" and type(Constants.MacroConsts) == "table" then
        v = Constants.MacroConsts.MAX_ACCOUNT_MACROS
    end
    return type(v) == "number" and v or 120
end

-- Create or update FD_Logs. Returns ok, message. Out of combat only.
function Logs.EnsureMacro(silent)
    local rec = { time = time and time() or nil }
    ns.db.macro = rec
    if ns.InCombat() then
        pendingMacro = true
        rec.ok, rec.err = false, "in combat (deferred until PLAYER_REGEN_ENABLED)"
        if not silent then ns.Print("FD_Logs: can't edit macros in combat; will update after combat.") end
        return false, rec.err
    end
    local getIndex, create, edit, num = rawget(_G, "GetMacroIndexByName"), rawget(_G, "CreateMacro"),
        rawget(_G, "EditMacro"), rawget(_G, "GetNumMacros")
    if type(getIndex) ~= "function" or type(create) ~= "function" or type(edit) ~= "function" then
        rec.ok, rec.err = false, "macro API missing"
        ns.Print("FD_Logs: macro API missing on this client.")
        return false, rec.err
    end
    local body = Logs.MacroBody(not state().on)
    rec.body, rec.chars = body, #body
    local okI, index = pcall(getIndex, MACRO_NAME)
    index = okI and tonumber(index) or 0
    if index > 0 then
        local ok, res = pcall(edit, index, MACRO_NAME, MACRO_ICON, body)
        rec.ok, rec.action, rec.index = ok, "updated", ok and res or index
        if not ok then rec.err = tostring(res) end
    else
        local numAccount = 0
        if type(num) == "function" then
            local okN, a = pcall(num)
            numAccount = okN and tonumber(a) or 0
        end
        local max = maxAccountMacros()
        rec.slots = { used = numAccount, max = max }
        if numAccount >= max then
            rec.ok, rec.err = false, string.format("no free account macro slot (%d/%d)", numAccount, max)
            ns.Print("FD_Logs: " .. rec.err .. ". Delete a general macro and try again.")
            return false, rec.err
        end
        local ok, res = pcall(create, MACRO_NAME, MACRO_ICON, body, nil) -- nil = account-wide (General tab)
        rec.ok, rec.action, rec.index = ok and res ~= nil, "created", res
        if not ok then rec.err = tostring(res) elseif res == nil then rec.err = "CreateMacro returned nil" end
    end
    pendingMacro = not rec.ok
    if not silent or not rec.ok then
        ns.Print(string.format("FD_Logs macro %s%s. Drag it from /macro (General tab) to a bar; one click toggles all logging.",
            rec.ok and (rec.action or "ok") or "FAILED", rec.err and (": " .. rec.err) or ""))
    end
    return rec.ok, rec.err
end

local function describe(changes)
    local parts = {}
    for _, c in ipairs(changes) do parts[#parts + 1] = c end
    return table.concat(parts, ", ")
end

-- Verify the client reached the target state (after the macro's /combatlog and /chatlog lines ran) and report.
local function verify(target, changes)
    local combat, chat = Logs.ClientState()
    local s = state()
    local msgs = {}
    local function report(label, v, file)
        if v == nil then msgs[#msgs + 1] = label .. " state unknown (check the chat message above)"
        elseif v == target then msgs[#msgs + 1] = label .. " " .. (v and ("ON" .. (file and (" -> " .. file) or "")) or "OFF")
        else
            msgs[#msgs + 1] = string.format("|cffff5555%s is still %s|r (type %s once, or click FD_Logs again)", label,
                v and "ON" or "OFF", label == "combat log" and "/combatlog" or "/chatlog")
            s.mismatch = true
        end
    end
    s.mismatch = nil
    report("combat log", combat, "Logs/WoWCombatLog*.txt")
    if cfg().chat then report("chat log", chat, "Logs/WoWChatLog.txt") end
    s.client = { combat = combat, chat = chat, checked = time and time() or nil }
    ns.Print(string.format("|cff33ff99ForeverDump logging: %s|r - %s%s", target and "ON" or "OFF", describe(msgs),
        (#changes > 0) and ("; " .. describe(changes)) or ""))
    if target then ns.Print("Reproduce the problem, then click FD_Logs again (logs flush on toggle/logout).") end
    Logs.EnsureMacro(true) -- next click's toggles
end

function Logs.Set(target, source)
    local s = state()
    local c = cfg()
    local changes = {}
    local function setCVar(name, value)
        local before = cvarGet(name)
        if before == nil then changes[#changes + 1] = name .. " missing" return end
        if tostring(before) == tostring(value) then return before end
        local ok, err = cvarSet(name, value)
        local after = cvarGet(name)
        if ok and tostring(after) == tostring(value) then
            changes[#changes + 1] = string.format("%s %s->%s", name, tostring(before), tostring(value))
        else
            changes[#changes + 1] = string.format("|cffff5555%s not set (%s)|r", name, tostring(err or after))
        end
        return before
    end
    if target then
        local fresh = s.saved == nil -- keep the pre-ON values if ON is requested twice
        s.saved = s.saved or {}
        if c.advanced then
            local before = setCVar("advancedCombatLogging", 1)
            if fresh then s.saved.advancedCombatLogging = before end
        end
        if c.scriptErrors then
            local before = setCVar("scriptErrors", 1)
            if fresh then s.saved.scriptErrors = before end
        end
        if c.taintLog and c.taintLog > 0 then setCVar("taintLog", c.taintLog) end
    else
        local saved = s.saved or {}
        if c.advanced then setCVar("advancedCombatLogging", saved.advancedCombatLogging or "0") end
        if c.scriptErrors then setCVar("scriptErrors", saved.scriptErrors or "0") end
        setCVar("taintLog", 0)
        s.saved = nil
    end
    if c.callLogging then
        -- opt-in: the addon toggles the logs itself (only if LoggingCombat/LoggingChat are not protected!)
        local lc, lch = rawget(_G, "LoggingCombat"), rawget(_G, "LoggingChat")
        if type(lc) == "function" then
            local ok, err = pcall(lc, target)
            if not ok then changes[#changes + 1] = "|cffff5555LoggingCombat failed: " .. tostring(err) .. "|r" end
        end
        if c.chat and type(lch) == "function" then
            local ok, err = pcall(lch, target)
            if not ok then changes[#changes + 1] = "|cffff5555LoggingChat failed: " .. tostring(err) .. "|r" end
        end
    end
    s.on = target
    s.lastToggle = { time = time and time() or nil, date = date and date("%Y-%m-%d %H:%M:%S") or nil,
        source = source, inCombat = ns.InCombat(), changes = changes }
    -- the macro's /combatlog and /chatlog lines run right after "/fdump logs": verify a moment later
    local after = rawget(_G, "C_Timer") and C_Timer.After
    if type(after) == "function" then after(0.3, function() verify(target, changes) end) else verify(target, changes) end
end

function Logs.Toggle(source) Logs.Set(not state().on, source or "toggle") end

function Logs.Status()
    local s = state()
    local combat, chat = Logs.ClientState()
    local m = ns.db.macro or {}
    ns.Print(string.format("logging: %s (saved); client combat log %s, chat log %s; advancedCombatLogging=%s scriptErrors=%s taintLog=%s; "
        .. "macro FD_Logs: %s%s", s.on and "ON" or "OFF", tostring(combat), tostring(chat), tostring(cvarGet("advancedCombatLogging")),
        tostring(cvarGet("scriptErrors")), tostring(cvarGet("taintLog")), m.ok and (m.action or "ok") or (m.err or "not created"),
        ns.Meta().scriptsDisallowedForBeta and " (scripts disallowed: irrelevant, FD_Logs uses no /run)" or ""))
end

function Logs.Command(rest)
    local sub = string.lower(rest[1] or "")
    if sub == "" or sub == "toggle" then Logs.Toggle("slash")
    elseif sub == "on" then Logs.Set(true, "slash")
    elseif sub == "off" then Logs.Set(false, "slash")
    elseif sub == "macro" or sub == "macros" then Logs.EnsureMacro()
    else Logs.Status() end
end

ns.On("PLAYER_REGEN_ENABLED", function()
    if pendingMacro then Logs.EnsureMacro(true) end
end)
