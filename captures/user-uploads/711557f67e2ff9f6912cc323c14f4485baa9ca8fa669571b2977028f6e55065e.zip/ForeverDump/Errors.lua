-- ForeverDump v2 - error & taint capture: /fdump errors [status|on|off|clear|show]
-- Chains the Lua error handler (seterrorhandler), keeping whatever handler was installed before (Blizzard's
-- ScriptErrorsFrame / BugGrabber keep working), and logs each unique error with count, stack (debugstack)
-- and locals (debuglocals, when available) into ForeverDumpLogDB.errors. Also logs ADDON_ACTION_BLOCKED,
-- ADDON_ACTION_FORBIDDEN, MACRO_ACTION_BLOCKED, MACRO_ACTION_FORBIDDEN, LUA_WARNING and
-- ADDON_RESTRICTION_STATE_CHANGED into ForeverDumpLogDB.blocked. Secret values are never touched.
local _, ns = ...
local Err = {}
ns.Errors = Err

local BLOCK_EVENTS = {
    ADDON_ACTION_BLOCKED = { "addon", "function" },
    ADDON_ACTION_FORBIDDEN = { "addon", "function" },
    MACRO_ACTION_BLOCKED = { "function" },
    MACRO_ACTION_FORBIDDEN = { "function" },
    LUA_WARNING = { "warningText" },
    ADDON_RESTRICTION_STATE_CHANGED = { "type", "state" },
}

local installed = false
local previous
local inHandler = false
local sessionErrors = 0
local index -- msg -> entry

local function cfg() return ns.config and ns.config.errors or ns.defaults.errors end

local function safeString(v, max)
    if v == nil then return nil end
    if ns.IsSecret(v) then return ns.SECRET end
    local s = tostring(v)
    if max and #s > max then s = string.sub(s, 1, max) .. "<...>" end
    return s
end

local function addonFromText(s)
    if type(s) ~= "string" then return nil end
    return string.match(s, "[Ii]nterface[/\\][Aa]dd[Oo]ns[/\\]([^/\\]+)[/\\]")
end

local function capture(msg)
    local c = cfg()
    local log = ForeverDumpLogDB and ForeverDumpLogDB.errors
    if not log then return end
    local text = safeString(msg, 2000) or "<nil error>"
    index = index or {}
    if not next(index) then for _, e in ipairs(log) do if e.message then index[e.message] = e end end end
    local now = time and time() or nil
    local e = index[text]
    if e then
        e.count = e.count + 1
        e.lastTime = now
        e.lastSession = sessionErrors
        return
    end
    if #log >= (tonumber(c.maxErrors) or 200) then
        ForeverDumpLogDB.droppedErrors = (ForeverDumpLogDB.droppedErrors or 0) + 1
        return
    end
    local ds = rawget(_G, "debugstack")
    local dl = rawget(_G, "debuglocals")
    local stack, locals
    if type(ds) == "function" then
        local ok, s = pcall(ds, 2, 30, 30)
        stack = ok and safeString(s, c.maxStack) or nil
    end
    if c.captureLocals and type(dl) == "function" then
        local ok, l = pcall(dl, 4)
        locals = ok and safeString(l, c.maxLocals) or nil
    end
    e = { message = text, count = 1, time = now, lastTime = now, date = date and date("%Y-%m-%d %H:%M:%S") or nil,
        stack = stack, locals = locals, inCombat = ns.InCombat(), addon = addonFromText(text) or addonFromText(stack),
        build = ns.Meta().build, gameTime = GetTime and GetTime() or nil }
    log[#log + 1] = e
    index[text] = e
end

local function handler(msg, ...)
    sessionErrors = sessionErrors + 1
    if not inHandler then
        inHandler = true
        pcall(capture, msg)
        inHandler = false
    end
    if previous then return previous(msg, ...) end
end

function Err.Install()
    if installed then return true end
    local get, set = rawget(_G, "geterrorhandler"), rawget(_G, "seterrorhandler")
    if type(set) ~= "function" then
        ForeverDumpLogDB.handlerEvents[#ForeverDumpLogDB.handlerEvents + 1] = { time = time and time(), what = "seterrorhandler missing" }
        return false
    end
    previous = type(get) == "function" and get() or nil
    local ok, err = pcall(set, handler)
    local ev = ForeverDumpLogDB.handlerEvents
    ev[#ev + 1] = { time = time and time() or nil, what = ok and "installed" or ("seterrorhandler failed: " .. tostring(err)) }
    while #ev > 20 do table.remove(ev, 1) end
    installed = ok
    return ok
end

function Err.Uninstall()
    if not installed then return end
    local get, set = rawget(_G, "geterrorhandler"), rawget(_G, "seterrorhandler")
    if type(get) == "function" and get() == handler and previous then
        pcall(set, previous)
        installed = false
    else
        -- someone chained after us; stay installed but stop capturing
        installed = "passive"
    end
end

function Err.IsInstalled() return installed end

local function onBlock(event, ...)
    local log = ForeverDumpLogDB and ForeverDumpLogDB.blocked
    if not log then return end
    if #log >= (tonumber(cfg().maxBlocked) or 500) then
        ForeverDumpLogDB.droppedBlocked = (ForeverDumpLogDB.droppedBlocked or 0) + 1
        return
    end
    local names = BLOCK_EVENTS[event] or {}
    local entry = { event = event, time = time and time() or nil, gameTime = GetTime and GetTime() or nil,
        inCombat = ns.InCombat(), args = {} }
    for i = 1, select("#", ...) do
        entry.args[names[i] or i] = ns.SerializeArg and ns.SerializeArg((select(i, ...)), 300) or safeString((select(i, ...)), 300)
    end
    local ds = rawget(_G, "debugstack")
    if type(ds) == "function" then
        local ok, s = pcall(ds, 2, 20, 10)
        entry.stack = ok and safeString(s, 2000) or nil
    end
    log[#log + 1] = entry
    if event ~= "LUA_WARNING" and event ~= "ADDON_RESTRICTION_STATE_CHANGED" then
        ns.Print(string.format("|cffff8800%s|r %s", event, tostring(entry.args["function"] or "")))
    end
end

for ev in pairs(BLOCK_EVENTS) do
    ns.On(ev, function(event, ...)
        if not (ns.config and ns.config.errors and ns.config.errors.enabled) then return end
        onBlock(event, ...)
    end)
end

ns.On("ADDON_LOADED", function(_, name)
    if name == ns.ADDON and ns.config.errors.enabled then Err.Install() end
end)

function Err.Status()
    local log = ForeverDumpLogDB or {}
    local total = 0
    for _, e in ipairs(log.errors or {}) do total = total + (e.count or 0) end
    ns.Print(string.format("errors: handler %s (enabled=%s); %d unique errors (%d total, %d this session, %d dropped); "
        .. "%d blocked/forbidden/warning events (%d dropped)",
        tostring(installed), tostring(ns.config.errors.enabled), #(log.errors or {}), total, sessionErrors,
        log.droppedErrors or 0, #(log.blocked or {}), log.droppedBlocked or 0))
end

function Err.Clear()
    ForeverDumpLogDB.errors, ForeverDumpLogDB.blocked = {}, {}
    ForeverDumpLogDB.droppedErrors, ForeverDumpLogDB.droppedBlocked = nil, nil
    index = {}
end

function Err.Text()
    local lines = { "==== ERRORS ====" }
    for _, e in ipairs(ForeverDumpLogDB.errors or {}) do
        lines[#lines + 1] = string.format("[%dx] %s", e.count or 1, tostring(e.message))
        if e.stack then lines[#lines + 1] = e.stack end
        if e.locals then lines[#lines + 1] = "Locals:\n" .. e.locals end
        lines[#lines + 1] = ""
    end
    lines[#lines + 1] = "==== BLOCKED / FORBIDDEN / WARNINGS ===="
    for _, b in ipairs(ForeverDumpLogDB.blocked or {}) do
        local parts = {}
        for k, v in pairs(b.args or {}) do parts[#parts + 1] = tostring(k) .. "=" .. tostring(v) end
        table.sort(parts)
        lines[#lines + 1] = string.format("%s %s %s", tostring(b.date or b.time), b.event, table.concat(parts, " "))
    end
    return table.concat(lines, "\n")
end
