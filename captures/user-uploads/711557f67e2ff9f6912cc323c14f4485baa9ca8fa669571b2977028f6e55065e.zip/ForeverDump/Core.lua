-- ForeverDump v2 - Core: namespace, safe value handling, scheduler, saved variables.
-- Lua 5.1 only. Never yield inside pcall (Lua 5.1 cannot yield across a C boundary).
local ADDON_NAME, ns = ...

ns.ADDON = ADDON_NAME or "ForeverDump"
ns.VERSION = "2.0.0"
ns.SCHEMA = 2
ns.SECRET = "<secret>"
ns.SECRET_TABLE = "<secrettable>"

local type, pairs, next, tostring, rawget, pcall, select =
      type, pairs, next, tostring, rawget, pcall, select
local sort, concat, sub, format = table.sort, table.concat, string.sub, string.format

----------------------------------------------------------------------------
-- Output
----------------------------------------------------------------------------
local PREFIX = "|cff33ff99ForeverDump|r "
function ns.Print(...)
    local parts = {}
    for i = 1, select("#", ...) do parts[#parts + 1] = tostring((select(i, ...))) end
    local msg = PREFIX .. concat(parts, " ")
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage(msg)
    else
        print(msg)
    end
end

----------------------------------------------------------------------------
-- Secret values. Only issecretvalue/issecrettable/canaccessvalue ever see a
-- value before we know it is safe; nothing else touches a secret.
----------------------------------------------------------------------------
local issecretvalue = _G.issecretvalue
local issecrettable = _G.issecrettable
local canaccessvalue = _G.canaccessvalue

local function probeSecret(v)
    if issecretvalue and issecretvalue(v) then return true end
    if canaccessvalue and not canaccessvalue(v) then return true end
    if issecrettable and type(v) == "table" and issecrettable(v) then return true end
    return false
end

function ns.IsSecret(v)
    if v == nil then return false end
    local ok, res = pcall(probeSecret, v)
    if not ok then return true end -- if we cannot even ask, treat as secret
    return res
end
local IsSecret = ns.IsSecret

----------------------------------------------------------------------------
-- SavedVariables-safe copies (no functions/userdata/secrets/NaN/inf/cycles)
----------------------------------------------------------------------------
local HUGE = math.huge
local function cleanNumber(v)
    if v ~= v then return "<nan>" end
    if v == HUGE then return "<inf>" end
    if v == -HUGE then return "<-inf>" end
    return v
end
ns.CleanNumber = cleanNumber

function ns.IsFrame(v)
    return type(v) == "table" and type(rawget(v, 0)) == "userdata"
end
local IsFrame = ns.IsFrame

local function frameLabel(v)
    local ok, name = pcall(v.GetName, v)
    if ok and type(name) == "string" and not IsSecret(name) then return "<frame:" .. name .. ">" end
    return "<frame>"
end

-- opts: maxDepth (default 4), maxKeys (default 200), maxString (default 4000)
function ns.Clean(v, opts, depth, path)
    if v == nil then return nil end
    if IsSecret(v) then
        return (type(v) == "table") and ns.SECRET_TABLE or ns.SECRET
    end
    local t = type(v)
    if t == "number" then return cleanNumber(v) end
    if t == "boolean" then return v end
    if t == "string" then
        local maxString = opts and opts.maxString or 4000
        if #v > maxString then return sub(v, 1, maxString) .. "<...truncated " .. #v .. ">" end
        return v
    end
    if t == "table" then
        if IsFrame(v) then return frameLabel(v) end
        depth = depth or 0
        local maxDepth = opts and opts.maxDepth or 4
        if depth >= maxDepth then return "<table>" end
        path = path or {}
        if path[v] then return "<cycle>" end
        path[v] = true
        local out, n = {}, 0
        local maxKeys = opts and opts.maxKeys or 200
        for k, val in next, v do
            n = n + 1
            if n > maxKeys then out["<truncated>"] = true break end
            local kt = type(k)
            local key
            if IsSecret(k) then
                key = nil
            elseif kt == "string" then
                key = k
            elseif kt == "number" then
                key = (k ~= k or k == HUGE or k == -HUGE) and tostring(k) or k
            elseif kt == "boolean" then
                key = "<bool:" .. tostring(k) .. ">"
            else
                key = "<" .. kt .. ">"
            end
            if key ~= nil then
                local cv = ns.Clean(val, opts, depth + 1, path)
                if cv ~= nil then out[key] = cv end
            end
        end
        path[v] = nil
        return out
    end
    return "<" .. t .. ">"
end

function ns.Pack(...) return { n = select("#", ...), ... } end

-- Pack all returns of a pcall-ed function into a clean array plus count.
function ns.SafeCall(fn, ...)
    if type(fn) ~= "function" then return { ok = false, err = "missing" } end
    local res = ns.Pack(pcall(fn, ...))
    if not res[1] then
        return { ok = false, err = ns.Clean(res[2], { maxString = 300 }) }
    end
    local out = { ok = true, n = 0, values = {}, secret = {} }
    local count = res.n - 1
    out.n = count
    for i = 1, count do
        local v = res[i + 1]
        if IsSecret(v) then out.secret[#out.secret + 1] = i end
        local cv = ns.Clean(v, { maxDepth = 5, maxKeys = 300 })
        if cv == nil then cv = "<nil>" end
        out.values[i] = cv
    end
    if #out.secret == 0 then out.secret = nil end
    return out
end

function ns.SortedKeys(t)
    local keys = {}
    for k in next, t do keys[#keys + 1] = k end
    sort(keys, function(a, b) return tostring(a) < tostring(b) end)
    return keys
end

function ns.SortedList(set)
    local list = {}
    for k in next, set do list[#list + 1] = k end
    sort(list, function(a, b) return tostring(a) < tostring(b) end)
    return list
end

-- Resolve "C_Item.GetItemInfo" or "GetTime" to a value without metamethods.
function ns.Resolve(path)
    local cur = _G
    for part in string.gmatch(path, "[^%.]+") do
        if type(cur) ~= "table" then return nil end
        cur = rawget(cur, part)
    end
    return cur
end

function ns.Call(path, ...)
    local fn = ns.Resolve(path)
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c, d, e, f, g, h, i, j, k, l, m, n2, o, p, q, r, s =
        pcall(fn, ...)
    if not ok then return nil end
    return a, b, c, d, e, f, g, h, i, j, k, l, m, n2, o, p, q, r, s
end

----------------------------------------------------------------------------
-- Build / meta
----------------------------------------------------------------------------
-- Flavor info. Do NOT assume Mainline: newer Forever builds report WOW_PROJECT_ID == WOW_PROJECT_CAMELOT,
-- older ones (e.g. 70009) reported WOW_PROJECT_MAINLINE. Record every WOW_PROJECT_* constant verbatim.
function ns.ProjectInfo()
    local id = rawget(_G, "WOW_PROJECT_ID")
    local consts, names = {}, {}
    for k, v in pairs(_G) do
        if type(k) == "string" and string.find(k, "^WOW_PROJECT_") and type(v) ~= "table" and type(v) ~= "function" then
            consts[k] = v
            if v == id and k ~= "WOW_PROJECT_ID" then names[#names + 1] = k end
        end
    end
    table.sort(names)
    return id, consts, (#names > 0) and table.concat(names, ",") or nil
end

-- Returns true/false, or nil if the API is missing / errored (scripts disallowed => /run, /dump, /tinspect are inert).
function ns.ScriptsDisallowed()
    local A = rawget(_G, "C_AddOns")
    local f = type(A) == "table" and A.GetScriptsDisallowedForBeta
    if type(f) ~= "function" then return nil end
    local ok, v = pcall(f)
    if ok and not ns.IsSecret(v) then return v end
    return nil
end

function ns.Meta()
    local version, build, buildDate, toc = ns.Call("GetBuildInfo")
    local projectID, projectConstants, projectName = ns.ProjectInfo()
    return {
        addonVersion = ns.VERSION,
        schemaVersion = ns.SCHEMA,
        version = version,
        build = build,
        buildDate = buildDate,
        toc = toc,
        locale = ns.Call("GetLocale"),
        projectID = projectID,
        projectName = projectName,
        projectConstants = projectConstants,
        scriptsDisallowedForBeta = ns.ScriptsDisallowed(),
        time = time and time() or nil,
        date = date and date("%Y-%m-%d %H:%M:%S") or nil,
        inCombat = ns.InCombat(),
    }
end

-- Events that must never be registered by an addon on Forever/Midnight-era clients: registering them fires
-- ADDON_ACTION_FORBIDDEN and the "blocked from an action only available to the Blizzard UI" popup.
ns.EVENT_DENYLIST = {
    COMBAT_LOG_EVENT = "restricted since 12.0.0 (ADDON_ACTION_FORBIDDEN on register)",
    COMBAT_LOG_EVENT_UNFILTERED = "restricted since 12.0.0 (ADDON_ACTION_FORBIDDEN on register)",
    COMBAT_LOG_EVENT_INTERNAL_UNFILTERED = "internal combat log event",
}

-- Documented events that are safe to register individually. Returns list, skipped{event = reason} or nil, err.
-- Skips: denylist, events with HasRestrictions, events of systems whose Environment is not "All"
-- (e.g. SecureOnly), and events C_EventUtils.IsEventValid rejects.
function ns.SafeEventList()
    local docs, err = ns.Legacy.LoadDocs()
    if not docs then return nil, nil, "Blizzard_APIDocumentation unavailable: " .. tostring(err) end
    local isValid = C_EventUtils and C_EventUtils.IsEventValid
    local list, skipped, seen = {}, {}, {}
    for i = 1, #docs.systems do
        local sys = docs.systems[i]
        local env = type(sys) == "table" and rawget(sys, "Environment")
        local events = type(sys) == "table" and rawget(sys, "Events")
        if type(events) == "table" then
            for j = 1, #events do
                local ev = events[j]
                local name = type(ev) == "table" and (rawget(ev, "LiteralName") or rawget(ev, "Name"))
                if type(name) == "string" and not seen[name] then
                    seen[name] = true
                    if ns.EVENT_DENYLIST[name] then
                        skipped[name] = "denylist: " .. ns.EVENT_DENYLIST[name]
                    elseif rawget(ev, "HasRestrictions") then
                        skipped[name] = "docs: HasRestrictions"
                    elseif env and env ~= "All" then
                        skipped[name] = "docs: system Environment=" .. tostring(env)
                    elseif isValid then
                        local ok, valid = pcall(isValid, name)
                        if ok and valid == false then skipped[name] = "C_EventUtils.IsEventValid=false"
                        else list[#list + 1] = name end
                    else
                        list[#list + 1] = name
                    end
                end
            end
        end
    end
    for name, reason in pairs(ns.EVENT_DENYLIST) do
        if not skipped[name] then skipped[name] = "denylist: " .. reason end
    end
    table.sort(list)
    return list, skipped
end

function ns.InCombat()
    local f = rawget(_G, "InCombatLockdown")
    if type(f) ~= "function" then return false end
    local ok, v = pcall(f)
    return ok and v == true
end

----------------------------------------------------------------------------
-- Saved variables
----------------------------------------------------------------------------
ns.defaults = {
    frameBudgetMs = 12,      -- per-frame CPU budget for chunked jobs
    progressEverySec = 2,
    uiMaxChars = 120000,     -- copy UI text cap
    record = {
        maxEvents = 5000,    -- ring buffer size
        perEventPerSec = 5,  -- throttle for spammy events (UNIT_*, CLEU, ...)
        maxSessions = 3,
        maxArgs = 20,
        maxString = 300,
        callbacks = true,    -- also log EventRegistry callbacks
        redactChat = true,   -- CHAT_MSG_*/BN_*/CLUB_* args replaced by "<redacted>" (privacy)
    },
    cl = {
        maxEvents = 20000,    -- combat log ring buffer size (entries, incl. context events)
        maxSessions = 3,
        maxArgs = 40,         -- CLEU payload args kept per entry
        maxString = 200,
        redactPlayers = false, -- true: player names -> "<player>", Player GUIDs -> "Player-#n"
        advanced = true,      -- with "/fdump cl start file": also set advancedCombatLogging=1 (restored on stop)
        damageMeter = true,   -- C_DamageMeter snapshot after PLAYER_REGEN_ENABLED and on stop (secret in combat)
    },
    logs = {                  -- /fdump logs + FD_Logs macro
        chat = true,          -- include the chat log (/chatlog -> Logs/WoWChatLog.txt; contains other players' chat!)
        advanced = true,      -- advancedCombatLogging=1 while on
        scriptErrors = true,  -- scriptErrors=1 while on
        taintLog = 1,         -- taintLog level while on (1 blocked actions, 2 global reads/writes); 0 = leave alone
        callLogging = false,  -- true: addon calls LoggingCombat/LoggingChat itself (only if not protected on your build)
    },
    errors = {
        enabled = true,       -- chain the Lua error handler at load and log errors (/fdump errors off to disable)
        maxErrors = 200,      -- unique error messages kept
        maxBlocked = 500,     -- ADDON/MACRO_ACTION_BLOCKED/FORBIDDEN + LUA_WARNING entries kept
        captureLocals = true, -- debuglocals() when available
        maxLocals = 4000,
        maxStack = 4000,
    },
    probe = {
        items = { 6948, 2589, 118, 25, 2070, 159 },
        spells = { 6603, 8690, 133, 2050, 1459, 78, 465, 1752 },
        quests = { 783, 7, 33 },
        units = { "player", "target", "focus", "pet", "mouseover", "party1" },
        achievements = { 6, 7 },
        currencies = { 1, 81, 1792 },
        maxAuras = 40,
        redactPlayers = true, -- player names/realm/player GUIDs replaced by placeholders
    },
}

local function mergeDefaults(dst, src)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            mergeDefaults(dst[k], v)
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

function ns.InitDB()
    if type(ForeverDumpDB) ~= "table" then ForeverDumpDB = {} end
    local db = ForeverDumpDB
    db.schemaVersion = ns.SCHEMA
    db.addonVersion = ns.VERSION
    if type(db.config) ~= "table" then db.config = {} end
    mergeDefaults(db.config, ns.defaults)
    if type(db.sections) ~= "table" then db.sections = {} end
    if type(db.history) ~= "table" then db.history = {} end
    if type(ForeverDumpDocsDB) ~= "table" then ForeverDumpDocsDB = {} end
    if type(ForeverDumpStringsDB) ~= "table" then ForeverDumpStringsDB = {} end
    if type(ForeverDumpRecordDB) ~= "table" then ForeverDumpRecordDB = {} end
    if type(ForeverDumpRecordDB.sessions) ~= "table" then ForeverDumpRecordDB.sessions = {} end
    ForeverDumpRecordDB.schemaVersion = ns.SCHEMA
    if type(ForeverDumpLogDB) ~= "table" then ForeverDumpLogDB = {} end
    for _, k in ipairs({ "errors", "blocked", "handlerEvents" }) do
        if type(ForeverDumpLogDB[k]) ~= "table" then ForeverDumpLogDB[k] = {} end
    end
    ForeverDumpLogDB.schemaVersion = ns.SCHEMA
    if type(ForeverDumpCombatLogDB) ~= "table" then ForeverDumpCombatLogDB = {} end
    if type(ForeverDumpCombatLogDB.sessions) ~= "table" then ForeverDumpCombatLogDB.sessions = {} end
    ForeverDumpCombatLogDB.schemaVersion = ns.SCHEMA
    ns.db = db
    ns.config = db.config
end

function ns.SaveSection(name, data)
    data.meta = ns.Meta()
    ns.db.sections[name] = data
    ns.db.meta = ns.Meta()
    local h = ns.db.history
    h[#h + 1] = { section = name, build = data.meta.build, version = data.meta.version, time = data.meta.time }
    while #h > 100 do table.remove(h, 1) end
end

----------------------------------------------------------------------------
-- Chunked job scheduler (coroutines driven by OnUpdate)
----------------------------------------------------------------------------
local debugprofilestop = _G.debugprofilestop or function() return (os and os.clock and os.clock() or 0) * 1000 end
ns.queue = {}
ns.current = nil
local sliceStart = 0
local lastProgress = 0

-- Collectors call this often. Yields when the frame budget is used up.
function ns.Yield()
    if not ns.current then return end
    if debugprofilestop() - sliceStart >= (ns.config and ns.config.frameBudgetMs or 12) then
        coroutine.yield()
    end
end

function ns.Progress(label, done, total)
    local now = (GetTime and GetTime()) or 0
    if now - lastProgress >= (ns.config and ns.config.progressEverySec or 2) then
        lastProgress = now
        if total and total > 0 then
            ns.Print(format("%s: %d/%d (%d%%)", label, done, total, math.floor(done * 100 / total)))
        else
            ns.Print(format("%s: %d", label, done))
        end
    end
end

-- job = { name=, fn=function(job) end, combatSafe=bool, onDone=function(ok, err) }
function ns.Enqueue(job)
    ns.queue[#ns.queue + 1] = job
    ns.EnsureRunner()
end

function ns.IsBusy() return ns.current ~= nil or #ns.queue > 0 end

local runner
local pausedNotice = false
local function step()
    if not ns.current then
        local job = table.remove(ns.queue, 1)
        if not job then
            runner:SetScript("OnUpdate", nil)
            return
        end
        job.co = coroutine.create(job.fn)
        job.started = GetTime and GetTime() or 0
        ns.current = job
        ns.Print("running '" .. job.name .. "'...")
    end
    local job = ns.current
    if not job.combatSafe and ns.InCombat() then
        if not pausedNotice then
            ns.Print("combat started: '" .. job.name .. "' paused until you leave combat.")
            pausedNotice = true
        end
        return
    end
    pausedNotice = false
    sliceStart = debugprofilestop()
    local ok, err = coroutine.resume(job.co, job)
    local status = coroutine.status(job.co)
    if not ok or status == "dead" then
        ns.current = nil
        local secs = (GetTime and GetTime() or 0) - (job.started or 0)
        if ok then
            ns.Print(format("'%s' done in %.1fs.", job.name, secs))
        else
            ns.Print("|cffff5555'" .. job.name .. "' failed:|r " .. tostring(err))
            if ns.db then
                ns.db.errors = ns.db.errors or {}
                ns.db.errors[#ns.db.errors + 1] = { job = job.name, err = tostring(err), time = time and time() }
                while #ns.db.errors > 50 do table.remove(ns.db.errors, 1) end
            end
        end
        if job.onDone then pcall(job.onDone, ok, err) end
        if #ns.queue == 0 then
            ns.Print("all jobs finished. |cffffff00/reload or log out to write SavedVariables to disk.|r")
        end
    end
end

function ns.EnsureRunner()
    if not runner then runner = CreateFrame("Frame") end
    runner:SetScript("OnUpdate", step)
end

function ns.CancelAll()
    ns.queue = {}
    ns.current = nil
    if runner then runner:SetScript("OnUpdate", nil) end
end

----------------------------------------------------------------------------
-- Section registry
----------------------------------------------------------------------------
ns.sections = {}
ns.sectionOrder = {}
-- def = { name=, desc=, run=function(job) ... end, combatSafe=, inAll=bool }
function ns.RegisterSection(def)
    ns.sections[def.name] = def
    ns.sectionOrder[#ns.sectionOrder + 1] = def.name
end

function ns.RunSection(name, args)
    local def = ns.sections[name]
    if not def then ns.Print("unknown section: " .. tostring(name)) return end
    if not def.combatSafe and ns.InCombat() then
        ns.Print("|cffff5555refusing '" .. name .. "' in combat.|r Leave combat and try again.")
        return
    end
    ns.Enqueue({ name = name, combatSafe = def.combatSafe, fn = function(job) def.run(job, args) end })
end

----------------------------------------------------------------------------
-- Events
----------------------------------------------------------------------------
ns.eventHandlers = {}
function ns.On(event, fn)
    ns.eventHandlers[event] = ns.eventHandlers[event] or {}
    table.insert(ns.eventHandlers[event], fn)
    if ns.eventFrame then ns.eventFrame:RegisterEvent(event) end
end

ns.loadedAddOns = {} -- ADDON_LOADED order seen this session (includes Blizzard_*)

local eventFrame = CreateFrame("Frame")
ns.eventFrame = eventFrame
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if type(name) == "string" and not IsSecret(name) then
            ns.loadedAddOns[#ns.loadedAddOns + 1] = name
        end
        if name == ns.ADDON then ns.InitDB() end
    end
    local list = ns.eventHandlers[event]
    if list then
        for i = 1, #list do
            local ok, err = pcall(list[i], event, ...)
            if not ok then ns.Print("handler error (" .. event .. "): " .. tostring(err)) end
        end
    end
end)
