-- ForeverDump v2 - recorder: /fdump record start|stop|status
-- Registers all events on a hidden frame and logs timestamp, event, args
-- (secret values become "<secret>" and are never touched), combat flag.
-- Bounded ring buffer + per-event throttle for spam. Combat-safe.
local _, ns = ...
local Rec = {}
ns.Recorder = Rec

local GetTime = GetTime
local frame
local active = false
local session, ring, head, size
local cfg
local throttle = {}   -- event -> { second = n, count = c }

local function serializeArg(v, maxString)
    if v == nil then return "<nil>" end
    if ns.IsSecret(v) then return (type(v) == "table") and ns.SECRET_TABLE or ns.SECRET end
    local t = type(v)
    if t == "string" then
        if #v > maxString then return string.sub(v, 1, maxString) .. "<...>" end
        return v
    elseif t == "number" then
        return ns.CleanNumber(v)
    elseif t == "boolean" then
        return v
    elseif t == "table" then
        return ns.Clean(v, { maxDepth = 2, maxKeys = 30, maxString = maxString })
    end
    return "<" .. t .. ">"
end

local function packArgs(maxArgs, maxString, ...)
    local n = select("#", ...)
    local args = {}
    local secrets
    for i = 1, math.min(n, maxArgs) do
        local v = select(i, ...)
        local s = serializeArg(v, maxString)
        if s == ns.SECRET or s == ns.SECRET_TABLE then
            secrets = secrets or {}
            secrets[#secrets + 1] = i
        end
        args[i] = s
    end
    return args, n, secrets
end

ns.SerializeArg = serializeArg
ns.PackArgs = packArgs

local function push(entry)
    head = head % size + 1
    ring[head] = entry
    session.total = session.total + 1
end

local function allowed(event)
    local now = math.floor(GetTime())
    local t = throttle[event]
    if not t or t.second ~= now then
        t = { second = now, count = 0 }
        throttle[event] = t
    end
    t.count = t.count + 1
    local limit = cfg.perEventPerSec
    if event == "COMBAT_LOG_EVENT_UNFILTERED" or event == "COMBAT_LOG_EVENT" then limit = limit * 4 end
    return t.count <= limit
end

local function onEvent(_, event, ...)
    if not active then return end
    local counts = session.counts
    counts[event] = (counts[event] or 0) + 1
    if not allowed(event) then
        session.dropped[event] = (session.dropped[event] or 0) + 1
        return
    end
    local entry = { t = GetTime(), e = event, c = ns.InCombat() or nil }
    local args, n, secrets
    if cfg.redactChat and (string.find(event, "^CHAT_MSG_") or string.find(event, "^BN_") or string.find(event, "^CLUB_")) then
        n = select("#", ...)
        entry.a, entry.n, entry.redacted = { "<redacted>" }, n, true
        push(entry)
        return
    end
    if event == "COMBAT_LOG_EVENT_UNFILTERED" and type(rawget(_G, "CombatLogGetCurrentEventInfo")) == "function" then
        local ok = pcall(function()
            args, n, secrets = packArgs(cfg.maxArgs + 10, cfg.maxString, CombatLogGetCurrentEventInfo())
        end)
        if not ok then args, n = { "<CombatLogGetCurrentEventInfo failed>" }, 1 end
        entry.cleu = true
    else
        args, n, secrets = packArgs(cfg.maxArgs, cfg.maxString, ...)
    end
    entry.a = args
    entry.n = n
    entry.s = secrets
    push(entry)
end

local callbackHooked = false
local function hookCallbacks()
    if callbackHooked then return end
    local reg = rawget(_G, "EventRegistry")
    if type(reg) == "table" and type(reg.TriggerEvent) == "function" then
        hooksecurefunc(reg, "TriggerEvent", function(_, event, ...)
            if not active or not cfg.callbacks then return end
            if type(event) ~= "string" or ns.IsSecret(event) then return end
            local key = "CB:" .. event
            session.counts[key] = (session.counts[key] or 0) + 1
            if not allowed(key) then
                session.dropped[key] = (session.dropped[key] or 0) + 1
                return
            end
            local args, n, secrets = packArgs(cfg.maxArgs, cfg.maxString, ...)
            push({ t = GetTime(), e = event, cb = true, c = ns.InCombat() or nil, a = args, n = n, s = secrets })
        end)
        callbackHooked = true
    end
end

function Rec.Start()
    if active then ns.Print("recorder already running.") return end
    cfg = ns.config.record
    size = math.max(100, tonumber(cfg.maxEvents) or 5000)
    ring, head = {}, 0
    throttle = {}
    session = { meta = ns.Meta(), startTime = GetTime(), startEpoch = time(), total = 0, counts = {}, dropped = {},
                config = ns.Clean(cfg) }
    if not frame then
        frame = CreateFrame("Frame")
        frame:Hide()
    end
    -- Never RegisterAllEvents(): on Forever it would include restricted events (COMBAT_LOG_EVENT*), and
    -- registering those fires ADDON_ACTION_FORBIDDEN + a "disable addon" popup that pcall cannot stop.
    -- Register documented events one by one, skipping anything the docs mark restricted/secure-only.
    local events, skipped, why = ns.SafeEventList()
    if not events then
        ns.Print("|cffff5555cannot record:|r " .. tostring(why) .. " (refusing to fall back to RegisterAllEvents)")
        session = nil
        return
    end
    local failed = {}
    for _, e in ipairs(events) do
        local ok, err = pcall(frame.RegisterEvent, frame, e)
        if not ok then failed[e] = tostring(err) end
    end
    frame:SetScript("OnEvent", onEvent)
    session.registered = #events
    session.skippedEvents = skipped
    session.registerFailed = failed
    hookCallbacks()
    active = true
    local nSkipped = 0
    for _ in pairs(session.skippedEvents) do nSkipped = nSkipped + 1 end
    ns.Print(string.format("registered %d documented events, skipped %d restricted/secure-only (see session.skippedEvents)",
        session.registered, nSkipped))
    ns.Print("recording events (ring buffer " .. size .. ", throttle " .. cfg.perEventPerSec .. "/s per event). /fdump record stop to save.")
end

function Rec.Stop()
    if not active then ns.Print("recorder is not running.") return end
    active = false
    pcall(frame.UnregisterAllEvents, frame)
    -- linearize ring buffer, oldest first
    local events = {}
    local count = math.min(session.total, size)
    local start = (session.total > size) and (head % size + 1) or 1
    for i = 0, count - 1 do
        local idx = (start + i - 1) % size + 1
        events[#events + 1] = ring[idx]
    end
    session.events = events
    session.stopTime = GetTime()
    session.stopEpoch = time()
    session.kept = #events
    session.overwritten = math.max(0, session.total - size)
    local sessions = ForeverDumpRecordDB.sessions
    sessions[#sessions + 1] = session
    while #sessions > (tonumber(ns.config.record.maxSessions) or 3) do table.remove(sessions, 1) end
    ns.Print(string.format("recording saved: %d events kept (%d recorded, %d overwritten). /reload or log out to write it.",
        #events, session.total, session.overwritten))
    ring, session = nil, nil
end

function Rec.Status()
    if active then
        ns.Print(string.format("recording: %d events so far (%.0fs).", session.total, GetTime() - session.startTime))
    else
        ns.Print("recorder idle; " .. #ForeverDumpRecordDB.sessions .. " saved session(s).")
    end
end

function Rec.IsActive() return active end
