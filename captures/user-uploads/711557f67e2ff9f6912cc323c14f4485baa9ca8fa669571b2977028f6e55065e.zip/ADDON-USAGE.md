# ForeverDump v2: addon usage

ForeverDump records what the WoW Forever client (1.60.x, Interface 16001, game type `camelot`) actually
exposes to addons, and saves it to SavedVariables so the box-side converter (`tools/fdump.py`) can turn it into
JSON, LuaLS stubs, a luacheck std, busted mocks and replay fixtures.

> It has been tested only in a mock client built from the real Forever API documentation, **not in-game yet**.

## Install
1. Unzip `ForeverDump-v2.zip`. Copy the `ForeverDump` folder (it contains `ForeverDump.toc`) to
   `World of Warcraft\_classic_beta_\Interface\AddOns\ForeverDump\`
   (this folder is for Forever; `_retail_` and `_classic_` are different clients).
2. Start the game and enable **ForeverDump** in the AddOns list on the character screen. If it shows as
   "out of date", tick "Load out of date AddOns".
3. In game, type `/fdump help`. Every command also works as `/foreverdump`.

## Run order (out of combat; the addon refuses heavy dumps in combat)
| Step | Command | What it does |
|---|---|---|
| 1 | `/fdump status` | Prints the build, `WOW_PROJECT_ID` (Forever = 18, `WOW_PROJECT_CAMELOT`), every `WOW_PROJECT_*` constant, `C_AddOns.GetScriptsDisallowedForBeta()`, and what has been collected so far |
| 2 | `/fdump all` | Runs docs, api, globals, strings, widgets, templates, frames, addons, cvars, protected and extras, in chunks over many frames. You can keep playing; `/fdump cancel` stops it |
| 3 | `/fdump getters` *(optional)* | Calls the documented zero-argument `Get*`/`Is*` functions that have no restriction flags, and records their returns and secrecy |
| 4 | `/fdump widgets risky` *(optional)* | Also creates the rarer widget types (Browser and similar) |
| 5 | `/fdump probe`, `/fdump probe combat` *(optional)* | Samples tooltips and getters now, or arms a sample for the next combat (secret detection) |
| 6 | `/fdump record start` … `/fdump record stop` | Event recorder: registers each documented event **individually** and skips restricted or SecureOnly events plus a denylist. The skipped events and reasons are saved |
| 7 | `/fdump cl start` … fight … `/fdump cl stop` | Combat recorder (UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING, COMBAT_TEXT_UPDATE + `C_CombatText.GetCurrentEventInfo`, ENCOUNTER_*, PLAYER_REGEN_*). It takes a `C_DamageMeter` snapshot after each combat |
| 8 | `/fdump logs macro`, then click **FD_Logs** | Creates one account macro, FD_Logs. **One click turns all logging ON** (combat log, advancedCombatLogging, scriptErrors, taintLog, chat log). **The next click turns it all OFF.** Watch for the chat line `ForeverDump logging: ON/OFF - …` |
| 9 | `/fdump errors show`, `/fdump profile` | Shows the captured Lua errors and ADDON_ACTION_BLOCKED/FORBIDDEN events; takes a per-addon CPU/memory snapshot |
| 10 | `/reload` (or log out) | **Required.** The client only writes SavedVariables on reload, logout or exit |

Other commands: `/fdump show <status|apis|events|enums|cvars|all|errors|section>` opens a copy window (capped size).
`/fdump clear <section|docs|strings|record|cl|errors|probe|all>` deletes collected data, and `/fdump set <key> <value>` changes
an option (for example `set logs.chat false` or `set cl.maxEvents 50000`). Plain `/fdump` still does the v1 quick dump.

### The FD_Logs macro
- The macro body is `/fdump logs` plus `/combatlog` and/or `/chatlog` lines (under 255 characters). The addon tracks
  ON/OFF in SavedVariables and sets the CVars itself. It does **not** call `LoggingCombat`/`LoggingChat`, because
  it is unverified whether those are protected on Forever, and a protected call raises a "disable addon" popup.
  The `/combatlog` and `/chatlog` lines run through Blizzard's own slash handlers when **you** click, which works
  either way.
- `/combatlog` and `/chatlog` are toggles. After every click the addon rewrites the macro (out of combat only) so it
  contains just the toggles needed for the next state, checked against `C_ChatInfo.IsLoggingCombat()`/`IsLoggingChat()`.
  If the chat line shows something in red as "still ON/OFF", type that command once or click again.
- OFF restores advancedCombatLogging and scriptErrors to their values before ON, and sets taintLog to 0.
- The macro uses no `/run` or `/script`, so it works even when `GetScriptsDisallowedForBeta()` is true (as reported on
  Forever). These docs don't rely on `/run` anywhere.
- Macros can't be created or edited in combat. In that case the addon waits and does it after combat. If all 120
  General macro slots are full, it says so.

### Combat log restriction on Forever
`COMBAT_LOG_EVENT(_UNFILTERED)` is restricted. Registering it fires ADDON_ACTION_FORBIDDEN and a popup offering to
disable the addon (pcall doesn't prevent this), and `CombatLogGetCurrentEventInfo` is gone. ForeverDump never registers it.
`/fdump cl cleu-force` is an explicit opt-in that refuses unless the getter exists **and**
`C_CombatLog.IsCombatLogRestricted()` returns false. Use the file log (FD_Logs) together with
`tools/fdump.py combatlog` instead.

## Where the files land
- SavedVariables: `World of Warcraft\_classic_beta_\WTF\Account\<ACCOUNT>\SavedVariables\ForeverDump.lua`
  (ForeverDumpDB, …DocsDB, …StringsDB, …RecordDB, …LogDB, …CombatLogDB; a full run is around 8 MB)
- Logs (after FD_Logs ON): `World of Warcraft\_classic_beta_\Logs\WoWCombatLog-*.txt`, `WoWChatLog.txt`, `taint.log`
- Copy them to the box and run `python3 tools/fdump.py all ForeverDump.lua -o out/` (see `tools/README.md`).

## Privacy
`<ACCOUNT>` in the WTF path is your account name, and the chat log and combat log contain other players' names and
messages. Don't post those files publicly or share account-identifying or credential-bearing data. The recorder has
`set cl.redactPlayers true` for player GUIDs and names in legacy captures. Review files before sharing them.
