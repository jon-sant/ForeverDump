"""v2.2.18 derivation inventory: for every guide row (value family x unit family) and every former
"unsolvable" HSM row, the alternate API / higher-order inference chain that derives the secret value, which inputs are
readable, the offline estimate on runs 9-14 (combat log truth, leave-one-run-out reference data) and the live probe
(ForeverDumpLogDB.derive key) that settles the open readability question.

Status vocabulary:
  direct        the value itself is readable (no derivation needed)
  derived       derivation implemented and scored offline (numbers in `estimate`)
  derivable     derivation designed; inputs readable; needs the probe / live scoring
  probe         an input's readability is still unknown; the Derive probe measures it in the next BG
  bound         only a bound / presence is derivable from readable inputs today
"""

DERIVE_STATUSES = ("direct", "derived", "derivable", "probe", "bound")

# id -> dict(path, inputs, estimate, probe, status, fam={family: overrides})
DERIVE = {
    "health": dict(
        status="derived",
        path="UNIT_COMBAT amounts (clear on every token) accumulated per IdKey (GUID, or name key for hostile players) "
             "on a cached max (healthMax row) -> c-hp-net running estimate; resync on any clear UnitHealth read and on "
             "UNIT_DIED (0) / out-of-combat full",
        inputs="UNIT_COMBAT action/amount/school (clear), UNIT_HEALTH tick timing (clear), healthMax cache",
        estimate="c-hp-net offline (run 14 BG): 89.1% of samples within tolerance of the log value",
        probe="derive.read UnitHealthPercent|UnitHealthMissing per family/ctx (an alternate API may be clear)",
        fam={"player": dict(status="direct", path="UnitHealth on player is clear; running estimate only as a fallback")}),
    "healthMax": dict(
        status="derived",
        path="clear UnitHealthMax reads cached per IdKey / NPC id; otherwise RefData.npcs[npcId].maxHP[level] (mined) "
             "or RefData.classLevelHP[class][level] once the class engine knows the class (UnitLevel is clear on target)",
        inputs="UnitHealthMax ooc, UnitLevel (clear on target), class engine, RefData npcs (35) and classLevelHP (106 cells)",
        estimate="NPC max: exact per level from the log; player max: class x level median (gear spread, the HP net "
                 "corrects with the first clear percentage)",
        probe="derive.read UnitHealthMax|nameplateN|hostileP|combat and UnitLevel per family",
        fam={"player": dict(status="direct", path="clear")}),
    "power": dict(
        status="derivable",
        path="power TYPE is clear in UNIT_POWER_* (feeds the class engine); amount: player = UNIT_POWER_UPDATE deltas + "
             "own cast costs (RefData cost); others = RefData spell cost x observed casts (mana spent lower bound), rage "
             "from UNIT_COMBAT dealt/taken, energy regen model",
        inputs="UNIT_POWER_FREQUENT powerType (clear: plates RAGE 599 / MANA 446 / ENERGY 112), cast timing, RefData cost",
        estimate="type: 100% readable (run 14 tape); amount: not scored yet",
        probe="derive.read UnitPower / UnitPowerMax per family/ctx; UnitPowerType (clear)"),
    "absorbs": dict(
        status="derivable",
        path="UNIT_ABSORB_AMOUNT_CHANGED (fires) + UNIT_COMBAT WOUND with the ABSORB flag in the same frame; the shield "
             "size from RefData amount bands of the absorb spell (caster class known)",
        inputs="absorb-changed delivery, UNIT_COMBAT flags (clear), RefData amount bands",
        estimate="presence: 100% from the event; size: amount band of the spell (2-98 percentile)",
        probe="derive.read UnitGetTotalAbsorbs per family/ctx"),
    "incheal": dict(
        status="bound",
        path="UNIT_HEAL_PREDICTION timing + the healer's cast start (raid tokens: timing clear) + RefData heal amount band",
        inputs="event timing, friendly cast timing, RefData amount bands",
        estimate="not scored (low value)",
        probe="derive.read UnitGetIncomingHeals per family/ctx"),
    "health-event": dict(status="direct", path="event delivery is clear", inputs="UNIT_HEALTH", estimate="-", probe="-"),
    "dead": dict(status="direct", path="UnitIsDeadOrGhost clear", inputs="-", estimate="-", probe="-"),
    "casting": dict(status="direct", path="event delivery is clear", inputs="-", estimate="-", probe="-"),
    "spellid": dict(
        status="derivable",
        path="(1) UnitCastingInfo planned start/end (if clear) -> planned cast time -> RefData castTime x the caster's class "
             "(class engine) -> candidate spells; (2) out of combat the meter's CombatSpells per clear-GUID source lists the "
             "spellIds actually used; (3) NPCs: castModel per NPC id",
        inputs="cast timing (clear), class engine, meter CombatSpells ooc (clear), RefData castTime (640 spells)",
        estimate="START->SUCCESS duration as the fingerprint: 0-60% (pushback stretches it) -> rejected; planned time "
                 "needs the probe",
        probe="derive.cast cast:<family> positions 5/6 (startMS/endMS) and 10 (spellID) codes",
        fam={"player": dict(status="direct", path="own spellIds clear")}),
    "castbar": dict(status="direct", path="castBarID clear", inputs="-", estimate="-", probe="-"),
    "casttiming": dict(
        status="derivable",
        path="START->STOP/SUCCEEDED event timing (clear) + RefData castTime of the derived spell; planned end from "
             "UnitCastingInfo if clear",
        inputs="event timing, RefData", estimate="planned-time readability pending",
        probe="derive.cast positions 5/6",
        fam={"player": dict(status="direct", path="clear")}),
    "interrupted": dict(status="direct", path="event delivery is clear", inputs="-", estimate="-", probe="-"),
    "interrupt-mine": dict(status="derived", path="HSM frame join (my cast / DM type 5 in the INTERRUPTED frame)",
                           inputs="clear timing", estimate="HSM accuracy in the guide evidence", probe="-"),
    "aura-event": dict(status="direct", path="UNIT_AURA delivery is clear", inputs="-", estimate="-", probe="-"),
    "aura-payload": dict(
        status="bound",
        path="payload wholly secret in BG -> presence/timing only: UNIT_AURA frame joined with a cast SUCCEEDED of a "
             "class-known caster in the same frame -> RefData spells of that class with an aura duration",
        inputs="UNIT_AURA timing, cast timing, class engine, RefData auraDur",
        estimate="identity from duration alone 1.0% unique (27.6k applications); with caster class 5.3% -> needs the "
                 "cast-frame join",
        probe="derive.read GetAuraSlots / GetAuraDataByIndex field codes per family/ctx"),
    "aura-details": dict(
        status="derivable",
        path="own auras: HSM cast+aura frame join (proven); others: caster cast frame + class + RefData auraDur, confirmed "
             "by the removal time (UNIT_AURA) matching the mined duration",
        inputs="as aura-payload", estimate="duration+class unique 5.3% offline; cast-frame join not yet scored",
        probe="derive.read aura field codes (spellId/duration/expirationTime/sourceUnit)"),
    "aura-count": dict(
        status="derivable",
        path="count = clear ooc baseline + UNIT_AURA add/remove deltas inferred from the cast-frame join",
        inputs="UNIT_AURA timing", estimate="not scored", probe="derive.read GetAuraSlots per family/ctx"),
    "aura-mine": dict(status="derived", path="HSM my-cast + UNIT_AURA frame join", inputs="clear own casts",
                      estimate="HSM accuracy in the guide evidence", probe="-"),
    "guid": dict(
        status="derivable",
        path="hostile players: name key (UnitName is clear on target C60, plate C6, targettarget C9) replaces the GUID as "
             "the identity (IdKey('name', name)); the meter's GUID is clear out of combat",
        inputs="UnitName (clear), meter sourceGUID ooc", estimate="name key covers 100% of named hostile players",
        probe="derive.meter.ooc guidClear / nameClear counters",
        fam={"player": dict(status="direct", path="clear")}),
    "name": dict(status="direct", path="clear (never stored raw)", inputs="-", estimate="-", probe="-"),
    "unit-combat": dict(status="direct", path="clear", inputs="-", estimate="-", probe="-"),
    "hit-mine": dict(status="derived", path="HSM dm-frame / cast-frame / swing-lag rules", inputs="clear timing + meter ticks",
                     estimate="HSM accuracy in the guide evidence", probe="-"),
    "hit-taken": dict(status="derived", path="UNIT_COMBAT player WOUND + DM type 7", inputs="clear", estimate="proven", probe="-"),
    "heal-mine": dict(status="derived", path="UNIT_COMBAT HEAL on me; same-class tie-break via the totem tick phase",
                      inputs="clear", estimate="see same-class tie-break", probe="-"),
    "heal-hostile": dict(status="derivable", path="UNIT_COMBAT HEAL on hostile tokens is clear; record it into the world unit",
                         inputs="clear", estimate="input clear", probe="-"),
    "unit-died": dict(status="derivable", path="secret player deaths: DM type 9 (deaths) in the same frame + the c-hp-net "
                                               "estimate reaching 0 + UnitIsDeadOrGhost on the name-keyed token",
                      inputs="DM type 9, UnitIsDeadOrGhost (clear)", estimate="not scored", probe="-"),
    "threat": dict(status="bound", path="n/a for enemy players; NPCs: last clear status + hit-mine damage share",
                   inputs="UNIT_THREAT_LIST_UPDATE timing", estimate="-", probe="derive.read UnitThreatSituation"),
    "range": dict(status="derivable", path="UnitDistanceSquared / UnitInRange probes; else own-spell range errors and "
                                           "swing updates; plates exist only within the plate distance",
                  inputs="plate add/remove (clear)", estimate="bound only", probe="derive.read UnitDistanceSquared/UnitInRange",
                  fam={"target": dict(status="direct", path="cached")}),
    "cooldown": dict(status="derived", path="HSM cd tracker from my casts + SPELL_UPDATE_COOLDOWN", inputs="clear own casts",
                     estimate="proven", probe="-"),
    "meter": dict(status="derived", path="totals clear after combat; in combat the session update timing + DM ticks",
                  inputs="session events", estimate="provisional", probe="derive.meter counters"),
    "class": dict(
        status="derived",
        path="class engine (Lib/ClassEvidence): power type (P) -> candidates; meter composition per team (K) eliminates "
             "absent classes; meter name-key join out of combat (M) assigns; clear spellId / summon -> RefData class; "
             "scoreboard name+classToken; plate bar colour; arena spec",
        inputs="powerType (clear), meter classFilename (always clear), meter names ooc (14/16 clear), RefData",
        estimate="P+K 0 false assignments on runs 9-14, coverage 6.7-26.3%; M join 100% coverage, median time-to-identify "
                 "48-217 s (accuracy depends on enemy row names being clear ooc: probe)",
        probe="derive.meter.ooc enemyNameClear, derive.score field codes, derive.color bar:<ctx>, derive.summary",
        fam={"player": dict(status="direct", path="clear"), "friendly": dict(status="direct", path="party/raid UnitClass clear")}),
}

# value families that have no guide row of their own (former HSM-STATUS section 3 + new)
EXTRA = [
    ("census", "enemy same-class census (how many enemy shamans)", dict(
        status="derived",
        path="meter rows with displayType 2 (enemy) carry a clear classFilename -> per-team class composition -> "
             "Inference.SetMeterEnemyCensus (max with the plate count, 120 s validity)",
        inputs="meter classFilename (clear)", estimate="enemy shaman count = log on runs 10-14 (0/0, 1/1, 3/3, 0/0, 3/3); "
                                                       "full composition 13/15 to 16/19 enemies in the window",
        probe="derive.meterCompLast vs the log")),
    ("same-class", "which of two same-class players applied an identical aura / heal on me", dict(
        status="derived",
        path="totem tick phase: a friendly shaman's raid-token cast timing (clear) sets candidate drop times; a tick not on "
             "my own drop phase (mod 2 s) is not mine; RefData summons -> owner class; GetTotemInfo for my own slots",
        inputs="raid-token cast timing (clear), my totem drop time (clear), RefData summons",
        estimate="Healing Stream ticks on me, runs 9-14: other shamans' ticks exclude me 35/35; my ticks keep me "
                 "204/215 (94.9%); unique-owner by phase 132/250",
        probe="derive.read GetTotemInfo#1-4|global, UnitIsOwnerOrControllerOfUnit on pet/totem plates")),
    ("aura-source", "aura identity and source on other units (BG)", dict(
        status="bound",
        path="UNIT_AURA frame + the caster's cast timing in that frame + caster class (engine) + RefData auraDur; "
             "confirmed by the removal at the mined duration",
        inputs="UNIT_AURA timing, cast timing, class engine, RefData",
        estimate="duration alone 1.0%, duration + caster class 5.3% unique; cast-frame join not yet scored",
        probe="derive.read aura field codes")),
    ("others-spellid", "other players' cast spellIds (BG)", dict(
        status="derivable",
        path="planned cast time (UnitCastingInfo) x class -> RefData; ooc meter CombatSpells per source; learned votes "
             "(refLearned[build].spellClass)",
        inputs="cast timing (clear), meter ooc spell lists (clear)", estimate="see spellid",
        probe="derive.cast positions 5/6/10")),
    ("meter-enemy", "meter breakdown per enemy unit", dict(
        status="derivable",
        path="enemy rows (displayType 2, no id) out of combat: name + classFilename + totals + CombatSpells clear -> "
             "per-enemy breakdown keyed by name key; in combat only the composition",
        inputs="meter rows ooc", estimate="names clear in 14/16 ooc observations (run 14); per-enemy totals ooc",
        probe="derive.meter.ooc enemyNameClear / rows")),
    ("race-level", "race / sex / level / faction of hostile players", dict(
        status="derivable", path="UnitLevel + UnitFactionGroup clear on target; race/sex: probe; scoreboard race field",
        inputs="UnitLevel, UnitFactionGroup (clear on target)", estimate="level/faction: direct on target",
        probe="derive.read UnitRace/UnitSex per family; derive.score race")),
    ("pet-owner", "pet / totem / summon owner", dict(
        status="derivable",
        path="RefData.summons npc id -> owner class (28 mined); UnitIsOwnerOrControllerOfUnit pair probe; pet power "
             "type FOCUS/HAPPINESS -> hunter pet",
        inputs="pet powerType (clear), npc id from clear GUIDs", estimate="28 summon types, share >= 0.9 used",
        probe="derive.read UnitIsOwnerOrControllerOfUnit|pair")),
    ("scoreboard", "BG scoreboard (kills, damage, healing per player)", dict(
        status="probe", path="GetBattlefieldScore / C_PvP.GetScoreInfo out of combat (RequestBattlefieldScoreData every 10 s)",
        inputs="unknown", estimate="-", probe="derive.score field codes")),
    ("spec", "spec of hostile players", dict(
        status="derivable", path="GetArenaOpponentSpec (arena); BG: talent-only spells from RefData via the spellId path",
        inputs="spellId path", estimate="-", probe="derive.score talentSpec, ARENA_PREP")),
]


def lookup(row_id, family=None):
    e = DERIVE.get(row_id)
    if e is None:
        return None
    out = {k: v for k, v in e.items() if k != "fam"}
    if family and family in e.get("fam", {}):
        out.update(e["fam"][family])
    return out
