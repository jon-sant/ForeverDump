"""v2.2.15: score the HSM's parallel candidate (shadow) rules against the combat-log truth.

Each replayed attribution may carry `cand = {id: "mine"|"other"}` (claims made by candidate rules while the HSM handled
that event). For every candidate the category score is computed twice with coverage.score: `before` = the live rule's
claims, `after` = the same attributions with the candidate's claim substituted where it made one. A candidate is
promotable only if it beats the live rule (accuracy up, falseSelf not up) on every run that has scorable events.
"""
import collections
import copy

from . import coverage


def cand_ids(attrs):
    ids = collections.OrderedDict()
    for a in attrs:
        for k in (a.get("cand") or {}):
            ids[k] = True
    return list(ids)


def _cat_of(a, refs):
    x = refs.get(a.get("ref")) or {}
    if a["k"] == "uc":
        if x.get("player"):
            return "heal-on-me" if x.get("action") == "HEAL" else "damage-taken"
        return "damage-on-target" if x.get("action") == "WOUND" else ("miss-on-target" if x.get("action") != "HEAL" else "heal-on-target")
    if a["k"] == "interrupt":
        return "interrupt"
    return "aura-on-target" if x.get("unit") != "player" else "aura-on-me"


def score_candidates(attrs, truth, refs):
    """-> {cid: {cat: {before: score, after: score, n: claims}}}"""
    attrs = [a for a in attrs if a.get("k") in ("uc", "interrupt", "aura")]
    base, _ = coverage.score(attrs, truth, refs)
    out = {}
    for cid in cand_ids(attrs):
        alt = []
        cats = collections.Counter()
        for a in attrs:
            c = (a.get("cand") or {}).get(cid)
            if c is not None:
                b = dict(a)
                b["src"], b["rule"] = c, cid
                alt.append(b)
                cats[_cat_of(a, refs)] += 1
            else:
                alt.append(a)
        sc, _ = coverage.score(alt, truth, refs)
        out[cid] = {cat: {"before": base.get(cat), "after": sc.get(cat), "claims": n} for cat, n in cats.items()}
    return out


def verdict(per_run):
    """per_run = {run: {cid: {cat: {before, after}}}} -> {cid: {cat: 'promote'|'provisional'|'off', why}}"""
    res = {}
    cids = sorted({c for r in per_run.values() for c in r})
    for cid in cids:
        cats = sorted({cat for r in per_run.values() for cat in (r.get(cid) or {})})
        for cat in cats:
            better, worse, runs = 0, 0, 0
            for run, r in per_run.items():
                x = (r.get(cid) or {}).get(cat)
                if not x or not x.get("after") or not (x["after"].get("scorable") or 0):
                    continue
                b, a = x.get("before") or {}, x["after"]
                runs += 1
                ab, aa = b.get("accuracy") or 0.0, a.get("accuracy") or 0.0
                fb, fa = b.get("falseSelf", 0), a.get("falseSelf", 0)
                if aa > ab and fa <= fb:
                    better += 1
                elif aa < ab or fa > fb:
                    worse += 1
            st = "promote" if runs and better == runs else ("provisional" if better > worse else "off")
            res.setdefault(cid, {})[cat] = {"status": st, "runs": runs, "better": better, "worse": worse}
    return res
