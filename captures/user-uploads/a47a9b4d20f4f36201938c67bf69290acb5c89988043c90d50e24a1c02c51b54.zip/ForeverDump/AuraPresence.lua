-- ForeverDump v2.2.25 - aura PRESENCE probe (data collection; user idea 2026-10-10).
-- Question: while unit aura access is restricted (BG, arena, combat ...), is the PRESENCE of one known aura readable?
-- Per the 70245 API inventory: C_UnitAuras.GetUnitAuraBySpellID(unit, spellID) is AllowedWhenTainted +
-- SecretWhenUnitAuraRestricted (+ RequiresNonSecretAura); AuraIsBigDefensive(spellID) and GetAuraCasterGUID(unit,
-- auraInstanceID) take secret arguments when tainted; GetAuraSlots needs unit aura access (also probed, 'HELPFUL|PLAYER').
-- Every result is coded per environment x combat x phase (ns.EnvTag): N nil (absent), S secret value, K/T table
-- (present; fields coded per field), C clear scalar, E error (first message kept), held (circuit breaker).
-- Change-only tape (unit name, spell, state) is scored offline against the combat log's aura applications
-- (tools/fdump/aurapresence.py). Capture level lab only; budget: a few units per second.
local _, ns = ...
local AP = {}
ns.AuraPresence = AP

-- Curated from the included runs' combat logs (SPELL_AURA_APPLIED counts, caster class from log truth, healer flag
-- from the KTH replay truth). role: H healer signature, D dps signature (counter-evidence), M my own spells.
AP.SPELLS = {
    -- SHAMAN
    { 408510, "Water Shield", "SHAMAN", "H" }, { 16177, "Ancestral Fortitude", "SHAMAN", "H" },
    { 16188, "Nature's Swiftness", "SHAMAN", "H" },
    { 408505, "Maelstrom Weapon", "SHAMAN", "D" }, { 1238931, "Improved Stormstrike", "SHAMAN", "D" },
    { 16257, "Flurry", "SHAMAN", "D" },
    -- DRUID
    { 774, "Rejuvenation", "DRUID", "H" }, { 1430, "Rejuvenation", "DRUID", "H" }, { 2090, "Rejuvenation", "DRUID", "H" },
    { 2091, "Rejuvenation", "DRUID", "H" }, { 8938, "Regrowth", "DRUID", "H" }, { 8939, "Regrowth", "DRUID", "H" },
    { 8940, "Regrowth", "DRUID", "H" }, { 17116, "Nature's Swiftness", "DRUID", "H" }, { 740, "Tranquility", "DRUID", "H" },
    { 408255, "Eclipse", "DRUID", "D" }, { 768, "Cat Form", "DRUID", "D" }, { 5487, "Bear Form", "DRUID", "D" },
    -- PRIEST
    { 139, "Renew", "PRIEST", "H" }, { 6074, "Renew", "PRIEST", "H" }, { 6076, "Renew", "PRIEST", "H" },
    { 17, "Power Word: Shield", "PRIEST", "H" }, { 3747, "Power Word: Shield", "PRIEST", "H" },
    { 6065, "Power Word: Shield", "PRIEST", "H" }, { 6788, "Weakened Soul", "PRIEST", "H" },
    { 14751, "Inner Focus", "PRIEST", "H" }, { 27828, "Focused Casting", "PRIEST", "H" },
    { 15271, "Spirit Tap", "PRIEST", "D" }, { 15473, "Shadowform", "PRIEST", "D" },
    -- PALADIN
    { 20216, "Divine Favor", "PALADIN", "H" }, { 437063, "Infusion of Light", "PALADIN", "H" },
    { 19746, "Concentration Aura", "PALADIN", "H" },
    { 10298, "Retribution Aura", "PALADIN", "D" }, { 7294, "Retribution Aura", "PALADIN", "D" },
    { 20915, "Seal of Command", "PALADIN", "D" }, { 20375, "Seal of Command", "PALADIN", "D" },
    { 20050, "Vengeance", "PALADIN", "D" },
    -- my own (Uglaz, enhancement shaman): self buffs + debuffs I put on targets
    { 905, "Lightning Shield", "SHAMAN", "M" }, { 1238640, "Ghost Wolf", "SHAMAN", "M" },
    { 8056, "Frost Shock", "SHAMAN", "M" }, { 17364, "Stormstrike", "SHAMAN", "M" }, { 8052, "Flame Shock", "SHAMAN", "M" },
    { 422621, "Preparation", "-", "M" },
}
AP.FIELDS = { "spellId", "auraInstanceID", "sourceUnit", "duration", "expirationTime", "applications",
    "isFromPlayerOrPlayerPet", "name" }
AP.PERIOD = 1.0          -- s
AP.ROTATE = 3            -- rotating units per tick (target / focus / mouseover / player every tick)
AP.TAPE_MAX = 40000
AP.FIXED = { "player", "target", "focus", "mouseover" }
AP.ROT = {}
for i = 1, 40 do AP.ROT[#AP.ROT + 1] = "nameplate" .. i end
for i = 1, 5 do AP.ROT[#AP.ROT + 1] = "arena" .. i end
for i = 1, 4 do AP.ROT[#AP.ROT + 1] = "party" .. i end
for i = 1, 40 do AP.ROT[#AP.ROT + 1] = "raid" .. i end

local function g(n) return rawget(_G, n) end
local function now() local f = g("GetTime") return f and f() or 0 end
local function code(v) return ns.ClassifyValue and ns.ClassifyValue(v) or (v == nil and "N" or "C") end
local function clearStr(v) return ns.ClearStr and ns.ClearStr(v) or nil end
local function fam(u) return (u:gsub("%d+$", "N")) end
local function isTrue(v) return ns.IsTrue and ns.IsTrue(v) or false end

local function db()
    local log = g("ForeverDumpLogDB")
    if type(log) ~= "table" then return nil end
    local d = log.auraPresence
    if not d then
        d = { v = 1, codes = {}, fields = {}, slots = {}, caster = {}, bigDef = {}, err = {}, tape = {}, last = {},
              units = {}, tapeDropped = 0 }
        log.auraPresence = d
    end
    return d
end
local function inc(t, k, c)
    local x = t[k]
    if not x then x = {} t[k] = x end
    x[c] = (x[c] or 0) + 1
end
local function sub(t, k)
    local x = t[k]
    if not x then x = {} t[k] = x end
    return x
end

-- classify one GetUnitAuraBySpellID result -> state P (present table) / A (absent nil) / S / C / E / H (held)
function AP.Classify(held, ok, v)
    if held then return "H", "held" end
    if not ok then return "E", "E" end
    local c = code(v)
    if c == "N" then return "A", c end
    if c == "K" or c == "T" then return "P", c end
    return c == "S" and "S" or "C", c
end

local function unitName(u)
    local f = g("UnitName")
    if type(f) ~= "function" then return "" end
    local ok, n, r = pcall(f, u)
    if not ok then return "" end
    local s = clearStr(n)
    if not s then return "" end
    local rs = clearStr(r)
    if rs and rs ~= "" then s = s .. "-" .. rs end
    return s
end

function AP.ProbeUnit(d, u, tag)
    local Aur = g("C_UnitAuras")
    if type(Aur) ~= "table" then return 0 end
    local okE, ex = pcall(g("UnitExists") or error, u)
    if not (okE and isTrue(ex)) then return 0 end
    local okP, isP = pcall(g("UnitIsPlayer") or error, u)
    local f = fam(u)
    if not (okP and isTrue(isP)) and u ~= "target" and u ~= "focus" then return 0 end
    if ns.Derive and ns.Derive.UnitKey then pcall(ns.Derive.UnitKey, u) end   -- full name for the exact join
    local name = unitName(u)
    local okG, guid = pcall(g("UnitGUID") or error, u)
    guid = okG and clearStr(guid) or ""
    local AG = ns.AuraGate
    local tc = sub(d.codes, tag)
    local fc = sub(tc, f)
    local n = 0
    local fn = Aur.GetUnitAuraBySpellID
    if type(fn) == "function" then
        for _, s in ipairs(AP.SPELLS) do
            local sid = s[1]
            local held, ok, v
            if AG and AG.Call then held, ok, v = AG.Call("GetUnitAuraBySpellID", f, fn, u, sid)
            else held, ok, v = false, pcall(fn, u, sid) end
            n = n + 1
            local st, c = AP.Classify(held, ok, v)
            inc(fc, sid, c)
            if st == "E" then
                local et = sub(d.err, tag)
                if not et.GetUnitAuraBySpellID then et.GetUnitAuraBySpellID = tostring(v):sub(1, 160) end
            end
            if st == "P" then
                local flds = sub(d.fields, tag)
                local iid
                for _, fld in ipairs(AP.FIELDS) do
                    local okF, fv = pcall(function() return v[fld] end)
                    local fcode = okF and code(fv) or "E"
                    inc(flds, fld, fcode)
                    if fld == "auraInstanceID" and fcode == "C" then iid = fv end
                end
                -- caster GUID for a clear instance ID (needs unit aura access; secret when restricted)
                local gc = Aur.GetAuraCasterGUID
                if iid and type(gc) == "function" then
                    local hC, okC, cg = false
                    if AG and AG.Call then hC, okC, cg = AG.Call("GetAuraCasterGUID", f, gc, u, iid)
                    else okC, cg = pcall(gc, u, iid) end
                    inc(d.caster, tag, hC and "held" or (okC and code(cg) or "E"))
                end
            end
            -- change-only tape keyed by (unit name or token, spell)
            local who = name ~= "" and name or u
            local lk = who .. "|" .. sid
            if d.last[lk] ~= st then
                d.last[lk] = st
                if #d.tape < AP.TAPE_MAX then
                    d.tape[#d.tape + 1] = string.format("%.2f|%s|%s|%s|%d|%s|%s", now(), u, name, guid, sid, st, tag)
                else
                    d.tapeDropped = d.tapeDropped + 1
                end
            end
        end
    end
    -- GetAuraSlots(unit, 'HELPFUL|PLAYER'): needs unit aura access
    local gs = Aur.GetAuraSlots
    if type(gs) == "function" then
        local held, ok, a1, a2
        if AG and AG.Call then held, ok, a1, a2 = AG.Call("GetAuraSlots", f, gs, u, "HELPFUL|PLAYER")
        else held, ok, a1, a2 = false, pcall(gs, u, "HELPFUL|PLAYER") end
        inc(sub(d.slots, tag), f, held and "held" or (ok and (code(a1) .. "/" .. code(a2)) or "E"))
        if not held and not ok then
            local et = sub(d.err, tag)
            if not et.GetAuraSlots then et.GetAuraSlots = tostring(a1):sub(1, 160) end
        end
    end
    inc(d.units, tag, f)
    return n
end

-- AuraIsBigDefensive(spellID): static per spell; once per env tag
function AP.BigDefensive(d, tag)
    local Aur = g("C_UnitAuras")
    local fn = type(Aur) == "table" and Aur.AuraIsBigDefensive or nil
    if type(fn) ~= "function" then return end
    local t = sub(d.bigDef, tag)
    if t.done then return end
    t.done = true
    for _, s in ipairs(AP.SPELLS) do
        local ok, v = pcall(fn, s[1])
        local c = ok and code(v) or "E"
        t[s[1]] = c == "C" and (v and "true" or "false") or c
    end
end

local rot = 0
function AP.Active()
    return ns.LabActive and ns.LabActive() and ns.db and ns.db.logs and ns.db.logs.on and true or false
end
function AP.Tick()
    local d = db()
    if not d then return end
    local tag = ns.EnvTag and ns.EnvTag() or "?"
    if not d.anchor then
        local tf = g("time")
        d.anchor = { gameTime = now(), epoch = type(tf) == "function" and tf() or nil }
    end
    AP.BigDefensive(d, tag)
    local done = {}
    for _, u in ipairs(AP.FIXED) do AP.ProbeUnit(d, u, tag) done[u] = true end
    local tried, probed = 0, 0
    while probed < AP.ROTATE and tried < #AP.ROT do
        rot = rot + 1
        if rot > #AP.ROT then rot = 1 end
        tried = tried + 1
        local u = AP.ROT[rot]
        if not done[u] and AP.ProbeUnit(d, u, tag) > 0 then probed = probed + 1 end
    end
end

local ticker
function AP.Start()
    local ct = g("C_Timer")
    if not (type(ct) == "table" and type(ct.NewTicker) == "function") then return false end
    if ticker then return true end
    if not AP.Active() then return false end
    local log = g("ForeverDumpLogDB")
    if type(log) == "table" then log.auraPresence = nil end   -- fresh per capture
    local d = db()
    if not d then return false end
    rot = 0
    ticker = ct.NewTicker(AP.PERIOD, function()
        if not AP.Active() then return end
        if ns.Perf then ns.Perf.Run("AuraPresence.tick", AP.Tick) else pcall(AP.Tick) end
    end)
    return true
end
function AP.Stop()
    if ticker and ticker.Cancel then ticker:Cancel() end
    ticker = nil
    local d = g("ForeverDumpLogDB") and ForeverDumpLogDB.auraPresence
    if not d then return nil end
    d.last = nil   -- transient (reset next capture)
    return #d.tape
end

ns.captureModules = ns.captureModules or {}
ns.captureModules[#ns.captureModules + 1] = { name = "aura presence probe (v2.2.25)",
    start = function() return AP.Start() end,
    stop = function()
        local n = AP.Stop()
        return n and string.format("aura presence: %d tape entries", n) or nil
    end }
