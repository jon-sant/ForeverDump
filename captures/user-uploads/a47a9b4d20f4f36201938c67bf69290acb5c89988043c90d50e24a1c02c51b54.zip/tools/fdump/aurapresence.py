"""v2.2.25 aura-presence probe: offline scorer.

The addon (ForeverDump/AuraPresence.lua) writes ForeverDumpLogDB.auraPresence:
  codes[envTag][unitFamily][spellID] = {N|S|K|T|C|E|held: n}   result codes of C_UnitAuras.GetUnitAuraBySpellID
  tape = ["t|unit|name|guid|sid|state|envTag", ...]           change-only presence states P/A/S/C/E/H
  anchor = {gameTime, epoch}                                   GetTime() <-> time() at the first tick
This scores the tape's P (present) / A (absent) states against the combat log's aura state for the same player and
spell (SPELL_AURA_APPLIED / _REFRESH / _APPLIED_DOSE open, SPELL_AURA_REMOVED / UNIT_DIED close). S / C / E / H are
reported as "unreadable" per env tag - the key question is whether presence is readable while restricted.

usage: python3 -m tools.fdump.aurapresence SV.lua WoWCombatLog.txt truth.json [--json out.json]
"""
import argparse
import bisect
import collections
import json
import os
import sys
import time

from . import refdata

OPEN = {"SPELL_AURA_APPLIED", "SPELL_AURA_REFRESH", "SPELL_AURA_APPLIED_DOSE"}
CLOSE = {"SPELL_AURA_REMOVED"}
EDGE = 0.5   # s: a tape sample within EDGE of a log transition is scored "edge" (not right / wrong)


def as_list(x):
    if isinstance(x, list):
        return x
    if isinstance(x, dict):
        try:
            return [x[k] for k in sorted(x, key=lambda k: int(k))]
        except (TypeError, ValueError):
            return list(x.values())
    return []


def parse_tape(rows):
    out = []
    for r in as_list(rows):
        p = str(r).split("|")
        if len(p) < 7:
            continue
        try:
            out.append({"t": float(p[0]), "unit": p[1], "name": p[2], "guid": p[3], "sid": int(p[4]), "st": p[5],
                        "tag": "|".join(p[6:])})
        except ValueError:
            continue
    return out


def log_intervals(lines_iter, sids=None):
    """(guid, sid) -> sorted list of [start, end] log-seconds; plus the transition times"""
    openAt, iv = {}, collections.defaultdict(list)
    for t, p in lines_iter:
        if t is None or not p:
            continue
        ev = p[0]
        if ev in OPEN or ev in CLOSE:
            if len(p) < 10:
                continue
            try:
                sid = int(p[9])
            except ValueError:
                continue
            if sids is not None and sid not in sids:
                continue
            k = (p[5], sid)
            if ev in OPEN:
                openAt.setdefault(k, t)
            elif k in openAt:
                iv[k].append([openAt.pop(k), t])
        elif ev == "UNIT_DIED" and len(p) > 5:
            for k in [k for k in openAt if k[0] == p[5]]:
                iv[k].append([openAt.pop(k), t])
    for k, t0 in openAt.items():
        iv[k].append([t0, float("inf")])
    return iv


def state_at(ivs, t):
    """True present / False absent / None within EDGE of a transition"""
    for a, b in ivs or ():
        if abs(t - a) <= EDGE or (b != float("inf") and abs(t - b) <= EDGE):
            return None
        if a <= t <= b:
            return True
    return False


def epoch_to_logsec(epoch):
    lt = time.localtime(epoch)   # combat log timestamps are the client's local time (the box runs in the user's zone)
    return ((lt.tm_mday * 24 + lt.tm_hour) * 60 + lt.tm_min) * 60 + lt.tm_sec + (epoch - int(epoch))


def name_index(truth):
    """'First Surname' (UnitName name + realm, realm == Forever surname) and first name -> guid"""
    full, first = {}, collections.defaultdict(list)
    for g, r in (truth or {}).items():
        if r.get("full"):
            full[r["full"]] = g
        if r.get("first"):
            first[r["first"]].append(g)
    return full, first


def resolve(sample, full, first, mine_guid=None):
    if sample["guid"]:
        return sample["guid"], "guid"
    if sample["unit"] == "player" and mine_guid:
        return mine_guid, "player"
    nm = sample["name"]
    if not nm:
        return None, "noname"
    fn = nm.replace("-", " ", 1)
    if fn in full:
        return full[fn], "full"
    f = nm.split("-")[0]
    if len(first.get(f, ())) == 1:
        return first[f][0], "first"
    return None, "ambiguous"


def score(ap, iv, truth, offset=0.0):
    anchor = ap.get("anchor") or {}
    g0, e0 = anchor.get("gameTime"), anchor.get("epoch")
    full, first = name_index(truth)
    mine = next((g for g, r in (truth or {}).items() if r.get("mine")), None)
    res = collections.defaultdict(lambda: collections.Counter())
    unresolved = collections.Counter()
    for s in parse_tape(ap.get("tape")):
        tag = s["tag"]
        if s["st"] not in ("P", "A"):
            res[tag]["unreadable:" + s["st"]] += 1
            continue
        if g0 is None or e0 is None:
            res[tag]["noanchor"] += 1
            continue
        g, how = resolve(s, full, first, mine)
        if not g:
            unresolved[how] += 1
            res[tag]["unresolved"] += 1
            continue
        lt = epoch_to_logsec(e0 + (s["t"] - g0)) + offset
        truthState = state_at(iv.get((g, s["sid"])), lt)
        if truthState is None:
            res[tag]["edge"] += 1
        elif truthState == (s["st"] == "P"):
            res[tag]["agree:" + s["st"]] += 1
        else:
            res[tag]["disagree:" + s["st"]] += 1
    return {k: dict(v) for k, v in res.items()}, dict(unresolved)


def code_table(ap):
    """envTag -> {code: n} summed over unit families and spells (the readability question)"""
    out = {}
    for tag, byF in (ap.get("codes") or {}).items():
        c = collections.Counter()
        for _f, byS in (byF or {}).items():
            for _sid, cc in (byS or {}).items():
                for k, n in (cc or {}).items():
                    if isinstance(n, (int, float)):
                        c[k] += n
        out[tag] = dict(c)
    return out


def occurrence(log_paths, sids):
    """spellID -> SPELL_AURA_APPLIED count over the given combat logs"""
    c = collections.Counter()
    for path in log_paths:
        for _t, p in refdata.lines(path):
            if p and p[0] == "SPELL_AURA_APPLIED" and len(p) > 9:
                try:
                    sid = int(p[9])
                except ValueError:
                    continue
                if sid in sids:
                    c[sid] += 1
    return dict(c)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("sv")
    ap.add_argument("log")
    ap.add_argument("truth")
    ap.add_argument("--offset", type=float, default=0.0, help="seconds added to the anchor-mapped time")
    ap.add_argument("--json")
    a = ap.parse_args(argv)
    from .dump import load_raw
    raw = load_raw(a.sv)
    apd = (raw.get("ForeverDumpLogDB") or {}).get("auraPresence")
    if not apd:
        print("no auraPresence section (capture level lab, v2.2.25+ needed)")
        return 2
    sids = {s["sid"] for s in parse_tape(apd.get("tape"))}
    iv = log_intervals(refdata.lines(a.log), sids or None)
    truth = json.load(open(a.truth))
    sc, unres = score(apd, iv, truth, a.offset)
    out = {"codes": code_table(apd), "score": sc, "unresolved": unres, "fields": apd.get("fields"),
           "slots": apd.get("slots"), "caster": apd.get("caster"), "bigDef": apd.get("bigDef"), "err": apd.get("err")}
    js = json.dumps(out, indent=1, sort_keys=True, default=str)
    if a.json:
        with open(a.json, "w") as f:
            f.write(js)
    print(js)
    return 0


if __name__ == "__main__":
    sys.exit(main())
