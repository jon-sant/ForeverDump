# ForeverDump: changes

v1 (`ForeverDump.lua`, 333 lines; one SavedVariable `ForeverDumpDB`) collected the APIs (`C_*` functions), events,
enums and CVars in one pass and showed them in a copy window via `/fdump` and `/foreverdump`. **All of that still
works:** plain `/fdump` runs the same quick dump into the same `ForeverDumpDB` fields.

## v2.1.0 (2026-10-07, after the first real Forever 70245 run)
**Addon**
- **FD_Logs = capture everything.** One click starts all client logs plus the event recorder, combat recorder, error
  capture, secrets verifier and getter sweep, and probe and profiler snapshots. It queues `/fdump all` if the build has no
  full dump yet, and takes an automatic in-combat probe at the first combat. The second click stops everything, copies
  BugGrabber errors and runs `/reload` (synchronous OFF, so SavedVariables are written). `/stopmacro [combat]` guard.
  Capture resumes after `/reload`/relog. Running sessions are saved at logout.
- **Compact SavedVariables by default** (about half the size); `/fdump all full` or `set dump.full true` for the v2.0
  full dump. UTF-8-safe truncation (the v2.0 SV contained cut multi-byte characters).
- **Secrets verifier** (`Secrets.lua`, section `secrets`). Live `issecretvalue`/`canaccessvalue` tallies per event, API
  and struct field position, with context buckets (ooc/combat/encounter, instance type, self/other). Throttled sweep of
  documented conditionally secret getters. Live contradictions against the documentation. `/fdump secrets` live
  panel, `state` and `sweep` subcommands. Bounded counters only (`secrets.maxKeys/maxCtx/maxLive`).
- **Common timebase.** Session IDs and anchors (GetTime, time(), GetServerTime, UTC offset; refined at a time() tick) on
  capture, recorder and combat sessions. `sid/t/epoch/server` on probes, errors, blocked actions and contradictions.
  Everything persists to SavedVariables.
- **BugGrabber/BugSack coexistence.** Uses BugGrabber callbacks (`BugGrabber_BugGrabbed`) when it is loaded, polls `GetDB()`
  as a fallback, and chains the previous handler otherwise. `/fdump errors bg` and FD_Logs OFF copy BugGrabber session
  errors. `## OptionalDeps: !BugGrabber, BugSack`.
- Error attribution to the addon that raised it; CLEU is still never registered by default.

**Converter**
- `secrets` (secrets map: every documented flag; SECRETS.md), `verify` (CONFIRMED / CONTRADICTED / UNOBSERVED /
  UNDOCUMENTED-SECRET, coverage), `xref` (merged timeline with match quality), `migrate` + `migrate-db` (legacy addon
  migration report; 109 curated + 373 Blizzard_Deprecated shim mappings), `fixtures` (anonymized fixture pack).
- `check` gained the `secret-op` rule (arithmetic, comparison, length or boolean tests on documented/observed secret values,
  with guard detection). LuaLS stubs carry secrecy annotations marked `[verified]`/`[unverified]`/`[CONTRADICTED]`.
  Mocks return secret sentinels per documented/verified secrecy (`wow.secretMode`, per-field struct secrets, secret
  event payloads).
- Fixes from the real run: invalid UTF-8 in SV broke JSON export; combat log v22 ENVIRONMENTAL_* advanced-block order,
  ST/AOE scope marker, isOffHand padding; Ketho comparison scoping; `cl-compare` Forever mode.
- Tests: BugGrabber paths (`tests/buggrabber.lua`), verifier with deliberate contradictions (smoke), `tests/test_xref.py`
  (synthetic file log), `tests/test_migrate.py` (deliberate legacy addon), `tests/spec/forever_fixture_spec.lua`
  (anonymized real capture).

## v2.0.0

New in v2 compared to v1:
- **Structure:** 19 Lua files; `.toc` Interface 16001, Version 2.0.0; 6 SavedVariables (DB, DocsDB, StringsDB,
  RecordDB, LogDB, CombatLogDB) so large data stays separate; `schemaVersion` plus a meta header (build, locale,
  `WOW_PROJECT_ID` and **every** `WOW_PROJECT_*` constant, with Forever = 18 / CAMELOT, never assumed mainline;
  `C_AddOns.GetScriptsDisallowedForBeta()`).
- **Sections** (`/fdump all` or one at a time): full APIDocumentation walk with documented/present cross-check;
  C_ namespaces; global tables, functions (secure/insecure), constants and Enum; all global strings; widget API
  (methods per type, inheritance; `risky` option); XML templates; named frames; addons; CVars and console commands;
  protected info (issecurevariable plus doc restriction and secret flags); extras (bindings, slash commands, settings,
  fonts, SOUNDKIT, maps, classes, spells, talents, currencies); opt-in getters; profiling snapshot.
- **Recorders:** event recorder registers documented events individually (no RegisterAllEvents) and saves the
  skipped restricted/SecureOnly events with reasons. The Forever-safe combat recorder (`/fdump cl`) records
  UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING with swing range, COMBAT_TEXT_UPDATE with the C_CombatText getter,
  encounter and regen context with restriction states, and post-combat C_DamageMeter snapshots. Legacy CLEU is
  opt-in only (`cl cleu-force`, guarded). Probe (tooltips and getters, now or next combat).
- **Diagnostics:** chained Lua error handler (stack and locals); ADDON_ACTION_BLOCKED/FORBIDDEN, MACRO_ACTION_*,
  LUA_WARNING and ADDON_RESTRICTION_STATE_CHANGED log.
- **FD_Logs:** `/fdump logs` and the single account macro FD_Logs toggle the combat log, chat log,
  advancedCombatLogging, scriptErrors and taintLog together, with state in SavedVariables and a clear chat line.
- **Safety and UX:** refuses heavy work in combat; frame-sliced chunking with `/fdump cancel`; secret-value detection
  everywhere (`<secret>`); per-section toggles, clear and set; capped copy window; status view; /reload reminder.
- **Box-side converter** (`tools/`): SV to JSON, LuaLS stubs, luacheck std, busted mocks and replay, API checker,
  diff, combat log file parser, taint.log parser, error report, Ketho comparison.
