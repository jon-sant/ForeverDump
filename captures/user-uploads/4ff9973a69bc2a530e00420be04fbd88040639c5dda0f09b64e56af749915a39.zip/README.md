# ForeverDump v2.1 bundle

- `ForeverDump/`: the addon. Copy it to `World of Warcraft\_classic_beta_\Interface\AddOns\`. See `ADDON-USAGE.md`.
- `ADDON-USAGE.md`: install, slash commands and run order, the FD_Logs macro, where SavedVariables land, privacy.
- `INSTRUCTIONS-console.md`: console, CVar and log instructions. `SELF-HOSTING.md`: self-hosting and community sources.
- `tools/`: converter (`tools/README.md`) and `tools/refresh/` (refresh scripts).
- `tests/`: mock client, addon smoke test, converter tests, sample addon, deliberate legacy addon (`tests/legacy_addon`) and **synthetic** log fixtures.
- `fixtures/forever-70245/`: an **anonymized** real Forever capture (API surface, environment, documented secrets map, combat/taint log). See its README.
- `CHANGES.md`: what changed from v1, v2.0 and v2.1.

**Not included (too large):** `data/` (≈215 MB extracted client data) and every `.cache/` folder (≈900 MB, e.g.
`tools/refresh/.cache`), plus `ref/` (reference API docs used by the smoke test) and `tests/out/` (generated). Re-create
them with `tools/refresh/refresh_all.sh` (see SELF-HOSTING.md).

Status: tested in a mock client built from the real Forever API documentation, **not yet tested in-game**.
