#!/usr/bin/env python3
"""ForeverDump converter CLI. Run `python3 tools/fdump.py -h` for subcommands.
DUMP may be a SavedVariables ForeverDump.lua (parsed safely, never executed), a dump.json written by
`fdump.py json`, or the folder containing that dump.json."""
import argparse
import json
import os
import datetime
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fdump import apicheck, combatlog, diff as diffmod, export_json, ketho, luacheck_gen, luals, mocks, secrets as secretsmod, taintlog, xref as xrefmod, migrate as migratemod, anonymize  # noqa: E402
from fdump.dump import Dump  # noqa: E402
from fdump.luasv import as_list  # noqa: E402


def _write(path, text):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def info(dump):
    m = dump.meta()
    consts = m.get("projectConstants") or {}
    names = [k for k, v in consts.items() if v == m.get("projectID") and k != "WOW_PROJECT_ID"]
    lines = ["build:     %s" % dump.build_label(),
             "project:   WOW_PROJECT_ID=%s (%s)" % (m.get("projectID"), m.get("projectName") or ",".join(names) or "unknown"),
             "constants: %s" % ", ".join("%s=%s" % kv for kv in sorted(consts.items())),
             "scriptsDisallowedForBeta: %s" % m.get("scriptsDisallowedForBeta"),
             "locale:    %s, dumped %s" % (m.get("locale"), m.get("date")),
             "sections:  %s" % ", ".join(sorted(dump.sections)),
             "docs:      %s systems" % len(dump.doc_systems()),
             "strings:   %d" % len(dump.strings),
             "recorder:  %d session(s); combat log: %d session(s)" % (
                 len(as_list(dump.record.get("sessions"))), len(as_list(dump.combatlog.get("sessions")))),
             "errors:    %d unique, %d blocked/forbidden/warnings" % (
                 len(as_list(dump.log.get("errors"))), len(as_list(dump.log.get("blocked"))))]
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(prog="fdump.py", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name, help_, dump=True, out=None):
        sp = sub.add_parser(name, help=help_)
        if dump:
            sp.add_argument("dump")
        if out:
            sp.add_argument("-o", "--out", default=out)
        return sp

    add("info", "print build / project / what the dump contains")
    add("json", "(1) JSON per section", out="out/json")
    add("luals", "(2) LuaLS ---@meta annotation stubs", out="out/luals")
    sp = add("luacheck", "(3) luacheck config with std 'forever'", out="out/.luacheckrc")
    sp.add_argument("--std", default="forever")
    add("mocks", "(4) busted mocks + replay helper + fixtures", out="out/mocks")
    sp = add("check", "(5) API-check an addon folder against the dump")
    sp.add_argument("addon")
    sp.add_argument("--json", help="also write findings as JSON")
    sp.add_argument("--strict", action="store_true", help="exit non-zero on warnings too")
    sp = add("diff", "(6) diff two dumps (OLD NEW)", dump=False, out=None)
    sp.add_argument("old")
    sp.add_argument("new")
    sp.add_argument("-o", "--out", help="markdown output (default stdout)")
    sp.add_argument("--json", help="also write JSON")
    add("all", "json + luals + luacheck + mocks into one folder", out="out")
    sp = add("combatlog", "parse Logs/WoWCombatLog*.txt into CLEU replay fixtures (.json and/or .lua)", dump=False)
    sp.add_argument("logfile")
    sp.add_argument("-o", "--out", default="out/combatlog_file.json", help=".json or .lua (Lua fixture for replay.lua)")
    sp.add_argument("--year", type=int, help="year for logs whose timestamps lack one")
    sp.add_argument("--utc-offset", type=float, help="hours east of UTC for timestamps without a zone (default: box zone)")
    sp.add_argument("--shape", choices=["cleu", "raw"], default="cleu")
    sp.add_argument("--limit", type=int)
    sp.add_argument("--subevents", help="comma-separated subevent filter")
    sp.add_argument("--forever-player", metavar="GUID",
                    help="also synthesize Forever-style events (UNIT_SPELLCAST_*, UNIT_COMBAT, PLAYER_SWING) for this player GUID")
    sp = add("cl-compare", "cross-check a parsed file fixture against a /fdump cl session in DUMP", dump=False)
    sp.add_argument("fixture")
    sp.add_argument("dump")
    sp.add_argument("--session", type=int, default=0, help="1-based session index (default: last)")
    sp.add_argument("--json")
    sp.add_argument("--player", help="player GUID: match UNIT_COMBAT(player) against file damage/heal when the session has no CLEU")
    sp = add("taint", "parse Logs/taint.log", dump=False)
    sp.add_argument("logfile")
    sp.add_argument("-o", "--out", help="JSON output")
    sp = add("errors", "summarize captured Lua errors / blocked actions in DUMP")
    sp.add_argument("--json")
    sp = add("ketho", "optional: compare against Ketho/BlizzardInterfaceResources (forever branch)")
    sp.add_argument("--ref", help="local checkout of the Resources folder (default: download from GitHub)")
    sp.add_argument("--branch", default="forever")
    sp.add_argument("--ui-source", help="wow-ui-source Interface dir: drop dump-only names that are Lua-defined there")
    sp.add_argument("--json")

    add("secrets", "secrets map: secrets.json + SECRETS.md (documented secrecy + runtime observations)", out="out/secrets")
    sp = add("migrate", "scan a legacy addon: per call site status, replacement, secrecy; TOC, events, taint patterns -> MIGRATION.md")
    sp.add_argument("addon")
    sp.add_argument("-o", "--out", default="out/migrate")
    sp = add("fixtures", "write an ANONYMIZED, shareable fixture pack (api surface, env, combat/taint log, secrets map)")
    sp.add_argument("-o", "--out", default="fixtures/forever")
    sp.add_argument("--file", help="WoWCombatLog*.txt to anonymize")
    sp.add_argument("--taint", help="taint.log to anonymize")
    sp.add_argument("--max-lines", type=int, default=2000)
    sp.add_argument("--forbid", default="", help="comma list of words that must not appear (character names, account); fails if found")
    sp = add("migrate-db", "rebuild tools/fdump/data/migration_shims.json from Blizzard_Deprecated* sources", dump=False)
    sp.add_argument("dirs", nargs="+", help="BRANCH=path/to/Interface/AddOns (e.g. forever=.cache/wus-forever/Interface/AddOns)")
    add("verify", "secrets verifier: reconcile documented secrecy with observations -> verify.json + VERIFY.md", out="out/verify")
    sp = add("xref", "merge addon event log, CL sessions, verifier data and WoWCombatLog into timeline.jsonl + TIMELINE.md",
             out="out/xref")
    sp.add_argument("--file", help="Logs/WoWCombatLog*.txt (optional)")
    sp.add_argument("--player", help="your character GUID (Player-...) for damage-on-player / own-cast matching")
    sp.add_argument("--window-ms", type=int, default=750)
    sp.add_argument("--year", type=int)

    a = p.parse_args(argv)

    if a.cmd == "diff":
        r = diffmod.diff(Dump.load(a.old), Dump.load(a.new))
        md = diffmod.markdown(r)
        if a.out:
            _write(a.out, md)
            print("wrote", a.out)
        else:
            print(md)
        if a.json:
            export_json.write_json(a.json, r)
        return 0
    if a.cmd == "combatlog":
        fx = combatlog.parse_file(a.logfile, year=a.year,
                                  utc_offset_sec=None if a.utc_offset is None else a.utc_offset * 3600,
                                  shape=a.shape, limit=a.limit,
                                  subevents=set(a.subevents.split(",")) if a.subevents else None)
        if a.forever_player:
            fx = combatlog.synthesize_forever(fx, a.forever_player)
        if a.out.endswith(".lua"):
            mocks.write_lua(a.out, "WoWCombatLog fixture from %s" % os.path.basename(a.logfile), fx)
        else:
            export_json.write_json(a.out, fx)
        print("wrote %s: %d CLEU events (%s), %d non-CLEU lines, header %s" % (
            a.out, fx["total"], ", ".join("%s=%d" % kv for kv in sorted(fx["counts"].items(), key=lambda x: -x[1])[:8]),
            len(fx["events"]) - fx["total"], fx["header"]))
        return 0
    if a.cmd == "cl-compare":
        with open(a.fixture, encoding="utf-8") as f:
            fx = json.load(f)
        d = Dump.load(a.dump)
        sessions = as_list(d.combatlog.get("sessions"))
        if not sessions:
            print("no /fdump cl sessions in", a.dump)
            return 2
        if a.session:
            sess = sessions[a.session - 1]
        else:  # newest session with legacy CLEU entries, else the newest session
            with_cleu = [s_ for s_ in sessions if (s_.get("cleuTotal") or 0) > 0]
            sess = (with_cleu or sessions)[-1]
        if (sess.get("cleuTotal") or 0) == 0:
            if not a.player:
                print("session has no legacy CLEU entries; pass --player GUID to match UNIT_COMBAT against the file")
                return 2
            r = combatlog.compare_forever(fx, sess, a.player)
            print("forever mode: %(addonUnitCombat)d addon UNIT_COMBAT(player), %(fileDamageHealOnPlayer)d file damage/heal "
                  "on player, matched %(matched)d (%(secretAmounts)d secret amounts), addon-only %(addonOnly)d, "
                  "file-only %(fileOnly)d" % r)
            if a.json:
                export_json.write_json(a.json, r)
            return 0
        r = combatlog.compare(fx, sess)
        print("matched %d, addon-only %d, file-only %d" % (r["matched"], r["addonOnly"], r["fileOnly"]))
        for subev, d_ in r["arityMismatch"].items():
            print("  arity %s: %s" % (subev, d_))
        for fd in r["fieldDiffs"][:20]:
            print("  diff %s arg %d: addon=%r file=%r" % (fd["sub"], fd["pos"], fd["addon"], fd["file"]))
        if a.json:
            export_json.write_json(a.json, r)
        return 0
    if a.cmd == "migrate-db":
        dirs = [tuple(d.split("=", 1)) for d in a.dirs]
        db = migratemod.build_shim_db(dirs)
        path = os.path.join(migratemod.DATA, "migration_shims.json")
        export_json.write_json(path, {"_about": "parsed from Blizzard_Deprecated* (%s)" % ", ".join(b for b, _ in dirs), "functions": db})
        print("wrote %d shim entries to %s" % (len(db), path))
        return 0
    if a.cmd == "taint":
        r = taintlog.parse(a.logfile)
        print(taintlog.text_summary(r))
        if a.out:
            export_json.write_json(a.out, r)
            print("wrote", a.out)
        return 0

    dump = Dump.load(a.dump)
    if a.cmd == "info":
        print(info(dump))
    elif a.cmd == "json":
        files = export_json.export(dump, a.out)
        print("wrote %d JSON files to %s" % (len(files), a.out))
    elif a.cmd == "luals":
        files = luals.generate(dump, a.out)
        print("wrote %d LuaLS stub files to %s (add it to workspace.library; see .luarc.json.example)" % (len(files), a.out))
    elif a.cmd == "luacheck":
        _write(a.out, luacheck_gen.generate(dump, std_name=a.std))
        print("wrote", a.out)
    elif a.cmd == "mocks":
        files = mocks.generate(dump, a.out)
        print("wrote %d mock files to %s" % (len(files), a.out))
    elif a.cmd == "all":
        print(info(dump))
        export_json.export(dump, os.path.join(a.out, "json"))
        luals.generate(dump, os.path.join(a.out, "luals"))
        _write(os.path.join(a.out, ".luacheckrc"), luacheck_gen.generate(dump))
        mocks.generate(dump, os.path.join(a.out, "mocks"))
        smap = secretsmod.build(dump)
        export_json.write_json(os.path.join(a.out, "secrets", "secrets.json"), smap)
        _write(os.path.join(a.out, "secrets", "SECRETS.md"), secretsmod.to_markdown(smap))
        print("wrote json/, luals/, .luacheckrc, mocks/, secrets/ under", a.out)
    elif a.cmd == "check":
        r = apicheck.run(dump, a.addon)
        print(apicheck.text(r))
        if a.json:
            export_json.write_json(a.json, r)
        if r["counts"]["error"] or (a.strict and r["counts"]["warn"]):
            return 1
    elif a.cmd == "errors":
        errs, blocked = as_list(dump.log.get("errors")), as_list(dump.log.get("blocked"))
        addon_re = re.compile(r"[Ii]nterface[/\\][Aa]dd[Oo]ns[/\\]([^/\\]+)[/\\]")

        def attribute(e):
            # skip ForeverDump's own handler frames (v2.0 recorded them as the culprit)
            for text in (e.get("message"), e.get("stack")):
                for name in addon_re.findall(str(text or "")):
                    if name != "ForeverDump":
                        return name
            return e.get("addon")

        for e in sorted(errs, key=lambda e: -(e.get("count") or 0)):
            e["attributedAddon"] = attribute(e)
            note = "  (addon %s)" % e["attributedAddon"] if e.get("attributedAddon") else ""
            if e.get("addon") and e.get("addon") != e.get("attributedAddon"):
                note += "  [dump said %s: its own handler frames, fixed in 2.1]" % e["addon"]
            print("[%dx] %s%s" % (e.get("count", 1), e.get("message"), note))
            if e.get("stack"):
                print("    " + str(e["stack"]).replace("\n", "\n    "))
        for b in blocked:
            ts = b.get("time")
            when = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S") if isinstance(ts, (int, float)) else ts
            print("%s %s %s%s" % (when, b.get("event"), b.get("args"), " (in combat)" if b.get("inCombat") else ""))
        print("%d unique errors, %d blocked/forbidden/warning events" % (len(errs), len(blocked)))
        if a.json:
            export_json.write_json(a.json, {"errors": errs, "blocked": blocked})
    elif a.cmd == "secrets":
        smap = secretsmod.build(dump)
        export_json.write_json(os.path.join(a.out, "secrets.json"), smap)
        _write(os.path.join(a.out, "SECRETS.md"), secretsmod.to_markdown(smap))
        print(json.dumps(smap["headline"], indent=1))
        print("wrote secrets.json + SECRETS.md to", a.out)
    elif a.cmd == "fixtures":
        os.makedirs(a.out, exist_ok=True)
        anon = anonymize.Anonymizer()
        written = []
        env = anonymize.environment(dump)
        anonymize.write_json(os.path.join(a.out, "environment.json"), env)
        anonymize.write_json(os.path.join(a.out, "api-surface.json"), anonymize.api_surface(dump))
        smap = secretsmod.build(dump)
        for k in ("observations", "liveContradictions", "sessions", "fieldVerify"):
            smap.pop(k, None)  # runtime data can carry unit/context info: keep the documented map only
        def _interesting(e):
            e.pop("verify", None)
            if e.get("secrecy") not in (None, "unspecified") or e.get("restrictions") or e.get("conditions"):
                return True
            if e.get("secretArguments") == "NotAllowed" or any(x.get("secrecy") not in (None, "unspecified")
                                                                for x in (e.get("returns") or []) + (e.get("payload") or [])):
                return True
            return any(k not in ("SecretArguments",) for k in (e.get("flags") or {}))
        dropped = {}
        for sect in ("functions", "widgetMethods", "events"):
            tab = smap.get(sect) or {}
            keep = {k: v for k, v in tab.items() if isinstance(v, dict) and _interesting(v)}
            dropped[sect] = len(tab) - len(keep)
            smap[sect] = keep
        smap["fixtureNote"] = "secrecy-relevant entries only; dropped (no secrecy/restriction data): %s" % dropped
        with open(os.path.join(a.out, "secrets-documented.json"), "w", encoding="utf-8") as f:
            json.dump(smap, f, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        written += ["environment.json", "api-surface.json", "secrets-documented.json"]
        if a.file:
            _, nl = anonymize.combat_log(a.file, os.path.join(a.out, "WoWCombatLog-anon.txt"), a.max_lines, anon)
            fx = combatlog.parse_file(os.path.join(a.out, "WoWCombatLog-anon.txt"))
            mocks.write_lua(os.path.join(a.out, "combatlog_file.lua"), "anonymized WoWCombatLog fixture (%s)" % dump.build_label(), fx)
            written += ["WoWCombatLog-anon.txt (%d lines)" % nl, "combatlog_file.lua (%d CLEU events)" % fx["total"]]
        if a.taint:
            anonymize.taint_log(a.taint, os.path.join(a.out, "taint-anon.log"), anon)
            written.append("taint-anon.log")
        hits = anonymize.leak_scan(a.out, [w.strip() for w in a.forbid.split(",") if w.strip()])
        anonymize.write_json(os.path.join(a.out, "anonymization.json"), {
            "mapped": anon.mapping_summary(), "build": dump.build_label(), "files": written,
            "rules": "player GUIDs -> Player-0000-NNNNNNNN, player names -> PlayerN (realm kept), player pets -> Pet-0-0000-0-0-<npc>-N / PetN; "
                     "NPCs, spells, zones kept; api surface keeps names only; secrets map keeps documentation-derived data only",
            "leakScan": {"hits": len(hits)}})
        print("wrote", ", ".join(written), "to", a.out, "| mapped", anon.mapping_summary(), "| leak hits", len(hits))
        if hits:
            for h in hits[:20]:
                print("LEAK", *h)
            return 3
    elif a.cmd == "migrate":
        rep = migratemod.Migrator(dump).scan(a.addon)
        export_json.write_json(os.path.join(a.out, "migration.json"), rep)
        _write(os.path.join(a.out, "MIGRATION.md"), migratemod.markdown(rep))
        print(json.dumps({k: rep[k] for k in ("apiCounts", "callSiteCounts", "eventCounts")}, indent=1))
        print("TOC findings %d, taint patterns %d, secret-flow findings %d" % (len(rep["toc"]), len(rep["taint"]), len(rep["secretFlow"])))
        print("wrote migration.json + MIGRATION.md to", a.out)
    elif a.cmd == "verify":
        smap = secretsmod.build(dump)
        rep = secretsmod.verify_report(smap)
        export_json.write_json(os.path.join(a.out, "verify.json"), rep)
        _write(os.path.join(a.out, "VERIFY.md"), secretsmod.verify_markdown(rep))
        print(json.dumps({"statusCounts": rep["statusCounts"], "coverage": rep["coverage"],
                          "liveContradictions": len(rep["liveContradictions"])}, indent=1))
        print("wrote verify.json + VERIFY.md to", a.out)
    elif a.cmd == "xref":
        fx = combatlog.parse_file(a.file, year=a.year) if a.file else None
        guid = a.player
        if not guid:
            for sess in as_list(dump.combatlog.get("sessions")):
                guid = guid or sess.get("playerGUID") or (sess.get("meta") or {}).get("playerGUID")
        res = xrefmod.build(dump, fx, guid, a.window_ms)
        os.makedirs(a.out, exist_ok=True)
        xrefmod.write_jsonl(os.path.join(a.out, "timeline.jsonl"), res)
        _write(os.path.join(a.out, "TIMELINE.md"), xrefmod.markdown(res))
        print(json.dumps({"bySource": res["bySource"], "matches": res["stats"], "segments": len(res["segments"]),
                          "player": guid}, indent=1))
        print("wrote timeline.jsonl + TIMELINE.md to", a.out)
    elif a.cmd == "ketho":
        r = ketho.compare(dump, ref=a.ref, branch=a.branch, ui_source=a.ui_source)
        print(ketho.text(r))
        if a.json:
            export_json.write_json(a.json, r)
    return 0


if __name__ == "__main__":
    sys.exit(main())
