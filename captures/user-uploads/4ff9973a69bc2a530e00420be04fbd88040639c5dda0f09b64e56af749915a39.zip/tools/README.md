# ForeverDump converter (`tools/fdump.py`)

Python 3.8+ with only the standard library. Lua 5.1 and busted are needed only to *run* the generated mocks and specs.

```
python3 tools/fdump.py info  ForeverDump.lua                 # build, WOW_PROJECT_ID, scriptsDisallowedForBeta, sections present
python3 tools/fdump.py all   ForeverDump.lua -o out/          # json + luals + luacheck + mocks in one go
```
`DUMP` can be the SavedVariables file `WTF\Account\<ACCOUNT>\SavedVariables\ForeverDump.lua`, a `dump.json` written
by `json`, or the folder that contains it.

**Safe parsing:** `fdump/luasv.py` is a small recursive-descent parser for the SavedVariables data subset (tables,
strings, numbers, booleans, nil). It never executes Lua, so a tampered SV file can't run code. Anything else is a
`LuaParseError`.

| Subcommand | Output |
|---|---|
| `json DUMP -o DIR` | `dump.json`, `meta.json`, `v1.json`, `sections/*.json`, `docs.json`, `strings.json`, `record/session_N.json`, `combatlog/session_N.json`, `errors.json` |
| `luals DUMP -o DIR` | LuaLS `---@meta` stubs: `Namespaces/C_*.lua`, `Globals.lua`, `Structures.lua`, `Enums.lua` (runtime values), `Constants.lua`, `Events.lua` (`ForeverEvent` alias with payloads), `Widgets.lua` (typed `RegisterEvent`, `CreateFrame` overloads), `Frames.lua`, `GlobalStrings.lua`, `.luarc.json.example`. Documented but missing functions are `---@deprecated` |
| `luacheck DUMP -o .luacheckrc [--std NAME]` | Self-contained config with `stds.forever` (read globals, namespace and Enum fields) and `std = "lua51+forever"` |
| `mocks DUMP -o DIR` | `wowmock.lua` (mock client from the dump: namespaces, Enum, widgets, secret values that error when touched, restricted-event tracking `wow.forbidden`), `forever_data.lua`, `replay.lua`, `fixtures/session_N.lua` (recorder), `fixtures/combatlog_N.lua`, `fixtures/probe.lua`, `spec/example_spec.lua`, `run_spec.lua` (mini runner if busted is missing) |
| `check DUMP ADDON_DIR [--json F] [--strict]` | API checker: missing APIs, namespaces, Enums, widget types and methods, unknown events; notes for restricted or secret flags; exits 1 on errors |
| `diff OLD NEW [-o F.md] [--json F]` | Build-to-build diff: functions, signatures, events and payloads, enums, tables, constants, CVars (defaults), widgets, templates, global strings |
| `combatlog Logs/WoWCombatLog-*.txt -o F.lua\|F.json [--year Y] [--utc-offset H] [--shape cleu\|raw] [--limit N] [--subevents A,B] [--forever-player GUID]` | Replay fixtures from the client's combat log file. Handles advanced logging (v22: 19-field advanced block, extra raw amount), `COMBAT_LOG_VERSION` header, timezone in the timestamp. `--forever-player` also synthesizes Forever events (UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING, marked `synthetic`) |
| `cl-compare FIXTURE DUMP [--session N]` | Cross-checks a file fixture against a legacy `/fdump cl cleu-force` capture (arity and field differences) |
| `taint Logs/taint.log [-o F.json]` | Groups taint.log entries (blocked actions, tainted globals or executions, forbidden calls) by kind and addon |
| `errors DUMP [--json F]` | Lua errors (stack, locals) and ADDON_ACTION_BLOCKED/FORBIDDEN captured by the addon |
| `secrets DUMP -o DIR` | Secrets map: `secrets.json` + `SECRETS.md`. Every documented secrecy flag (SecretArguments, SecretReturns, SecretWhen*/SecretIn*, ConditionalSecret, NeverSecret, SecretReturnsForAspect, ...), per function/event/struct field classes (always / conditional / never / partial / observed), aspects, secret-related APIs, state and CVars, plus the addon's runtime observations |
| `verify DUMP -o DIR` | Reconciles docs with the verifier tallies: `verify.json` + `VERIFY.md`, each API/event/field position CONFIRMED / **CONTRADICTED** / UNOBSERVED / UNDOCUMENTED-SECRET with sample counts, contexts (`ooc\|combat\|enc / instanceType / self\|other`) and coverage %. LuaLS stubs, mocks and the `secret-op` check use the verified class when there is one and mark the rest `[unverified]` |
| `xref DUMP [--file WoWCombatLog.txt] [--player GUID] [--window-ms 750] [--year Y] -o DIR` | One ordered timeline from the addon event log, combat recorder sessions, errors/blocked, verifier contradictions and the file combat log: `timeline.jsonl` (each line: source, secret status, match quality) + `TIMELINE.md` (an excerpt per combat). Match qualities: `exact`, `time+amount`, `time+spell`, `time-only:secret-amount`, `time-only:amount-differs`, `unmatched` (e.g. UNIT_COMBAT to SWING_DAMAGE within N ms) |
| `migrate DUMP ADDON_DIR -o DIR` | **Legacy migration report** (`MIGRATION.md` + `migration.json`): every call site with status `ok` / `removed` / `renamed` / `signature-changed` / `now-secret` / `protected` / `deprecated-shim` / `replacement-missing`, the replacement, return-shape notes, examples and secrecy; events (`restricted-event`, `renamed-event`, `removed-event`); TOC Interface issues; taint-prone patterns (global overwrites, UIDropDownMenu, RegisterAllEvents, SetBackdrop, string PlaySound, unguarded secure attributes/layout); secret-value flow findings. Understands `local X = X` upvalue caching |
| `migrate-db BRANCH=Interface/AddOns ...` | Rebuilds `fdump/data/migration_shims.json` from the Blizzard_Deprecated* addons of one or more source trees (`forever=... live=...`). The curated table is `fdump/data/migration_curated.json` |
| `fixtures DUMP [--file LOG] [--taint LOG] [--forbid a,b] -o DIR` | Anonymized, shareable fixture pack (api surface, environment, documented secrets map, anonymized combat/taint logs + replay fixture); fails if the leak scan finds a real player GUID or a `--forbid` word |
| `ketho DUMP [--ref DIR] [--branch forever]` | Optional: compares against Ketho/BlizzardInterfaceResources GlobalAPI/CVars (downloads from GitHub unless `--ref` is given) |

## Replay (busted)
```lua
local wow = dofile("out/mocks/wowmock.lua"); package.loaded.wowmock = wow
local Replay = dofile("out/mocks/replay.lua")
wow.install()                                         -- globals from the dump
local s = Replay.load("out/mocks/fixtures/combatlog_1.lua")
local stats = Replay.run(s, { frame = myFrame })     -- Forever events; captured C_CombatText getter returns are stubbed
Replay.run(fileFixture, { frame = f, cleu = false }) -- only Forever/synthetic events
Replay.run(fileFixture, { frame = f, forever = false }) -- only legacy CLEU (CombatLogGetCurrentEventInfo stubbed)
```
`<secret>` values come back as secret objects. Arithmetic, comparison or concatenation on them raises an error,
just as on the client, and `wow.secretTouches` counts any such touch. `issecretvalue()` works on them.

## Migration workflow (old addon -> Forever)
```
python3 tools/fdump.py migrate ForeverDump.lua path/to/OldAddon -o out/migrate-OldAddon
python3 tools/fdump.py check   ForeverDump.lua path/to/OldAddon           # after porting: missing APIs / secret ops
```
The mapping DB has 109 curated entries (old global -> C_ replacement with return-shape notes and an example) and 373
entries parsed from the Blizzard_Deprecated* shims (forever + live branches). Shims load only while the CVar
`loadDeprecationFallbacks` is 1, so `deprecated-shim` means "works today, may vanish". Present/missing comes from your dump.
`replacement-missing` means the shim maps to an API that this client doesn't have (e.g. `CombatLogGetNumEntries` ->
`C_CombatLog.GetEntryCount`).

## Caveats
- The combat log parser (v22) was checked against one real Forever 70245 log (1029 lines, advanced logging).
  `tests/fixtures/` is synthetic; `fixtures/forever-70245/` is the anonymized real capture.
- `migrate` is lexical (no full Lua parser): dynamic calls (`_G[name]`, method tables) are not resolved, and secret-flow
  findings follow simple local assignments. Treat the report as a checklist, then run the addon in the mocks.
- Forever events synthesized from a file log are approximations; the real client may fire them differently.
- `ketho` and the self-hosting refresh scripts in `tools/refresh/` (separate docs: `SELF-HOSTING.md`) need network
  access. The refresh scripts' `.cache/` and the extracted `data/` folder are **not in the zip** (≈1 GB); re-create
  them with `tools/refresh/refresh_all.sh`.

## Tests
`sh tests/run_converter_tests.sh` runs luac, luacheck, the addon smoke test in the mock client (driven by the real
Forever API docs; set `FORE_DOCS` to an `Interface/AddOns` tree with `Blizzard_APIDocumentationGenerated`), and
the converter end-to-end checks, including busted (example spec, replay spec, anonymized fixture spec), the
BugGrabber coexistence test (`tests/buggrabber.lua`), `tests/test_xref.py` and `tests/test_migrate.py` (deliberate legacy
addon `tests/legacy_addon/` plus the anonymizer). The docs tree (`ref/`) is not in the zip.
