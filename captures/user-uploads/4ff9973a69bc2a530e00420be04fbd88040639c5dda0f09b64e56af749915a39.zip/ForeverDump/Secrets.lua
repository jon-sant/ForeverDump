-- ForeverDump v2.1 - secrets map + live VERIFIER (runtime side). Everything persists in ForeverDumpDB:
--  secretsObs[kind..":"..name] = { [pos] = { oN, oS, cN, cS, eN, eS },          -- seen/secret out of combat / combat / encounter
--                                  x = { [pos] = { [ctx] = { n, s, inaccessible } } } }
--     ctx = "<ooc|combat|enc>/<instanceType>/<self|other|none>", at most secrets.maxCtx per position.
--     kind: event (every event the recorder / combat recorder sees, tallied live with issecretvalue and
--     canaccessvalue before any throttling), api (probe calls, sweep calls, C_CombatText getter), field (struct fields).
--  secretsObs._sessions[sid] = { anchor, endAnchor, sweepCalls, events }   -- per capture session timebase
--  secretsLive = { contradictions = { {key, pos, doc, observed, ctx, sid, t, epoch, count} ... }, recent = {...} }
--     contradictions are detected in real time against the documented class from ForeverDumpDocsDB:
--     documented never-secret but observed secret, documented always-secret but observed clear,
--     undocumented (no annotation) but observed secret.
--  Getter sweep (FD_Logs, or /fdump secrets sweep on): documented conditionally/always-secret getters that take no
--     arguments or just a unit token are called with "player" (and "target" when it exists) on a throttled timer.
--  section "secrets": secret-related API presence + current restriction state; /fdump secrets: live panel.
local _, ns = ...
local Secrets = {}
ns.Secrets = Secrets

local inEncounter = false
local instanceType = "none"
local function updateInstance()
    local f = rawget(_G, "IsInInstance")
    if type(f) == "function" then
        local ok, inside, kind = pcall(f)
        if ok and not ns.IsSecret(kind) then instanceType = (inside and type(kind) == "string") and kind or "none" end
    end
end
ns.On("ENCOUNTER_START", function() inEncounter = true end)
ns.On("ENCOUNTER_END", function() inEncounter = false end)
ns.On("PLAYER_ENTERING_WORLD", function() inEncounter = false updateInstance() end)
ns.On("ZONE_CHANGED_NEW_AREA", updateInstance)
function Secrets.InEncounter() return inEncounter end

local MAX_POS = 24
local function scfg() return (ns.config and ns.config.secrets) or ns.defaults.secrets end

local UNIT_PATTERNS = { "^player$", "^pet$", "^vehicle$", "^target", "^focus", "^mouseover", "^party%d", "^raid%d",
    "^nameplate%d", "^boss%d", "^arena%d", "^softenemy", "^softfriend", "^softinteract", "^none$", "^npc$" }
local function unitClass(v)
    if type(v) ~= "string" or ns.IsSecret(v) then return "none" end
    if v == "player" or v == "vehicle" then return "self" end
    for _, p in ipairs(UNIT_PATTERNS) do if string.find(v, p) then return "other" end end
    return "none"
end
Secrets.UnitClass = unitClass

local function slotAndState()
    if inEncounter then return 5, "enc" end
    if ns.InCombat() then return 3, "combat" end
    return 1, "ooc"
end

-- documented class lookup (built lazily from ForeverDumpDocsDB): docClass["api:Name"] = { [pos] = class }
local docClass
local function classOf(node, parent)
    if node.SecretValue then return "always" end
    if node.NeverSecret then return "never" end
    if node.ConditionalSecret or node.ConditionalSecretContents then return "conditional" end
    return parent
end
local function parentClass(node)
    if node.SecretReturns or node.SecretValue or node.SecretPayloads then return "always" end
    for k, v in pairs(node) do
        if v and type(k) == "string" and (string.find(k, "^SecretWhen") or string.find(k, "^SecretIn")) then return "conditional" end
    end
    if node.SecretReturnsForAspect or node.ConstSecretAccessor then return "conditional" end
    if node.ReturnsNeverSecret then return "never" end
    return "unspecified"
end
Secrets.ParentClass = parentClass

local function buildDocClass()
    docClass = {}
    local docs = rawget(_G, "ForeverDumpDocsDB")
    if type(docs) ~= "table" or type(docs.systems) ~= "table" then return docClass end
    for _, sys in ipairs(docs.systems) do
        if sys.Type ~= "ScriptObject" then
            for _, f in ipairs(sys.Functions or {}) do
                if type(f.Name) == "string" then
                    local pc, row = parentClass(f), {}
                    for i, r in ipairs(f.Returns or {}) do row[i] = classOf(r, pc) end
                    row.parent = pc
                    docClass["api:" .. (sys.Namespace and (sys.Namespace .. "." .. f.Name) or f.Name)] = row
                end
            end
        end
        for _, e in ipairs(sys.Events or {}) do
            if type(e.LiteralName) == "string" then
                local pc, row = parentClass(e), {}
                for i, p in ipairs(e.Payload or {}) do row[i] = classOf(p, pc) end
                row.parent = pc
                docClass["event:" .. e.LiteralName] = row
            end
        end
    end
    return docClass
end
function Secrets.DocClass(key, pos)
    local row = (docClass or buildDocClass())[key]
    if not row then return nil end
    return row[pos] or row.parent
end
function Secrets.ResetDocClass() docClass = nil end

local function obsDB()
    local db = ns.db
    if not db then return nil end
    local obs = db.secretsObs
    if type(obs) ~= "table" then obs = { _keys = 0 } db.secretsObs = obs end
    return obs
end

local liveIndex -- id -> contradiction (rebuilt from the persisted list; not saved twice)
local function liveDB()
    local l = ns.db.secretsLive
    if type(l) ~= "table" then l = { contradictions = {}, recent = {} } ns.db.secretsLive = l liveIndex = nil end
    l.contradictions = l.contradictions or {}
    l.recent = l.recent or {}
    l.index = nil
    if not liveIndex then
        liveIndex = {}
        for _, c in ipairs(l.contradictions) do
            liveIndex[tostring(c.key) .. "#" .. tostring(c.pos) .. "#" .. tostring(c.observed) .. "#" .. tostring(c.ctx)] = c
        end
    end
    return l
end
function Secrets.ResetLive() liveIndex = nil end

local function contradiction(key, pos, doc, observed, ctx)
    local l = liveDB()
    local id = key .. "#" .. pos .. "#" .. observed .. "#" .. ctx
    local c = liveIndex[id]
    if c then c.count = c.count + 1 c.lastT = GetTime() return end
    if #l.contradictions >= (tonumber(scfg().maxLive) or 200) then l.dropped = (l.dropped or 0) + 1 return end
    c = ns.Stamp({ key = key, pos = pos, doc = doc, observed = observed, ctx = ctx, count = 1 })
    l.contradictions[#l.contradictions + 1] = c
    liveIndex[id] = c
end

-- core tally: secretFlags[pos] = true when secret; inacc[pos] = true when canaccessvalue said false
local function tally(kind, name, n, secretFlags, inacc, unitArg)
    local cfgS = scfg()
    if cfgS.observe == false then return end
    local obs = obsDB()
    if not obs or type(name) ~= "string" then return end
    local key = kind .. ":" .. name
    local row = obs[key]
    if not row then
        if (obs._keys or 0) >= (tonumber(cfgS.maxKeys) or 4000) then obs._dropped = (obs._dropped or 0) + 1 return end
        row = {}
        obs[key] = row
        obs._keys = (obs._keys or 0) + 1
    end
    local slot, state = slotAndState()
    local ctx = state .. "/" .. instanceType .. "/" .. unitClass(unitArg)
    n = math.min(tonumber(n) or 0, MAX_POS)
    if n == 0 then n = 1 end
    row.x = row.x or {}
    local maxCtx = tonumber(cfgS.maxCtx) or 16
    local checkDocs = kind == "api" or kind == "event"
    for pos = 1, n do
        local c = row[pos]
        if not c then c = { 0, 0, 0, 0, 0, 0 } row[pos] = c end
        local sec = secretFlags[pos] == true
        c[slot] = c[slot] + 1
        if sec then c[slot + 1] = c[slot + 1] + 1 end
        local xp = row.x[pos]
        if not xp then xp = { _n = 0 } row.x[pos] = xp end
        local b = xp[ctx]
        if not b and xp._n < maxCtx then b = { 0, 0, 0 } xp[ctx] = b xp._n = xp._n + 1 end
        if b then
            b[1] = b[1] + 1
            if sec then b[2] = b[2] + 1 end
            if inacc and inacc[pos] then b[3] = b[3] + 1 end
        end
        if checkDocs then
            local doc = Secrets.DocClass(key, pos)
            if doc then
                if sec and (doc == "never" or doc == "unspecified") then
                    contradiction(key, pos, doc, "secret", ctx)
                elseif not sec and doc == "always" and secretFlags.valuePresent and secretFlags.valuePresent[pos] then
                    contradiction(key, pos, doc, "clear", ctx)
                end
            end
        end
    end
    -- recent list for the live panel (bounded)
    if kind == "event" or kind == "api" then
        local l = liveDB()
        local rec = l.recent
        local found
        for i = 1, #rec do if rec[i].key == key then found = table.remove(rec, i) break end end
        found = found or { key = key, n = 0, s = 0 }
        found.n = found.n + 1
        for pos = 1, n do if secretFlags[pos] then found.s = found.s + 1 break end end
        table.insert(rec, 1, found)
        while #rec > 15 do table.remove(rec) end
    end
end

-- live values (event payloads): issecretvalue + canaccessvalue per position
local canaccess = rawget(_G, "canaccessvalue")
function ns.ObserveLive(kind, name, ...)
    local n = select("#", ...)
    local flags, inacc, present = {}, nil, {}
    local lim = math.min(n, MAX_POS)
    for i = 1, lim do
        local v = select(i, ...)
        if v ~= nil then present[i] = true end
        if ns.IsSecret(v) then
            flags[i] = true
        elseif canaccess and v ~= nil then
            local ok, can = pcall(canaccess, v)
            if ok and can == false then inacc = inacc or {} inacc[i] = true end
        end
    end
    flags.valuePresent = present
    local unitArg = select(1, ...)
    tally(kind, name, n, flags, inacc, unitArg)
end

-- pre-computed observations (packed positions list)
function ns.ObserveArgs(kind, name, n, secretPositions, unitArg)
    local flags, present = {}, {}
    if type(secretPositions) == "table" then for _, p in ipairs(secretPositions) do flags[p] = true end end
    for i = 1, math.min(tonumber(n) or 0, MAX_POS) do present[i] = true end
    flags.valuePresent = present
    tally(kind, name, n, flags, nil, unitArg)
end

-- SafeCall result -> observation (+ struct fields)
function Secrets.ObserveResult(path, res, unitArg)
    if type(res) ~= "table" or not res.ok then return end
    local flags, present = {}, {}
    for _, p in ipairs(res.secret or {}) do flags[p] = true end
    for i = 1, math.min(res.n or 0, MAX_POS) do
        local v = res.values and res.values[i]
        if v ~= nil and v ~= "<nil>" then present[i] = true end
    end
    flags.valuePresent = present
    tally("api", path, res.n, flags, nil, unitArg)
    for i = 1, math.min(res.n or 0, 4) do
        local v = res.values and res.values[i]
        if type(v) == "table" then
            for k, fv in pairs(v) do
                if type(k) == "string" then
                    local f = {}
                    if fv == ns.SECRET or fv == ns.SECRET_TABLE then f[1] = true end
                    tally("field", path .. "#" .. i .. "." .. k, 1, f, nil, unitArg)
                end
            end
        end
    end
end

----------------------------------------------------------------------------
-- getter sweep
----------------------------------------------------------------------------
local SAFE_PREFIX = { "Get", "Is", "Has", "Can", "Should", "Are", "Does", "Unit", "Player" }
local function safeName(name)
    for _, p in ipairs(SAFE_PREFIX) do if string.sub(name, 1, #p) == p then return true end end
    return false
end
local function isUnitArg(a)
    local t, n = tostring(a.Type or ""), string.lower(tostring(a.Name or ""))
    return string.find(t, "UnitToken") or n == "unit" or n == "unittoken" or n == "unitid"
end

function Secrets.SweepCandidates()
    local out = {}
    local docs = rawget(_G, "ForeverDumpDocsDB")
    if type(docs) ~= "table" or type(docs.systems) ~= "table" then return out end
    for _, sys in ipairs(docs.systems) do
        if sys.Type ~= "ScriptObject" then
            for _, f in ipairs(sys.Functions or {}) do
                local name = f.Name
                local ok = type(name) == "string" and safeName(name) and not f.HasRestrictions and not f.IsProtectedFunction
                if ok then
                    for k in pairs(f) do if type(k) == "string" and string.find(k, "^Require") then ok = false break end end
                end
                if ok then
                    local pc = parentClass(f)
                    local secretish = pc == "always" or pc == "conditional"
                    for _, r in ipairs(f.Returns or {}) do if r.SecretValue or r.ConditionalSecret then secretish = true end end
                    local args = f.Arguments or {}
                    local unitFirst = args[1] and isUnitArg(args[1])
                    local rest = true
                    for i = unitFirst and 2 or 1, #args do
                        if not (args[i].Nilable or args[i].Default ~= nil) then rest = false break end
                    end
                    if secretish and rest and (#args == 0 or unitFirst) then
                        local path = sys.Namespace and (sys.Namespace .. "." .. name) or name
                        if type(ns.Resolve(path)) == "function" then out[#out + 1] = { path = path, unit = unitFirst and true or false } end
                    end
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.path < b.path end)
    return out
end

local sweeping, sweepList, sweepPos, sweepCalls, sweepSession = false, nil, 1, 0, nil

local function unitExists(u)
    if u == "player" then return true end
    local f = rawget(_G, "UnitExists")
    if type(f) ~= "function" then return false end
    local ok, r = pcall(f, u)
    return ok and not ns.IsSecret(r) and r and true or false
end

function Secrets.SweepTick(maxCalls)
    if not sweepList then sweepList = Secrets.SweepCandidates() sweepPos = 1 end
    if #sweepList == 0 then return 0 end
    local calls = 0
    maxCalls = maxCalls or tonumber(scfg().sweepPerTick) or 25
    local units = { "player" }
    if unitExists("target") then units[2] = "target" end
    local guard = 0
    while calls < maxCalls and guard < #sweepList do
        guard = guard + 1
        local c = sweepList[sweepPos]
        sweepPos = sweepPos % #sweepList + 1
        local fn = ns.Resolve(c.path)
        if type(fn) == "function" then
            if c.unit then
                for _, u in ipairs(units) do
                    Secrets.ObserveResult(c.path, ns.SafeCall(fn, u), u)
                    calls = calls + 1
                end
            else
                Secrets.ObserveResult(c.path, ns.SafeCall(fn), nil)
                calls = calls + 1
            end
        end
    end
    sweepCalls = sweepCalls + calls
    if sweepSession then sweepSession.sweepCalls = (sweepSession.sweepCalls or 0) + calls end
    return calls
end

local function schedule()
    local after = rawget(_G, "C_Timer") and C_Timer.After
    if not after then return end
    after(tonumber(scfg().sweepInterval) or 5, function()
        if not sweeping then return end
        pcall(Secrets.SweepTick)
        schedule()
    end)
end

local function sessionRecord()
    local obs = obsDB()
    obs._sessions = obs._sessions or {}
    local sid = ns.SessionId()
    local s = obs._sessions[sid]
    if not s then
        local n = 0
        for _ in pairs(obs._sessions) do n = n + 1 end
        if n >= 50 then return nil end
        s = { anchor = ns.TimeAnchor(), sweepCalls = 0, started = 0 }
        obs._sessions[sid] = s
    end
    return s
end

function Secrets.StartSweep()
    if sweeping then return true end
    sweepList = Secrets.SweepCandidates()
    sweepPos, sweepCalls = 1, 0
    sweepSession = sessionRecord()
    if sweepSession then sweepSession.started = sweepSession.started + 1 sweepSession.candidates = #sweepList end
    if #sweepList == 0 then return false end
    sweeping = true
    pcall(Secrets.SweepTick)
    schedule()
    return true
end

function Secrets.StopSweep()
    if not sweeping then return 0 end
    sweeping = false
    if sweepSession then sweepSession.endAnchor = ns.TimeAnchor(true) end
    return sweepCalls
end
function Secrets.IsSweeping() return sweeping end

ns.On("PLAYER_LOGOUT", function()
    if sweeping then Secrets.StopSweep() end
end)

----------------------------------------------------------------------------
-- state snapshot
----------------------------------------------------------------------------
local PRIMS = { "issecretvalue", "issecrettable", "canaccessvalue", "canaccesssecrets", "canaccesstable",
    "hasanysecretvalues", "scrubsecretvalues", "scrub", "secretwrap", "secretunwrap", "dropsecretaccess",
    "issecure", "issecurevariable", "forceinsecure", "securecallfunction", "InCombatLockdown" }
local STATE_PATTERN = { "Restrict", "Secret", "Lockdown", "Declassif" }
local CVAR_PATTERN = { "secret", "restrict", "lockdown", "taint", "scripterror", "addonperformance", "protected" }

local function matchesAny(s, pats)
    local l = string.lower(s)
    for _, p in ipairs(pats) do if string.find(l, string.lower(p), 1, true) then return true end end
    return false
end

local function stateGetters()
    local out = {}
    local docs = rawget(_G, "ForeverDumpDocsDB")
    if type(docs) ~= "table" or type(docs.systems) ~= "table" then return out end
    for _, sys in ipairs(docs.systems) do
        if sys.Type ~= "ScriptObject" and type(sys.Functions) == "table" then
            for _, f in ipairs(sys.Functions) do
                local name = f.Name
                if type(name) == "string" and (not f.Arguments or #f.Arguments == 0) and not f.HasRestrictions
                    and not f.IsProtectedFunction and matchesAny(name, STATE_PATTERN)
                    and (string.find(name, "^Is") or string.find(name, "^Should") or string.find(name, "^Has")
                        or string.find(name, "^Get") or string.find(name, "^Are") or string.find(name, "^Can")) then
                    out[#out + 1] = sys.Namespace and (sys.Namespace .. "." .. name) or name
                end
            end
        end
    end
    table.sort(out)
    return out
end

function Secrets.State()
    local st = ns.Stamp({ inCombat = ns.InCombat(), inEncounter = inEncounter, instanceType = instanceType, primitives = {},
        getters = {}, restrictions = {}, cvars = {} })
    for _, name in ipairs(PRIMS) do st.primitives[name] = type(rawget(_G, name)) end
    local CS = rawget(_G, "C_Secrets")
    if type(CS) == "table" then
        st.cSecrets = {}
        for name, fn in next, CS do if type(fn) == "function" then st.cSecrets[#st.cSecrets + 1] = name end end
        table.sort(st.cSecrets)
    end
    for _, path in ipairs(stateGetters()) do
        local res = ns.SafeCall(ns.Resolve(path))
        st.getters[path] = res
        Secrets.ObserveResult(path, res)
    end
    local RA = rawget(_G, "C_RestrictedActions")
    local types = rawget(rawget(_G, "Enum") or {}, "AddOnRestrictionType")
    if type(RA) == "table" and type(RA.GetAddOnRestrictionState) == "function" and type(types) == "table" then
        for tname, v in pairs(types) do st.restrictions[tname] = ns.SafeCall(RA.GetAddOnRestrictionState, v) end
    end
    local CL = rawget(_G, "C_CombatLog")
    if type(CL) == "table" then st.combatLogRestricted = ns.SafeCall(CL.IsCombatLogRestricted) end
    local names = ns.db and ns.db.cvarNames
    if type(names) ~= "table" or #names == 0 then
        names = { "taintLog", "scriptErrors", "scriptProfile", "addonPerformanceMsgWarning", "addonChallengeModeRestrictionsForced",
                  "addonCombatRestrictionsForced", "addonEncounterRestrictionsForced", "addonMapRestrictionsForced",
                  "addonPvPMatchRestrictionsForced", "addonChatRestrictionsForced" }
    end
    local get = (rawget(_G, "C_CVar") and C_CVar.GetCVar) or rawget(_G, "GetCVar")
    for _, name in ipairs(names) do
        if type(name) == "string" and matchesAny(name, CVAR_PATTERN) and type(get) == "function" then
            local ok, v = pcall(get, name)
            if ok and not ns.IsSecret(v) then st.cvars[name] = v end
        end
    end
    return ns.Clean(st, { maxDepth = 6, maxKeys = 2000 })
end

function Secrets.Snapshot(reason)
    local sct = ns.db.sections.secrets or {}
    local key = inEncounter and "inEncounter" or (ns.InCombat() and "inCombat" or "outOfCombat")
    local st = Secrets.State()
    st.reason = reason
    sct[key] = st
    ns.db.sections.secrets = sct
    return key, st
end

----------------------------------------------------------------------------
-- live panel
----------------------------------------------------------------------------
local panel
local function panelText()
    local l = liveDB()
    local lines = { "|cff33ff99ForeverDump secrets verifier|r  " .. (sweeping and "sweep ON" or "sweep off")
        .. string.format("  (%s, %s)", ns.InCombat() and "in combat" or "out of combat", instanceType) }
    lines[#lines + 1] = "recent (secret/seen):"
    for i = 1, math.min(#l.recent, 10) do
        local r = l.recent[i]
        lines[#lines + 1] = string.format("  %s  %d/%d", r.key, r.s, r.n)
    end
    lines[#lines + 1] = string.format("contradictions: %d", #l.contradictions)
    for i = math.max(1, #l.contradictions - 5), #l.contradictions do
        local c = l.contradictions[i]
        if c then lines[#lines + 1] = string.format("  |cffff5555%s #%d|r doc %s, seen %s (%s) x%d", c.key, c.pos, c.doc, c.observed, c.ctx, c.count) end
    end
    return table.concat(lines, "\n")
end
Secrets.PanelText = panelText

function Secrets.TogglePanel(show)
    if not panel then
        panel = CreateFrame("Frame", "ForeverDumpSecretsPanel", UIParent)
        panel:SetSize(420, 260)
        panel:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -40, -200)
        panel:SetFrameStrata("HIGH")
        if panel.SetMovable then panel:SetMovable(true) panel:EnableMouse(true) panel:RegisterForDrag("LeftButton")
            panel:SetScript("OnDragStart", panel.StartMoving) panel:SetScript("OnDragStop", panel.StopMovingOrSizing) end
        local bg = panel:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0.7)
        panel.text = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        panel.text:SetPoint("TOPLEFT", 8, -8)
        panel.text:SetPoint("BOTTOMRIGHT", -8, 8)
        panel.text:SetJustifyH("LEFT")
        panel.text:SetJustifyV("TOP")
        local acc = 0
        panel:SetScript("OnUpdate", function(self, dt)
            acc = acc + (dt or 0)
            if acc >= 1 then acc = 0 self.text:SetText(panelText()) end
        end)
        panel:Hide()
    end
    if show == nil then show = not panel:IsShown() end
    if show then panel.text:SetText(panelText()) panel:Show() else panel:Hide() end
    return show
end

ns.RegisterSection({
    name = "secrets",
    desc = "secret/restriction state (C_Secrets predicates, restriction states, getters, CVars); "
        .. "/fdump secrets [panel|state|sweep on|off|now|status]: live verifier panel",
    inAll = true,
    combatSafe = true,
    run = function(_, args)
        local sub = args and string.lower(args[1] or "") or nil
        if sub == "sweep" then
            local w = string.lower(args[2] or "status")
            if w == "on" then ns.Print(Secrets.StartSweep() and "secrets sweep running" or "secrets sweep: no candidates (run /fdump docs first)")
            elseif w == "off" then ns.Print(string.format("secrets sweep stopped (%d calls)", Secrets.StopSweep()))
            elseif w == "now" then ns.Print(string.format("secrets sweep: %d calls", Secrets.SweepTick(200)))
            else ns.Print(string.format("secrets sweep %s, %d candidates, %d calls", sweeping and "ON" or "off",
                #(sweepList or Secrets.SweepCandidates()), sweepCalls)) end
            return
        end
        if sub == "panel" or sub == "" then
            Secrets.TogglePanel()
            if sub == "panel" then return end
        end
        local key, st = Secrets.Snapshot("section")
        local nG = 0
        for _ in pairs(st.getters or {}) do nG = nG + 1 end
        local sct = ns.db.sections.secrets
        local obs = obsDB()
        sct.counts = { getters = nG, observedKeys = obs and obs._keys or 0, contradictions = #liveDB().contradictions }
        ns.SaveSection("secrets", sct)
        ns.Print(string.format("secrets: state stored under secrets.%s (%d state getters); %d keys observed, %d live contradictions",
            key, nG, sct.counts.observedKeys, sct.counts.contradictions))
    end,
})
