-- ForeverDump v2 - slash commands. `/fdump` alone keeps the v1 behaviour.
local _, ns = ...

local ALL_ORDER = { "docs", "api", "globals", "strings", "widgets", "templates", "frames", "addons",
                    "cvars", "protected", "secrets", "extras" }

function ns.RunAll()
    for _, name in ipairs(ALL_ORDER) do ns.RunSection(name) end
end

local function help()
    local p = ns.Print
    p("v" .. ns.VERSION .. " commands (/fdump or /foreverdump):")
    p("  /fdump                 v1 quick dump (APIs, events, enums, CVars) + copy window")
    p("  /fdump all [full]      every section below in order, chunked (out of combat); compact by default, 'full' = everything")
    for _, name in ipairs(ns.sectionOrder) do
        local def = ns.sections[name]
        p(string.format("  /fdump %-15s %s", name, def.desc or ""))
    end
    p("  /fdump record start|stop|status   event recorder (combat-safe)")
    p("  /fdump cl start [file]|stop|status   combat recorder: UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING,")
    p("                         COMBAT_TEXT_UPDATE, encounter/regen context, post-combat C_DamageMeter snapshot;")
    p("                         'file' sets advancedCombatLogging; the log file itself: FD_Logs macro or /combatlog")
    p("  /fdump cl cleu-force   legacy CLEU capture - refused unless CombatLogGetCurrentEventInfo exists and the")
    p("                         combat log is unrestricted; restricted clients show a 'disable addon' popup")
    p("  /fdump logs macro      create the account macro FD_Logs - THE way to use ForeverDump: click = capture everything")
    p("                         (all logs, recorders, probes, errors, profiler, full dump if needed); click again = stop, save, /reload")
    p("  /fdump logs [on|off|status]   the same toggle without the macro (no /combatlog, /chatlog, /reload lines)")
    p("  /fdump errors [status|on|off|clear|show|bg]   Lua error + ADDON_ACTION_BLOCKED/FORBIDDEN capture (bg: copy BugGrabber's session errors)")
    p("  /fdump probe [combat]  sample tooltips/getters now (or arm for next combat)")
    p("  /fdump probe add|remove item|spell|quest|unit|achievement|currency <id>, probe list")
    p("  /fdump status          what is collected; /fdump show <status|apis|events|enums|cvars|all|section>")
    p("  /fdump clear <section|docs|strings|record|cl|errors|probe|all>   /fdump cancel   /fdump set <key> <value>")
    p("Then /reload or log out so the client writes WTF\\Account\\<account>\\SavedVariables\\ForeverDump.lua")
end

local function words(msg)
    local out = {}
    for w in string.gmatch(msg or "", "%S+") do out[#out + 1] = w end
    return out
end

local function clear(what)
    local db = ns.db
    if what == "all" then
        local config = ns.config
        ForeverDumpDB = { config = config }
        ForeverDumpDocsDB, ForeverDumpStringsDB, ForeverDumpRecordDB = {}, {}, {}
        ForeverDumpLogDB, ForeverDumpCombatLogDB = {}, {}
        ns.InitDB()
    elseif what == "docs" then
        ForeverDumpDocsDB = {}
        db.sections.docs = nil
    elseif what == "strings" then
        ForeverDumpStringsDB = {}
        db.sections.strings = nil
    elseif what == "record" then
        ForeverDumpRecordDB = { sessions = {} }
    elseif what == "cl" or what == "combatlog" then
        ForeverDumpCombatLogDB = { sessions = {} }
        ns.InitDB()
    elseif what == "errors" or what == "log" then
        ns.Errors.Clear()
    elseif what and db.sections[what] then
        db.sections[what] = nil
    else
        ns.Print("nothing to clear for '" .. tostring(what) .. "'")
        return
    end
    ns.Print("cleared " .. tostring(what))
end

local SETTABLE = { frameBudgetMs = true, progressEverySec = true, uiMaxChars = true,
    ["record.maxEvents"] = true, ["record.perEventPerSec"] = true, ["record.maxSessions"] = true,
    ["record.callbacks"] = true, ["record.redactChat"] = true, ["probe.maxAuras"] = true,
    ["probe.redactPlayers"] = true, ["cl.maxEvents"] = true, ["cl.maxSessions"] = true, ["cl.maxArgs"] = true,
    ["cl.maxString"] = true, ["cl.redactPlayers"] = true, ["cl.damageMeter"] = true, ["cl.advanced"] = true,
    ["logs.chat"] = true, ["logs.advanced"] = true, ["logs.scriptErrors"] = true, ["logs.taintLog"] = true,
    ["logs.callLogging"] = true, ["dump.full"] = true, ["logs.recorder"] = true, ["logs.combat"] = true, ["logs.errors"] = true,
    ["logs.probe"] = true, ["logs.combatProbe"] = true, ["logs.profile"] = true, ["logs.fullDump"] = true,
    ["logs.autoReload"] = true, ["errors.maxErrors"] = true, ["errors.maxBlocked"] = true, ["errors.captureLocals"] = true,
    ["errors.maxLocals"] = true, ["errors.maxStack"] = true }

local function set(key, value)
    if not SETTABLE[key] then
        local keys = ns.SortedList(SETTABLE)
        ns.Print("settable: " .. table.concat(keys, ", "))
        return
    end
    local v
    if value == "true" then v = true elseif value == "false" then v = false else v = tonumber(value) end
    if v == nil then ns.Print("bad value") return end
    local a, b = string.match(key, "^(%w+)%.(%w+)$")
    if a then ns.config[a][b] = v else ns.config[key] = v end
    ns.Print(key .. " = " .. tostring(v))
end

local function handler(msg)
    if not ns.db then ns.InitDB() end
    local w = words(msg)
    local cmd = string.lower(w[1] or "")
    local rest = { select(2, unpack(w)) }
    if cmd == "" then
        ns.Legacy.Dump()
    elseif cmd == "help" or cmd == "?" then
        help()
    elseif cmd == "all" then
        if ns.InCombat() then ns.Print("|cffff5555refusing full dump in combat.|r") return end
        if ns.IsBusy() then ns.Print("already running; /fdump cancel to stop.") return end
        if string.lower(rest[1] or "") == "full" then
            ns.config.dump.full = true
            ns.Print("full dump: dump.full=true (everything, ~2x SavedVariables size). /fdump set dump.full false to go back.")
        end
        ns.RunAll()
    elseif cmd == "record" then
        local sub = string.lower(rest[1] or "status")
        if sub == "start" then ns.Recorder.Start()
        elseif sub == "stop" then ns.Recorder.Stop()
        else ns.Recorder.Status() end
    elseif cmd == "cl" or cmd == "combatlog" then
        local sub = string.lower(rest[1] or "status")
        local opt = string.lower(rest[2] or "")
        if sub == "start" then ns.CombatLog.Start({ file = opt == "file", cleuForce = opt == "cleu-force" })
        elseif sub == "cleu-force" then ns.CombatLog.Start({ cleuForce = true, file = opt == "file" })
        elseif sub == "stop" then ns.CombatLog.Stop()
        else ns.CombatLog.Status() end
    elseif cmd == "logs" or cmd == "macro" or cmd == "macros" then
        if cmd ~= "logs" then rest = { "macro" } end
        ns.Logs.Command(rest)
    elseif cmd == "errors" then
        local sub = string.lower(rest[1] or "status")
        if sub == "on" then
            ns.config.errors.enabled = true
            ns.Errors.Install()
            ns.Errors.Status()
        elseif sub == "off" then
            ns.config.errors.enabled = false
            ns.Errors.Uninstall()
            ns.Errors.Status()
        elseif sub == "clear" then ns.Errors.Clear() ns.Print("errors cleared")
        elseif sub == "show" then ns.UI.Show("errors")
        elseif sub == "bg" or sub == "buggrabber" then
            local r = ns.Errors.ImportBugGrabber("command")
            if r then ns.Print(string.format("copied %d BugGrabber error(s) from session %s into ForeverDumpLogDB.bugGrabber",
                #r.errors, tostring(r.session)))
            else ns.Print("BugGrabber is not loaded (or has no database yet).") end
        else ns.Errors.Status() end
    elseif cmd == "probe" then
        local sub = string.lower(rest[1] or "")
        if sub == "" or sub == "now" then ns.Probe.Run("manual")
        elseif sub == "combat" then ns.Probe.Arm()
        elseif sub == "add" or sub == "remove" then ns.Probe.Edit(sub, string.lower(rest[2] or ""), rest[3])
        elseif sub == "list" then ns.Probe.List()
        else help() end
    elseif cmd == "status" then
        local m = ns.Meta()
        ns.Print(string.format("client %s.%s toc %s, WOW_PROJECT_ID=%s (%s), scriptsDisallowedForBeta=%s",
            tostring(m.version), tostring(m.build), tostring(m.toc), tostring(m.projectID),
            tostring(m.projectName or "?"), tostring(m.scriptsDisallowedForBeta)))
        ns.UI.Show("status")
        ns.Recorder.Status()
        ns.CombatLog.Status()
        ns.Errors.Status()
        ns.Logs.Status()
    elseif cmd == "show" then
        ns.UI.Show(string.lower(rest[1] or "status"))
    elseif cmd == "clear" then
        clear(string.lower(rest[1] or ""))
    elseif cmd == "cancel" then
        ns.CancelAll()
        ns.Print("cancelled queued jobs.")
    elseif cmd == "set" then
        set(rest[1], rest[2])
    elseif ns.sections[cmd] then
        if ns.IsBusy() then ns.Print("queued after the running job.") end
        ns.RunSection(cmd, rest)
    else
        ns.Print("unknown command '" .. cmd .. "'")
        help()
    end
end

SLASH_FOREVERDUMP1 = "/fdump"
SLASH_FOREVERDUMP2 = "/foreverdump"
SlashCmdList.FOREVERDUMP = handler
ns.HandleSlash = handler
