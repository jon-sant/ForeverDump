# ForeverDump v2.1: addon usage

ForeverDump records what the WoW Forever client (1.60.x, Interface 16001, game type `camelot`) actually
exposes to addons, and saves it to SavedVariables so the box-side converter (`tools/fdump.py`) can turn it into
JSON, LuaLS stubs, a luacheck std, busted mocks and replay fixtures.

> It has been tested only in a mock client built from the real Forever API documentation, **not in-game yet**.

## Install
1. Unzip `ForeverDump-v2.zip`. Copy the `ForeverDump` folder (it contains `ForeverDump.toc`) to
   `World of Warcraft\_classic_beta_\Interface\AddOns\ForeverDump\`
   (this folder is for Forever; `_retail_` and `_classic_` are different clients).
2. Start the game and enable **ForeverDump** in the AddOns list on the character screen. If it shows as
   "out of date", tick "Load out of date AddOns".
3. In game, type `/fdump help`. Every command also works as `/foreverdump`.

## Run order (out of combat; the addon refuses heavy dumps in combat)
| Step | Command | What it does |
|---|---|---|
| 1 | `/fdump status` | Prints the build, `WOW_PROJECT_ID` (Forever = 18, `WOW_PROJECT_CAMELOT`), every `WOW_PROJECT_*` constant, `C_AddOns.GetScriptsDisallowedForBeta()`, and what has been collected so far |
| 2 | `/fdump all` | Runs docs, api, globals, strings, widgets, templates, frames, addons, cvars, protected and extras, in chunks over many frames. You can keep playing; `/fdump cancel` stops it |
| 3 | `/fdump getters` *(optional)* | Calls the documented zero-argument `Get*`/`Is*` functions that have no restriction flags, and records their returns and secrecy |
| 4 | `/fdump widgets risky` *(optional)* | Also creates the rarer widget types (Browser and similar) |
| 5 | `/fdump probe`, `/fdump probe combat` *(optional)* | Samples tooltips and getters now, or arms a sample for the next combat (secret detection) |
| 6 | `/fdump record start` … `/fdump record stop` | Event recorder: registers each documented event **individually** and skips restricted or SecureOnly events plus a denylist. The skipped events and reasons are saved |
| 7 | `/fdump cl start` … fight … `/fdump cl stop` | Combat recorder (UNIT_COMBAT, UNIT_SPELLCAST_*, PLAYER_SWING, COMBAT_TEXT_UPDATE + `C_CombatText.GetCurrentEventInfo`, ENCOUNTER_*, PLAYER_REGEN_*). It takes a `C_DamageMeter` snapshot after each combat |
| 8 | `/fdump logs macro`, then click **FD_Logs** | **The easy path: steps 2 to 7 and 9 in one click** (see below). Click again to stop, save and `/reload` |
| 9 | `/fdump errors show`, `/fdump errors bg`, `/fdump profile` | Shows the captured Lua errors and ADDON_ACTION_BLOCKED/FORBIDDEN events; copies BugGrabber's session errors; takes a per-addon CPU/memory snapshot |
| 10 | `/reload` (or log out) | **Required.** The client only writes SavedVariables on reload, logout or exit |

Other commands: `/fdump show <status|apis|events|enums|cvars|all|errors|section>` opens a copy window (capped size).
`/fdump clear <section|docs|strings|record|cl|errors|probe|all>` deletes collected data, and `/fdump set <key> <value>` changes
an option (for example `set logs.chat false` or `set cl.maxEvents 50000`). Plain `/fdump` still does the v1 quick dump.

### The FD_Logs macro (v2.1: one click captures everything)
`/fdump logs macro` creates one account macro, **FD_Logs**. Drag it from `/macro` (General tab) to an action bar.

- **Click 1 = ON.** Turns on the client logs (combat log file, advancedCombatLogging, scriptErrors, taintLog, chat log),
  and starts the event recorder, the combat recorder, error capture, the secrets verifier and its getter sweep. It also
  takes a probe and profiler snapshot, and queues `/fdump all` if this build has no full dump yet. The first combat of each
  recording session gets an automatic in-combat probe.
- **Click 2 = OFF.** Stops everything, takes the closing probe and profiler snapshot, copies BugGrabber's session errors
  (if BugGrabber is installed), saves the sessions, then the macro's last line `/reload` writes SavedVariables to disk.
- **It survives `/reload` and relog.** If the UI reloads while capture is ON, recording resumes after login, and a chat line
  confirms it. Each resume adds a new segment with its own time anchor.
- **In combat** the macro stops at `/stopmacro [combat]`, so nothing changes. Click again after combat.
- The macro body is `/fdump logs`, `/stopmacro [combat]`, the `/combatlog` and/or `/chatlog` toggles the next state needs,
  and `/reload` (on the OFF click only). It is under 255 characters. The addon rewrites it after each click, out of combat,
  checking against `C_ChatInfo.IsLoggingCombat()`/`IsLoggingChat()`. It does **not** call `LoggingCombat`/`LoggingChat`
  (they may be protected on Forever). Blizzard's own slash handlers do the toggling when **you** click.
- OFF restores advancedCombatLogging and scriptErrors to their values before ON, and sets taintLog to 0.
- No `/run` or `/script`, so it works even when `GetScriptsDisallowedForBeta()` is true. These docs don't rely on `/run`.
- Macros can't be created or edited in combat; the addon waits until after combat. If all 120 General macro slots
  are full, it says so.
- Options: `/fdump set logs.autoReload false` (the OFF click doesn't reload; type `/reload` yourself), `logs.chat false`
  (no chat log), `logs.sweep false`, `logs.fullDump false`, and so on. See `/fdump set` and Core.lua `ns.defaults`.

**What one FD_Logs click does NOT capture:** the legacy combat log event stream inside the addon (COMBAT_LOG_EVENT is
restricted on Forever, so the unrestricted source is the `Logs\WoWCombatLog-*.txt` file). It also misses events the
recorder skips (restricted/SecureOnly or denylisted, listed with reasons in the dump), raw values of secret payloads
(only their secrecy is counted), and anything that happens after the OFF click. SavedVariables are written only on
`/reload`, logout or exit, so a client crash loses the unsaved part.

### Secrets verifier (`/fdump secrets`)
While capture is ON, every event the recorders see is checked live with `issecretvalue` (and `canaccessvalue` if present)
per argument position. The getter sweep calls documented, conditionally secret, unrestricted getters with harmless
arguments (`player`, `target`) every 5 s, 25 calls per tick. Results go into **bounded counters only** (never raw values):
secret/clear counts per API, event or struct field position, split by context: out of combat / in combat / in an encounter,
instance type, and unit self / other. When an observation disagrees with the documentation (documented secret but seen
clear, or the reverse), it is logged as a live contradiction.

| Command | What it does |
|---|---|
| `/fdump secrets` | Opens or closes a small live panel (recent events with secret vs clear counts, contradictions) and stores a state snapshot |
| `/fdump secrets state` | Prints the secret-related state (C_Secrets, restriction states, combat-log restriction, related CVars) |
| `/fdump secrets sweep on\|off\|now\|status` | Controls the getter sweep outside FD_Logs |

Limits: `/fdump set secrets.maxKeys 4000`, `secrets.maxCtx 16`, `secrets.maxLive 200`, `secrets.sweepInterval 5`,
`secrets.sweepPerTick 25`. On the box, `python3 tools/fdump.py verify ForeverDump.lua` turns this into VERIFY.md.

### What persists, and the common timebase
Everything is written to SavedVariables: verifier tallies and the contradiction log, sweep results, the event recorder
log, combat recorder sessions, errors (plus copied BugGrabber errors), blocked actions and probes. Each capture
session gets a session ID and a time anchor: `GetTime()`, `time()`, `GetServerTime()` and the UTC offset, captured once at
session start and refined when `time()` ticks over. Every record carries `sid`, `t` (GetTime), `epoch` and `server`.
`tools/fdump.py xref` uses this to line up the addon logs with the `WoWCombatLog` file (local wall time + UTC offset).

### Optional: BugSack / BugGrabber (on-screen errors while playing)
ForeverDump records Lua errors either way. If you also want to *see* errors while playing, install **BugGrabber** and
**BugSack** (CurseForge / Wago, by Funkeh; use versions that list your client). ForeverDump detects BugGrabber.
If BugGrabber is loaded, it owns the error handler, and ForeverDump subscribes to its `BugGrabber_BugGrabbed` callback.
If BugGrabber isn't loaded, ForeverDump chains the previous handler as before. On the FD_Logs OFF click, or with
`/fdump errors bg`, BugGrabber's current-session errors are copied into `ForeverDumpLogDB.bugGrabber`. Nothing is
required: both addons are optional (`## OptionalDeps`).

### Combat log restriction on Forever
`COMBAT_LOG_EVENT(_UNFILTERED)` is restricted. Registering it fires ADDON_ACTION_FORBIDDEN and a popup offering to
disable the addon (pcall doesn't prevent this), and `CombatLogGetCurrentEventInfo` is gone. ForeverDump never registers it.
`/fdump cl cleu-force` is an explicit opt-in that refuses unless the getter exists **and**
`C_CombatLog.IsCombatLogRestricted()` returns false. Use the file log (FD_Logs) together with
`tools/fdump.py combatlog` instead.

## Where the files land
- SavedVariables: `World of Warcraft\_classic_beta_\WTF\Account\<ACCOUNT>\SavedVariables\ForeverDump.lua`
  (ForeverDumpDB, …DocsDB, …StringsDB, …RecordDB, …LogDB, …CombatLogDB). v2.1 writes a **compact** dump by default
  (about half the size); `/fdump set dump.full true` restores the v2.0 full dump (addon-created tables, all named regions, global string values)
- Logs (after FD_Logs ON): `World of Warcraft\_classic_beta_\Logs\WoWCombatLog-*.txt`, `WoWChatLog.txt`, `taint.log`
- Copy them to the box and run `python3 tools/fdump.py all ForeverDump.lua -o out/` (see `tools/README.md`).

## Privacy
`<ACCOUNT>` in the WTF path is your account name, and the chat log and combat log contain other players' names and
messages. Don't post those files publicly or share account-identifying or credential-bearing data. The recorder has
`set cl.redactPlayers true` for player GUIDs and names in legacy captures. Review files before sharing them.
