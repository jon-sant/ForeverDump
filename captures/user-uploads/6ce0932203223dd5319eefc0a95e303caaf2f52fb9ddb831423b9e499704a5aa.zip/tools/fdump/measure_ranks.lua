-- v2.2.28: candidate count before/after rank grouping, by replaying each stored run's ForeverDumpDB through the real
-- AuraPresence.List (in-game build, BG prep env, spellbook mocked from that run's knowledge store).
-- usage: lua5.1 tools/fdump/measure_ranks.lua ForeverDump real/<run>/sv/ForeverDump.lua [...]
package.path = "./tests/?.lua;" .. package.path
local addonDir = arg[1]
local W = require("wowenv")
local S = W.state
local files = {}
for line in io.lines(addonDir .. "/ForeverDump.toc") do
    if line:match("%.lua%s*$") then files[#files + 1] = line:match("^%s*(.-)%s*$") end
end
local function run(path, libOn, per)
    S.frames, S.timers, S.onUpdate = {}, {}, {}
    for _, n in ipairs(W.SV_NAMES or {}) do _G[n] = nil end
    ForeverDumpDB = nil
    dofile(path)
    local raw = io.open(path):read("*a")
    local b = raw:match('lastClientBuild\\?"?%]?%s*=%s*\\?"(%d+)')
    GetBuildInfo = function() return "1.60.1", b, "", 16001 end
    C_SpellBook = nil
    UnitClass = function() return "Shaman", "SHAMAN", 7 end
    local ns = W.loadAddon(addonDir, files, "ForeverDump")
    if not libOn then ns.LearnedAuras = nil end
    IsInInstance = function() return true, "pvp" end
    W.fire("ADDON_LOADED", "ForeverDump")
    W.fire("PLAYER_LOGIN")
    local AP = ns.AuraPresence
    AP.RANKS_PER_NAME = per
    AP.listDirty = true
    local list = AP.List()
    local names = {}
    for _, e in ipairs(list) do names[(e[2] or tostring(e[1])):lower()] = true end
    local ng = 0 for _ in pairs(names) do ng = ng + 1 end
    local st = AP.listStats or {}
    return st.ungrouped, st.candidates, ng, #list, b, st.limit
end
print("run|build|library|candidates_ungrouped|candidates_grouped(<=2/ability)|abilities_in_list|list_n|limit")
for i = 2, #arg do
    for _, lib in ipairs({ false, true }) do
        local u, c, ab, n, b, lim = run(arg[i], lib, 2)
        print(string.format("%s|%s|%s|%d|%d|%d|%d|%s", arg[i]:match("run%d+[%w-]*"), b, lib and "on" or "off", u, c, ab, n, tostring(lim)))
    end
end
