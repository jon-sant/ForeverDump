-- v2.2.12 permanent regression for the in-BG taint error (live, 2026-10-08, count 1433 and rising):
--   "attempted to iterate a table that cannot be accessed while tainted (execution tainted by 'ForeverDump')",
--   Locals: BattlegroundChatFilters <BattlegroundChatFilters.xml:3>, with every "N players have joined the battle".
-- Blizzard_ChatFrame/Mainline/BattlegroundChatFilters.lua OnUpdate prints the summary with
-- DEFAULT_CHAT_FRAME:AddMessage and THEN iterates ADDED_PLAYERS (keys = player names from the secret system message ->
-- restricted table). AddMessage reads the chat frame's Lua fading state (oldestFadingLineTimestamp, run 3); if an addon
-- line wrote it, the rest of OnUpdate runs tainted and the iteration errors; the error skips the interval reset, so it
-- repeats every frame. Model of that mechanism below (the control proves the model catches an addon line), then the
-- addon is driven through everything that prints inside a BG and must leave Blizzard's chat frame untouched.
-- usage: lua5.1 tests/bg_chat_taint.lua ForeverDump
package.path = "./tests/?.lua;" .. package.path
local addonDir = arg[1] or "ForeverDump"
local fails, passed = 0, 0
local function check(c, m) if c then passed = passed + 1 print("  ok   " .. m) else fails = fails + 1 print("  FAIL " .. m) end end
local W = require("wowenv")
local S = W.state

-- chat frame taint model (Lua ScrollingMessageFrame fading state)
local CF = DEFAULT_CHAT_FRAME
local secureDepth = 0
CF.addonLines, CF.blizzLines = 0, 0
local baseAdd = CF.AddMessage
CF.AddMessage = function(self, msg, ...)
    if secureDepth > 0 then self.blizzLines = self.blizzLines + 1 else self.addonLines = self.addonLines + 1 end
    if self.oldestFading and S.time - self.oldestFading > 120 then self.oldestFading, self.fadeOwner = nil, nil end
    if not self.oldestFading then self.oldestFading, self.fadeOwner = S.time, (secureDepth > 0) and "blizzard" or "addon" end
    if secureDepth > 0 and self.fadeOwner == "addon" then self.taintedRead = true end
    return baseAdd(self, msg, ...)
end
-- BattlegroundChatFilters (Blizzard), reduced to the failing path
local BG = { added = {}, restricted = false, errors = 0 }
function BG.joined(name, secretName)
    BG.added[name] = true
    if secretName then BG.restricted = true end
end
function BG.onUpdate()
    secureDepth = secureDepth + 1
    CF.taintedRead = false
    local n = 0
    for _ in next, BG.added do n = n + 1 end
    if n > 0 then
        CF:AddMessage(string.format("%d players have joined the battle.", n))
        if CF.taintedRead and BG.restricted then
            BG.errors = BG.errors + 1   -- "attempted to iterate a table that cannot be accessed while tainted"
        else
            for k in next, BG.added do BG.added[k] = nil end
            BG.restricted = false
        end
    end
    secureDepth = secureDepth - 1
end

-- control: one addon line into the chat frame, then the BG summary -> the model reports the live error
CF.oldestFading, CF.fadeOwner = nil, nil
CF:AddMessage("addon line")
BG.joined("p1", true) BG.onUpdate() BG.onUpdate()
check(BG.errors == 2, "control: an addon line in ChatFrame1 before the BG summary reproduces the error every update (" .. BG.errors .. ")")
BG.errors, BG.added, BG.restricted = 0, {}, false
CF.oldestFading, CF.fadeOwner, CF.addonLines = nil, nil, 0

local files = {}
for line in io.lines(addonDir .. "/ForeverDump.toc") do
    if line:match("%.lua%s*$") then files[#files + 1] = line:match("^%s*(.-)%s*$") end
end
local inInstance, itype = false, "none"
IsInInstance = function() return inInstance, itype end
local ns = W.loadAddon(addonDir, files, "ForeverDump")
W.fire("ADDON_LOADED", "ForeverDump")
W.fire("PLAYER_LOGIN")
W.fire("PLAYER_ENTERING_WORLD", true, false)
W.tick(5)

-- enter a battleground; everything below would print
S.time = S.time + 200   -- earlier lines have faded (the model resets the fading state)
inInstance, itype = true, "pvp"
local before = CF.addonLines
W.fire("PLAYER_ENTERING_WORLD", false, false)
W.tick(3)
W.slash("logs on")                  -- FD_Logs ON: wipe line + "logging: ON" lines
W.tick(3)
W.slash("level status")             -- slash replies
W.slash("cl status")
ns.Print("direct ns.Print inside the BG")
S.combat = true W.fire("PLAYER_REGEN_DISABLED") W.slash("logs off") W.tick(2)   -- in-combat refusal line
S.combat = false W.fire("PLAYER_REGEN_ENABLED") W.tick(5)
if ns.Errors and ns.Errors.Capture then pcall(ns.Errors.Capture, "ForeverDump/Test.lua:1: boom") end
W.tick(3)
check(CF.addonLines == before, "in the BG: no ForeverDump line reached DEFAULT_CHAT_FRAME (" .. (CF.addonLines - before) .. ")")
local held = ns.chatQueue and #ns.chatQueue.lines or 0
check(held >= 3, "in the BG: lines held for later (" .. held .. "), none lost")
check(ns.ChatSafe ~= nil and ns.ChatSafe() == false, "ChatSafe() is false inside an instance")
for i = 1, 6 do BG.joined("p" .. i, true) end
for _ = 1, 5 do BG.onUpdate() end
check(BG.errors == 0, "BattlegroundChatFilters summary + table iteration runs untainted (" .. BG.errors .. " errors)")

-- open-world combat is held too
inInstance, itype = false, "none"
S.combat = true
local b2 = CF.addonLines
ns.Print("in open-world combat")
check(CF.addonLines == b2, "open-world combat: line held, not printed")
S.combat = false
-- back in the world: one flush, all held lines in order
W.fire("PLAYER_ENTERING_WORLD", false, false)
W.tick(3)
check(ns.chatQueue ~= nil and #ns.chatQueue.lines == 0 and CF.addonLines >= b2 + held, "back in the open world: held lines flushed to chat ("
    .. (CF.addonLines - b2) .. ")")

-- static: Core's sink is the only writer into Blizzard chat; no hooks / filters on chat frames
local function src(f) local h = assert(io.open(addonDir .. "/" .. f:gsub("\\", "/"))) local s = h:read("*a") h:close() return s end
local offenders = {}
for _, f in ipairs(files) do
    local s = src(f):gsub("%-%-[^\n]*", ""):gsub('"[^"\n]*"', '""')   -- code only (names in data lists are not calls)
    for _, pat in ipairs({ "DEFAULT_CHAT_FRAME", "SELECTED_CHAT_FRAME", "ChatFrame%d", "AddMessageEventFilter", "hooksecurefunc",
        "ChatFrameUtil", "ChatTypeInfo", "[^%w_%.:]print%s*%(", "pcall%(%s*print%s*," }) do
        for _ in s:gmatch(pat) do offenders[#offenders + 1] = f .. ":" .. pat end
    end
end
local allowed = { ["Core.lua:DEFAULT_CHAT_FRAME"] = 1, ["Core.lua:[^%w_%.:]print%s*%("] = 1, ["Controls.lua:pcall%(%s*print%s*,"] = 1 }
local bad = {}
for _, o in ipairs(offenders) do if not allowed[o] then bad[#bad + 1] = o end end
check(#bad == 0, "static: only Core.lua's ns.Print sink writes Blizzard chat (" .. table.concat(bad, ", ") .. ")")
local cs = src("Controls.lua")
local i1, i2 = cs:find("ns.ChatSafe", 1, true), cs:find("pcall(print", 1, true)
check(i1 and i2 and i1 < i2, "static: the opt-in chat print sink checks ChatSafe first")
local core = src("Core.lua")
local pr = core:match("function ns%.Print%(%.%.%.%)(.-)\nend")
check(pr and pr:find("chatSafe()", 1, true) and pr:find("chatSafe()", 1, true) < pr:find("toChat(msg)", 1, true),
    "static: ns.Print tests chatSafe() before the chat sink")
print(string.format("bg_chat_taint: %d passed, %d failed", passed, fails))
if fails > 0 then os.exit(1) end
