# ForeverDump v2.2.1 bundle

- `SECRETS-GUIDE.html`: the Forever secret-values guide (single file; open in a browser). Built from the run-2 capture
  with `tools/fdump.py guide`.
- `ForeverDump/`: the addon. Copy it to `World of Warcraft\_classic_beta_\Interface\AddOns\`. See `ADDON-USAGE.md`.
- `ADDON-USAGE.md`: install, slash commands and run order, the FD_Logs macro, where SavedVariables land, privacy.
- `INSTRUCTIONS-console.md`: console, CVar and log instructions. `SELF-HOSTING.md`: self-hosting and community sources.
- `tools/`: converter (`tools/README.md`), guide generator (`tools/guide/`), packaging (`tools/package.py`) and `tools/refresh/` (refresh scripts).
- `tests/`: mock client, addon smoke test, converter tests, sample addon, deliberate legacy addon (`tests/legacy_addon`) and **synthetic** log fixtures.
- `fixtures/forever-70245/`: an **anonymized** real Forever capture (API surface, environment, documented secrets map, combat/taint log). See its README.
- `fixtures/baselines/70245/`: the first stored baseline signature (run 2), used by `fdump.py drift` / `all`.
- `CHANGES.md`: what changed from v1, v2.0, v2.1 and v2.2.

**Not included (too large):** `data/` (≈215 MB extracted client data) and every `.cache/` folder (≈900 MB, e.g.
`tools/refresh/.cache`), plus `ref/` (reference API docs used by the smoke test) and `tests/out/` (generated). Re-create
them with `tools/refresh/refresh_all.sh` (see SELF-HOSTING.md).

Status: v2.1 ran in-game on Forever 70245 (two runs, 2026-10-07). The v2.2 additions (bug-B fix, probes, inference/HSM, HSM
window, baseline) pass the mock client built from the real Forever API documentation but **have not run in-game yet**.
