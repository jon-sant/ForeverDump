# ForeverDump HSM status (v2.2.16, final state-engine build) - for sign-off

Scope: every value and rule the Hybrid State Machine (`ForeverDump/Lib/HybridState.lua`, driven by `Inference.lua`)
produces, its status, the evidence, and what cannot be solved by design. Evidence = replay of BG runs 9-13 against the
combat log (truth used offline only; nothing at runtime depends on the combat log), live verdict rings, and the
post-combat un-secret sweep. Status words:

- **live** - acts in release builds; passed every gate on every run with scorable events.
- **provisional** - live, but with a known weakness (named) that the next BG must settle.
- **shadow** - runs only at capture level `lab`, own rule ID, prediction verdict per decision, never acts.
- **unsolved** - no Forever-observable signal found yet.
- **unsolvable by design** - the value is secret in BGs and no clear side signal exists (no side-channel extraction).

## 1. Attribution safety (the v2.2.16 gate)

Every claim "this change was mine" passes `HybridState:gate(rule, what, unit, now, ownCast, corroborator)`:

1. **target match** - my cast's effective target equals the unit that changed. Effective target = "me" for self
   buffs, summons/totems and spells with a learned self link (>= 4 casts, >= 60 % same-frame aura on me); otherwise the
   unit targeted at cast time. Melee (swing rules) additionally needs the hit to be on my current target; a group
   member's (raidN/partyN) WOUND is never my damage.
2. **spell plausibility** - the learned spell link fits: a heal or damage spell with no aura never claims an aura, a
   heal never claims damage, a self buff never claims an aura on another unit, an interrupt needs an interrupt spell.
3. **ambiguity guard** - if same-class actors are around (live census: clear `UnitClass` of raid/party members and of
   enemy players on plates/arena in the last 60 s) or several events hit the unit in one frame, the claim is U unless
   corroborated: same-frame timing for a learned self link, the amount inside my learned band, the interrupt lockout
   signature. An unlearned spell with a target match and no competitor stays allowed (identical replay results on runs
   9-13 either way; keeps solo/PvE claims).

Every inference carries its evidence string (`ev`): `tm,pl` (matched, plausible), `pl:no`, `tm:no`,
`amb:same-class,cor:band`, `amb:crowd`, `token:swing` ... Per-rule gate counters: `inference.attr.stats` (SV) and per
fight in the lab sweep (`labProbes.sweeps[n].attr`, with the census).

### False-self gate in replay scoring

A rule may not raise false-self claims (claimed mine, log says someone else) on ANY run and may not lose accuracy beyond
noise (max(2 pt, 100/n)) on any run; promotion needs at least one run strictly better (`tools/fdump/candscore.py`
`gate_run` / `verdict`, `rule_metrics`; `ANALYSIS.md` lists `mine:<rule>` precision and false-self).

### Per category (accuracy % / false-self claims / coverage %), v2.2.15 live -> v2.2.16 gated

| category | run | before | after | gate |
|---|---|---|---|---|
| aura-on-me | 9 | 97.2 / fs 1 / cov 100 | 97.2 / fs 0 / cov 99 | better |
| aura-on-me | 10 | 87.4 / fs 6 / cov 100 | 88.1 / fs 1 / cov 98 | better |
| aura-on-me | 11 | 88.8 / fs 10 / cov 100 | 92.5 / fs 0 / cov 98 | better |
| aura-on-me | 12 | 91.0 / fs 3 / cov 100 | 89.6 / fs 2 / cov 97 | better |
| aura-on-me | 13 | 87.4 / fs 2 / cov 100 | 86.5 / fs 1 / cov 98 | better |
| aura-on-target | 9 | 96.7 / fs 1 / cov 100 | 100.0 / fs 0 / cov 100 | better |
| aura-on-target | 10 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| aura-on-target | 11 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| aura-on-target | 12 | 50.0 / fs 1 / cov 100 | 100.0 / fs 0 / cov 100 | better |
| aura-on-target | 13 | 80.0 / fs 4 / cov 100 | 100.0 / fs 0 / cov 100 | better |
| damage-on-target | 9 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| damage-on-target | 10 | 83.3 / fs 1 / cov 100 | 100.0 / fs 0 / cov 100 | better |
| damage-on-target | 11 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| damage-on-target | 12 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| damage-on-target | 13 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| heal-on-me | 9 | 87.6 / fs 7 / cov 100 | 87.6 / fs 7 / cov 100 | ok |
| heal-on-me | 10 | 69.5 / fs 10 / cov 100 | 69.5 / fs 10 / cov 100 | ok |
| heal-on-me | 11 | 90.6 / fs 5 / cov 100 | 90.6 / fs 5 / cov 100 | ok |
| heal-on-me | 12 | 94.4 / fs 1 / cov 100 | 94.4 / fs 1 / cov 100 | ok |
| heal-on-me | 13 | 95.3 / fs 0 / cov 100 | 95.3 / fs 0 / cov 100 | ok |
| heal-on-target | 9 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| heal-on-target | 10 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| heal-on-target | 11 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| heal-on-target | 13 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| interrupt | 9 | 77.8 / fs 1 / cov 100 | 77.8 / fs 0 / cov 89 | better |
| interrupt | 10 | 33.3 / fs 2 / cov 100 | 66.7 / fs 0 / cov 67 | better |
| interrupt | 12 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| interrupt | 13 | 75.0 / fs 1 / cov 100 | 75.0 / fs 0 / cov 75 | better |
| miss-on-target | 9 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| miss-on-target | 10 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| miss-on-target | 11 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| miss-on-target | 12 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |
| miss-on-target | 13 | 100.0 / fs 0 / cov 100 | 100.0 / fs 0 / cov 100 | ok |

False-self claims, all categories, runs 9-13: **56 -> 27**

Out-of-sample check (run 13 with the self-link seed learned from runs 9-12 only): aura-on-me 86.5 / fs 1 / cov 98; aura-on-target 100.0 / fs 0 / cov 100; damage-on-target 100.0 / fs 0 / cov 100; heal-on-me 95.3 / fs 0 / cov 100; heal-on-target 100.0 / fs 0 / cov 100; interrupt 75.0 / fs 0 / cov 75; miss-on-target 100.0 / fs 0 / cov 100

### Per rule: mine claims / false-self / precision (runs 9-13 summed)

| rule | before mine | before fs | before prec | after mine | after fs | after prec | after U |
|---|---|---|---|---|---|---|---|
| own-cast-frame | 220 | 28 | 87.3 | 186 | 4 | 97.8 | 0 |
| heal-cadence | 104 | 13 | 87.5 | 104 | 13 | 87.5 | 0 |
| heal-tgt-frame | 31 | 0 | 100.0 | 31 | 0 | 100.0 | 0 |
| secret-timing | 27 | 0 | 100.0 | 27 | 0 | 100.0 | 0 |
| summon-cadence | 24 | 10 | 58.3 | 24 | 10 | 58.3 | 0 |
| cast-frame | 14 | 1 | 92.9 | 13 | 0 | 100.0 | 0 |
| aura-ambiguous | 0 | 0 | — | 0 | 0 | — | 12 |
| interrupt-cast+dm | 6 | 3 | 50.0 | 3 | 0 | 100.0 | 0 |
| interrupt-ambiguous | 0 | 0 | — | 0 | 0 | — | 3 |
| interrupt-cast-frame | 1 | 1 | 0.0 | 0 | 0 | — | 0 |

Gate failures: none

### Shadow candidates through the false-self gate (runs 9-13)

| candidate | category | status | runs | better | worse | why |
|---|---|---|---|---|---|---|
| c-aura-me-elim | aura-on-me | off | 5 | 0 | 5 | run9: falseSelf 0 -> 1; run10: falseSelf 1 -> 6; run11: falseSelf 0 -> 10; run12: falseSelf 2 -> 3; run13: falseSelf 1 - |
| c-aura-me-self | aura-on-me | off | 5 | 0 | 5 | run9: accuracy 97.2 -> 73.6 (noise 2.0); run10: accuracy 88.1 -> 74.8 (noise 2.0); run11: falseSelf 0 -> 2; run12: false |
| c-aura-me-tight | aura-on-me | off | 5 | 0 | 2 | run10: falseSelf 1 -> 4; run11: falseSelf 0 -> 6 |
| c-cad-amount | heal-on-me | off | 5 | 1 | 3 | run10: accuracy 69.5 -> 25.4 (noise 2.0); run11: accuracy 90.6 -> 84.9 (noise 2.0); run13: accuracy 95.3 -> 79.1 (noise  |
| c-cad-guard | heal-on-me | off | 5 | 1 | 3 | run10: accuracy 69.5 -> 36.4 (noise 2.0); run11: accuracy 90.6 -> 84.9 (noise 2.0); run13: accuracy 95.3 -> 88.4 (noise  |
| c-cad-phase | heal-on-me | off | 5 | 2 | 2 | run11: falseSelf 5 -> 7; run12: falseSelf 1 -> 2 |
| c-cad-phase-amount | heal-on-me | off | 5 | 1 | 4 | run10: accuracy 69.5 -> 29.7 (noise 2.0); run11: accuracy 90.6 -> 81.1 (noise 2.0); run12: falseSelf 1 -> 2; run13: accu |
| c-cad-tight | heal-on-me | off | 5 | 2 | 3 | run9: falseSelf 7 -> 8; run11: falseSelf 5 -> 6; run12: falseSelf 1 -> 2 |
| c-heal-me-wide | heal-on-me | off | 5 | 0 | 2 | run10: falseSelf 10 -> 11; run11: falseSelf 5 -> 6 |
| c-heal-tgt-frame | heal-on-target | provisional | 4 | 0 | 0 |  |
| c-heal-tgt-totem | heal-on-target | off | 4 | 0 | 3 | run9: falseSelf 0 -> 2; run10: falseSelf 0 -> 1; run13: falseSelf 0 -> 3 |
| c-heal-tgt-wide | heal-on-target | off | 4 | 0 | 1 | run13: falseSelf 0 -> 1 |
| c-int-wide | interrupt | off | 4 | 0 | 3 | run9: falseSelf 0 -> 2; run10: falseSelf 0 -> 2; run13: falseSelf 0 -> 1 |


Notes:
- Accuracy counts U as not-correct; coverage = share of events decided. The remaining aura-on-me losses (runs 12/13,
  inside noise) are U claims, not errors.
- Run 13 aura-on-me's one remaining false-self claim (14:51:56 ET) is my own Strength of Earth totem cast in the same
  frame; the log has no aura apply from it (totem auras are not in the combat log), so the truth matcher picked another
  player's aura. Likely a truth artifact; kept counted.
- Self-link seed: in-sample (runs 9-13) and out-of-sample (run 13 scored with links learned from runs 9-12 only) give
  identical run-13 numbers.

### Regression fixtures

`tests/attr_v2216.lua` (23 checks): the run-13 14:58:38 ET case (Lesser Healing Wave at a friendly target + someone's
aura 63 ms later; the legacy path reproduces the false claim), the 1238640 self buff guessed at the friendly target,
duplicate Flame Shocks on two enemies, a heal on me during an offensive cast, raid/nameplate WOUNDs in my cast frame
(the run-13 dm-damage contradictions), melee on a non-target, c-hp-net, and the dead cast failure.

## 2. Value / rule inventory

| value / rule | status | evidence (runs 9-13 replay unless noted) | notes |
|---|---|---|---|
| own cast pairing (START/STOP/SUCCEEDED, my spellID) | live | spellID clear for the player on 1.60.1 (all runs) | basis of every "mine" rule |
| `own-cast-frame` (aura on me / my target in my cast's frame) | live | 220 -> 186 mine claims, false-self 28 -> 4, precision 87.3 -> 97.8 % | gated (target, plausibility, ambiguity + timing/self-link) |
| `aura-me-elim` (no matching own cast -> someone else's) | live | aura-on-me 97.2 / 88.1 / 92.5 / 89.6 / 86.5 % (runs 9-13) | now also takes target mismatches (12 of 13 right) |
| `aura-ambiguous` (U) | live | 12 U over runs 9-13 | same-class actors, no corroborator |
| `secret-timing` (predicted aura arrives on the predicted unit) | live | 27 mine, 0 false | v2.2.16: target-matched (unit-less = me only), guarded |
| `single-applier` / `iid-map` / `observed` aura identity | live | clear payload out of combat; iid ledger in combat | identity only; no attribution claim beyond the cast |
| aura-on-target attribution | live | 96.7/100/100/50/80 -> 100 % on every run, false-self 6 -> 0 | self-link effective target fixed run 12/13 |
| `cast-frame` damage on target | live | 14 -> 13 mine, false-self 1 -> 0; damage-on-target 100 % all runs | gated; amount band corroborates under ambiguity |
| `dm-frame` damage / heal (DAMAGE_METER frame) | live (solo only) | run 9 finding: the meter fires for every group member | groupSize <= 1 |
| `swing-frame` / `swing-lag` melee | live | damage-on-target 100 %; v2.2.16 needs the hit on my target | `swing-ambiguous` U under crowd |
| miss-on-target | live | 100 % all runs | |
| damage taken (me) | live | 100 % (run 13: 112 events) | |
| `heal-tgt-frame` (heal on another unit) | live | 31 mine, 0 false, 100 % all runs | gated, amount band under ambiguity |
| heal on me: `cast-frame` | live | gated (target me, band) | |
| heal on me: `heal-cadence` | provisional | 104 mine, 13 false (87.5 %); the ambiguity guard failed the gate (run 10 69.5 -> 36.4 %) | guarded variant = shadow `c-cad-guard` |
| heal on me: `summon-cadence` | provisional | 24 mine, 10 false (58.3 %); phase lock does not separate another shaman's HST | weakest live rule; demoting it loses accuracy beyond noise on run 10 |
| interrupt attribution (`interrupt-cast+dm`, lockout) | live | false-self 5 -> 0; interrupt 77.8 / 66.7 / - / 100 / 75 % (n 9/3/0/1/4) | small n; `interrupt-ambiguous` U |
| dispel (`dispel-cast+dm`) | live | meter Dispels row | |
| cooldowns (CooldownTracker: learned cd, GCD, fail-inside-cd) | live | verify:cooldown 97.8 % (run 13, n 316); cooldown-fail scoring now excludes precondition failures | v2.2.16: dead -> `fail-dead` U |
| cast time model (enemy NPC casts) | live | cast-end verdicts vs log NPC cast success | |
| damage range (my spells) | live | verify:damage-range 100 % (run 13, n 49) | |
| player health estimate + overheal | live | overheal-estimate 97.7 % (run 13, n 43) | |
| per-unit net HP (`c-hp-net`) | shadow (new) | live V/C vs clear UnitHealth; offline vs combat-log health next run | readable UNIT_COMBAT amounts + cached max health |
| meter reconcile (`dm-reconcile`, dm-unit-me/other) | live | run 13 had 3 dm-damage C's: root-caused (raid/plate WOUNDs credited to me), fixed | analyzer now joins by meter session |
| self links (cast -> aura on me) | live | seed from runs 9-13; per-account accumulation | spell IDs and counts only |
| census (same-class actors) | live (probe + guard input) | counts only; per fight in the sweep | first live run will validate vs log census |
| enemy heals | live (tracked per unit in `fight.world[*].heal`) | UNIT_COMBAT HEAL on hostile tokens when readable | no attribution claim |
| shadow candidates | shadow | `c-heal-tgt-frame` provisional (no run worse); all other candidates fail the false-self gate (table above) | |

## 3. Unsolvable by design (BG secrets, no side channel)

- Aura **identity and source** on other units in restricted (BG) state: `GetAuraDataByIndex` errors when secret while
  tainted, the addedAuras payload is wholly secret; only presence/timing is observable.
- Other players' spellIDs of cast events in BGs (secret); only timing and (for plates) the cast bar existence.
- Exact health of non-group units while restricted (secret `UnitHealth`); `c-hp-net` estimates it from readable amounts.
- Which of two same-class players applied an identical aura on me in the same frame with no corroborating signal: the
  gate returns U by design (the census tells how often this happens).
- Meter breakdown per enemy unit (session-level only).

## 4. What the next BG must settle

1. Live census vs log census (stand-in used for runs 9-13).
2. `c-cad-guard` live verdicts and whether any corroborator (meter delta per tick) rescues the cadence chain.
3. `fight.dmg.tok`: claimed damage by token family per fight - must be target-only after the fix (no raid/plate).
4. `peakMarks`: the step that sets the all-time 182.7 ms PeakTime.
5. `c-hp-net` V/C rate.
