#!/usr/bin/env bash
# Full test run: addon smoke test in the mock client (writes tests/out/ForeverDump.lua), then converter e2e.
set -eo pipefail   # a failing test fails the run even when piped through tail (perf gate included)
cd "$(dirname "$0")/.."
mkdir -p tests/out
export FORE_DOCS="${FORE_DOCS:-$PWD/ref/wusf/Interface/AddOns}"
luac5.1 -p ForeverDump/*.lua ForeverDump/Lib/*.lua
luacheck ForeverDump tests --no-color -q --exclude-files "tests/legacy_addon/*"
lua5.1 tests/smoke.lua ForeverDump tests/out/ForeverDump.lua | tail -1
lua5.1 tests/hsm.lua ForeverDump | tail -1
lua5.1 tests/knowledge_parse.lua ForeverDump | tail -1
lua5.1 tests/timing.lua ForeverDump | tail -1
lua5.1 tests/learned.lua ForeverDump | tail -1
python3 tests/test_converter.py
lua5.1 tests/buggrabber.lua ForeverDump | tail -1
python3 tests/test_xref.py
python3 tests/test_migrate.py
lua5.1 tests/regress.lua ForeverDump | tail -1
python3 tests/test_v22.py
python3 tests/test_identity.py
python3 tests/test_v222.py
busted tests/spec/containers_spec.lua | tail -1
python3 tests/test_v223.py
python3 tests/test_v224.py
python3 tests/test_v224_tools.py
python3 tests/test_v225_ho.py
python3 tests/test_v225_findings.py
python3 tests/test_v226_replay.py
python3 tests/test_v226_replay_exec.py
python3 tests/test_golden_run5.py
# PERFORMANCE.md gate: static perf lint (errors and warnings fail) + runtime N-cast benchmark (25/50/100 casts + aged session):
# per-event cost flat, <1% frame impact, no idle OnUpdate. Hard 2-minute wall cap (bench --cap 100 aborts itself; timeout 120 backstop).
# v2.2.4 perf gate inside --assert: aged/fresh impact ratio <= 1.5, SPELL_UPDATE_COOLDOWN storm <= 0.5 %, 40-man scanner
# slice max <= budget (the bench re-executes itself with glibc fastbins off; see its header).
python3 tools/fdump.py perfcheck ForeverDump --strict | tail -1
timeout 120 lua5.1 tests/perf_bench.lua ForeverDump --assert --json tests/out/perf_bench.json | tail -1
