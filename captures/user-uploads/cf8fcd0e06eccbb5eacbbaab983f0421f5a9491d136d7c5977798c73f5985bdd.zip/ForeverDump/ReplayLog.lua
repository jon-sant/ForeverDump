-- ForeverDump v2.2.6 - capture verbosity, session header, sealed replay tape, cast sync anchors.
-- ONE build: default level = release (<1%). FD_Logs ON elevates to test (or diag if configured) (<=10%);
-- FD_Logs OFF restores the prior level. /fdump level <release|test|diag> is a manual override.
-- Privacy: no names / raw GUIDs in SavedVariables — identity keys use per-session salted FNV hashes or class keys.
local _, ns = ...
local R = {}
ns.ReplayLog = R

local GetTime = GetTime
local function g(n) return rawget(_G, n) end
local function now() return (GetTime and GetTime()) or 0 end

-- levels ------------------------------------------------------------------
local LEVELS = { release = 1, test = 2, diag = 3 }
R.LEVELS = LEVELS
local function cfg()
    ns.config = ns.config or {}
    ns.config.replay = ns.config.replay or {}
    local c = ns.config.replay
    if c.level == nil then c.level = "release" end
    if c.captureLevel == nil then c.captureLevel = "test" end  -- FD_Logs elevates to this
    if c.anchorEveryN == nil then c.anchorEveryN = 8 end       -- release: every Nth own SUCCEEDED
    if c.byteBudgetKB == nil then c.byteBudgetKB = { release = 512, test = 8192, diag = 16384 } end
    if c.tapeCap == nil then c.tapeCap = { release = 800, test = 8000, diag = 16000 } end
    if c.verifyCap == nil then c.verifyCap = { release = 600, test = 4000, diag = 8000 } end
    return c
end

local state = {
    level = "release",
    priorLevel = nil,       -- restored after FD_Logs OFF
    captureElevated = false,
    session = nil,          -- active capture session table (in ForeverDumpLogDB.replay)
    salt = 0,
    seq = 0,
    castN = 0,
    bytes = 0,
    dropped = {},           -- priority -> count
    ruleIds = {},           -- rule string -> small int
    nextRule = 1,
}

local function levelNum(name) return LEVELS[name] or 1 end
function R.Level() return state.level end
function R.LevelNum() return levelNum(state.level) end
function R.IsTest() return levelNum(state.level) >= 2 end
function R.IsDiag() return levelNum(state.level) >= 3 end

function R.SyncFromConfig()
    local c = cfg()
    if not state.captureElevated and c.level and LEVELS[c.level] then
        state.level = c.level
    end
    return state.level
end

function R.SetLevel(name, _)
    name = tostring(name or ""):lower()
    if not LEVELS[name] then return false, "unknown level" end
    local prev = state.level
    state.level = name
    cfg().level = name
    if ns.HSMUI and ns.HSMUI.MarkDirty then ns.HSMUI.MarkDirty() end
    return true, prev
end

-- Fast 32-bit mix (Lua 5.1, no bitlib). Privacy: salt + raw → non-reversible without salt.
-- Not cryptographic; only for opaque identity keys in the SV tape.
local function hash32(str)
    str = tostring(str or "")
    local h = 2166136261
    for i = 1, #str do
        -- h = h XOR byte; then multiply-add mix (avoid 32 XOR bit loops)
        h = h + string.byte(str, i)
        h = (h * 16777619 + (h % 65521) * 31) % 4294967296
    end
    return h
end

-- identity key: never store raw GUID/name; salted FNV or stable class key
function R.IdKey(kind, raw)
    if raw == nil or raw == "" then return nil end
    if raw == "player" then return "player" end
    kind = tostring(kind or "guid")
    -- NPC: keep npc:<id> from Creature-*-<id>-* without salt (public game data)
    if kind == "npc" and type(raw) == "string" then
        local nid = raw:match("Creature%-%d+%-%d+%-(%d+)%-") or raw:match("^npc:(%d+)$")
        if nid then return "npc:" .. nid end
    end
    local s = state.salt or 0
    return kind .. ":" .. string.format("%08x", hash32(tostring(s) .. "|" .. tostring(raw)))
end

-- seed hashes (spell ids + numbers only files) ----------------------------
local function seedHash(tbl, tag)
    if type(tbl) ~= "table" then return tag .. ":0" end
    local parts = { tag }
    local n = 0
    local function walk(t, depth)
        if depth > 3 or n > 400 then return end
        for k, v in pairs(t) do
            if type(k) == "number" or (type(k) == "string" and k:sub(1, 1) ~= "_") then
                parts[#parts + 1] = tostring(k)
                if type(v) == "number" then parts[#parts + 1] = tostring(v) n = n + 1
                elseif type(v) == "table" then walk(v, depth + 1) end
                if n > 400 then return end
            end
        end
    end
    walk(tbl, 0)
    return tag .. ":" .. string.format("%08x", hash32(table.concat(parts, ",")))
end

local function groupInfo()
    local gt, size = "solo", 1
    local ig = g("IsInGroup")
    local ir = g("IsInRaid")
    local nm = g("GetNumGroupMembers")
    local okG, inG = pcall(function() return ig and ig() end)
    local okR, inR = pcall(function() return ir and ir() end)
    local okN, n = pcall(function() return nm and nm() or 0 end)
    if okR and inR then gt = "raid" elseif okG and inG then gt = "party" end
    if okN and type(n) == "number" and n > 0 then size = n end
    return gt, size
end

local function mapInfo()
    local out = {}
    local gi = g("GetInstanceInfo")
    if type(gi) == "function" then
        local packed = { pcall(gi) }
        local ok = packed[1]
        local typ, instanceId = packed[3], packed[9]
        if ok then
            -- name may be secret / personal — store type + id only
            out.instanceType = type(typ) == "string" and typ or nil
            out.instanceId = type(instanceId) == "number" and instanceId or nil
        end
    end
    local zm = g("C_Map") and g("C_Map").GetBestMapForUnit
    if type(zm) == "function" then
        local ok, mapId = pcall(zm, "player")
        if ok and type(mapId) == "number" then out.uiMapId = mapId end
    end
    return out
end

local function combatLogOn()
    local C = g("C_ChatInfo")
    if type(C) == "table" and type(C.IsLoggingCombat) == "function" then
        local ok, v = pcall(C.IsLoggingCombat)
        if ok and type(v) == "boolean" then return v end
    end
    return nil
end

-- DB ----------------------------------------------------------------------
local function db()
    local log = g("ForeverDumpLogDB")
    if type(log) ~= "table" then return nil end
    log.replay = type(log.replay) == "table" and log.replay or { v = 1, sessions = {} }
    return log.replay
end

local PRI = { hdr = 0, overflow = 0, decide = 1, verdict = 1, anchor = 2, sig = 3, map = 4, sec = 5, api = 6 }

local function budgetKB()
    local b = cfg().byteBudgetKB
    return (b and b[state.level]) or 512
end

local function tapeCap()
    local t = cfg().tapeCap
    return (t and t[state.level]) or 800
end

function R.VerifyCap()
    local t = cfg().verifyCap
    return (t and t[state.level]) or 600
end

local function estimateBytes(rec)
    -- rough: 8 bytes/number field, 2 per short string key — avoid formatting
    local n = 24
    for _ in pairs(rec) do n = n + 12 end
    return n
end

local function append(kind, rec)
    local s = state.session
    if not s then return nil end
    local cap = tapeCap()
    local ring = s.tape
    if not ring then return nil end
    -- byte budget: drop lower-priority kinds first
    local est = estimateBytes(rec)
    local lim = budgetKB() * 1024
    if state.bytes + est > lim then
        local p = PRI[kind] or 9
        if p >= 3 then
            s.dropped = s.dropped or {}
            s.dropped[kind] = (s.dropped[kind] or 0) + 1
            s.overflow = (s.overflow or 0) + 1
            return nil
        end
    end
    state.seq = state.seq + 1
    rec.k = kind
    rec.i = state.seq
    rec.d = math.floor((now() - (s.t0 or now())) * 1000 + 0.5)  -- ms since session start
    local head = (s.head or 0) % cap + 1
    if ring[head] then
        s.overwritten = (s.overwritten or 0) + 1
    end
    s.head = head
    ring[head] = rec
    if (s.n or 0) < cap then s.n = (s.n or 0) + 1 end
    state.bytes = state.bytes + est
    s.bytes = state.bytes
    return rec.i
end

function R.RuleId(rule)
    if type(rule) ~= "string" then return 0 end
    local id = state.ruleIds[rule]
    if id then return id end
    id = state.nextRule
    state.nextRule = id + 1
    state.ruleIds[rule] = id
    local s = state.session
    if s then
        s.rules = s.rules or {}
        s.rules[id] = rule
    end
    return id
end

-- session lifecycle -------------------------------------------------------
function R.ElevateForCapture()
    R.SyncFromConfig()
    local c = cfg()
    if not state.captureElevated then
        state.priorLevel = state.level
        local elev = c.captureLevel or "test"
        if levelNum(elev) < 2 then elev = "test" end
        state.level = elev
        state.captureElevated = true
        cfg().level = elev
    end
    return state.level
end

function R.BeginCapture()
    R.SyncFromConfig()
    local c = cfg()
    -- elevate from release to captureLevel (test by default)
    if not state.captureElevated then
        state.priorLevel = state.level
        local elev = c.captureLevel or "test"
        if levelNum(elev) < 2 then elev = "test" end
        state.level = elev
        state.captureElevated = true
    end
    local store = db()
    if not store then return nil end
    state.salt = (math.floor(now() * 1000) % 2147483647) + (ns.db and ns.db.sessionCounter or 1) * 9973
    state.seq, state.castN, state.bytes = 0, 0, 0
    state.ruleIds, state.nextRule = {}, 1
    local gt, gsz = groupInfo()
    local map = mapInfo()
    local hdr = {
        v = 1,
        addonVersion = ns.VERSION,
        schemaVersion = ns.SCHEMA,
        verbosity = state.level,
        captureElevated = true,
        priorLevel = state.priorLevel,
        saltNote = "per-session; hashes are not reversible without salt (salt not stored)",
        seeds = {
            spellTiming = seedHash(ns.SpellTimingSeed, "st"),
            learned = seedHash(ns.LearnedSeed, "ln"),
            knowledgePatch = seedHash(ns.KnowledgePatch, "kp"),
        },
        groupType = gt,
        groupSize = gsz,
        mapStart = map,
        combatLogStart = combatLogOn(),
        ringCaps = {
            record = (ns.config.record and ns.config.record.maxEvents) or 4000,
            combat = (ns.config.cl and ns.config.cl.maxEvents) or 10000,
            signals = (ns.config.hsm and ns.config.hsm.maxSignals) or 3000,
            tape = tapeCap(),
            verify = R.VerifyCap(),
        },
        byteBudgetKB = budgetKB(),
        t0 = now(),
        sid = ns.SessionId and ns.SessionId() or nil,
        anchor = ns.TimeAnchor and ns.TimeAnchor() or nil,
        build = ns.Build and ns.Build() or nil,
    }
    local sess = {
        hdr = hdr,
        tape = {},
        head = 0,
        n = 0,
        overwritten = 0,
        overflow = 0,
        dropped = {},
        anchors = {},
        t0 = hdr.t0,
        rules = {},
    }
    state.session = sess
    store.current = sess
    append("hdr", { verbosity = state.level, groupType = gt, groupSize = gsz })
    if ns.Inference and ns.Inference.hs then ns.Inference.hs.shadowFindings = R.IsTest() or nil end
    if ns.HSMUI and ns.HSMUI.MarkDirty then ns.HSMUI.MarkDirty() end
    return sess
end

function R.EndCapture()
    local s = state.session
    if s and s.hdr then
        s.hdr.mapEnd = mapInfo()
        s.hdr.combatLogEnd = combatLogOn()
        s.hdr.verbosityEnd = state.level
        s.hdr.groupTypeEnd, s.hdr.groupSizeEnd = groupInfo()
        s.bytes = state.bytes
        s.seqEnd = state.seq
        local store = db()
        if store then
            store.sessions = store.sessions or {}
            store.sessions[#store.sessions + 1] = s
            while #store.sessions > 4 do table.remove(store.sessions, 1) end
            store.current = nil
        end
    end
    state.session = nil
    -- restore release (or prior manual level if it was release); after capture always drop to release
    -- unless user had manually set test/diag before capture — restore priorLevel
    local restore = state.priorLevel or "release"
    state.captureElevated = false
    state.priorLevel = nil
    state.level = restore
    cfg().level = restore
    if ns.HSMUI and ns.HSMUI.MarkDirty then ns.HSMUI.MarkDirty() end
    return s
end

-- ring overflow helper (shared) -------------------------------------------
function R.NoteOverflow(ringName, n)
    local s = state.session
    if not s then return end
    s.ringOverflow = s.ringOverflow or {}
    s.ringOverflow[ringName] = (s.ringOverflow[ringName] or 0) + (n or 1)
end

-- cast sync anchors -------------------------------------------------------
function R.OnOwnSucceeded(spellId, unit)
    if type(spellId) ~= "number" then return end
    if unit and unit ~= "player" then return end
    state.castN = state.castN + 1
    local every = cfg().anchorEveryN or 8
    local take = R.IsTest() or (state.castN % every == 1)
    if not take then return end
    local rec = { spell = spellId, n = state.castN }
    local id = append("anchor", rec)
    local s = state.session
    if s and id then
        s.anchors[#s.anchors + 1] = { i = id, spell = spellId, d = rec.d, t = now() }
    end
end

-- decide / verdict tape ---------------------------------------------------
-- input bitmap bits: 1 cast 2 aura 3 combat 4 meter 5 ledgerToken 6 ledgerAura 7 cd 8 knowledge
function R.OnInfer(rec)
    if not state.session then return end
    local bits = 0
    local rule = rec.rule or "?"
    if rule:find("cast", 1, true) or rule == "own-cast-frame" then bits = bits + 1 end
    if rule:find("aura", 1, true) or rule == "observed" or rule:find("applier", 1, true) then bits = bits + 2 end
    if rule:find("combat", 1, true) or rule == "elimination" then bits = bits + 4 end
    if rule:find("meter", 1, true) or rule:find("dm", 1, true) then bits = bits + 8 end
    if rule:find("ledger", 1, true) then bits = bits + 16 end
    if rule == "ledger" or rule == "ledger-elimination" then bits = bits + 32 end
    if rule:find("cd", 1, true) or rule:find("cooldown", 1, true) or rule:find("gcd", 1, true) then bits = bits + 64 end
    if rec.known or rule:find("knowledge", 1, true) or rule:find("single-applier", 1, true) then bits = bits + 128 end
    local conf = rec.conf
    local confN = (conf == "observed" and 4) or (conf == "high" and 3) or (conf == "medium" and 2) or (conf == "low" and 1) or 0
    append("decide", {
        id = rec.id,
        r = R.RuleId(rule),
        c = confN,
        b = bits,
        u = type(rec.unit) == "string" and (rec.unit == "player" and "player" or R.IdKey("guid", rec.unit)) or nil,
        sp = type(rec.spell) == "number" and rec.spell or nil,
        kind = rec.kind,
    })
end

function R.OnVerdict(rec)
    if not state.session then return end
    append("verdict", {
        kind = rec.kind,
        v = rec.v,
        sp = type(rec.spell) == "number" and rec.spell or nil,
        src = type(rec.src) == "string" and rec.src:sub(1, 40) or nil,
        cf = rec.conf,
        -- link to last decide id when present
        id = rec.id,
    })
end

-- test-only extras --------------------------------------------------------
local CRITICAL = {
    UNIT_SPELLCAST_SUCCEEDED = true, UNIT_SPELLCAST_START = true, UNIT_SPELLCAST_SENT = true,
    UNIT_SPELLCAST_INTERRUPTED = true, UNIT_SPELLCAST_STOP = true,
    UNIT_COMBAT = true, SPELL_UPDATE_COOLDOWN = true,
    DAMAGE_METER_COMBAT_SESSION_UPDATED = true, UNIT_AURA = true,
}

function R.OnCriticalEvent(event, _args, states)
    if not R.IsTest() or not state.session then return end
    if not CRITICAL[event] then return end
    -- pack up to 8 arg states into one integer (4 bits each): 0=N 1=S 2=T 3=K 4=C 5=?
    local code = { N = 0, S = 1, T = 2, K = 3, C = 4 }
    local pack, n = 0, math.min(type(states) == "table" and #states or 0, 8)
    for i = 1, n do
        local c = code[states[i] or "?"] or 5
        pack = pack + c * (16 ^ (i - 1))
    end
    append("sec", { e = event, n = n, p = pack })
end

function R.OnApiSample(apiId, spellId, states, clearVals)
    if not R.IsTest() or not state.session then return end
    append("api", {
        a = apiId,
        sp = spellId,
        st = states,  -- small array of state letters or packed
        -- clearVals: numbers only
        v = clearVals,
    })
end

function R.OnMapDelta(tok, idKey, how)
    if not R.IsTest() or not state.session then return end
    -- tok family only (player/target/nameplateN), never raw GUID
    local fam = tok
    if type(tok) == "string" then
        fam = tok:gsub("%d+$", "N")
    end
    append("map", { tok = fam, id = idKey, how = how })
end

function R.StatusLine()
    local elev = state.captureElevated and " (capture)" or ""
    return "log:" .. state.level .. elev
end

function R.Command(rest)
    R.SyncFromConfig()
    rest = tostring(rest or ""):match("^%s*(.-)%s*$") or ""
    local sub, arg = rest:match("^(%S+)%s*(.*)$")
    sub = sub and sub:lower() or "status"
    if sub == "status" or sub == "" then
        ns.Print(string.format("replay verbosity: %s%s; tape seq=%d bytes≈%d budget=%dKB; captureElevated=%s",
            state.level, state.captureElevated and " (FD_Logs capture)" or "",
            state.seq, state.bytes, budgetKB(), tostring(state.captureElevated)))
        return
    end
    if sub == "release" or sub == "test" or sub == "diag" then
        if state.captureElevated then
            ns.Print("FD_Logs capture is active — level is pinned to capture mode (" .. state.level .. "). Stop capture first, or set captureLevel.")
            return
        end
        local ok, prev = R.SetLevel(sub, "cmd")
        if ok then ns.Print("verbosity " .. tostring(prev) .. " -> " .. sub .. " (manual override; FD_Logs will still elevate on next capture)") end
        return
    end
    if sub == "capturelevel" and arg ~= "" then
        local a = arg:lower()
        if LEVELS[a] and LEVELS[a] >= 2 then
            cfg().captureLevel = a
            ns.Print("FD_Logs capture will elevate to " .. a)
        else
            ns.Print("captureLevel must be test or diag")
        end
        return
    end
    ns.Print("usage: /fdump level [status|release|test|diag|capturelevel test|diag]")
end

-- wire capture module -----------------------------------------------------
ns.captureModules = ns.captureModules or {}
-- Start before HSM/Inference so IsTest() is true when NewHSM enables shadow findings
table.insert(ns.captureModules, math.min(2, #ns.captureModules + 1), {
    name = "replay log (session_hdr + tape)",
    start = function()
        R.BeginCapture()
        if ns.Inference and ns.Inference.hs then ns.Inference.hs.shadowFindings = true end
        return true
    end,
    stop = function()
        local s = R.EndCapture()
        if not s then return nil end
        if ns.Inference and ns.Inference.hs then ns.Inference.hs.shadowFindings = false end
        return string.format("replay tape %s: %d records, %d overwritten, %d overflow-drops, ~%d bytes",
            (s.hdr and s.hdr.verbosity) or "?", s.n or 0, s.overwritten or 0, s.overflow or 0, s.bytes or 0)
    end,
})

return R
