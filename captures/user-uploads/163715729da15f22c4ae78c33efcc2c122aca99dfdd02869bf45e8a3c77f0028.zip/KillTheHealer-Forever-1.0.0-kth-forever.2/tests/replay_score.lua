-- Replay a ForeverDump BG stream (tests/replay/<run>.lua) through K.T.H. Forever loaded in the Forever mock and
-- record, per scoreboard player, the first time K.T.H.'s own nameplate verdict (CheckUnitIsHealer) marks them.
-- usage: lua5.1 replay_score.lua <KTH.toc> <stream.lua> <out.json> [mode]   mode: port (default) | original-mn
-- Unit model follows the baseline BG diag (2026-10-10): enemy UnitClass/UnitGUID/UnitHealthMax SECRET, UnitName clear
-- first-name-only, UnitPowerType clear, UnitCanAttack clear; GetScoreInfo table clear with name/classToken/faction
-- clear and talentSpec/roleAssigned/guid/healingDone/damageDone SECRET (in-match).
package.path = "/workspace/foreverdump/tests/?.lua;/workspace/kth/tests/?.lua;" .. package.path
local W = dofile("/workspace/foreverdump/tests/wowenv.lua"); _G.__W = W
local TF = require("tocfiles")
dofile("/workspace/kth/tests/mockextra.lua")
local SECRET = W.SECRET
local tocPath, streamPath, outPath, mode = arg[1], arg[2], arg[3], arg[4] or "port"
local D = dofile(streamPath)
local errors = {}
seterrorhandler(function(m) errors[#errors + 1] = tostring(m) end)

if mode == "original-mn" then
    -- original K.T.H. on Forever data, Midnight path forced (what retail K.T.H. logic would do with Forever's values)
    GetBuildInfo = function() return "12.0.1", "70334", "", 120001, "", "", 120001 end
end

-- ---------------------------------------------------------------- unit model
local roster = D.roster
local U, POWER = {}, {}           -- token -> roster index (0 = player); roster index -> power token
local PT = { MANA = 0, RAGE = 1, FOCUS = 2, ENERGY = 3, HAPPINESS = 4 }
local function R(tok) local i = U[tok] if i and i > 0 then return roster[i], i end end
UnitExists = function(u) return u == "player" or U[u] ~= nil end
UnitIsPlayer = function(u) return u == "player" or R(u) ~= nil end
UnitName = function(u) if u == "player" then return "Owner", nil end local r = R(u) if r then return r.first, nil end end
UnitGUID = function(u) if u == "player" then return "Player-1-OWNER" end if R(u) then return SECRET end end
UnitCanAttack = function(a, b) local r = R(b) if r then return r.side == "E" end return false end
UnitIsFriend = function(a, b) local r = R(b) if r then return r.side == "F" end return true end
UnitIsEnemy = function(a, b) local r = R(b) return r and r.side == "E" or false end
UnitClass = function(u)
    local r = R(u)
    if not r then return "Shaman", "SHAMAN", 7 end
    if r.side == "E" then return SECRET, SECRET, SECRET end           -- measured: 750/750 secret
    return r.class, r.class, 1                                        -- friendly: not measured (no friendly plates seen)
end
UnitPowerType = function(u) local _, i = R(u) if not i then return 0, "MANA" end local p = POWER[i] or "MANA" return PT[p] or 0, p end
UnitIsUnit = function(a, b) return U[a] ~= nil and U[a] == U[b] end
UnitIsDead = function() return false end
UnitHealthMax = function(u) if u == "player" then return 4000 end return SECRET end
UnitFactionGroup = function() return "Horde", "Horde" end
IsInInstance = function() return true, "pvp" end
local plates = {}
C_NamePlate = C_NamePlate or {}
C_NamePlate.GetNamePlateForUnit = function(u)
    if not U[u] or not u:match("^nameplate") then return nil end
    plates[u] = plates[u] or CreateFrame("Frame", nil, UIParent)
    return plates[u]
end
C_NamePlate.GetNamePlates = function() local t = {} for _, p in pairs(plates) do t[#t + 1] = p end return t end
GetNumBattlefieldScores = function() return #roster end
C_PvP = C_PvP or {}
C_PvP.GetScoreInfo = function(i)
    local r = roster[i]
    if not r then return nil end
    return { name = r.full, classToken = r.class, className = r.class, faction = (r.side == "F") and 0 or 1,
             talentSpec = SECRET, roleAssigned = SECRET, guid = SECRET, healingDone = SECRET, damageDone = SECRET,
             killingBlows = SECRET, deaths = SECRET }
end
GetBattlefieldScore = function(i)
    local r = roster[i]
    if not r then return nil end
    return r.full, SECRET, SECRET, SECRET, SECRET, (r.side == "F") and 0 or 1, "Race", r.class, r.class,
        SECRET, SECRET, SECRET, SECRET, nil, SECRET, SECRET, SECRET
end
RequestBattlefieldScoreData = function() end

-- ---------------------------------------------------------------- load
local ns = {}
for _, f in ipairs(TF.files(tocPath)) do
    local chunk, err = loadfile(f)
    if not chunk then errors[#errors + 1] = "COMPILE " .. err
    else local ok, e = pcall(chunk, "KTH", ns) if not ok then errors[#errors + 1] = "LOAD " .. f .. ": " .. tostring(e) end end
end
local function fire(...) local ok, e = pcall(W.fire, ...) if not ok then errors[#errors + 1] = "FIRE " .. tostring(e) end end
fire("ADDON_LOADED", "KTH")
IsLoggedIn = function() return true end
fire("PLAYER_LOGIN")
local A = LibStub("AceAddon-3.0"):GetAddon("K.T.H.")
local check = A.MN_CheckUnitIsHealer

-- ---------------------------------------------------------------- replay
local ev = D.ev
local t0 = ev[1][1]
W.state.time = 1000
fire("PLAYER_ENTERING_WORLD", false, false)
fire("UPDATE_BATTLEFIELD_SCORE")
local marks, seen, wrongMarks = {}, {}, {}
local nextSweep = 0
local function sweep(t)
    for tok, i in pairs(U) do
        if i and i > 0 and tok:match("^nameplate%d+$") then
            if not seen[i] then seen[i] = t end
            local ok, isHealer, isFriend, method = pcall(check, tok)
            if ok and isHealer and not marks[i] then marks[i] = { t = t, method = method } end
            if not ok then errors[#errors + 1] = "CHECK " .. tostring(isHealer) end
        end
    end
end
local counts = { C = 0, U = 0, A = 0 }
for _, e in ipairs(ev) do
    local t, k, tok, gi, a = e[1], e[2], e[3], e[4], e[5]
    W.state.time = 1000 + (t - t0)
    if t - t0 >= nextSweep then
        if A.ForeverEvidence then A.ForeverEvidence.flush() end
        sweep(t); nextSweep = (t - t0) + 1
    end
    if k == "S" then fire("UPDATE_BATTLEFIELD_SCORE")
    elseif k == "T" then -- target change: nothing to model
    elseif tok then
        if k == "R" then
            fire("NAME_PLATE_UNIT_REMOVED", tok); U[tok] = nil
        else
            U[tok] = gi
            if k == "A" then fire("NAME_PLATE_UNIT_ADDED", tok); counts.A = counts.A + 1
            elseif k == "P" then if gi and a then POWER[gi] = a end
            elseif k == "C" then counts.C = counts.C + 1; fire("UNIT_SPELLCAST_SUCCEEDED", tok, "Cast-x", (a == "SECRET" or a == nil) and SECRET or a)
            elseif k == "U" then counts.U = counts.U + 1; fire("UNIT_COMBAT", tok, a, "", SECRET, 1) end
        end
    end
end
if A.ForeverEvidence then A.ForeverEvidence.flush() end
sweep(ev[#ev][1])

local out = { mode = mode, errors = errors, counts = counts, marks = {}, seen = {}, t0 = t0, t1 = ev[#ev][1],
              stats = A.ForeverEvidence and A.ForeverEvidence.stats or nil }
out.recs = {}
if A.ForeverEvidence then for k, r in pairs(A.ForeverEvidence.R) do out.recs[k] = { heal = r.heal, dmg = r.dmg, casts = r.casts, claim = r.claim, claimT = r.claimT, contradicted = r.contradicted } end end
for i, m in pairs(marks) do out.marks[tostring(i)] = m end
for i, t in pairs(seen) do out.seen[tostring(i)] = t end
-- minimal JSON writer
local function J(v)
    local tv = type(v)
    if tv == "table" then
        local isArr = #v > 0 or next(v) == nil
        local parts = {}
        if isArr then for _, x in ipairs(v) do parts[#parts + 1] = J(x) end return "[" .. table.concat(parts, ",") .. "]" end
        for kk, x in pairs(v) do parts[#parts + 1] = string.format("%q", tostring(kk)) .. ":" .. J(x) end
        return "{" .. table.concat(parts, ",") .. "}"
    elseif tv == "string" then return string.format("%q", v)
    elseif tv == "number" or tv == "boolean" then return tostring(v) end
    return "null"
end
local f = io.open(outPath, "w") f:write(J(out)) f:close()
print(mode, streamPath:match("[^/]+$"), "errors", #errors, "marks", (function() local n = 0 for _ in pairs(marks) do n = n + 1 end return n end)())
for i = 1, math.min(5, #errors) do print("  ERR " .. errors[i]:sub(1, 200)) end
