# Tests
- `load_smoke.lua <KTH.toc>`: loads the addon in ForeverDump's Forever mock (needs /workspace/foreverdump/tests/wowenv.lua)
  and reports errors, Blizzard chat lines and restricted event registrations. baseline: 1 (CLEU); port: 0.
- `replay_score.lua <KTH.toc> <replay/run.lua> <out.json> [port|original-mn]`: replays a captured BG through K.T.H.'s own
  nameplate verdict; unit model per the baseline diag.
- `../tools/score.py orig port strictD8`: precision / recall / time-to-identify vs combat-log truth → results/SCORES.md.
- `replay/*.lua|*.truth.json`: exported by tools/export_replay.py from the raw ForeverDump captures + combat logs.
