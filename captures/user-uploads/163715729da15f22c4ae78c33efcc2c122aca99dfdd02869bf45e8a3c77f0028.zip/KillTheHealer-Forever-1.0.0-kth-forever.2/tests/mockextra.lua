-- WoW's xpcall forwards extra arguments (Lua 5.2 style); plain Lua 5.1 drops them, which made AceAddon call
-- OnInitialize/OnEnable with self = nil inside the mock.
do
    local x51 = xpcall
    xpcall = function(f, h, ...)
        local n, a = select("#", ...), { ... }
        return x51(function() return f(unpack(a, 1, n)) end, h)
    end
end
-- extra globals the Ace libs / K.T.H. touch that ForeverDump's mock does not provide (test harness only)
local function noop() end
geterrorhandler = function() return _G.__errh or print end
seterrorhandler = function(f) _G.__errh = f end
hooksecurefunc = function(a, b, c)
    if type(a) == "table" then local o = a[b]; a[b] = function(...) local r = { o(...) }; c(...); return unpack(r) end
    else local o = _G[a]; _G[a] = function(...) local r = { o(...) }; b(...); return unpack(r) end end
end
IsLoggedIn = IsLoggedIn or function() return true end
strmatch, strfind, strsub, strlower, strupper, strtrim, format = string.match, string.find, string.sub, string.lower, string.upper,
    function(s) return (s:gsub("^%s+", ""):gsub("%s+$", "")) end, string.format
tinsert, tremove, tconcat = table.insert, table.remove, table.concat
strjoin = strjoin or function(sep, ...) return table.concat({ ... }, sep) end
table.wipe = table.wipe or wipe
securecall = securecall or function(f, ...) if type(f) == "string" then f = _G[f] end return f(...) end
issecurevariable = issecurevariable or function() return true end
UnitFactionGroup = UnitFactionGroup or function() return "Horde", "Horde" end
UnitHealthMax = UnitHealthMax or function() return 5000 end
UnitClass = UnitClass or function() return "Warrior", "WARRIOR", 1 end
UnitIsFriend = UnitIsFriend or function() return false end
UnitCanAttack = UnitCanAttack or function() return false end
UnitIsDead = UnitIsDead or function() return false end
UnitIsUnit = UnitIsUnit or function(a, b) return a == b end
UnitPowerType = UnitPowerType or function() return 0, "MANA" end
UnitSex = UnitSex or function() return 2 end
IsInInstance = function() return _G.__inInstance or false, _G.__instType or "none" end
GetNumBattlefieldScores = function() return _G.__numScores or 0 end
GetBattlefieldScore = GetBattlefieldScore or function() end
RequestBattlefieldScoreData = function() end
GetBattlefieldWinner = function() return _G.__winner end
LocalizedClassList = function() return { WARRIOR = "Warrior", PRIEST = "Priest", DRUID = "Druid",
    PALADIN = "Paladin", SHAMAN = "Shaman", MAGE = "Mage", ROGUE = "Rogue", HUNTER = "Hunter", WARLOCK = "Warlock" } end
LOCALIZED_CLASS_NAMES_MALE = LocalizedClassList()
RAID_CLASS_COLORS = RAID_CLASS_COLORS or setmetatable({}, { __index = function() return { r = 1, g = 1, b = 1 } end })
for k in pairs(LocalizedClassList()) do RAID_CLASS_COLORS[k] = { r = 1, g = 1, b = 1 } end
MAX_CLASSES = MAX_CLASSES or 9
C_CreatureInfo = C_CreatureInfo or {}
do local L = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", nil, "SHAMAN", "MAGE", "WARLOCK", nil, "DRUID" }
   C_CreatureInfo.GetClassInfo = function(id) local f = L[id]; if f then return { classFile = f, className = f:sub(1,1) .. f:sub(2):lower(), classID = id } end end end
GetSpecializationInfoForClassID = GetSpecializationInfoForClassID or function() end
GetSpecializationRoleByID = GetSpecializationRoleByID or function() end
StaticPopupDialogs = StaticPopupDialogs or {}
StaticPopup_Show = StaticPopup_Show or noop
UIErrorsFrame = UIErrorsFrame or { AddMessage = function(_, m) local W = _G.__W; if W then W.blizzChat[#W.blizzChat + 1] = "UIErrorsFrame: " .. tostring(m) end end }
RaidWarningFrame = RaidWarningFrame or {}
RaidNotice_AddMessage = function(_, m) local W = _G.__W; if W then W.blizzChat[#W.blizzChat + 1] = "RaidWarningFrame: " .. tostring(m) end end
ChatTypeInfo = ChatTypeInfo or setmetatable({}, { __index = function() return {} end })
SELECTED_CHAT_FRAME = nil
InterfaceOptionsFramePanelContainer = InterfaceOptionsFramePanelContainer or CreateFrame("Frame")
GameFontHighlightLarge = GameFontHighlightLarge or GameFontNormal
BINDING_HEADER_HHTD = nil
LE_PARTY_CATEGORY_HOME, LE_PARTY_CATEGORY_INSTANCE = 1, 2
COMBATLOG_OBJECT_AFFILIATION_OUTSIDER, COMBATLOG_OBJECT_REACTION_HOSTILE, COMBATLOG_OBJECT_REACTION_FRIENDLY = 8, 64, 16
COMBATLOG_OBJECT_TYPE_NPC, COMBATLOG_OBJECT_TYPE_PLAYER = 2048, 1024
bit = { band = function(a, b) local r, p = 0, 1; while a > 0 and b > 0 do if a % 2 == 1 and b % 2 == 1 then r = r + p end a = math.floor(a / 2); b = math.floor(b / 2); p = p * 2 end return r end,
        bor = function(a, b) local r, p = 0, 1; while a > 0 or b > 0 do if a % 2 == 1 or b % 2 == 1 then r = r + p end a = math.floor(a / 2); b = math.floor(b / 2); p = p * 2 end return r end }
-- record what lands in the diagnostic frame and in K.T.H.'s own frame
local origCF = CreateFrame
CreateFrame = function(kind, name, ...)
    local o = origCF(kind, name, ...)
    if type(kind) == "string" and kind:lower() == "scrollingmessageframe" then
        o.AddMessage = function(_, m)
            if name == "KTHForeverDiagFrame" then _G.__diagLines = _G.__diagLines or {}; table.insert(_G.__diagLines, m)
            elseif name == "KTH_MessageFrame" then _G.__kthLines = _G.__kthLines or {}; table.insert(_G.__kthLines, m) end
        end
        o.ScrollUp, o.ScrollDown, o.Clear = noop, noop, noop
    end
    return o
end
C_Timer = C_Timer or {}
C_Timer.NewTicker = C_Timer.NewTicker or function(_, fn) return { Cancel = noop } end
C_Timer.NewTimer = C_Timer.NewTimer or function(_, fn) return { Cancel = noop } end
FOREIGN_SERVER_LABEL = FOREIGN_SERVER_LABEL or " (*)"
NumberFont_Shadow_Small = NumberFont_Shadow_Small or GameFontNormal
GameFontHighlight = GameFontHighlight or GameFontNormal
GameFontNormalSmall = GameFontNormalSmall or GameFontNormal
GameFontDisableSmall = GameFontDisableSmall or GameFontNormal
GameTooltip = GameTooltip or CreateFrame("GameTooltip", "GameTooltip")

-- texture getters (AceConfigDialog popup buttons) return a no-op texture stub in this mock
do
    local stub = setmetatable({}, { __index = function() return function() end end })
    local CF = CreateFrame
    CreateFrame = function(...)
        local f = CF(...)
        for _, m in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetHighlightTexture", "GetDisabledTexture" }) do
            local orig = f[m]
            f[m] = function(self, ...) local t = orig and orig(self, ...) return t or stub end
        end
        local am = f.AddMessage
        if am then f.AddMessage = function(self, msg, ...) self.__lines = self.__lines or {}; self.__lines[#self.__lines + 1] = msg; return am(self, msg, ...) end end
        return f
    end
end

-- metadata: only addons that are actually loaded have metadata (the real client returns nil for others, e.g. "HHTD")
do
    local orig = C_AddOns.GetAddOnMetadata
    C_AddOns.GetAddOnMetadata = function(n, f)
        if n == "HHTD" then return nil end
        return orig(n, f)
    end
    if GetAddOnMetadata then GetAddOnMetadata = C_AddOns.GetAddOnMetadata end
end

-- Settings panel API (Forever ships the modern Settings UI: SettingsInbound attributes in ForeverDump run6b/7/9 globals)
Settings = Settings or {}
do
    local function cat(name) return { ID = name, name = name, GetID = function(self) return self.ID end } end
    Settings.RegisterCanvasLayoutCategory = Settings.RegisterCanvasLayoutCategory or function(_, name) return cat(name) end
    Settings.RegisterCanvasLayoutSubcategory = Settings.RegisterCanvasLayoutSubcategory or function(_, _, name) return cat(name) end
    Settings.RegisterAddOnCategory = Settings.RegisterAddOnCategory or function() end
    Settings.GetCategory = Settings.GetCategory or function(id) return cat(id) end
    Settings.OpenToCategory = Settings.OpenToCategory or function() end
end
