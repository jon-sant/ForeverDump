-- [Forever] K.T.H. Forever port - ForeverChat.lua (new file, port helper; not part of the original K.T.H.)
-- K.T.H. prints through AceConsole (HHTD:Print -> DEFAULT_CHAT_FRAME). On Forever, addon writes into Blizzard chat
-- frames can taint ChatFrame1 and break BattlegroundChatFilters, so every K.T.H. Print/Printf goes to K.T.H.'s own
-- message frame instead. Nothing else about the messages changes. /kthlog shows/hides the frame.
-- K.T.H. is (c) John Wellesz (H.H.T.D.) and Scone (K.T.H.), All Rights Reserved; private port, no redistribution.
local ADDON_NAME, T = ...;
local HHTD = T.HHTD;
if not (T.FS and T.FS.IS_FOREVER) then return; end

local f;
local function Frame()
    if f then return f; end
    f = CreateFrame("ScrollingMessageFrame", "KTH_ForeverMessageFrame", UIParent);
    f:SetSize(420, 110);
    f:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -180);
    pcall(f.SetFontObject, f, _G.GameFontHighlightSmall or _G.ChatFontNormal);
    f:SetJustifyH("LEFT");
    f:SetFading(true);
    f:SetFadeDuration(3);
    f:SetTimeVisible(20);
    f:SetMaxLines(200);
    f:SetMovable(true);
    f:EnableMouse(false);
    return f;
end

local tostring, select, type, format = tostring, select, type, string.format;

local function Print(self, ...)
    local first = ...;
    local n, start = select("#", ...), 1;
    if type(first) == "table" and first.AddMessage then start = 2; end -- an explicit chat frame is ignored too
    local parts = {};
    for i = start, n do parts[#parts + 1] = tostring((select(i, ...))); end
    Frame():AddMessage("|cff33ff99K.T.H.|r: " .. table.concat(parts, " "));
end

local function Printf(self, ...)
    local first = ...;
    if type(first) == "table" and first.AddMessage then return Print(self, format(select(2, ...))); end
    return Print(self, format(...));
end

HHTD.Print, HHTD.Printf = Print, Printf;
for _, module in HHTD:IterateModules() do
    module.Print, module.Printf = Print, Printf;
    if module.IterateModules then
        for _, sub in module:IterateModules() do sub.Print, sub.Printf = Print, Printf; end
    end
end
if HHTD.MODULE_PROTOTYPE then HHTD.MODULE_PROTOTYPE.Print, HHTD.MODULE_PROTOTYPE.Printf = Print, Printf; end

HHTD.ForeverMessageFrame = Frame;
SLASH_KTHLOG1 = "/kthlog";
SlashCmdList["KTHLOG"] = function()
    local fr = Frame();
    if fr:IsShown() then fr:Hide(); else fr:Show(); end
end
