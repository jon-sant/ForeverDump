-- [Forever] K.T.H. Forever port - ForeverEvidence.lua (new file, port helper; not part of the original K.T.H.)
--
-- Why this exists (measured in the baseline BG diag, 2026-10-10, see FOREVER-PORT.md):
--   * enemy nameplate UnitClass is secret (750/750 reads, ooc + combat) -> K.T.H.'s class conditions need the class
--     from somewhere else: the scoreboard (C_PvP.GetScoreInfo name/classToken/faction are clear in every phase);
--   * enemy plate UnitName is clear but first-name-only ("Aerie") while the scoreboard says "Aerie Dunleary" ->
--     join on first word + side, never when that first name is not unique;
--   * talentSpec/roleAssigned are secret during the match (clear only post-match) and the WOWC spec->role table is
--     empty -> the scoreboard names no healer during the match;
--   * nameplate/party/raid spellIDs are secret (nameplate 20/20) -> K.T.H.'s SPELL confirmation never fires.
-- Substitute for the last two: heal evidence. All events of one client frame share one GetTime(); a cast
-- (UNIT_SPELLCAST_SUCCEEDED) by exactly one identified player in a frame plus a UNIT_COMBAT "HEAL" on another player of
-- the same side in that frame = one heal-on-other link. Enough links (and mostly heals, not damage) confirm that
-- specific player as a healer, the same way SpellcastConfirmed does in K.T.H. Only clear values are used
-- (UnitName, UnitCanAttack, UnitIsPlayer, UnitPowerType, the UNIT_COMBAT action string); amounts are never read.
-- No division anywhere (shares are cross-multiplied).
-- K.T.H. is (c) John Wellesz (H.H.T.D.) and Scone (K.T.H.), All Rights Reserved; private port, no redistribution.
local ADDON_NAME, T = ...;
local HHTD = T.HHTD;
local FS = T.FS;
if not (FS and FS.IS_FOREVER) then return; end

local GetTime, pairs, ipairs, type, pcall = GetTime, pairs, ipairs, type, pcall;
local str, num, bool, firstWord = FS.str, FS.num, FS.bool, FS.firstWord;

local E = {};
HHTD.ForeverEvidence = E;

E.HEALER_CLASS = { PRIEST = true, PALADIN = true, SHAMAN = true, DRUID = true };
E.CFG = { healMin = 2, healPct = 60, unknownHealMin = 3 };

local R, roster, firstCount = {}, {}, {};
E.R, E.roster = R, roster;
E.stats = {};

local function key(isFriend, first) return (isFriend and "F:" or "E:") .. first; end

function E.reset()
    for k in pairs(R) do R[k] = nil; end
    for k in pairs(roster) do roster[k] = nil; end
    for k in pairs(firstCount) do firstCount[k] = nil; end
    E.stats = { joinFrames = 0, joinAmbig = 0, healLinks = 0, dmgLinks = 0, contradictions = 0 };
end
E.reset();

---------------------------------------------------------------------------------------------------- roster
-- full: clear scoreboard name ("First Surname"), classToken clear, isFriend boolean
function E.rosterAdd(full, classToken, isFriend)
    local first = firstWord(full);
    if not first or type(isFriend) ~= "boolean" then return; end
    local k = key(isFriend, first);
    local ro = roster[k];
    if not ro then
        roster[k] = { full = full, class = classToken, isFriend = isFriend, first = first };
        firstCount[first] = (firstCount[first] or 0) + 1;
    elseif ro.full ~= full then
        ro.ambiguous = true; -- duplicate guard: two players of one side share this first name -> never joined
    elseif classToken and not ro.class then
        ro.class = classToken;
    end
    local r = R[k];
    if r then E.evaluate(r, GetTime()); end
end

local function rosterRec(isFriend, first)
    if not first then return nil; end
    local ro = roster[key(isFriend, first)];
    if ro and not ro.ambiguous then return ro; end
end

-- class token for a (side, plate first name), nil if unknown or ambiguous
function HHTD.MN_RosterClass(isFriend, first) local ro = rosterRec(isFriend, first); return ro and ro.class or nil; end
function HHTD.MN_RosterFull(isFriend, first)  local ro = rosterRec(isFriend, first); return ro and ro.full or nil; end

-- Key for HHTD.MN_HealersByName: the first word when it is unique among ALL scoreboard rows (K.T.H.'s friendly
-- nameplate lookup is by plate name, which is first-name-only on Forever), else the full scoreboard name (no join).
function HHTD.MN_ShortKey(full)
    local first = firstWord(full);
    if first and firstCount[first] == 1 and (rosterRec(true, first) or rosterRec(false, first)) then
        return first;
    end
    return full:match("^([^-]+)") or full;
end

-- Reads every scoreboard row (name, classToken, faction: clear in every BG phase per the diag).
function HHTD.MN_RosterSweep()
    if not (C_PvP and C_PvP.GetScoreInfo) then return; end
    local n = num(GetNumBattlefieldScores and GetNumBattlefieldScores()) or 0;
    local pf = HHTD.Constants.PLAYER_FACTION;
    for i = 1, n do
        local ok, info = pcall(C_PvP.GetScoreInfo, i);
        if ok and type(info) == "table" and FS.clear(info) then
            local name, cls, fac = str(info.name), str(info.classToken), num(info.faction);
            if name and fac then
                local isFriend = (pf == "Horde" and fac == 0) or (pf == "Alliance" and fac == 1) or false;
                E.rosterAdd(name, cls, isFriend);
            end
        end
    end
end

---------------------------------------------------------------------------------------------------- engine
local function get(isFriend, first)
    local k = key(isFriend, first);
    local r = R[k];
    if not r then
        r = { key = k, isFriend = isFriend, first = first, heal = 0, dmg = 0, casts = 0 };
        R[k] = r;
    end
    return r;
end
E.get = get;

local function notify(r)
    if r.claim ~= "HEALER" or r.notified then return; end
    r.notified = true;
    local full = HHTD.MN_RosterFull(r.isFriend, r.first) or r.first;
    if HHTD._MN_RegisterHealer and HHTD.db then
        pcall(HHTD._MN_RegisterHealer, GetTime(), r.isFriend, "Scoreboard-" .. full, full, true,
            "heal evidence", false, 0, HHTD.db.global, true);
    end
    if HHTD.MN_OnEvidence then HHTD.MN_OnEvidence(); end
    if E.onClaim then pcall(E.onClaim, r); end
end

function E.evaluate(r, t)
    local cfg = E.CFG;
    local ro = rosterRec(r.isFriend, r.first);
    local cls = ro and ro.class or nil;
    if r.claim == "HEALER" then return; end -- claims last the whole match (like K.T.H.'s scoreboard list)
    if cls and not E.HEALER_CLASS[cls] then
        if r.heal >= cfg.healMin and not r.contradicted then
            r.contradicted = true; E.stats.contradictions = E.stats.contradictions + 1;
        end
        return;
    end
    local need = cls and cfg.healMin or cfg.unknownHealMin;
    if r.heal >= need and r.heal * 100 >= cfg.healPct * (r.heal + r.dmg) then
        r.claim, r.claimT, r.why = "HEALER", t, "heal-links " .. r.heal .. "/" .. (r.heal + r.dmg);
        notify(r);
    end
end

-- one client frame: casters (key -> rec), heals / wounds = lists of target recs
function E.join(t, casters, nCasters, heals, wounds)
    if nCasters == 0 then return; end
    E.stats.joinFrames = E.stats.joinFrames + 1;
    if nCasters > 1 then E.stats.joinAmbig = E.stats.joinAmbig + 1; return; end
    local c;
    for _, r in pairs(casters) do c = r; end
    c.casts = c.casts + 1;
    local healed, hurt = false, false;
    for _, tr in ipairs(heals) do if tr ~= c and tr.isFriend == c.isFriend then healed = true; end end
    for _, tr in ipairs(wounds) do if tr.isFriend ~= c.isFriend then hurt = true; end end
    if healed then c.heal = c.heal + 1; E.stats.healLinks = E.stats.healLinks + 1; end
    if hurt then c.dmg = c.dmg + 1; E.stats.dmgLinks = E.stats.dmgLinks + 1; end
    if healed or hurt then E.evaluate(c, t); end
end

-- nameplate check: is this (side, plate first name) confirmed by heal evidence?
function HHTD.MN_EvidenceConfirmed(isFriend, first)
    if not first then return false; end
    local r = R[key(isFriend, first)];
    return (r and r.claim == "HEALER" and not (roster[r.key] and roster[r.key].ambiguous)) and true or false;
end

---------------------------------------------------------------------------------------------------- driver
local inBG = false;
local identCache, identT = {}, -1;

local function call(f, ...)
    if type(f) ~= "function" then return; end
    local ok, a, b = pcall(f, ...);
    if ok then return a, b; end
end

local function ident(tok)
    tok = str(tok);
    if not tok then return nil; end
    local t = GetTime();
    if t ~= identT then identT = t; for k in pairs(identCache) do identCache[k] = nil; end end
    local c = identCache[tok];
    if c ~= nil then return c or nil; end
    local rec = false;
    if bool(call(UnitIsPlayer, tok)) and not bool(call(UnitIsUnit, tok, "player")) then
        local first = firstWord((call(UnitName, tok)));
        local enemy = bool(call(UnitCanAttack, "player", tok));
        if first and enemy ~= nil then rec = get(not enemy, first); end
    end
    identCache[tok] = rec;
    return rec or nil;
end
E.ident = ident;

local B = { t = nil, casters = {}, n = 0, heals = {}, wounds = {} };
local function flush()
    if B.t and B.n > 0 then E.join(B.t, B.casters, B.n, B.heals, B.wounds); end
    B.t = nil; B.n = 0;
    for k in pairs(B.casters) do B.casters[k] = nil; end
    for i = #B.heals, 1, -1 do B.heals[i] = nil; end
    for i = #B.wounds, 1, -1 do B.wounds[i] = nil; end
end
E.flush = flush;
local function bucket()
    local t = GetTime();
    if B.t ~= t then flush(); B.t = t; end
    return t;
end

function E.onCast(tok)
    if not inBG then return; end
    local rec = ident(tok);
    if not rec then return; end
    bucket();
    if not B.casters[rec.key] then B.casters[rec.key] = rec; B.n = B.n + 1; end
end

function E.onCombat(tok, action)
    if not inBG then return; end
    action = str(action);
    if action ~= "HEAL" and action ~= "WOUND" then return; end
    local rec = ident(tok);
    if not rec then return; end
    bucket();
    local L = (action == "HEAL") and B.heals or B.wounds;
    for _, r in ipairs(L) do if r == rec then return; end end
    L[#L + 1] = rec;
end

function E.updateZone()
    local inInst, kind = call(IsInInstance);
    local was = inBG;
    inBG = (bool(inInst) and str(kind) == "pvp") or false;
    if inBG and not was then E.reset(); flush(); end
end
function E.setInBG(v) inBG = v and true or false; end -- replay harness

local frame = CreateFrame("Frame");
frame:SetScript("OnEvent", function(_, event, a1, a2)
    if event == "UNIT_SPELLCAST_SUCCEEDED" then E.onCast(a1);
    elseif event == "UNIT_COMBAT" then E.onCombat(a1, a2);
    else E.updateZone(); end
end);
-- none of these is restricted on Forever (the diag and ForeverDump register them without ADDON_ACTION_FORBIDDEN)
frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED");
frame:RegisterEvent("UNIT_COMBAT");
frame:RegisterEvent("PLAYER_ENTERING_WORLD");
frame:RegisterEvent("ZONE_CHANGED_NEW_AREA");
E.frame = frame;
