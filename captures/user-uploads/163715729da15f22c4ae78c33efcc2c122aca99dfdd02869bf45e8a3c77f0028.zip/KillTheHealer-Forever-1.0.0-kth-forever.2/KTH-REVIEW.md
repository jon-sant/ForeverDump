# K.T.H. review: secret handling compared with ours (ForeverDump / HSM tooling), and what carried over to Forever

## How K.T.H. 1.0.0-kth handles secrets (retail 12.0 Midnight)
1. **Scoreboard first.** `C_PvP.GetScoreInfo` → talentSpec → `CLASS_SPEC_TO_ROLE` (from
   GetSpecializationInfoForClassID). roleAssigned is the fallback. It builds an independent healer list (by name, by
   GUID, by class:spec) that bypasses the H.H.T.D. registry/reaper.
2. **Nameplates by class + power.** Enemy names and GUIDs are secret on retail, but UnitClass and UnitPowerType are
   not. Priest/Druid/Monk on mana counts as a healer. Paladin/Shaman/Evoker are ambiguous and need a SPELL
   confirmation (a clear healer-only spellID on that plate) or CLASS+SCORE (the enemy team has a healer of that class).
3. **Guards.** `canaccessvalue` on every read, pcall around each API, and pcall around every plate check.
4. **Output.** Diagnostics go only to DebugLog. Only the login banner and slash replies use HHTD:Print.
5. **Combat log.** It registers COMBAT_LOG_EVENT_INTERNAL_UNFILTERED via C_CombatLogInternal when present. Otherwise
   it uses UNIT_SPELLCAST_* only.

## Compared with our approach
| topic | K.T.H. | ours (ForeverDump probes, replay harness) | verdict |
|---|---|---|---|
| per-value readability | `canaccessvalue` checks inline, with no record of what was secret | KTH_ForeverDiag records a per-field code for every read, per BG phase, including fields inside readable tables | ours is better for deciding what to build. K.T.H.'s is fine at runtime |
| truth tests | some `x and canaccessvalue(x)` (truth test first) | `canaccessvalue`/type first, then the truth test (Forever errors on a secret boolean test) | ours is safer. Ported as D4 |
| scoreboard | trusts talentSpec | measured: secret in-match on Forever, clear post-match | the K.T.H. idea is right, but Forever withholds the field until the end |
| class on plates | UnitClass | measured secret on Forever enemy plates → scoreboard roster join on first name + side, with a duplicate guard | the join is our technique (D5) |
| spell confirmation | clear healer-only spellIDs | spellIDs secret → frame-join heal evidence (cast + same-frame UNIT_COMBAT HEAL on a teammate) | ours; works for teammates, but almost no enemy casts are delivered on Forever |
| chat hygiene | DebugLog + HHTD:Print banner | nothing in Blizzard chat at all (own frame) | ours is stricter. Ported as D3 |
| restricted events | does not register CLEU on 12.0 (MN branch) | ForeverDump denylist: CLEU / COMBAT_LOG_EVENT | same idea. K.T.H. only failed on Forever because its MN switch is toc-based (D2) |
| testing | none shipped | Forever mock + replay of 5 captured BGs against combat-log truth | ours |

## What K.T.H. taught us
- An **independent healer list** that bypasses the registry and reaper is a good pattern for nameplate marking. We kept it.
- **CLASS+SCORE** (mark every plate of a class when the scoreboard shows a healer of that class) is a useful low-precision
  fallback. On Forever it only fires post-match, because talentSpec is secret until then.
- K.T.H.'s **power check** still pays off on Forever: replays give 6/7 enemy healers marked on first sight. The
  cost is 50% precision, since DPS priests and caster DPS druids are also on mana there.

## Forever versus retail, as measured (baseline BG, 2026-10-09)
- Same as retail: GetScoreInfo table readable; name, classToken and faction clear; GUIDs secret; spellIDs secret;
  GetBattlefieldScore layout.
- Different: enemy plate **UnitClass secret**. Enemy plate **UnitName clear, first name only** (the scoreboard has
  "First Surname"). **No CLEU getter** at all, and registering CLEU is forbidden. MN detection by toc fails
  (toc 16001). Classic power types.

## Open points
- Paladin/shaman enemy healers: confirmation only post-match (CLASS+SCORE / D6) or by rare heal evidence.
- Friendly nameplates were off in every capture, so friendly plate marks are untested.
- AddToBlizOptions on Forever is untested in game (the baseline skipped it). It is expected to work: the Settings UI is
  present.
