# K.T.H. Forever 1.0.0-kth-forever.2

K.T.H. (Kill The Healer) by Scone, built on H.H.T.D. by John Wellesz, ported to WoW Forever 1.60.1 (toc 16001).
**All Rights Reserved. This is a private port for personal use. Do not redistribute it.**

## Install
1. Close WoW Forever.
2. In `World of Warcraft/_forever_/Interface/AddOns/`, delete the old `KTH` folder (the baseline build).
3. Copy `AddOns/KTH` there.
4. Optional: copy `AddOns/KTH_ForeverDiag` (the same probe as in the baseline). It writes only to its own frame and
   SavedVariables. Keep it for one more BG if you want a second measurement with the port. Otherwise leave it out.
5. Start the client.

## In game
- `/kthg`: settings window (K.T.H.'s own panel). `/hhtd` opens the H.H.T.D. options window. On Forever, nothing is
  printed to chat.
- K.T.H. messages appear in its own small frame, top-left (`KTH_ForeverMessageFrame`). `/kthlog` shows or hides it.
- Enemy healer markers: the class comes from the scoreboard (first name + team), and the mana check is K.T.H.'s own.
  Priests and druids on mana are marked straight away. Paladins and shamans need confirmation, either from the
  scoreboard (post-match) or from heal evidence.
- `/hhtdp` posts K.T.H.'s healer placard to BG chat. This is K.T.H.'s original feature and only runs when you type it.

## What to expect (replays of 5 captured BGs)
- Enemy healers seen on nameplates: 6 of 7 marked on first sight, but half of all marks are DPS priests or druids,
  because on Forever DPS priests also use mana.
- Friendly healers (heal evidence, for K.T.H.'s alerts and lists): 6 of 9 found, median about 6 minutes in, at 50%
  precision.
- No "blocked from an action only available to the Blizzard UI" popup: the port never registers COMBAT_LOG_EVENT_UNFILTERED.

See `FOREVER-PORT.md` for every change and its evidence, `KTH-REVIEW.md` for the comparison with our own tools,
`tests/` for the harness, and `original/KTH` for the untouched original.
