# K.T.H. Forever: port notes and diff list (1.0.0-kth-forever.2)

This is a private port of **K.T.H. (Kill The Healer) 1.0.0-kth** to **WoW Forever 1.60.1** (build 70334, toc 16001,
WOW_PROJECT_ID 18). Credits: K.T.H. by Scone, built on H.H.T.D. by John Wellesz. **All Rights Reserved**: the port is for
private use only. Do not redistribute it.

The code, structure, design and four-condition healer logic are K.T.H.'s own. Every change is tagged `[Forever]` in
the source. The full patch against the untouched original is in `FOREVER-PORT.diff` (`original/KTH` holds the original).
Evidence comes from the user's baseline battleground run (original K.T.H. with only the TOC changed, plus the
KTH_ForeverDiag probe) on 2026-10-09 between 23:51 and 00:13 ET. It is backed by the ForeverDump captures of runs
10 to 16.

## What the baseline diag measured (per-value reads, C = clear, S = secret, N = nil; counts per phase)
See `docs/diag-tables.md` for the full per-field × per-phase tables. Summary:
- **Branch**: `MN=false`, `WOWC=true`, project 18, toc 16001, `canaccessvalue` present, `CombatLogGetCurrentEventInfo`
  absent, `C_CombatLogInternal` absent. K.T.H. printed nothing (kthPrints = 0), and 0 Lua errors were logged.
- **Blocked action**: one `ADDON_ACTION_FORBIDDEN`, `AceEvent30Frame:RegisterEvent()`, at 23:51:53 ET. That was the
  second K.T.H. load (a login or reload inside the BG). The cause is `Core.lua:1035`
  `self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")` on the non-MN branch. It is the only event K.T.H. registers on
  that branch that Forever restricts. ForeverDump's EVENT_DENYLIST documents the same popup for CLEU. The Forever mock
  reproduces it: baseline gives 1 restricted registration (CLEU), the port gives 0. The diag's blocked list is reset on
  each load, so the first load at 23:51:29 probably raised the same block.
- **C_PvP.GetScoreInfo**: the table itself is clear in every phase (prep 150/150, ooc 2849, combat 1050, post 60).
  `name` ("First Surname"), `classToken`, `className` and `faction` are clear in every phase. `talentSpec`,
  `roleAssigned`, `guid`, `healingDone`, `damageDone`, `killingBlows`, `deaths`, `honor*` and `rating` are secret in
  prep, ooc and combat, and clear post-match. `race` and `bgRating` are nil.
- **GetBattlefieldScore** layout from raw rows: 1 name, 6 faction (0/1), 7 race, 8 localized class, 9 classToken.
  These are clear in every phase. 2-5, 10-13 and 15-17 are secret in-match and clear post-match. 14 is nil.
  The layout is retail-like.
- **Enemy nameplates** (750 reads, ooc + combat): UnitName clear and **first-name-only** (13 names, none with a space
  or realm). UnitClass is secret (all 3 returns, 750/750). UnitGUID and UnitHealthMax are secret. UnitPowerType,
  UnitCanAttack and UnitIsFriend are clear. **No friendly nameplates** were seen.
- **spellIDs** (UNIT_SPELLCAST_SUCCEEDED): nameplate 20/20 secret, arena 12/12, party 194/194, target 7/7. raid is
  secret except when the raid token is the player. The player's own spellIDs are clear.

## Diff list
| # | Change | Status | Evidence |
|---|---|---|---|
| D1 | TOC `## Interface: 16001`, title suffix "Forever", version `1.0.0-kth-forever.2`, 3 new files | measured | the client only loads toc 16001 (baseline loaded) |
| D2 | `HHTD_C.MN = true` on Forever (Midnight path) | measured | diag MN=false, then classic branch, then CLEU RegisterEvent and ADDON_ACTION_FORBIDDEN popup; no CLEU getter on Forever. The MN branch registers no CLEU (C_CombatLogInternal absent, so only UNIT_SPELLCAST_*) |
| D3 | All K.T.H. `Print`/`Printf` (core + modules, incl. SafePrint banner) go to K.T.H.'s own frame `KTH_ForeverMessageFrame` (`/kthlog`); `/hhtd` opens the options window instead of AceConfigCmd chat output | user rule (no Blizzard chat writes) | code path: the MN branch prints the login banner and slash replies through HHTD:Print, which goes to DEFAULT_CHAT_FRAME. Mock: 0 Blizzard chat lines, all output on the own frame |
| D4 | Order `canaccessvalue(x)` before any truth test of scoreboard fields (talentSpec, roleAssigned, faction, guid), the spellcast spellID/guid/name and canAttack | measured secrecy; the change itself is semantics-preserving | diag: these fields are secret in-match and nameplate spellIDs are secret. No behaviour change when values are clear |
| D5 | Class for an enemy plate from the scoreboard roster (first name + side, duplicate first names never joined); `MN_HealersByName` keyed by the first word when unique | measured | enemy UnitClass S 750/750; plate names first-name-only; GetScoreInfo name/classToken/faction clear in every phase |
| D6 | Scoreboard Method 3: healingDone ≥ damageDone (>0) means healer | measured (post-match only) | healingDone/damageDone clear only post-match (60/60). The WOWC spec→role table is empty and roleAssigned is secret in-match |
| D7 | Heal evidence (cast + same-frame UNIT_COMBAT HEAL on a teammate) confirms a specific player and stands in for the SPELL check; it registers through K.T.H.'s RegisterHealer | measured need, scored | spellIDs secret (nameplate 20/20). Replay: friendly 6/9 healers, 50% precision; enemy 0/8 (enemy casts are almost never delivered: 3 to 9 per BG) |
| D8 | Treat PRIEST/DRUID as ambiguous (DPS also on mana) | measured, **not applied** | DPS priests and caster DPS druids are MANA-only in runs 10-16. But applying it drops enemy plate recall from 6/7 to 0/7. K.T.H.'s original rule is kept |
| T | `HHTD.MN_CheckUnitIsHealer = CheckUnitIsHealer` | test hook, no behaviour | used by tests/replay_score.lua |

### Earlier draft diffs, now dropped (refuted, or Forever behaves like retail, so original code kept)
- GetBattlefieldScore "classic layout" (faction 6 / rank 7 / class 9-10): **refuted**. The layout is retail-like, and the
  fallback is unreachable because the GetScoreInfo table is clear. K.T.H. reads faction at position 7 (race) there; that
  is an original K.T.H. bug, identical on retail, and was left alone.
- GetScoreInfo "secret table" guard: **refuted**. The table is clear in all phases (the old claim was a ForeverDump
  probe flaw).
- UnitHealthMax('player') guard in UpdateHealThresholds: **refuted**. The 50 s timer ran through the whole BG with
  0 errors.
- MAX_CLASSES loop bound: **refuted**. Loading had 0 errors.
- AddToBlizOptions pcall: **not needed**. Forever ships the Settings UI (SettingsInbound in ForeverDump globals).
  The original code is kept, but this path is untested in-game because K.T.H. skips it when MN=false.
- TestUnit GUID/name fallback and Announcer UnitClass guards: dropped. Retail Midnight BG GUIDs are secret too, so this
  is retail behaviour and the original is kept.
- `MN_MyTeam` via GetBattlefieldArenaFaction: dropped. faction (0/1) is clear, and K.T.H.'s PLAYER_FACTION rule matches
  it (player Horde = faction 0 in the diag).
- RaidWarningFrame / UIErrorsFrame rerouting: dropped. These are not chat frames, and the original is kept.
  `/hhtdp` (ChatPlacard → SendChatMessage) stays as in the original. It only runs when you type it, or when the
  opt-in "ChatWarning" option is on (default off).

## Replay scores (tests/results/SCORES.md)
These are the five ForeverDump BG captures (runs 10, 11, 12, 13, 16) replayed through each variant loaded in the
Forever mock. Truth: heal on others ≥ 30% of (damage + heal on others) and ≥ 5 direct heals on others (combat log).
Plates in these captures are enemy-only.

| variant | enemy plate precision | enemy plate recall (healers seen on plates) | plate time-to-identify (median) | heal-evidence claims precision | claim recall friendly / enemy | claim TTI median |
|---|---|---|---|---|---|---|
| original K.T.H. MN path on Forever values | 0/0 | 0/7 | n/a | n/a | 0/9 / 0/8 | n/a |
| **port (forever.2)** | **6/12 = 50%** | **6/7 = 86%** | **0 s (on first sight)** | 6/12 = 50% | 6/9 / 0/8 | 364 s |
| port + D8 | 0/0 | 0/7 | n/a | 6/12 = 50% | 6/9 / 0/8 | 364 s |
