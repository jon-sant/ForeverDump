-- HybridState-1.0: a reusable "hybrid state machine" for addons on secret-value clients (WoW Forever 1.60+).
-- Predicts and tracks combat state from READABLE inputs only:
--   * UNIT_SPELLCAST_* events (event timing always arrives; spellID only when the client reports it non-secret)
--   * UNIT_AURA updateInfo (auraInstanceIDs / counts / fields when non-secret)
--   * readable aura counts (e.g. GetAuraSlots(unit, "HELPFUL|PLAYER") when the count is not secret)
--   * restriction state, and spell knowledge cached while readable (durations, cooldowns, tooltip ranges)
-- It never reads secrets, never parses secret text, never uses the combat log (CLEU) and never derives numbers from
-- rendered widgets. Every inference carries the rule that produced it and a confidence tag.
--
-- Usage (any addon; no ForeverDump dependency):
--   local HS = HybridState.New({ now = GetTime, onPredict = fn, onInfer = fn, onContradiction = fn })
--   HS:Learn(spellID, { aura = { duration = 30, helpful = true }, cooldown = 8, amount = { min = 10, max = 12, kind = "damage" } })
--   HS:OnCast(event, unitKey, spellID|nil, isPlayer, targetKey)      -- from UNIT_SPELLCAST_* (spellID nil when secret)
--   HS:OnAura(unitKey, { full = bool, added = { { iid=, spellId=, fromPlayer=, helpful=, duration=, applications= } },
--                        addedCount = n, removed = { iid, ... }, removedCount = n })  -- unreadable fields = nil
--   HS:OnCount(unitKey, filter, count)                                   -- readable aura count for a filter
--   HS:Tick()                                                            -- expire predicted auras/cooldowns
--   HS:UnitState(unitKey), HS:CastState(unitKey), HS:Cooldown(spellID), HS.predictions, HS.inferences, HS.counters
-- MINOR 5 (v2.2.4, cooldown review): CooldownTracker. Per-spell cooldown + GCD state fused from every readable signal:
--   HS:CDInfo(spellID, { cooldown = s, gcd = s, category = n, srCategory = n })   -- static (knowledge, read out of combat)
--   HS:CDPayload(spellID, baseSpellID, category, startRecoveryCategory)        -- SPELL_UPDATE_COOLDOWN payload (clear, run 5)
--   HS:CDActive() -> { spellID, ... }                                          -- the k spells worth re-checking (O(k))
--   HS:CDCheckList(horizon, budget) -> { spellID, ... }                        -- per-event subset: due + GCD + budget RR
--   HS:CDObserve(spellID, isActive, isOnGCD, remaining|nil, duration|nil)      -- C_Spell.GetSpellCooldown NeverSecret fields
--   HS:GCDObserve(remaining, duration)                                         -- clear GCD read (61304 when it exists)
--   HS:Cooldown(spellID) -> { state = "ready"|"cooling"|"gcd", ends, remaining, confidence, source }
--   HS:GCD() -> { ends, spell, length, remaining, source } | nil
--   own UNIT_SPELLCAST_SUCCEEDED starts the spell's cooldown (+ its shared category) and the GCD with that spell's baseGCD;
--   isActive false outside the GCD = observed ready (learns the true cooldown); isOnGCD true -> false = observed GCD end
--   (learns the per-spell GCD); verdicts "cd-ready" and "gcd" go to the live verification ring.
-- MINOR 4 (v2.2.4, run-5 review): Ledger (collect-while-clear identity/aura cache), enemy cast-duration model per NPC
--   (OnEnemyCast / EnemyCast: interrupt window), interrupt dedupe across tokens, UNIT_SPELLCAST_FAILED as cooldown
--   evidence (OnCastFailed), running health estimate + overheal estimate for the player (OnHealthMax / OnHealthEvent)
-- MINOR 3 (ForeverDump v2.2.4, run 5): source attribution from clear event timing only
--   HS:OnCombatState(inCombat)                    -- PLAYER_REGEN_DISABLED/ENABLED: opens/closes a fight record
--   HS:OnSwing()                                  -- PLAYER_SWING (clear): my melee swing happened now
--   HS:OnDamageMeter(dmType)                      -- DAMAGE_METER_COMBAT_SESSION_UPDATED type arg (clear): my/group meter moved
--   HS:OnUnitCombat(unitKey, action, flag, amount, school, isPlayerUnit)  -- UNIT_COMBAT (clear on 1.60.1, run 5)
--   HS:OnInterrupt(unitKey)                       -- UNIT_SPELLCAST_INTERRUPTED on a hostile unit
--   HS:ReconcileDM(rec)                           -- post-combat C_DamageMeter totals (clear after combat) vs live attribution
--   HS.fights (newest last), HS:Fight()           -- per-fight mine/other damage, heals, interrupts, auras
-- Embedding: copy this file into your addon and load it before your code. It registers the global `HybridState`
-- (or returns the table when loaded with a module loader); a newer MINOR replaces an older one.
local MAJOR, MINOR = "HybridState-1.0", 5
local existing = rawget(_G, "HybridState")
if type(existing) == "table" and (existing.MINOR or 0) >= MINOR then return existing end

local Lib = { MAJOR = MAJOR, MINOR = MINOR }
local M = {}
M.__index = M

local function defaultNow()
    local f = rawget(_G, "GetTime")
    return type(f) == "function" and f() or os.clock()
end

local CONF = { observed = 3, high = 2, medium = 1, low = 0 }
Lib.CONF = CONF

function Lib.New(opts)
    opts = opts or {}
    local o = setmetatable({}, M)
    o.now = opts.now or defaultNow
    o.window = opts.window or 0.6           -- s: cast -> aura correlation window
    o.tolerance = opts.tolerance or 1.5     -- s: early-removal tolerance before calling it a contradiction
    o.maxLog = opts.maxLog or 2000
    o.onPredict, o.onInfer, o.onContradiction = opts.onPredict, opts.onInfer, opts.onContradiction
    o.knowledge = {}        -- [spellID] = { aura = { duration, helpful }, cooldown, castTime, amount = { min, max, kind } }
    o.units = {}            -- [unitKey] = { auras = { [key] = aura }, counts = { [filter] = n } }
    o.casts = {}            -- [unitKey] = { active, kind, start, spell, ends }
    o.cooldowns = {}        -- [spellID] = { start, ends }
    o.iidMap = {}           -- [unitKey .. "#" .. iid] = { spell, rule, conf }
    o.recent = {}           -- recent player casts { t, spell, target }
    o.unexplained = {}      -- recent auras with unreadable spellId and no explaining cast yet
    o.predictions, o.inferences, o.contradictions = {}, {}, {}
    o.summons, o.totems = {}, {}
    o.counters = { predictions = 0, inferences = 0, contradictions = 0, casts = 0, auraEvents = 0, unreadable = 0 }
    o.restriction = {}
    o.seq = 0
    o.version = 0           -- bumped on every state change (UIs redraw only when it moved: dirty flag)
    o.kver = 0              -- knowledge version (Appliers cache key)
    o.applCache = {}
    -- MINOR 3: attribution (all timing in seconds; defaults trained offline on the run-5 combat log, fdump coverage)
    o.legacy = opts.legacy                  -- true = v2.2.3 behaviour (no attribution, loose secret-timing window)
    o.timingWindow = opts.timingWindow or (o.legacy and o.window * 4 or 0.35)  -- secret aura event -> my cast
    o.sameFrame = opts.sameFrame or 0.06    -- s: same-frame tolerance (spell damage arrives with UNIT_SPELLCAST_SUCCEEDED)
    o.dmWindow = opts.dmWindow or 0.03      -- s: DAMAGE_METER_COMBAT_SESSION_UPDATED fires in the frame my damage lands
    o.swingLag = opts.swingLag or { 0.25, 1.1 }  -- s: melee UNIT_COMBAT lags the swing (log: median 0.458, max 0.979)
    o.healPeriod = opts.healPeriod or 2.0   -- s: periodic heal cadence (Healing Stream Totem, log)
    o.healJitter = opts.healJitter or 0.15
    o.ownRecent = {}                        -- my last successful casts (any spellID state) { t, spell }
    o.swings = {}                           -- recent PLAYER_SWING times { t, used }
    o.dmLast = {}                           -- [dmType] = last event time
    -- v2.2.6 capture-mode: shadow (non-acting) evaluation of prior correlate findings
    o.shadowFindings = opts.shadowFindings and true or false
    o.shadowDm7Expect = nil                 -- GetTime when DAMAGE_METER type 7 fired (enemy-melee finding)
    o.shadowTotemHealN = 0                  -- counts for capture summary
    o.shadowDm7N = 0
    o.lastMineHeal = nil
    o.fights = {}
    o.fight = nil
    -- MINOR 4
    o.ecast = {}                    -- [unitKey] = open enemy cast { start, bar, key, pred, lo, hi }
    o.castModel = {}                -- [npcKey(#spell)] = { d = { last 8 durations }, n } (learned live START -> SUCCEEDED)
    o.castPreds = {}                -- per enemy cast: { t, key, pred, actual | elapsed, outcome } (offline scoring)
    o.lastInterrupt = nil
    o.hp = {}                       -- [unitKey] = { max, cur, anchor, anchorT, unknown, lastEvt, lastUnknownT }
    o.quietFull = opts.quietFull or 3.5   -- s without UNIT_HEALTH out of combat = full health (regen stopped)
    o.inCombat = false
    o.verdicts = {}                 -- [kind|V/C/U/X] = n (live verification counters)
    o.onVerdict = opts.onVerdict
    o.idKey = opts.idKey  -- v2.2.6: ReplayLog.IdKey for per-unit meter join
    o.cachedIdx = {}                -- [unitKey] = { [ledger aura key] = true } (per-unit index into the ledger)
    -- MINOR 5: CooldownTracker
    o.cd = { spells = {}, active = {}, nActive = 0, cat = {}, gcd = nil, gcdLearn = {}, readies = {}, gcds = {},
        list = {}, pos = {}, heap = {}, due = {}, rr = 0 }   -- incremental indices: active array, ends min-heap, due set
    o.ledger = opts.ledger          -- set below once Lib.NewLedger exists (opts.ledger = false disables it)
    if o.ledger == nil and Lib.NewLedger then o.ledger = Lib.NewLedger({ now = o.now }) end
    return o
end

-- bounded append, amortised O(1): the list may hold up to max + max/4 entries; when it overflows, the newest max are
-- moved down in one pass (v2.2.3; table.remove(list, 1) shifted the whole list on EVERY insert once full)
local function push(list, rec, max)
    local n = #list + 1
    list[n] = rec
    local slack = math.max(8, math.floor(max / 4))
    if n > max + slack then
        local drop = n - max
        for i = 1, max do list[i] = list[i + drop] end
        for i = max + 1, n do list[i] = nil end
    end
    return rec
end
Lib.push = push

function M:Learn(spellID, k)
    if type(spellID) ~= "number" or type(k) ~= "table" then return end
    local cur = self.knowledge[spellID] or {}
    for key, v in pairs(k) do
        if type(v) == "table" and type(cur[key]) == "table" then for a, b in pairs(v) do cur[key][a] = b end else cur[key] = v end
    end
    self.knowledge[spellID] = cur
    self.kver = self.kver + 1
    self.version = self.version + 1
end

-- spells of the player that apply an aura of the given helpfulness ("single applier" rule input)
function M:Appliers(helpful)
    -- cached per knowledge version (v2.2.3: it was rebuilt + sorted on every aura event)
    local ck = (helpful == nil) and "any" or (helpful and "h" or "d")
    local c = self.applCache[ck]
    if c and c.v == self.kver then return c.list end
    local out = {}
    for id, k in pairs(self.knowledge) do
        if k.aura and (helpful == nil or k.aura.helpful == nil or k.aura.helpful == helpful) then out[#out + 1] = id end
    end
    table.sort(out)
    self.applCache[ck] = { v = self.kver, list = out }
    return out
end

function M:unit(key)
    local u = self.units[key]
    if not u then u = { auras = {}, counts = {} } self.units[key] = u end
    return u
end

function M:infer(rec)
    self.seq = self.seq + 1
    rec.id, rec.t = self.seq, rec.t or self.now()
    self.counters.inferences = self.counters.inferences + 1
    self.version = self.version + 1
    push(self.inferences, rec, self.maxLog)
    if self.onInfer then pcall(self.onInfer, rec) end
    return rec
end

-- MINOR 4: live verification loop. Every prediction checked against later readable reality emits one verdict:
-- V verified, C contradicted, U unverified (no readable reality to check against), X unexpected. O(1); the addon's
-- Verify.lua stores them in a capped SV ring (onVerdict). kind = check type, src = evidence signal.
function M:verdict(kind, v, rec)
    rec = rec or {}
    rec.kind, rec.v, rec.t = kind, v, rec.t or self.now()
    local vc = self.verdicts
    local key = kind .. "|" .. v
    vc[key] = (vc[key] or 0) + 1
    if self.onVerdict then pcall(self.onVerdict, rec) end
    return rec
end

function M:contradict(rec)
    rec.t = rec.t or self.now()
    self.counters.contradictions = self.counters.contradictions + 1
    self.version = self.version + 1
    push(self.contradictions, rec, 200)
    if self.onContradiction then pcall(self.onContradiction, rec) end
end

function M:SetRestriction(rtype, state) self.restriction[rtype] = state end

----------------------------------------------------------------------------
-- casts
----------------------------------------------------------------------------
local START = { UNIT_SPELLCAST_START = "cast", UNIT_SPELLCAST_CHANNEL_START = "channel", UNIT_SPELLCAST_EMPOWER_START = "empower" }
local STOP = { UNIT_SPELLCAST_STOP = "stop", UNIT_SPELLCAST_CHANNEL_STOP = "stop", UNIT_SPELLCAST_EMPOWER_STOP = "stop",
    UNIT_SPELLCAST_SUCCEEDED = "succeeded", UNIT_SPELLCAST_INTERRUPTED = "interrupted", UNIT_SPELLCAST_FAILED = "failed" }
Lib.START, Lib.STOP = START, STOP

function M:OnCast(event, unitKey, spellID, isPlayer, targetKey)
    local now = self.now()
    self.counters.casts = self.counters.casts + 1
    self.version = self.version + 1
    if spellID == nil then self.counters.unreadable = self.counters.unreadable + 1
    elseif self.ledger then self.ledger:Put("cast", unitKey, { spell = spellID, event = event }, "UNIT_SPELLCAST") end
    local c = self.casts[unitKey]
    if START[event] then
        local k = spellID and self.knowledge[spellID]
        if isPlayer and spellID then self:cdBegin(spellID, now) end
        self.casts[unitKey] = { active = true, kind = START[event], start = now, spell = spellID,
            ends = k and k.castTime and k.castTime > 0 and (now + k.castTime) or nil }
        self:infer({ rule = "cast-pair", kind = "cast-start", unit = unitKey, spell = spellID, conf = "observed" })
    elseif STOP[event] then
        if c and c.active then
            c.active = false
            self:infer({ rule = "cast-pair", kind = "cast-end", unit = unitKey, spell = spellID or c.spell, outcome = STOP[event],
                started = c.start, conf = "observed" })
        end
        if event == "UNIT_SPELLCAST_SUCCEEDED" and isPlayer then
            local cd = spellID and self.cooldowns[spellID]
            if cd and cd.ends then   -- predicted cooldown vs this successful recast
                if now < cd.ends - 0.15 then
                    self:contradict({ kind = "recast-before-ready", spell = spellID, early = cd.ends - now, rule = "cooldown" })
                    self:verdict("cooldown", "C", { spell = spellID, src = "UNIT_SPELLCAST_SUCCEEDED", conf = "high", d = now - cd.ends })
                else self:verdict("cooldown", "V", { spell = spellID, src = "UNIT_SPELLCAST_SUCCEEDED", conf = "high", d = now - cd.ends }) end
            end
            if spellID then self:CDCast(spellID, now) end
            local kk = spellID and self.knowledge[spellID]
            push(self.ownRecent, { t = now, spell = spellID, target = targetKey, summon = (kk and kk.summon) and true or nil }, 8)
            if spellID then self:predict(spellID, targetKey, now) end
        end
    end
end

function M:CastState(unitKey) return self.casts[unitKey] end

-- one prediction per successful player cast: aura (+duration), amount range, cooldown end
function M:predict(spellID, targetKey, now)
    local k = self.knowledge[spellID] or {}
    local p = { t = now, spell = spellID, unit = targetKey, known = next(k) ~= nil }
    -- retro correlation: an unexplained aura added within the window BEFORE this cast (UNIT_AURA can precede
    -- UNIT_SPELLCAST_SUCCEEDED) on the cast's aura unit
    if k.aura then
        local aunit = (k.aura.self and "player") or targetKey
        for i = #self.unexplained, 1, -1 do
            local x = self.unexplained[i]
            if now - x.t <= self.window and (aunit == nil or x.unit == aunit)
                and (x.helpful == nil or k.aura.helpful == nil or x.helpful == k.aura.helpful) then
                table.remove(self.unexplained, i)
                local appl = self:Appliers(k.aura.helpful)
                local rule = (#appl == 1) and "single-applier" or "cast-correlation"
                local conf = (#appl == 1 or x.fromPlayer == true) and "high" or "medium"
                local u = self:unit(x.unit)
                local a = u.auras["i" .. tostring(x.iid)]
                if a then
                    a.spell, a.rule, a.conf, a.source = spellID, rule, conf, "inferred"
                    a.duration = a.duration or k.aura.duration
                    a.expires = a.duration and (x.t + a.duration) or nil
                end
                self.iidMap[x.unit .. "#" .. tostring(x.iid)] = { spell = spellID, rule = rule, conf = conf }
                self:infer({ rule = rule, kind = "applied", unit = x.unit, spell = spellID, iid = x.iid, conf = conf,
                    expires = a and a.expires, retro = true, t = x.t })
                p.outcome = "aura seen (" .. rule .. ")"
                break
            end
        end
    end
    if k.aura then
        local aunit = (k.aura.self and "player") or targetKey
        p.aura = { unit = aunit, duration = k.aura.duration, expires = k.aura.duration and (now + k.aura.duration) or nil,
            helpful = k.aura.helpful, id = k.auraId }
    end
    if k.amount then p.amount = { min = k.amount.min, max = k.amount.max, kind = k.amount.kind } end
    -- v2.2.2: totems are summons (a creature with a lifetime), not auras on the target; verified live by
    -- PLAYER_TOTEM_UPDATE/GetTotemInfo when readable (OnTotem), offline by SPELL_SUMMON -> UNIT_DIED/DESTROYED
    if k.summon then
        p.unit = "player"
        p.summon = { name = k.summon.name, duration = k.summon.duration, expires = k.summon.duration and (now + k.summon.duration) or nil }
        self.summons[#self.summons + 1] = { spell = spellID, t = now, pred = p, name = k.summon.name }
        if #self.summons > 8 then table.remove(self.summons, 1) end
    end
    if k.dispel then p.dispel = true end   -- no live truth without CLEU; offline: SPELL_DISPEL/_FAILED/STOLEN
    if k.cooldown and k.cooldown > 1.5 then
        p.cooldownEnds = now + k.cooldown
        self.cooldowns[spellID] = { start = now, ends = p.cooldownEnds, source = "predicted", pred = p }
    end
    self.seq = self.seq + 1
    p.id = self.seq
    self.counters.predictions = self.counters.predictions + 1
    self.version = self.version + 1
    push(self.predictions, p, self.maxLog)
    push(self.recent, { t = now, spell = spellID, target = targetKey, pred = p }, 16)
    if self.onPredict then pcall(self.onPredict, p) end
    return p
end

-- legacy view (MINOR <= 4): the raw predicted-cooldown record or nil
function M:CooldownRecord(spellID)
    local c = self.cooldowns[spellID]
    if c and c.ends and c.ends <= self.now() then self.cooldowns[spellID] = nil return nil end
    return c
end

----------------------------------------------------------------------------
-- auras
----------------------------------------------------------------------------
-- the player cast that best explains an aura appearing on unitKey now (within the window)
function M:explain(unitKey, helpful, now)
    local best
    for i = #self.recent, 1, -1 do
        local r = self.recent[i]
        if now - r.t > self.window then break end
        local k = self.knowledge[r.spell]
        if k and k.aura and (helpful == nil or k.aura.helpful == nil or k.aura.helpful == helpful) then
            local au = r.pred and r.pred.aura and r.pred.aura.unit
            if au == nil or au == unitKey or unitKey == nil then best = r break end
        end
    end
    return best
end

function M:addAura(unitKey, key, a)
    local u = self:unit(unitKey)
    local prev = u.auras[key]
    u.auras[key] = a
    self.version = self.version + 1
    if prev and a.refresh == nil then a.refresh = true end
    return a
end

function M:OnAura(unitKey, info)
    if type(info) ~= "table" then return end
    local now = self.now()
    self.counters.auraEvents = self.counters.auraEvents + 1
    local u = self:unit(unitKey)
    if info.addedSecret then
        local p = self:verifyTiming(unitKey, now)
        -- MINOR 3: "not mine" by elimination: a secret added-aura on a non-player unit with no open aura prediction and
        -- no successful cast of mine inside the timing window was applied by someone else (or is a proc of theirs)
        if not p and not self.legacy and unitKey ~= "player" then
            local mine = self:ownWithin(now, self.timingWindow, true)
            local f = self:Fight()
            if mine then
                if f then f.auras.mine = f.auras.mine + 1 end
                self:infer({ rule = "own-cast-frame", kind = "applied", unit = unitKey, src = "mine", spell = mine.spell, conf = "medium" })
            else
                if f then f.auras.other = f.auras.other + 1 end
                self:infer({ rule = "elimination", kind = "applied", unit = unitKey, src = "other", conf = "medium" })
            end
        elseif p then
            local f = self:Fight()
            if f then f.auras.mine = f.auras.mine + 1 end
        elseif not self.legacy then
            -- on the player: any successful cast of mine in the window (self buffs, totem auras) explains it; without
            -- one it stays unattributed (procs, party buffs and my totems' pulses all arrive without a cast)
            local mine = self:ownWithin(now, self.timingWindow)
            if mine then self:infer({ rule = "own-cast-frame", kind = "applied", unit = unitKey, src = "mine", spell = mine.spell, conf = "medium" }) end
        end
    end
    if info.full then
        -- full update: keep inferred auras (they may still exist), drop observed ones we can no longer confirm
        for key, a in pairs(u.auras) do if a.source == "observed" then u.auras[key] = nil end end
        if self.ledger then for lkey in pairs(self.cachedIdx[unitKey] or {}) do self.ledger:Invalidate("aura", lkey) end end
    end
    local L = self.ledger
    for _, ad in ipairs(info.added or {}) do
        local spell, rule, conf = ad.spellId, nil, nil
        local lkey = ad.iid and (unitKey .. "#" .. tostring(ad.iid))
        if spell then
            rule, conf = "observed", "observed"
            if L and lkey then self:RecordAura(unitKey, ad, "UNIT_AURA") end   -- collect while clear
        elseif L and lkey and L.data.aura and L.data.aura[lkey] then
            -- resolve through the ledger: this instance was seen clear earlier (refresh / re-add of a known iid)
            local e, lconf = L:Get("aura", lkey)
            spell, rule, conf = e.spell, "ledger", (lconf == "cached-stale") and "low" or "medium"
            self.counters.ledger = (self.counters.ledger or 0) + 1
        else
            local r = self:explain(unitKey, ad.helpful, now)
            if r then
                local appl = self:Appliers(ad.helpful)
                rule = (#appl == 1) and "single-applier" or "cast-correlation"
                conf = (#appl == 1 or ad.fromPlayer == true) and "high" or "medium"
                spell = r.spell
            end
        end
        if not spell and ad.iid then   -- may be explained by a SUCCEEDED that arrives just after the aura (log order)
            push(self.unexplained, { t = now, unit = unitKey, iid = ad.iid, helpful = ad.helpful, fromPlayer = ad.fromPlayer }, 32)
        end
        local k = spell and self.knowledge[spell]
        local dur = ad.duration or (k and k.aura and k.aura.duration)
        local a = { spell = spell, iid = ad.iid, since = now, duration = dur, expires = dur and dur > 0 and (now + dur) or nil,
            applications = ad.applications, source = (rule == "observed") and "observed" or (rule and "inferred" or "unknown"),
            rule = rule or "none", conf = conf or "low", fromPlayer = ad.fromPlayer }
        self:addAura(unitKey, ad.iid and ("i" .. tostring(ad.iid)) or ("n" .. now), a)
        if ad.iid and spell then self.iidMap[unitKey .. "#" .. tostring(ad.iid)] = { spell = spell, rule = rule, conf = conf } end
        if spell then self:verify(spell, unitKey, rule) end
        if rule and rule ~= "observed" then
            self:infer({ rule = rule, kind = "applied", unit = unitKey, spell = spell, iid = ad.iid, conf = conf, expires = a.expires })
        elseif rule == "observed" then
            self:infer({ rule = "observed", kind = "applied", unit = unitKey, spell = spell, iid = ad.iid, conf = "observed", expires = a.expires })
        end
    end
    -- MINOR 4: a secret removed-list (presence readable) on a unit with exactly one live cached aura removes that one
    -- (ledger elimination); with several candidates they all turn stale (shown grey, not claimed as present)
    if L and info.removedSecret and not self.legacy then
        local cand, n = nil, 0
        for _, a in ipairs(self:CachedAuras(unitKey)) do n = n + 1 cand = a end
        if n == 1 and cand.lkey then
            L:Remove("aura", cand.lkey)
            self.cachedIdx[unitKey][cand.lkey] = nil
            self.counters.ledger = (self.counters.ledger or 0) + 1
            self:infer({ rule = "ledger-elimination", kind = "removed", unit = unitKey, spell = cand.spell, conf = "medium" })
        elseif n > 1 then
            for lkey in pairs(self.cachedIdx[unitKey] or {}) do L:Invalidate("aura", lkey) end
        end
    end
    for _, iid in ipairs(info.removed or {}) do
        local key = "i" .. tostring(iid)
        local a = u.auras[key]
        local m = self.iidMap[unitKey .. "#" .. tostring(iid)]
        local lkey = unitKey .. "#" .. tostring(iid)
        if L and not (a or m) then
            local e, lconf = L:Get("aura", lkey)
            if e then
                self.counters.ledger = (self.counters.ledger or 0) + 1
                self:infer({ rule = "ledger", kind = "removed", unit = unitKey, spell = e.spell, iid = iid,
                    conf = (lconf == "cached-stale") and "low" or "medium", age = now - (e.applied or now) })
            end
        end
        if L then
            L:Remove("aura", lkey)
            if self.cachedIdx[unitKey] then self.cachedIdx[unitKey][lkey] = nil end
        end
        if a or m then
            local spell = (a and a.spell) or (m and m.spell)
            self:infer({ rule = "iid-map", kind = "removed", unit = unitKey, spell = spell, iid = iid,
                conf = (m and m.conf) or (a and a.conf) or "low" })
            local kk = spell and self.knowledge[spell]
            if a and a.expires and now < a.expires - self.tolerance and kk and kk.aura and kk.aura.consumable then
                -- charge-based aura (Lightning Shield balls, ...): consumed early by design -> unverified, no contradiction
                self:verdict("aura-expiry", "U", { spell = spell, src = "UNIT_AURA removed (consumable)", conf = a.conf, d = a.expires - now })
            elseif a and a.expires and now < a.expires - self.tolerance then
                self:contradict({ kind = "aura-gone-early", unit = unitKey, spell = spell, early = a.expires - now, rule = a.rule })
                if a.pred then a.pred.outcome = "contradicted" end
                self:verdict("aura-expiry", "C", { spell = spell, src = "UNIT_AURA removed", conf = a.conf, d = a.expires - now })
            elseif a and a.expires then
                self:verdict("aura-expiry", "V", { spell = spell, src = "UNIT_AURA removed", conf = a.conf, d = a.expires - now })
            end
            u.auras[key] = nil
            self.iidMap[unitKey .. "#" .. tostring(iid)] = nil
        end
    end
end

-- readable count deltas: +n after my cast -> inferred application(s) of that cast's aura
function M:OnCount(unitKey, filter, count)
    if type(count) ~= "number" then self.counters.unreadable = self.counters.unreadable + 1 return end
    local now = self.now()
    local u = self:unit(unitKey)
    local prev = u.counts[filter]
    u.counts[filter] = count
    if prev == nil or count == prev then return end
    local helpful = filter:find("HELPFUL") ~= nil
    if count > prev and filter:find("PLAYER") then
        local r = self:explain(unitKey, helpful, now)
        if r then
            local appl = self:Appliers(helpful)
            local k = self.knowledge[r.spell]
            local dur = k and k.aura and k.aura.duration
            local rule = (#appl == 1) and "single-applier" or "count-delta"
            local a = { spell = r.spell, since = now, duration = dur, expires = dur and (now + dur) or nil, source = "inferred",
                rule = rule, conf = (#appl == 1) and "high" or "medium" }
            self:addAura(unitKey, "c" .. tostring(r.spell), a)
            self:infer({ rule = rule, kind = "applied", unit = unitKey, spell = r.spell, conf = a.conf, expires = a.expires, delta = count - prev })
            self:verify(r.spell, unitKey, rule)
        end
    elseif count < prev then
        self:infer({ rule = "count-delta", kind = "removed", unit = unitKey, conf = "medium", delta = count - prev, filter = filter })
    end
end

-- live verification: the newest open prediction for this spell (and unit when known) gets the rule that confirmed it
function M:verify(spell, unitKey, rule)
    local now = self.now()
    for i = #self.recent, 1, -1 do
        local r = self.recent[i]
        if now - r.t > self.window * 4 then break end
        local p = r.pred
        local unitOk = (p and p.aura and (p.aura.unit == nil or p.aura.unit == unitKey))
            or (p and not p.aura and rule == "observed" and (p.unit == nil or p.unit == unitKey or unitKey == "player"))
        if p and p.spell == spell and p.outcome == nil and unitOk then
            -- v2.2.3: a prediction without aura knowledge (Ghost Wolf, run 4) is confirmed by an observed aura with the
            -- same clear spellId; the aura becomes knowledge (duration 0 = until cancelled)
            p.outcome = "aura seen (" .. tostring(rule) .. ")"
            self.version = self.version + 1
            local u = self.units[unitKey]
            if u then for _, a in pairs(u.auras) do if a.spell == spell and a.since >= p.t then a.pred = p end end end
            return p
        end
    end
end

-- v2.2.3: in combat UNIT_AURA's addedAuras is a wholly secret list or nil (run 3/4). "secret" vs nil is itself a clear
-- yes/no, so an added-aura event on the predicted unit inside the window confirms the newest open aura prediction by
-- event timing only (no field is read). Weaker than "observed": outcome says so, conf medium.
function M:verifyTiming(unitKey, now)
    for i = #self.recent, 1, -1 do
        local r = self.recent[i]
        if now - r.t > self.timingWindow then break end   -- v2.2.4: 0.35 s (was window*4 = 2.4 s: run 5 showed it can
        local p = r.pred                                     -- swallow another player's aura); legacy keeps 2.4 s
        if p and p.aura and p.outcome == nil and (p.aura.unit == nil or p.aura.unit == unitKey) then
            p.outcome = "aura event seen (secret payload, timing)"
            p.timingOnly = true
            self:infer({ rule = "secret-timing", kind = "applied", unit = unitKey, spell = p.spell, conf = "medium",
                auraId = p.aura and p.aura.id,   -- MINOR 4: the debuff/buff spellID my cast applies (learned mapping)
                expires = p.aura.expires, src = "mine" })
            return p
        end
    end
end

function M:Tick()
    local now = self.now()
    if self.shadowFindings and self.shadowDm7Expect and (now - self.shadowDm7Expect) > ((self.dmWindow or 0.03) + 0.1) then
        self:verdict("shadow-dm-type7", "U", { src = "DAMAGE_METER type 7 with no UNIT_COMBAT wound", conf = "medium",
            d = now - self.shadowDm7Expect })
        self.shadowDm7Expect = nil
    end
    for i = #self.recent, 1, -1 do
        local p = self.recent[i].pred
        if p and p.aura and p.outcome == nil and now - p.t > self.window * 4 then p.outcome = "no aura seen" end
    end
    for unitKey, u in pairs(self.units) do
        local any = false
        for key, a in pairs(u.auras) do
            if a.expires and now > a.expires + self.tolerance and a.source ~= "observed" then
                u.auras[key] = nil
                self:verdict("aura-expiry", "U", { spell = a.spell, src = "predicted-expiry (removal not readable)", conf = a.conf })
                self:infer({ rule = "predicted-expiry", kind = "expired", unit = unitKey, spell = a.spell, conf = a.conf })
            elseif not a.expires and a.source ~= "observed" and now - (a.since or now) > (self.unknownTTL or 300) then
                u.auras[key] = nil   -- v2.2.3: unknown-duration auras no longer accumulate forever
                self.version = self.version + 1
            else any = true end
        end
        -- v2.2.3: drop empty per-unit state (one entry per GUID seen used to stay for the whole session)
        if not any and unitKey ~= "player" and not (self.casts[unitKey] and self.casts[unitKey].active) then
            self.units[unitKey] = nil
            self.casts[unitKey] = nil
        end
    end
    for id, c in pairs(self.cooldowns) do if c.ends and c.ends <= now then self.cooldowns[id] = nil self.version = self.version + 1 end end
end

-- ledger: auraInstanceID -> identity, recorded while clear (UNIT_AURA addedAuras, or an out-of-combat full scan).
-- ad = { iid, spellId, duration, expirationTime?, helpful, fromPlayer }
function M:RecordAura(unitKey, ad, src)
    local L = self.ledger
    if not (L and ad and ad.iid and ad.spellId) then return nil end
    local now, dur = self.now(), ad.duration
    local exp = ad.expirationTime
    if not (type(exp) == "number" and exp > 0) then exp = (type(dur) == "number" and dur > 0) and (now + dur) or false end
    local lkey = unitKey .. "#" .. tostring(ad.iid)
    local old = L.data.aura and L.data.aura[lkey]
    if not old and self.onAuraRecord then pcall(self.onAuraRecord, unitKey, ad, now) end   -- learned DB: cast -> aura map
    L:Put("aura", lkey, { spell = ad.spellId, duration = dur, helpful = ad.helpful, fromPlayer = ad.fromPlayer, unit = unitKey,
        applied = old and old.applied or now, expires = exp }, src or "UNIT_AURA")
    self.cachedIdx[unitKey] = self.cachedIdx[unitKey] or {}
    self.cachedIdx[unitKey][lkey] = true
    return lkey
end

-- auras of a unit known from the ledger (seen clear earlier, not removed, not past their cached expiry): what the HSM
-- believes is present during a secret period. Each: { spell, conf ("cached-fresh"/"cached-stale"), age, expires }
function M:CachedAuras(unitKey)
    local out = {}
    local L, idx = self.ledger, self.cachedIdx[unitKey]
    if not (L and idx) then return out end
    local now = self.now()
    for lkey in pairs(idx) do
        local e = L.data.aura and L.data.aura[lkey]
        if not e then idx[lkey] = nil
        elseif e.expires and e.expires ~= false and now > e.expires + self.tolerance then idx[lkey] = nil
        else
            local age = now - (e.t or now)
            -- maybe-removed: an ambiguous secret removal hit this unit since the value was cached (never claimed as present)
            out[#out + 1] = { spell = e.spell, conf = e.stale and "maybe-removed" or (age > L.fresh and "cached-stale" or "cached-fresh"), age = age,
                expires = e.expires ~= false and e.expires or nil, applied = e.applied, lkey = lkey, invalidated = e.stale or nil }
        end
    end
    return out
end

function M:UnitState(unitKey) return self.units[unitKey] end

-- PLAYER_TOTEM_UPDATE(slot) + GetTotemInfo(slot): have/name/start/duration, each nil when unreadable (secret).
-- A new totem verifies the newest open summon prediction (name match when readable, else the newest within the window);
-- a readable engine duration is compared with the predicted lifetime.
function M:OnTotem(slot, have, name, duration)
    local now = self.now()
    self.version = self.version + 1
    local prev = self.totems[slot]
    if have == true then
        if prev and prev.pred and prev.pred.summon then prev.pred.summon.endedAt = now - prev.pred.t end
        if prev then self:infer({ rule = "totem-update", kind = "summon-replaced", unit = "player", spell = prev.spell, slot = slot, conf = "high" }) end
        local best
        for i = #self.summons, 1, -1 do
            local s = self.summons[i]
            if s.pred.outcome == nil and now - s.t <= self.window * 4 and (name == nil or s.name == nil or s.name == name) then best = s break end
        end
        self.totems[slot] = { since = now, name = name, duration = duration, spell = best and best.spell, pred = best and best.pred }
        if best then
            local p = best.pred
            p.outcome = "totem seen (GetTotemInfo)"
            if type(duration) == "number" and duration > 0 then
                p.summon.engineDuration = duration
                if p.summon.duration and math.abs(p.summon.duration - duration) > self.tolerance then
                    self:contradict({ kind = "summon-duration", spell = best.spell, predicted = p.summon.duration, engine = duration })
                end
            end
            self:infer({ rule = "totem-update", kind = "summoned", unit = "player", spell = best.spell, slot = slot, conf = "high",
                expires = p.summon.expires })
        else
            self:infer({ rule = "totem-update", kind = "summoned", unit = "player", slot = slot, conf = "low" })
        end
    elseif have == false and prev then
        local p = prev.pred
        local early = p and p.summon and p.summon.expires and (p.summon.expires - now) or nil
        if p and p.summon then p.summon.endedAt = now - p.t end
        self:infer({ rule = "totem-update", kind = (early and early > self.tolerance) and "summon-ended-early" or "summon-ended",
            unit = "player", spell = prev.spell, slot = slot, conf = "high", early = early })
        self.totems[slot] = nil
    end
end


----------------------------------------------------------------------------
-- Ledger (MINOR 3, v2.2.4): "collect while available, retain, resolve later". Every value seen CLEAR is recorded with a
-- timestamp and source; during secret periods lookups resolve through it with a confidence derived from staleness.
-- Kinds (free-form strings): "guid" (GUID -> name/class/level/hpMax/powerMax/isPlayer/friend), "token" (unit token ->
-- last clear GUID), "aura" (unitKey#auraInstanceID -> spellId/duration/helpful/fromPlayer/applied), "cast" (unitKey ->
-- last clear cast), "plate" (nameplateN -> GUID). Per-kind LRU caps; eviction is an amortised O(1) sweep by access stamp.
-- Values must be clear (the caller checks); nothing here reads the game.
----------------------------------------------------------------------------
local LedgerM = {}
LedgerM.__index = LedgerM
local LEDGER_CAPS = { guid = 300, token = 64, aura = 400, cast = 64, plate = 40, fingerprint = 300 }
Lib.LEDGER_CAPS = LEDGER_CAPS

function Lib.NewLedger(opts)
    opts = opts or {}
    local l = setmetatable({}, LedgerM)
    l.now = opts.now or defaultNow
    l.caps = {}
    for k, v in pairs(LEDGER_CAPS) do l.caps[k] = v end
    for k, v in pairs(opts.caps or {}) do l.caps[k] = v end
    l.fresh = opts.fresh or 10        -- s: younger = "cached-fresh" (high), older = "cached-stale" (low)
    l.data, l.n, l.seq, l.version = {}, {}, 0, 0
    l.stats = { puts = 0, live = 0, fresh = 0, stale = 0, miss = 0, evicted = 0, invalidated = 0 }
    return l
end

function LedgerM:sweep(kind)
    local t, cap = self.data[kind], self.caps[kind] or 100
    local slack = math.max(8, math.floor(cap / 4))
    if (self.n[kind] or 0) <= cap + slack then return end
    -- keep the `cap` most recently touched: stamps are unique and increasing, so everything older than seq - cap goes
    local cut, n = self.seq - cap, 0
    for k, e in pairs(t) do
        if e.seq <= cut then t[k] = nil self.stats.evicted = self.stats.evicted + 1 else n = n + 1 end
    end
    self.n[kind] = n
end

-- record clear fields for (kind, key); fields merge into the entry (nil fields keep the older clear value)
function LedgerM:Put(kind, key, fields, src)
    if key == nil or type(fields) ~= "table" then return nil end
    local t = self.data[kind]
    if not t then t = {} self.data[kind] = t end
    local e = t[key]
    if not e then e = {} t[key] = e self.n[kind] = (self.n[kind] or 0) + 1 end
    local changed = false
    for k, v in pairs(fields) do if e[k] ~= v then e[k] = v changed = true end end
    self.seq = self.seq + 1
    e.seq, e.t, e.src = self.seq, self.now(), src or e.src
    e.first = e.first or e.t
    e.stale = nil
    self.stats.puts = self.stats.puts + 1
    if changed then self.version = self.version + 1 end
    self:sweep(kind)
    return e
end

-- entry, confidence ("live" same frame / "cached-fresh" / "cached-stale"), age in s
function LedgerM:Get(kind, key)
    local t = self.data[kind]
    local e = t and key ~= nil and t[key]
    if not e then self.stats.miss = self.stats.miss + 1 return nil end
    self.seq = self.seq + 1
    e.seq = self.seq
    local age = self.now() - e.t
    local conf = (age <= 0.05 and not e.stale and "live") or ((age <= self.fresh and not e.stale) and "cached-fresh") or "cached-stale"
    self.stats[conf == "live" and "live" or (conf == "cached-fresh" and "fresh" or "stale")] =
        self.stats[conf == "live" and "live" or (conf == "cached-fresh" and "fresh" or "stale")] + 1
    return e, conf, age
end

-- the mapping may no longer hold (token changed while its GUID is unreadable): keep the value, mark it stale
function LedgerM:Invalidate(kind, key)
    local e = self.data[kind] and self.data[kind][key]
    if e and not e.stale then e.stale = true self.stats.invalidated = self.stats.invalidated + 1 self.version = self.version + 1 end
end

function LedgerM:Remove(kind, key)
    local t = self.data[kind]
    if t and t[key] then t[key] = nil self.n[kind] = (self.n[kind] or 1) - 1 self.version = self.version + 1 end
end

function LedgerM:Count(kind) return self.n[kind] or 0 end

-- fingerprint resolution for a secret GUID: clear signals (class, level, hpMax, isPlayer, friend) matched against the
-- GUID entries recorded while clear. Unique match -> medium, several -> low (first returned), none -> nil
function LedgerM:Fingerprint(fp)
    if type(fp) ~= "string" or fp == "" then return nil end
    local e = self.data.fingerprint and self.data.fingerprint[fp]
    if not e then return nil end
    return e.guid, (e.count or 1) == 1 and "medium" or "low"
end
function LedgerM:PutFingerprint(fp, guid)
    if type(fp) ~= "string" or fp == "" or guid == nil then return end
    local e = self.data.fingerprint and self.data.fingerprint[fp]
    if e and e.guid ~= guid then
        self:Put("fingerprint", fp, { guid = guid, count = (e.count or 1) + 1 }, "fingerprint")
    elseif not e then self:Put("fingerprint", fp, { guid = guid, count = 1 }, "fingerprint") end
end

-- SavedVariables-safe summary: counts only (names/GUIDs stay in memory)
function LedgerM:Export()
    local n = {}
    for k, v in pairs(self.n) do n[k] = v end
    local st = {}
    for k, v in pairs(self.stats) do st[k] = v end
    return { counts = n, stats = st, caps = self.caps }
end

----------------------------------------------------------------------------
-- MINOR 3: fights + source attribution (clear inputs only: UNIT_COMBAT, PLAYER_SWING, DAMAGE_METER_* event type,
-- my UNIT_SPELLCAST_SUCCEEDED, UNIT_SPELLCAST_INTERRUPTED timing). Every attribution carries its rule.
----------------------------------------------------------------------------
local function newFight(t)
    return { start = t, dmg = { mine = 0, other = 0, mineN = 0, otherN = 0, crit = 0, miss = 0, rules = {} }, otherSchools = {},
        taken = { amount = 0, n = 0, miss = 0 }, heal = { mine = 0, other = 0, mineN = 0, otherN = 0, rules = {} },
        interrupts = { mine = 0, other = 0 }, dispels = { mine = 0, other = 0 },
        auras = { mine = 0, other = 0 }, power = 0,
        -- v2.2.6: live running estimates (own casts + meter timing + UNIT_COMBAT) for post-combat self-reconcile.
        -- world[unitKey] = per-unit taken/dmg/heal/interrupt/dispel estimates keyed by identity IdKey when known.
        liveEst = { damage = 0, healing = 0, interrupts = 0, dispels = 0, taken = 0, dmTicks = {} },
        world = {} }
end

local function worldIdKey(self, unitKey)
    if not unitKey or unitKey == "player" then return "player" end
    if self.idKey then
        local kind = "guid"
        if type(unitKey) == "string" then
            if unitKey:find("^Player%-") then kind = "player"
            elseif unitKey:find("^Creature%-") or unitKey:find("^Vehicle%-") then
                local nid = unitKey:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
                    or unitKey:match("^Vehicle%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
                if nid then return "npc:" .. nid end
                kind = "npc"
            elseif unitKey:find("^Pet%-") then kind = "pet"
            elseif unitKey:find("^npc:") or unitKey:find("^player:") or unitKey:find("^pet:") then return unitKey
            end
        end
        return self.idKey(kind, unitKey) or unitKey
    end
    if type(unitKey) == "string" then
        local nid = unitKey:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
        if nid then return "npc:" .. nid end
    end
    return unitKey
end

local function worldUnit(self, f, unitKey)
    if not unitKey then return nil end
    local w = f.world[unitKey]
    if not w then
        w = { taken = 0, takenN = 0, dmg = 0, dmgN = 0, heal = 0, healN = 0, interrupts = 0, dispels = 0,
            dmTicks = {}, lastTakenT = nil, dtps = 0, idKey = worldIdKey(self, unitKey) }
        f.world[unitKey] = w
        if w.idKey and w.idKey ~= unitKey then f.world[w.idKey] = f.world[w.idKey] or w end
    end
    return w
end

local function liveBump(f, field, amt)
    local e = f.liveEst
    if not e then return end
    e[field] = (e[field] or 0) + (amt or 0)
end

function M:Fight() return self.fight end

function M:OnCombatState(inCombat)
    local now = self.now()
    self.version = self.version + 1
    if self.hp.player then self:hpAnchor(self.hp.player, now) end
    self.inCombat = inCombat and true or false
    if inCombat then
        if self.fight and not self.fight.stop and not self.fight.soft then return self.fight end
        if self.fight and not self.fight.stop then self.fight.stop = now end   -- close an after-combat soft record
        self.fight = newFight(now)
        push(self.fights, self.fight, 10)
        self:infer({ rule = "regen", kind = "combat-start", conf = "observed" })
    elseif self.fight and not self.fight.stop then
        self.fight.stop = now
        self:infer({ rule = "regen", kind = "combat-end", conf = "observed", mine = self.fight.dmg.mine, other = self.fight.dmg.other })
    end
    return self.fight
end

-- a successful cast of mine within w seconds before (or the same frame after) now; offensive = only casts that did
-- not land on the player (a self heal in the same frame must not claim another player's hit)
function M:ownWithin(now, w, offensive)
    for i = #self.ownRecent, 1, -1 do
        local r = self.ownRecent[i]
        local dt = now - r.t
        if dt > w then break end
        -- a summon counts as offensive: a totem's debuff (Earthbind) lands on the target with no cast at the target
        if dt >= -self.sameFrame and not (offensive and r.target == "player" and not r.summon) then return r end
    end
end

function M:OnSwing()
    push(self.swings, { t = self.now() }, 8)
end

function M:OnDamageMeter(dmType)
    if type(dmType) ~= "number" then return end
    local now = self.now()
    self.dmLast[dmType] = now
    local f = self.fight
    if f and f.liveEst then
        f.liveEst.dmTicks[dmType] = (f.liveEst.dmTicks[dmType] or 0) + 1
    end
    -- type 6 = Dispels: join with a recent own dispel-capable cast (no CLEU SPELL_DISPEL live)
    if dmType == 6 and f then
        local own = self:ownWithin(now, self.sameFrame or 0.05, true)
        local k = own and own.spell and self.knowledge[own.spell]
        if own and k and k.dispel then
            f.dispels.mine = f.dispels.mine + 1
            liveBump(f, "dispels", 1)
            self:infer({ rule = "dispel-cast+dm", kind = "dispel", unit = own.target, src = "mine",
                spell = own.spell, conf = "high" })
        end
    end
    -- shadow: DM type 7 ↔ enemy melee on me (finding dm-type-7); expect a WOUND shortly
    if self.shadowFindings and dmType == 7 then
        self.shadowDm7Expect = now
    end
end

local function dmNear(self, now, types, w)
    for _, ty in ipairs(types) do
        local t = self.dmLast[ty]
        if t and math.abs(now - t) <= w then return ty end
    end
end
local DM_DAMAGE, DM_HEAL, DM_INTERRUPT, DM_TAKEN = { 0, 1, 10 }, { 2, 3 }, { 5 }, { 7 }

local function fightOrOpen(self, now)
    if not self.fight or self.fight.stop then
        -- UNIT_COMBAT outside a REGEN window (e.g. heals ticking after combat): a soft fight record is opened lazily
        self.fight = newFight(now)
        self.fight.soft = true
        push(self.fights, self.fight, 10)
    end
    return self.fight
end

local MISS = { MISS = true, DODGE = true, PARRY = true, BLOCK = true, RESIST = true, IMMUNE = true, EVADE = true, ABSORB = true,
    DEFLECT = true, REFLECT = true }
Lib.MISS = MISS

-- the rule that makes a hostile-unit UNIT_COMBAT mine (nil = someone else's)
function M:damageRule(now, school)
    if self:ownWithin(now, self.sameFrame, true) then return "cast-frame", "high" end
    if dmNear(self, now, DM_DAMAGE, self.dmWindow) then return "dm-frame", "high" end
    for i = #self.swings, 1, -1 do
        local s = self.swings[i]
        local dt = now - s.t
        if math.abs(dt) <= self.sameFrame and not s.used then s.used = true return "swing-frame", "high" end
    end
    if school == nil or school == 1 then   -- melee lands in combat text ~0.46 s after PLAYER_SWING (physical school)
        for i = 1, #self.swings do
            local s = self.swings[i]
            local dt = now - s.t
            if not s.used and dt >= self.swingLag[1] and dt <= self.swingLag[2] then s.used = true return "swing-lag", "medium" end
        end
    end
end

function M:OnUnitCombat(unitKey, action, flag, amount, school, isPlayerUnit)
    if self.legacy or type(action) ~= "string" then return nil end
    local now = self.now()
    local f = fightOrOpen(self, now)
    local amt = type(amount) == "number" and amount or 0
    self.version = self.version + 1
    if isPlayerUnit then
        if action == "HEAL" then
            local rule, conf
            local own = self:ownWithin(now, self.sameFrame)
            if own and own.target == "player" then rule, conf = "cast-frame", "high"
            elseif dmNear(self, now, DM_HEAL, self.dmWindow) then rule, conf = "dm-frame", "high"
            else
                local function onBeat(d)
                    local ph = d % self.healPeriod
                    return d >= self.healPeriod - self.healJitter and (ph <= self.healJitter or self.healPeriod - ph <= self.healJitter)
                end
                if self.lastMineHeal and now - self.lastMineHeal <= self.healPeriod * 8 + self.healJitter and onBeat(now - self.lastMineHeal) then
                    rule, conf = "heal-cadence", "medium"
                else
                    -- seed: a periodic heal on the beat of one of my live summons (Healing Stream Totem: 2 s from the drop;
                    -- overheals do not move the meter, so the DM rule cannot seed while I am at full health)
                    for i = #self.summons, 1, -1 do
                        local sm = self.summons[i]
                        local life = sm.pred and sm.pred.summon and sm.pred.summon.duration or 120
                        local d = now - sm.t
                        if d <= life + self.healJitter and onBeat(d) and d <= self.healPeriod * 40 then rule, conf = "summon-cadence", "medium" break end
                    end
                end
            end
            if rule == "cast-frame" and self.onAmount then
                if own and own.spell then pcall(self.onAmount, own.spell, "heal", amt, flag == "CRITICAL", school) end
            end
            if rule then
                f.heal.mine, f.heal.mineN = f.heal.mine + amt, f.heal.mineN + 1
                liveBump(f, "healing", amt)
                if rule ~= "cast-frame" then self.lastMineHeal = now end
            else f.heal.other, f.heal.otherN = f.heal.other + amt, f.heal.otherN + 1 end
            f.heal.rules[rule or "other"] = (f.heal.rules[rule or "other"] or 0) + 1
            local est = self:hpApply("player", amt, now)
            local healRec = self:infer({ rule = rule or "elimination", kind = "heal", unit = "player", src = rule and "mine" or "other",
                amount = amt, crit = flag == "CRITICAL" or nil, conf = conf or "medium",
                overhealEst = est and est.over, hpConf = est and est.conf })
            -- shadow: totem-heal (6371) finding — HEAL without own cast while a summon is on its heal beat
            if self.shadowFindings and rule ~= "cast-frame" then
                local totemish = (rule == "summon-cadence" or rule == "heal-cadence" or rule == "dm-frame")
                local hasSummon = false
                for i = #self.summons, 1, -1 do
                    local sm = self.summons[i]
                    local life = sm.pred and sm.pred.summon and sm.pred.summon.duration or 120
                    if now - sm.t <= life + self.healJitter then hasSummon = true break end
                end
                if totemish then
                    self:verdict("shadow-totem-heal", "V", { src = rule or "totem-heal", conf = conf or "medium", spell = 6371 })
                    self.shadowTotemHealN = (self.shadowTotemHealN or 0) + 1
                elseif hasSummon and not rule then
                    -- non-acting: finding would claim mine; live attributed other — unresolved shadow
                    self:verdict("shadow-totem-heal", "U", { src = "summon alive, heal attributed other", conf = "low", spell = 6371 })
                    self.shadowTotemHealN = (self.shadowTotemHealN or 0) + 1
                end
            end
            return healRec
        elseif action == "ENERGIZE" then
            f.power = f.power + 1
            return nil
        end
        f.taken.n = f.taken.n + 1
        if MISS[action] then f.taken.miss = f.taken.miss + 1
        else
            f.taken.amount = f.taken.amount + amt
            liveBump(f, "taken", amt)
            self:hpApply("player", -amt, now)
            local wu = worldUnit(self, f, "player")
            if wu then
                wu.taken, wu.takenN = wu.taken + amt, wu.takenN + 1
                if wu.lastTakenT and now > wu.lastTakenT then
                    local dt = now - wu.lastTakenT
                    if dt > 0.05 and dt < 8 then wu.dtps = amt / dt end
                end
                wu.lastTakenT = now
                -- join DM type 7 (DamageTaken) timing with this wound
                if dmNear(self, now, DM_TAKEN, self.dmWindow or 0.03) then
                    wu.dmTicks[7] = (wu.dmTicks[7] or 0) + 1
                end
            end
        end
        local rec = self:infer({ rule = "unit-combat", kind = "damage-taken", unit = "player", src = "hostile", amount = amt, action = action,
            crit = flag == "CRITICAL" or nil, conf = "observed" })
        if self.shadowFindings and self.shadowDm7Expect and not MISS[action] then
            local dt = now - self.shadowDm7Expect
            if dt >= -self.sameFrame and dt <= (self.dmWindow or 0.03) + 0.05 then
                self:verdict("shadow-dm-type7", "V", { src = "DAMAGE_METER type 7 + UNIT_COMBAT wound", conf = "high", d = dt })
                self.shadowDm7N = (self.shadowDm7N or 0) + 1
                self.shadowDm7Expect = nil
            end
        end
        return rec
    end
    if action == "HEAL" then return nil end   -- heals on hostiles: not attributed
    local rule, conf = self:damageRule(now, school)
    local src = rule and "mine" or "other"
    if rule == "cast-frame" and not MISS[action] and amt > 0 then   -- predicted damage range vs the clear UNIT_COMBAT amount
        local own = self:ownWithin(now, self.sameFrame, true)
        local k = own and own.spell and self.knowledge[own.spell]
        local r = k and k.amount
        if r and r.kind == "damage" and r.min then
            local crit = flag == "CRITICAL"
            local lo, hi = r.min * (crit and 1.4 or 0.9), (r.max or r.min) * (crit and 2.1 or 1.35)   -- +spell power / crits
            -- above the range = contradiction; below it may be a partial resist / absorb (UNIT_COMBAT does not say):
            -- unverified, not contradicted (run 5: a crit Earth Shock 103 with 17 resisted)
            local v = (amt > hi) and "C" or ((amt < lo) and "U" or "V")
            self:verdict("damage-range", v, { spell = own.spell, src = (v == "U") and "UNIT_COMBAT below range" or "UNIT_COMBAT",
                conf = "medium", d = amt / (r.max or r.min) })
        end
    end
    if rule == "cast-frame" and amt > 0 and not MISS[action] and self.onAmount then   -- learned DB: own damage ranges
        local own = self:ownWithin(now, self.sameFrame, true)
        if own and own.spell then pcall(self.onAmount, own.spell, "damage", amt, flag == "CRITICAL", school) end
    end
    local d = f.dmg
    local wu = worldUnit(self, f, unitKey)
    if rule then
        d.mine, d.mineN = d.mine + amt, d.mineN + 1
        liveBump(f, "damage", amt)
        if wu and not MISS[action] then wu.dmg, wu.dmgN = wu.dmg + amt, wu.dmgN + 1 end
    else
        d.other, d.otherN = d.other + amt, d.otherN + 1
        local sk = tostring(school or "?")
        f.otherSchools[sk] = (f.otherSchools[sk] or 0) + amt
        -- other damage on this token: still counts as that unit's damage-taken live estimate
        if wu and not MISS[action] then
            wu.taken, wu.takenN = wu.taken + amt, wu.takenN + 1
            if wu.lastTakenT and now > wu.lastTakenT then
                local dt = now - wu.lastTakenT
                if dt > 0.05 and dt < 8 then wu.dtps = amt / dt end
            end
            wu.lastTakenT = now
            if dmNear(self, now, DM_DAMAGE, self.dmWindow or 0.03) then
                wu.dmTicks[0] = (wu.dmTicks[0] or 0) + 1
            end
        end
    end
    if flag == "CRITICAL" then d.crit = d.crit + 1 end
    if MISS[action] then d.miss = d.miss + 1 end
    d.rules[rule or "other"] = (d.rules[rule or "other"] or 0) + 1
    return self:infer({ rule = rule or "elimination", kind = "damage", unit = unitKey, src = src, amount = amt, action = action,
        school = school, crit = flag == "CRITICAL" or nil, conf = conf or "medium" })
end

-- UNIT_SPELLCAST_INTERRUPTED on a hostile: my interrupt when my successful cast (or the meter's Interrupts type) is in
-- the same frame; otherwise someone else's interrupt, a stun, LoS or movement (not attributable live)
function M:OnInterrupt(unitKey)
    if self.legacy then return nil end
    local now = self.now()
    -- MINOR 4: one interrupt per unit per frame (target + focus on the same unit, or a replayed duplicate token);
    -- castBarID is per TOKEN on 1.60.1 (target/nameplate1/softenemy carry different ids for one cast), so not a dedupe key
    local li = self.lastInterrupt
    if li and li.unit == unitKey and math.abs(now - li.t) <= self.sameFrame then return nil end
    self.lastInterrupt = { unit = unitKey, t = now }
    local ec = self.lastClosed
    local elapsed = (ec and ec.unit == unitKey and ec.outcome == "interrupted" and math.abs(now - ec.tEnd) <= self.sameFrame) and ec or nil
    local f = fightOrOpen(self, now)
    local own = self:ownWithin(now, self.sameFrame, true)
    local dm = dmNear(self, now, DM_INTERRUPT, 0.1)
    local k = own and own.spell and self.knowledge[own.spell]
    local rule, conf, src
    if own and (dm or (k and k.interrupt)) then rule, conf, src = "interrupt-cast+dm", "high", "mine"
    elseif own then rule, conf, src = "interrupt-cast-frame", "medium", "mine"
    else rule, conf, src = "elimination", "low", "other" end
    f.interrupts[src] = f.interrupts[src] + 1
    if src == "mine" then liveBump(f, "interrupts", 1) end
    local wu = worldUnit(self, f, unitKey)
    if wu then wu.interrupts = wu.interrupts + 1 end
    self:verdict("interrupt-attribution", (rule == "interrupt-cast+dm") and "V" or "U",
        { src = rule, conf = conf, spell = own and own.spell })
    if own and own.spell and src == "mine" then
        local kk = self.knowledge[own.spell] or {}
        if not kk.interrupt then kk.interrupt = true self.knowledge[own.spell] = kk end
    end
    return self:infer({ rule = rule, kind = "interrupt", unit = unitKey, src = src, spell = own and own.spell, conf = conf,
        elapsed = elapsed and elapsed.elapsed, predicted = elapsed and elapsed.pred })
end

-- post-combat C_DamageMeter read (clear after combat): rec = {
--   damage/healing/interrupts/dispels/taken = my totals,
--   others = others' damage Done total,
--   spells = { [id] = amount }, duration = s,
--   sources = { DamageDone = { { id=, total=, isLocalPlayer=, spells= }, ... }, HealingDone=..., ... }
-- }. Reconciles live estimates vs meter; per-unit where sources are present. Verdicts: match / off by X / unexplained.
local function metricCmp(live, dm, tolAbs, tolRel)
    if type(dm) ~= "number" then return "unexplained", nil, nil end
    live = type(live) == "number" and live or 0
    local d = live - dm
    local tol = math.max(tolAbs or 5, math.abs(dm) * (tolRel or 0.02))
    if math.abs(d) <= tol then return "match", d, tol end
    return "off", d, tol
end

function M:ReconcileDM(rec)
    if type(rec) ~= "table" then return nil end
    local f
    for i = #self.fights, 1, -1 do if not self.fights[i].soft then f = self.fights[i] break end end
    if not f or f.dm then return nil end
    f.dm = rec
    -- sync liveEst from fight totals (authoritative running sums) before compare
    local le = f.liveEst or {}
    le.damage = f.dmg.mine
    le.healing = f.heal.mine
    le.interrupts = f.interrupts.mine
    le.dispels = (f.dispels and f.dispels.mine) or le.dispels or 0
    le.taken = f.taken.amount
    f.liveEst = le

    local out = { rule = "dm-reconcile", kind = "reconcile", conf = "high", metrics = {}, units = {} }
    local verdicts = {}

    local function one(name, live, dm, tolAbs)
        local status, d, tol = metricCmp(live, dm, tolAbs, 0.02)
        local row = { name = name, live = live, dm = dm, delta = d, status = status, tol = tol }
        out.metrics[name] = row
        verdicts[#verdicts + 1] = row
        if status == "match" then
            self:verdict("dm-" .. name, "V", { src = "match", conf = "high", d = d })
        elseif status == "off" and d and d > 0 then
            -- damage keeps the historical contradiction kind (tests/hsm.lua + offline scorers)
            local ck = (name == "damage") and "self-attribution-exceeds-dm" or ("self-attribution-exceeds-dm-" .. name)
            self:contradict({ kind = ck, live = live, dm = dm, rule = "dm-reconcile" })
            self:verdict("dm-" .. name, "C", { src = "off by +" .. tostring(d), conf = "high", d = d })
        elseif status == "off" then
            self:verdict("dm-" .. name, "U", { src = "off by " .. tostring(d) .. " (live under meter)", conf = "medium", d = d })
        else
            self:verdict("dm-" .. name, "U", { src = "unexplained (no meter value)", conf = "low" })
        end
        return row
    end

    one("damage", le.damage, rec.damage)
    one("healing", le.healing, rec.healing)
    one("interrupts", le.interrupts, rec.interrupts, 0)
    one("dispels", le.dispels, rec.dispels, 0)
    one("taken", le.taken, rec.taken)

    out.dmMine, out.liveMine, out.liveOther = rec.damage, f.dmg.mine, f.dmg.other
    out.liveTotal = f.dmg.mine + f.dmg.other
    if type(rec.damage) == "number" then
        out.othersOnTarget = math.max(0, out.liveTotal - rec.damage)
    end
    out.dmHeal, out.liveHeal = rec.healing, f.heal.mine
    out.dmInterrupts, out.liveInterrupts = rec.interrupts, f.interrupts.mine
    out.dmDispels, out.liveDispels = rec.dispels, le.dispels
    out.dmTaken, out.liveTaken = rec.taken, f.taken.amount

    -- per-unit: meter sources keyed by IdKey / player / npc:ID vs fight.world
    if type(rec.sources) == "table" then
        local byId = {}
        local function ingest(typeName, field)
            local list = rec.sources[typeName]
            if type(list) ~= "table" then return end
            for _, src in ipairs(list) do
                local id = src.id or (src.isLocalPlayer and "player") or nil
                if id then
                    local u = byId[id] or { id = id, kind = src.kind, class = src.class, isMe = src.isLocalPlayer }
                    byId[id] = u
                    if type(src.total) == "number" then u[field] = (u[field] or 0) + src.total end
                end
            end
        end
        ingest("DamageDone", "damage")
        ingest("HealingDone", "healing")
        ingest("Interrupts", "interrupts")
        ingest("Dispels", "dispels")
        ingest("DamageTaken", "taken")
        ingest("EnemyDamageTaken", "enemyTaken")

        for id, meterU in pairs(byId) do
            local liveU = (f.world and f.world[id]) or nil
            if id == "player" then
                liveU = liveU or {}
                liveU.dmg = f.dmg.mine
                liveU.heal = f.heal.mine
                liveU.taken = f.taken.amount
                liveU.interrupts = f.interrupts.mine
                liveU.dispels = le.dispels
            end
            local row = { id = id, kind = meterU.kind, isMe = meterU.isMe, meter = meterU, live = liveU, status = {} }
            for _, fld in ipairs({ "damage", "healing", "interrupts", "dispels", "taken" }) do
                local liveV = liveU and (liveU[fld] or liveU[(fld == "damage" and "dmg") or (fld == "healing" and "heal") or fld]) or nil
                local tolA = (fld == "interrupts" or fld == "dispels") and 0 or 5
                local st, d = metricCmp(liveV, meterU[fld], tolA, 0.05)
                row.status[fld] = { status = st, live = liveV, dm = meterU[fld], delta = d }
            end
            -- overall: match if all present metrics match; else off / unexplained
            local anyOff, anyUnex, anyMatch = false, false, false
            for _, s in pairs(row.status) do
                if s.dm ~= nil then
                    if s.status == "match" then anyMatch = true
                    elseif s.status == "off" then anyOff = true
                    else anyUnex = true end
                end
            end
            row.verdict = anyOff and "off" or (anyUnex and not anyMatch and "unexplained" or (anyMatch and "match" or "unexplained"))
            out.units[id] = row
            self:verdict("dm-unit-" .. (meterU.isMe and "me" or "other"),
                row.verdict == "match" and "V" or (row.verdict == "off" and "C" or "U"),
                { src = id, conf = meterU.isMe and "high" or "medium" })
        end
    end

    -- per-spell checks (mine)
    if type(rec.spells) == "table" then
        local casts = {}
        for _, p in ipairs(self.predictions) do
            if p.t >= f.start and (not f.stop or p.t <= f.stop + 0.5) then casts[p.spell] = (casts[p.spell] or 0) + 1 end
        end
        local checks = {}
        for id, total in pairs(rec.spells) do
            local amt = type(total) == "table" and total.amount or total
            local k = self.knowledge[id]
            local n = casts[id]
            local c = { spell = id, dm = amt, casts = n }
            if k and k.amount and n and k.amount.min and k.amount.max then
                c.min, c.max = k.amount.min * n, k.amount.max * n
                c.inRange = amt >= c.min * 0.5 and amt <= c.max * 2.5
            end
            checks[#checks + 1] = c
        end
        out.spells = checks
    end

    -- summary for HSM UI / Export
    local nMatch, nOff, nUnex = 0, 0, 0
    for _, r in ipairs(verdicts) do
        if r.status == "match" then nMatch = nMatch + 1
        elseif r.status == "off" then nOff = nOff + 1
        else nUnex = nUnex + 1 end
    end
    out.summary = { match = nMatch, off = nOff, unexplained = nUnex }
    f.reconcile = { metrics = out.metrics, summary = out.summary, t = self.now() }
    self.lastReconcile = f.reconcile
    return self:infer(out)
end

-- compact, SavedVariables-safe export (numbers/strings/booleans only)
----------------------------------------------------------------------------
-- MINOR 4: enemy cast-duration model (interrupt window). On 1.60.1 a hostile's UNIT_SPELLCAST_START/SUCCEEDED/STOP/
-- INTERRUPTED carry a clear unit token + castBarID (per token) while castGUID/spellID are secret: the duration from
-- START to SUCCEEDED is learned per NPC (npcID from the clear or ledger-cached GUID, else a fingerprint key) and
-- predicts the remaining time of the next cast of that NPC. Median of the last 8 durations; window = min..max.
----------------------------------------------------------------------------
function Lib.NpcKey(guid)
    if type(guid) ~= "string" then return nil end
    local kind, npc = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    if (kind == "Creature" or kind == "Vehicle") and npc then return "npc:" .. npc end
    if guid:find("^Player%-") then return "player:" .. guid end
    return nil
end

local function median(t)
    local c = {}
    for i = 1, #t do c[i] = t[i] end
    table.sort(c)
    local n = #c
    if n == 0 then return nil end
    if n % 2 == 1 then return c[(n + 1) / 2] end
    return (c[n / 2] + c[n / 2 + 1]) / 2
end

function M:castModelFor(key)
    local m = key and self.castModel[key]
    if not (m and #m.d > 0) then return nil end
    local lo, hi = math.huge, -math.huge
    for _, d in ipairs(m.d) do if d < lo then lo = d end if d > hi then hi = d end end
    return median(m.d), lo, hi, #m.d
end

local CAST_OPEN = { UNIT_SPELLCAST_START = "cast", UNIT_SPELLCAST_CHANNEL_START = "channel" }
function M:OnEnemyCast(event, unitKey, key, bar, spell)
    if unitKey == nil then return nil end
    local now = self.now()
    local mkey = key and (spell and (key .. "#" .. tostring(spell)) or key) or nil
    local c = self.ecast[unitKey]
    if CAST_OPEN[event] then
        if c and c.start and math.abs(now - c.start) <= self.sameFrame then return c end   -- same cast via a 2nd token
        local pred, lo, hi, n = self:castModelFor(mkey)
        if not pred and mkey ~= key then pred, lo, hi, n = self:castModelFor(key) end
        c = { start = now, bar = bar, key = mkey, base = key, kind = CAST_OPEN[event], pred = pred, lo = lo, hi = hi, n = n, unit = unitKey }
        self.ecast[unitKey] = c
        c.rec = push(self.castPreds, { t = now, key = mkey, pred = pred, lo = lo, hi = hi, n = n, kind = c.kind }, 200)
        self.version = self.version + 1
        return c
    end
    if not c then return nil end
    if bar ~= nil and c.bar ~= nil and bar ~= c.bar and event ~= "UNIT_SPELLCAST_STOP" then return nil end
    local dur = now - c.start
    local outcome
    if event == "UNIT_SPELLCAST_SUCCEEDED" or event == "UNIT_SPELLCAST_CHANNEL_STOP" then outcome = "completed"
    elseif event == "UNIT_SPELLCAST_INTERRUPTED" then outcome = "interrupted"
    elseif event == "UNIT_SPELLCAST_STOP" or event == "UNIT_SPELLCAST_FAILED" then outcome = "stopped"
    else return nil end
    if outcome == "completed" and dur > 0.2 then
        for _, k in ipairs({ c.key, (c.base ~= c.key) and c.base or nil }) do
            if k then
                local m = self.castModel[k] or { d = {}, n = 0 }
                self.castModel[k] = m
                m.n = m.n + 1
                m.d[#m.d + 1] = dur
                if #m.d > 8 then table.remove(m.d, 1) end   -- 8 entries: constant cost
            end
        end
    end
    c.rec.outcome = outcome
    if c.pred and outcome == "completed" then
        local tol = math.max(0.15, ((c.hi or c.pred) - (c.lo or c.pred)) / 2 + 0.05)
        self:verdict("cast-end", math.abs(dur - c.pred) <= tol and "V" or "C",
            { src = "UNIT_SPELLCAST_SUCCEEDED", conf = c.n and c.n >= 3 and "medium" or "low", d = dur - c.pred, key = c.key })
    elseif c.pred then self:verdict("cast-end", "U", { src = event, key = c.key, d = dur }) end
    if outcome == "interrupted" or outcome == "stopped" then c.rec.elapsed = dur else c.rec.actual = dur end
    self.lastClosed = { unit = unitKey, tEnd = now, elapsed = dur, pred = c.pred, outcome = outcome }
    self.ecast[unitKey] = nil
    self.version = self.version + 1
    return c.rec
end

-- open enemy cast on a unit: { start, pred, lo, hi, n, remaining (s, nil without a model) }
function M:EnemyCast(unitKey)
    local c = self.ecast[unitKey]
    if not c then return nil end
    local now = self.now()
    if c.pred and now > c.start + (c.hi or c.pred) + 2 then self.ecast[unitKey] = nil return nil end   -- missed end event
    if not c.pred and now > c.start + 12 then self.ecast[unitKey] = nil return nil end
    c.remaining = c.pred and math.max(0, c.start + c.pred - now) or nil
    c.elapsed = now - c.start
    return c
end

function M:CastModelExport()
    local out = {}
    for k, m in pairs(self.castModel) do
        if not k:find("^player:") then   -- npc ids only (no player GUIDs in SavedVariables exports)
            local pred, lo, hi, n = self:castModelFor(k)
            out[k] = { median = pred, min = lo, max = hi, n = m.n, recent = n }
        end
    end
    return out
end

----------------------------------------------------------------------------
-- MINOR 4: UNIT_SPELLCAST_FAILED (player, clear spellID on 1.60.1) as cooldown evidence. The live event carries no
-- reason: a fail inside the predicted cooldown window confirms it ("fail-inside-cd"); outside it (and outside the GCD)
-- it is recorded as weak "fail-outside-cd" evidence only (range / mana / LoS also fail). Offline the log's
-- SPELL_CAST_FAILED reason ("Not yet recovered") turns that into confirm / contradict.
----------------------------------------------------------------------------
function M:OnCastFailed(spellID, event)
    if type(spellID) ~= "number" then return nil end
    local now = self.now()
    local c = self.cooldowns[spellID]
    if c and c.ends and c.ends <= now - 0.05 then self.cooldowns[spellID] = nil c = nil end
    local rule, conf, remaining
    local tc = self.cd.spells[spellID]       -- MINOR 5: the tracker (learned / observed / shared category) wins
    if tc and tc.cooling and tc.ends and now < tc.ends then
        c = { ends = tc.ends, pred = c and c.pred }
        tc.failConfirm = (tc.failConfirm or 0) + 1
    end
    if c and c.ends and now < c.ends then
        rule, conf, remaining = "fail-inside-cd", "medium", c.ends - now
        if c.pred then c.pred.cdConfirm = (c.pred.cdConfirm or 0) + 1 end
    else
        local last = self.ownRecent[#self.ownRecent]
        if last and now - last.t < 1.5 then rule, conf = "fail-gcd", "low" else rule, conf = "fail-outside-cd", "low" end
    end
    self.counters[rule] = (self.counters[rule] or 0) + 1
    self:verdict("cooldown", rule == "fail-inside-cd" and "V" or "U",
        { spell = spellID, src = event or "UNIT_SPELLCAST_FAILED", conf = conf, d = remaining })
    return self:infer({ rule = rule, kind = "cast-failed", spell = spellID, conf = conf, remaining = remaining,
        quiet = event == "UNIT_SPELLCAST_FAILED_QUIET" or nil })
end

----------------------------------------------------------------------------
-- MINOR 4: running health estimate (player). UnitHealth(player) is secret in and out of combat on 1.60.1, UnitHealthMax
-- is clear (ledger). Anchor: out of combat, no UNIT_HEALTH for quietFull s = regeneration stopped = full health.
-- Then UNIT_COMBAT WOUND (clear amount) subtracts, HEAL adds (gross); overheal estimate = amount above max.
-- UNIT_HEALTH without a same-frame UNIT_COMBAT (regen, drains, absorbs) is counted as unknown and lowers confidence.
----------------------------------------------------------------------------
local function hpState(self, unitKey)
    local h = self.hp[unitKey]
    if not h then h = { unknown = 0 } self.hp[unitKey] = h end
    return h
end

function M:hpAnchor(h, now)
    if h.max and not self.inCombat and h.lastEvt and now - h.lastEvt >= self.quietFull
        and (h.anchor ~= "quiet-full" or h.cur ~= h.max or h.unknown > 0) then
        h.cur, h.unknown, h.anchor, h.anchorT = h.max, 0, "quiet-full", now
    end
end

function M:OnHealthMax(unitKey, max)
    if type(max) ~= "number" or max <= 0 then return end
    local h = hpState(self, unitKey)
    if h.max ~= max then
        if h.cur and h.max then h.cur = math.min(max, h.cur) end
        h.max = max
        if not h.cur then h.cur, h.anchor, h.anchorT = max, "assumed-full", self.now() end
        self.version = self.version + 1
    end
end

function M:OnHealthEvent(unitKey)
    local now = self.now()
    local h = hpState(self, unitKey)
    self:hpAnchor(h, now)
    h.lastEvt = now
    if not (h.lastUC and math.abs(now - h.lastUC) <= self.sameFrame) then
        h.unknown = h.unknown + 1
        h.lastUnknownT = now
    end
end

function M:hpApply(unitKey, delta, now)
    local h = hpState(self, unitKey)
    h.lastUC = now
    if h.lastUnknownT and math.abs(now - h.lastUnknownT) <= self.sameFrame then h.unknown = math.max(0, h.unknown - 1) h.lastUnknownT = nil end
    if not (h.max and h.cur) then return nil end
    local over
    if delta >= 0 then
        over = math.max(0, h.cur + delta - h.max)
        h.cur = math.min(h.max, h.cur + delta)
    else h.cur = math.max(1, h.cur + delta) end
    local conf = (h.anchor == "quiet-full" and h.unknown == 0) and "high" or ((h.unknown <= 2 and h.anchor) and "medium" or "low")
    return { over = over, cur = h.cur, conf = conf }
end

function M:Health(unitKey)
    local h = self.hp[unitKey]
    if not h or not h.cur then return nil end
    return h.cur, h.max, (h.anchor == "quiet-full" and h.unknown == 0) and "high" or ((h.unknown <= 2) and "medium" or "low"), h.unknown
end

----------------------------------------------------------------------------
-- MINOR 5: CooldownTracker (per spellID cooldown + GCD). Event-driven only: no OnUpdate; work per SPELL_UPDATE_COOLDOWN
-- is O(k) over the spells currently cooling (+ the GCD spell). Inputs are clear by documentation/observation on 1.60.1:
-- C_Spell.GetSpellCooldown(id).isActive / .isOnGCD / .isEnabled are NeverSecret (run 5 CONTAINERS: C in combat), the
-- SPELL_UPDATE_COOLDOWN payload (spellID, category, startRecoveryCategory) is clear in combat (run 5 RecordDB), and
-- startTime / duration are read ONLY when clear (out of combat) to calibrate. Nothing secret is stored or derived.
----------------------------------------------------------------------------
local CD_TOL, GCD_TOL = 0.25, 0.12
local function cdmed(t)
    if not t or #t == 0 then return nil end
    local c = {}
    for i = 1, #t do c[i] = t[i] end
    table.sort(c)
    return c[math.floor((#c + 1) / 2)]
end
local function ring8(list, v) list[#list + 1] = v if #list > 8 then table.remove(list, 1) end end

function M:cdSpell(id)
    local c = self.cd.spells[id]
    if not c then
        c = { learned = {}, gcdLearned = {} }
        self.cd.spells[id] = c
    end
    return c
end

function M:CDInfo(spellID, info)
    if type(spellID) ~= "number" or type(info) ~= "table" then return end
    local c = self:cdSpell(spellID)
    if type(info.cooldown) == "number" then c.base = info.cooldown end
    if type(info.gcd) == "number" then c.baseGCD = info.gcd end
    if type(info.category) == "number" then self:CDPayload(spellID, nil, info.category, info.srCategory) end
end

-- SPELL_UPDATE_COOLDOWN(spellID, baseSpellID, category, startRecoveryCategory, itemID): learns shared categories
-- (run 5: all shocks share category 19) and which spells trigger the GCD (startRecoveryCategory 133 vs 0)
function M:CDPayload(spellID, baseSpellID, category, srCategory)
    if type(spellID) ~= "number" then return end
    local c = self:cdSpell(spellID)
    if type(category) == "number" and category ~= c.category then
        if c.category and self.cd.cat[c.category] then self.cd.cat[c.category][spellID] = nil end
        c.category = category ~= 0 and category or nil
        if c.category then
            local m = self.cd.cat[category] or {}
            self.cd.cat[category] = m
            m[spellID] = true
        end
    end
    if type(srCategory) == "number" then c.srCategory = srCategory end
    if type(baseSpellID) == "number" and baseSpellID ~= spellID then c.baseSpell = baseSpellID end
end

-- active set + dense array (O(1) add / swap-remove) for the round-robin re-check
function M:cdActivate(id, on)
    local cd = self.cd
    local a = cd.active
    if on and not a[id] then
        a[id] = true cd.nActive = cd.nActive + 1
        local n = #cd.list + 1
        cd.list[n] = id cd.pos[id] = n
    elseif not on and a[id] then
        a[id] = nil cd.nActive = cd.nActive - 1
        local i, n = cd.pos[id], #cd.list
        if i then
            local last = cd.list[n]
            cd.list[i] = last cd.pos[last] = i
            cd.list[n] = nil cd.pos[id] = nil
        end
        cd.due[id] = nil
    end
end

-- min-heap of predicted ready times (lazy: an entry is stale when the spell's hseq moved on). Every change of c.ends
-- pushes one entry: O(log k) per change, O(1) amortised per event to find the spells that are about to be ready.
local function heapPush(h, e)
    local i = #h + 1
    h[i] = e
    while i > 1 do
        local p = (i - i % 2) / 2
        if h[p][1] <= e[1] then break end
        h[i], h[p] = h[p], e
        i = p
    end
end
local function heapPop(h)
    local n = #h
    local top = h[1]
    local last = h[n]
    h[n] = nil
    n = n - 1
    if n > 0 then
        local i = 1
        while true do
            local l = 2 * i
            if l > n then break end
            local m = (l + 1 <= n and h[l + 1][1] < h[l][1]) and l + 1 or l
            if h[m][1] >= last[1] then break end
            h[i] = h[m]
            i = m
        end
        h[i] = last
    end
    return top
end
function M:cdSchedule(id, c)
    if not (c and c.ends) then return end
    c.hseq = (c.hseq or 0) + 1
    local h = self.cd.heap
    heapPush(h, { c.ends, id, c.hseq })
    if #h > 4 * (self.cd.nActive + 16) then   -- stale entries pile up only under heavy rescheduling: rebuild O(k log k)
        local nh = {}
        for _, aid in ipairs(self.cd.list) do
            local ac = self.cd.spells[aid]
            if ac and ac.ends and ac.hseq then heapPush(nh, { ac.ends, aid, ac.hseq }) end
        end
        self.cd.heap = nh
    end
end

-- static seed (Data/spell-timing.lua, merged offline from earlier captures + known answers): lowest priority below live
function M:CDSeed(spellID, e)
    if type(spellID) ~= "number" or type(e) ~= "table" then return end
    local c = self:cdSpell(spellID)
    -- partial updates keep the other field (a drift override of the GCD must not wipe the seeded cooldown)
    local gv, cv = tonumber(e.gcd or e.observedGCD or e.baseGCD), tonumber(e.cooldown or e.observedCooldown or e.baseCooldown)
    if gv then c.seedGCD = gv end
    if cv then c.seedCD = cv end
    c.seedConf = e.confidence or c.seedConf
    c.seedSrc = e.source == "drift" and "drift" or (e.source == "learned" and "learned-sv" or "seed")
    if type(e.srCategory) == "number" and c.srCategory == nil then c.srCategory = e.srCategory end
    if type(e.category) == "number" and c.category == nil then self:CDPayload(spellID, nil, e.category, nil) end
end

function M:cdLearn(kind, id, v, extra)
    if self.onCDLearn then pcall(self.onCDLearn, kind, id, v, extra) end
end

function M:cdLength(c, id)
    local l = cdmed(c.learned)
    if l then return l, (#c.learned >= 2) and "high" or "medium", "learned" end
    if c.cal then return c.cal, "high", "api-clear" end
    local k = self.knowledge[id]
    local b = c.base or (k and k.cooldown)
    if b and b > 0 then return b, "medium", "baseCooldown" end
    if c.seedCD and c.seedCD > 0 then return c.seedCD, (c.seedSrc == "seed") and "low" or "medium", c.seedSrc or "seed" end
    return nil
end

function M:gcdLength(c, id)
    local l = cdmed(c.gcdLearned)
    if l then return l, "high", "learned" end
    local k = self.knowledge[id]
    local g = c.baseGCD or (k and k.gcd)
    if g then return g, "medium", "baseGCD" end
    if c.seedGCD then return c.seedGCD, (c.seedConf == "high") and "medium" or "low", c.seedSrc or "seed" end
    if c.srCategory == 0 then return 0, "medium", "srCategory" end
    if c.srCategory then return 1.5, "low", "default" end
    return nil
end

-- consecutive own cast begins (START for cast-time spells, SUCCEEDED for instants): the gap after a begin of spell X is
-- an upper bound of X's GCD (the minimum over many casts converges to it; offline it is checked against the log)
function M:cdBegin(id, now)
    local lb = self.cd.lastBegin
    if lb and lb.spell and now - lb.t > 0.05 and now - lb.t < 3 then self:cdLearn("gap", lb.spell, now - lb.t) end
    self.cd.lastBegin = { t = now, spell = id }
end

function M:CDCast(id, now)
    now = now or self.now()
    local c = self:cdSpell(id)
    c.lastCast = now
    local lb = self.cd.lastBegin
    local k = self.knowledge[id]
    if not (lb and lb.spell == id and now - lb.t <= ((k and k.castTime) or 0) + 0.5 and now - lb.t > 0.2) then self:cdBegin(id, now) end
    local len, conf, src = self:cdLength(c, id)
    if len and len > 1.5 then
        c.cooling, c.start, c.ends, c.conf, c.src, c.gcdOnly, c.obs = true, now, now + len, conf, src, nil, nil
        self:cdActivate(id, true)
        self:cdSchedule(id, c)
        self.cd.latest = id   -- most recent cooldown start (UI bar): O(1), re-picked only when it settles
        -- shared category: every member starts the same cooldown (run 5: Earth/Flame/Frost Shock = category 19)
        local m = c.category and self.cd.cat[c.category]
        if m then
            for oid in pairs(m) do
                if oid ~= id then
                    local o = self:cdSpell(oid)
                    o.cooling, o.start, o.ends, o.conf, o.src, o.obs = true, now, now + len, "medium", "category:" .. c.category, nil
                    o.sharedFrom = id
                    self:cdActivate(oid, true)
                    self:cdSchedule(oid, o)
                end
            end
        end
    end
    local g, gconf, gsrc = self:gcdLength(c, id)
    if g and g > 0 then
        self.cd.gcd = { start = now, ends = now + g, spell = id, length = g, conf = gconf, source = gsrc, seenOn = nil }
        self:cdActivate(id, true)
    end
    self.version = self.version + 1
end

-- returns a reused buffer (valid until the next call; callers iterate it immediately): no per-event allocation
function M:CDActive()
    local out, n = self.cd.activeBuf, 0
    if not out then out = {} self.cd.activeBuf = out end
    local now = self.now()
    for id in pairs(self.cd.active) do
        local c = self.cd.spells[id]
        local g = self.cd.gcd
        local keep = c and ((c.cooling and c.ends and now < c.ends + 2) or (g and g.spell == id and now < g.ends + 1))
        if keep then n = n + 1 out[n] = id
        else
            if c and c.cooling and c.ends and now >= c.ends + 2 then c.cooling = false c.readySrc = "predicted" end
            self:cdActivate(id, false)
        end
    end
    for i = n + 1, #out do out[i] = nil end
    return out
end

-- the cooling spell with the latest start (O(k), only when the current latest settles: once per cooldown end)
function M:cdPickLatest()
    local best, bs = nil, nil
    for _, aid in ipairs(self.cd.list) do
        local c = self.cd.spells[aid]
        if c and c.cooling and c.start and c.ends and (not bs or c.start > bs) then best, bs = aid, c.start end
    end
    self.cd.latest = best
end

-- keep an active spell (still cooling / holding the GCD) or retire it (predicted ready + 2 s grace)
local function cdVisit(self, id, now, g)
    local c = self.cd.spells[id]
    local keep = c and ((c.cooling and c.ends and now < c.ends + 2) or (g and g.spell == id and now < g.ends + 1))
    if not keep then
        if c and c.cooling and c.ends and now >= c.ends + 2 then c.cooling = false c.readySrc = "predicted" end
        self:cdActivate(id, false)
        if self.cd.latest == id then self:cdPickLatest() end
        return false
    end
    return true
end

-- per-event re-check list, O(due + budget) independent of how many spells are cooling (perf gate, SPELL_UPDATE_COOLDOWN
-- storm): spells whose predicted ready time is within `horizon` s (from the heap, then kept in the due set until they
-- settle), the GCD spell while the GCD runs, and `budget` far-from-ready active spells round-robin. Expiry pruning (what
-- CDActive does for all k) happens for the visited spells. Returns a reused buffer.
function M:CDCheckList(horizon, budget)
    local cd = self.cd
    local now = self.now()
    local h, due, spells = cd.heap, cd.due, cd.spells
    while h[1] and h[1][1] - now < horizon do
        local e = heapPop(h)
        local c = spells[e[2]]
        if c and c.hseq == e[3] and c.cooling and cd.active[e[2]] then due[e[2]] = true end
    end
    local out, n = cd.checkBuf, 0
    if not out then out = {} cd.checkBuf = out end
    local g = cd.gcd
    for id in pairs(due) do
        if cdVisit(self, id, now, g) then
            local c = spells[id]
            if c and c.cooling and c.ends and c.ends - now >= horizon and not (g and g.spell == id) then due[id] = nil end
            n = n + 1 out[n] = id
        end
    end
    if g and g.spell and not due[g.spell] and cd.active[g.spell] and cdVisit(self, g.spell, now, g) then n = n + 1 out[n] = g.spell end
    local list = cd.list
    local k = #list
    for _ = 1, math.min(budget, k) do
        k = #list
        if k == 0 then break end
        cd.rr = cd.rr % k + 1
        local id = list[cd.rr]
        -- far-from-ready spells (> 2 s from predicted ready): re-read at most once per second each (bounded staleness,
        -- independent of the event rate; due spells are read on every event)
        if id and not due[id] and not (g and g.spell == id) and cdVisit(self, id, now, g) then
            local c = spells[id]
            if now - (c.rrAt or -1e9) >= 1 then c.rrAt = now n = n + 1 out[n] = id end
        end
    end
    for i = n + 1, #out do out[i] = nil end
    return out
end

-- one NeverSecret read of C_Spell.GetSpellCooldown(id) (+ remaining/duration only when clear, out of combat)
function M:CDObserve(id, isActive, isOnGCD, remaining, duration)
    if type(id) ~= "number" then return end
    local now = self.now()
    local c = self:cdSpell(id)
    local g = self.cd.gcd
    -- GCD end: the GCD spell (or any checked spell) reported isOnGCD true, now false / inactive
    if g and not g.ended then
        if isOnGCD == true then g.seenOn = true
        elseif (isOnGCD == false or isActive == false) and g.seenOn and now - g.start > 0.3 then
            local len = now - g.start
            g.ended, g.observedEnd = true, now
            local sc = self:cdSpell(g.spell)
            ring8(sc.gcdLearned, len)
            self:cdLearn("gcd", g.spell, len)
            push(self.cd.gcds, { t = g.start, spell = g.spell, pred = g.length, actual = len, src = g.source }, 100)
            self:verdict("gcd", math.abs(len - g.length) <= GCD_TOL and "V" or "C",
                { spell = g.spell, src = "isOnGCD", conf = g.conf, d = len - g.length })
        end
    end
    -- calibration from clear numbers (out of combat): duration beyond the GCD = the real cooldown of this cast
    if type(duration) == "number" and type(remaining) == "number" and duration > 0 then
        if isOnGCD == true then
            if g and g.spell == id and not g.ended then
                g.ends = now + remaining g.source = "api-clear" g.conf = "high"
                if g.calLen ~= duration then g.calLen = duration self:cdLearn("gcdcal", id, duration) end
            end
        elseif duration > 1.5 then
            if c.cal ~= duration then self:cdLearn("cal", id, duration) end
            c.cal = duration
            if c.cooling then c.ends = now + remaining c.src = "api-clear" c.conf = "high" self:cdSchedule(id, c) end
        end
    end
    if isActive == true and isOnGCD == false and c.cooling then c.obs = "active" end
    if isActive == true and isOnGCD == true and c.cooling then c.gcdOnly = true end
    if isActive == false and c.cooling and c.start then
        local since = now - c.start
        local gl = (g and g.spell == id and g.length) or 1.5
        if since > gl + 0.05 then
            -- observed ready outside the GCD: learn the true cooldown of this spell (shared members learn their own)
            c.cooling, c.readyAt, c.readySrc = false, now, "isActive"
            if self.cd.latest == id then self:cdPickLatest() end
            if not c.sharedFrom or c.sharedFrom == id then ring8(c.learned, since) self:cdLearn("cd", id, since) end
            local pe = c.ends
            push(self.cd.readies, { t = c.start, spell = id, pred = pe and (pe - c.start), actual = since, src = c.src }, 100)
            if pe then
                self:verdict("cd-ready", math.abs(now - pe) <= CD_TOL and "V" or "C",
                    { spell = id, src = "isActive", conf = c.conf, d = now - pe })
            end
            c.sharedFrom = nil
            self:cdActivate(id, (g and g.spell == id and not g.ended) or false)
        end
    end
    self.version = self.version + 1
end

function M:GCDObserve(remaining, duration)
    local g = self.cd.gcd
    if g and not g.ended and type(remaining) == "number" then
        g.ends = self.now() + remaining
        if type(duration) == "number" and duration > 0 then g.length = duration end
        g.source, g.conf = "api-clear", "high"
    end
end

function M:GCD()
    local g = self.cd.gcd
    if not g then return nil end
    local now = self.now()
    local ends = g.observedEnd or g.ends
    if now >= ends then return nil end
    return { ends = ends, spell = g.spell, length = g.length, remaining = ends - now, source = g.source, confidence = g.conf }
end

function M:Cooldown(spellID)
    local now = self.now()
    local c = self.cd.spells[spellID]
    if c and c.cooling and c.ends and now < c.ends then
        return { state = "cooling", ends = c.ends, remaining = c.ends - now, confidence = c.conf, source = c.src,
            observed = c.obs, shared = c.sharedFrom }
    end
    local g = self:GCD()
    if g and not (c and c.srCategory == 0) then
        local gl = c and select(1, self:gcdLength(c, spellID))
        if gl ~= 0 then return { state = "gcd", ends = g.ends, remaining = g.remaining, confidence = g.confidence, source = "gcd:" .. tostring(g.source) } end
    end
    -- legacy prediction (no tracker entry yet)
    local lc = not (c and c.lastCast) and self:CooldownRecord(spellID)   -- the tracker owns spells it has seen cast
    if lc and lc.ends then return { state = "cooling", ends = lc.ends, remaining = lc.ends - now, confidence = "medium", source = lc.source or "predicted" } end
    return { state = "ready", confidence = c and (c.readySrc == "isActive" and "high" or "medium") or "low", source = c and c.readySrc or "default" }
end

function M:CDExport()
    local out = {}
    for id, c in pairs(self.cd.spells) do
        if c.lastCast or c.category or #c.learned > 0 then
            out[id] = { base = c.base, baseGCD = c.baseGCD, learned = cdmed(c.learned), learnedN = #c.learned, gcd = cdmed(c.gcdLearned),
                gcdN = #c.gcdLearned, category = c.category, srCategory = c.srCategory, cal = c.cal, failConfirm = c.failConfirm }
        end
    end
    return { spells = out, readies = self.cd.readies, gcds = self.cd.gcds }
end

function M:Export()
    return { predictions = self.predictions, inferences = self.inferences, contradictions = self.contradictions,
        counters = self.counters, fights = self.fights, ledger = self.ledger and self.ledger:Export() or nil,
        casts = self.castPreds, castModel = self:CastModelExport(), verdicts = self.verdicts, cd = self:CDExport(),
        lastReconcile = self.lastReconcile,
        knowledgeSpells = (function() local n = 0 for _ in pairs(self.knowledge) do n = n + 1 end return n end)() }
end

_G.HybridState = Lib
return Lib
