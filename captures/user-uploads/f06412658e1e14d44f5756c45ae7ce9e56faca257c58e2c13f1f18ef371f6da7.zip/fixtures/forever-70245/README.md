# Anonymized fixture pack: WoW Forever 1.60.1 build 70245 (TOC 16001, WOW_PROJECT_CAMELOT = 18)

Made from one real capture (2026-10-07) with
`python3 tools/fdump.py fixtures DUMP --file WoWCombatLog.txt --taint taint.log -o fixtures/forever-70245`.
The command refuses to finish (exit 3) if its leak scan still finds a real player GUID or any word passed in `--forbid`.

| file | content |
|---|---|
| environment.json | build, TOC, project constants, locale, a few non-personal CVars and CVar counts |
| api-surface.json | names only: 5046 present global functions, namespaces and their functions, 1797 events |
| secrets-documented.json | documentation-derived secrets map (flags, aspects, secrecy-relevant functions/events/widget methods/structs); runtime sections stripped |
| WoWCombatLog-anon.txt | the 1029-line advanced combat log (Orgrimmar), anonymized |
| combatlog_file.lua | the same log parsed into a replay fixture (`replay.lua`, 1023 CLEU events) |
| taint-anon.log | the taint log (7 ADDON_ACTION_BLOCKED lines from a public addon) |
| anonymization.json | what was mapped (counts only, no mapping table) and the leak-scan result |

Anonymization rules: player GUIDs become `Player-0000-NNNNNNNN` (stable within the pack), player names become `PlayerN`
(the realm cluster name is kept), player pets become `Pet-0-0000-0-0-<npcID>-N` / `PetN`. NPC names and IDs, spells,
zones and coordinates are game data and are kept. No SavedVariables, character, guild, chat or account data is included.

Used by `tests/spec/forever_fixture_spec.lua` (busted).
