"""Anonymize real captures into shareable fixtures (fixtures/<build>/).

Player GUIDs, player names, player-pet GUIDs/names and character-specific values are replaced by stable
placeholders (Player-0000-00000001, "Player1-Realm-", "Pet1"); game data (NPC names/IDs, spell IDs, zones,
realm cluster names) is kept. The api surface keeps only names (functions, events, namespaces), never values.
"""
import json
import os
import re

PLAYER_GUID = re.compile(r"Player-\d+-[0-9A-Fa-f]+")
PET_GUID = re.compile(r"Pet-0-\d+-\d+-\d+-(\d+)-[0-9A-Fa-f]+")
# "Name-Realm-Region" as written by the combat log for players (region may be empty)
PLAYER_NAME = re.compile(r'"([^"\-,]+)-([A-Za-z0-9]+)-([A-Za-z0-9]*)"')
PET_NAME_AFTER_GUID = re.compile(r'(Pet-0-0000-0-0-\d+-[0-9A-F]{10}),"([^"]*)"')


class Anonymizer:
    def __init__(self, names=(), guids=()):
        """names: first/last/full names of known characters (SV identity + characters.json) scrubbed anywhere in a line
        (Forever: 'First Last' in the UI and SV, only 'First-Realm-Region' in the combat log); guids: their GUIDs."""
        self.players, self.pets, self.names, self.petnames = {}, {}, {}, {}
        self.surnames = {}
        toks = sorted({n for n in names if n and len(n) >= 2}, key=lambda n: (-len(n), n))
        self.known_rx = re.compile(r"(?<![A-Za-z0-9])(%s)(?![A-Za-z0-9])" % "|".join(re.escape(t) for t in toks), re.I) if toks else None
        self.known_firsts = set()
        for n in names or ():
            parts = re.split(r"[\s\-]+", n.strip())
            if len(parts) > 1:
                self.known_firsts.add(parts[0].lower())
        for g in guids or ():
            self.guid(g)

    def guid(self, g):
        if g not in self.players:
            self.players[g] = "Player-0000-%08X" % (len(self.players) + 1)
        return self.players[g]

    def pet(self, m):
        g = m.group(0)
        if g not in self.pets:
            self.pets[g] = "Pet-0-0000-0-0-%s-%010X" % (m.group(1), len(self.pets) + 1)
        return self.pets[g]

    def name(self, m):
        n = m.group(1)
        if n not in self.names:
            self.names[n] = "Player%d" % (len(self.names) + 1)
        return '"%s-%s-%s"' % (self.names[n], m.group(2), m.group(3))

    def petname(self, m):
        nm = m.group(2)
        if nm in ("Unknown", ""):
            return m.group(0)
        if nm not in self.petnames:
            self.petnames[nm] = "Pet%d" % (len(self.petnames) + 1)
        return '%s,"%s"' % (m.group(1), self.petnames[nm])

    def _known(self, m):
        t = m.group(1)
        parts = re.split(r"[\s\-]+", t)
        out = []
        for i, p in enumerate(parts):
            key = p.lower()
            if i == 0 and (len(parts) > 1 or key in self.known_firsts or key in {k.lower() for k in self.names}):
                hit = next((v for k, v in self.names.items() if k.lower() == key), None)
                if hit is None:
                    hit = self.names[p] = "Player%d" % (len(self.names) + 1)
                out.append(hit)
            else:
                if key not in self.surnames:
                    self.surnames[key] = "Surname%d" % (len(self.surnames) + 1)
                out.append(self.surnames[key])
        sep = " " if " " in t else "-"
        return sep.join(out)

    def line(self, s):
        s = PLAYER_GUID.sub(lambda m: self.guid(m.group(0)), s)
        s = PET_GUID.sub(self.pet, s)
        s = PLAYER_NAME.sub(self.name, s)
        s = PET_NAME_AFTER_GUID.sub(self.petname, s)
        if self.known_rx:
            s = self.known_rx.sub(self._known, s)
        return s

    def mapping_summary(self):
        return {"players": len(self.players), "playerNames": len(self.names), "surnames": len(self.surnames), "pets": len(self.pets),
                "petNames": len(self.petnames)}


def combat_log(src, dst, max_lines=None, anon=None):
    anon = anon or Anonymizer()
    n = 0
    with open(src, encoding="utf-8", errors="replace") as f, open(dst, "w", encoding="utf-8") as o:
        for ln in f:
            if max_lines and n >= max_lines:
                break
            o.write(anon.line(ln))
            n += 1
    return anon, n


def taint_log(src, dst, anon=None):
    """taint.log names addons and Interface/AddOns paths (public); strip absolute user paths if any."""
    anon = anon or Anonymizer()
    with open(src, encoding="utf-8", errors="replace") as f, open(dst, "w", encoding="utf-8") as o:
        for ln in f:
            ln = re.sub(r"[A-Za-z]:\\\\?Users\\\\?[^\\\\/]+", "C:/Users/<user>", ln)
            ln = re.sub(r"/(home|Users)/[^/\s]+", r"/\1/<user>", ln)
            o.write(anon.line(ln))
    return anon


SAFE_CVARS = ("loadDeprecationFallbacks", "scriptErrors", "taintLog", "advancedCombatLogging", "portal", "agentUID",
              "textLocale", "audioLocale")


def environment(dump):
    """Build/environment facts only (no character, realm, guild, chat or positional data)."""
    meta = dump.meta() if callable(getattr(dump, "meta", None)) else {}
    keep = {k: meta.get(k) for k in ("addonVersion", "build", "buildDate", "locale", "projectID", "projectName",
                                     "projectConstants", "schemaVersion", "toc", "version", "scriptsDisallowedForBeta")}
    cv = (dump.sections.get("cvars") or {})
    changed = {c.get("name"): c.get("current") for c in (cv.get("changedFromDefault") or []) if isinstance(c, dict)}
    keep["cvarsChanged"] = {k: changed[k] for k in SAFE_CVARS if k in changed and k not in ("portal", "agentUID")}
    keep["cvarCounts"] = cv.get("counts")
    return keep


def api_surface(dump):
    ns = dump.namespaces()
    sec, insec = dump.global_functions()
    return {
        "globalFunctions": sorted(set(sec) | set(insec)),
        "namespaces": {k: sorted(v) for k, v in sorted(ns.items())},
        "events": sorted(dump.events()),
        "counts": {"globalFunctions": len(set(sec) | set(insec)), "namespaces": len(ns),
                   "namespaceFunctions": sum(len(v) for v in ns.values()), "events": len(dump.events())},
    }


LEAK_CHECK = re.compile(r"Player-\d{3,}-[0-9A-Fa-f]{8}")


def leak_scan(folder, forbidden_words=()):
    """-> list of (file, line, token) still looking like a real player GUID or a forbidden word."""
    hits = []
    for root, _, files in os.walk(folder):
        for fn in files:
            p = os.path.join(root, fn)
            with open(p, encoding="utf-8", errors="replace") as f:
                for i, ln in enumerate(f, 1):
                    for m in LEAK_CHECK.finditer(ln):
                        if not m.group(0).startswith("Player-0000-"):
                            hits.append((p, i, m.group(0)))
                    for w in forbidden_words:
                        if w and w in ln:
                            hits.append((p, i, w))
    return hits


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, sort_keys=True, ensure_ascii=False)
