"""Offline sealed-tape replay for ForeverDumpLogDB.replay (v2.2.6).

Reads session_hdr + decide/verdict/anchor/map/sec/api ring records from the SV,
reconstructs chronological order, joins cast-sync anchors to CLEU SPELL_CAST_SUCCESS
(when a combat log fixture is provided), and checks decide determinism
(same rule-id + input bitmap → same kind/conf across the tape).

Privacy: tape must not contain raw Player-/Pet- GUIDs or player names; this module
flags any that slip through.
"""
from __future__ import annotations

import collections
import json
import os
import re

from .luasv import as_list
from . import combatlog

PLAYER_GUID = re.compile(r"Player-\d+-[0-9A-Fa-f]+")
PET_GUID = re.compile(r"Pet-0-\d+-\d+-\d+-\d+-[0-9A-Fa-f]+")
NAME_REALM = re.compile(r"\b[A-Z][a-z]+-[A-Za-z]+(?:-[A-Za-z]+)?\b")


def _sessions(dump):
    log = dump.log or {}
    rep = log.get("replay") or {}
    return as_list(rep.get("sessions")), rep


def reconstruct_tape(sess):
    """Ring buffer -> chronological list (by rec.i / seq)."""
    tape = sess.get("tape") or {}
    if isinstance(tape, dict):
        items = [v for v in tape.values() if isinstance(v, dict)]
    else:
        items = [v for v in as_list(tape) if isinstance(v, dict)]
    items.sort(key=lambda r: (r.get("i") or 0, r.get("d") or 0))
    return items


def privacy_scan(obj, path=""):
    """Return list of (path, snippet) for raw GUID / likely Name-Realm in tape/hdr."""
    hits = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            hits.extend(privacy_scan(v, path + "." + str(k)))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            hits.extend(privacy_scan(v, "%s[%d]" % (path, i)))
    elif isinstance(obj, str):
        if PLAYER_GUID.search(obj) or PET_GUID.search(obj):
            hits.append((path, obj[:80]))
        # skip short tokens / hashed keys (kind:hex)
        elif "-" in obj and len(obj) > 6 and NAME_REALM.search(obj) and not re.match(r"^[a-z]+:[0-9a-f]{8}$", obj):
            if not obj.startswith(("npc:", "guid:", "pet:", "player", "Creature-")):
                hits.append((path, obj[:80]))
    return hits


def join_anchors_cleu(anchors, fx, t0_epoch=None, window_ms=750):
    """Match tape anchors (spell + ms-delta) to CLEU SPELL_CAST_SUCCESS by spell id + time."""
    if not fx or not anchors:
        return {"matched": 0, "anchors": len(anchors or []), "pairs": []}
    casts = []
    for e in fx.get("events") or []:
        if not e.get("cleu") or e.get("sub") != "SPELL_CAST_SUCCESS":
            continue
        a = e.get("a") or []
        spell = a[11] if len(a) > 11 else None
        t = a[0] if a else None
        if spell is None or t is None:
            continue
        casts.append({"t": t, "spell": spell, "src": a[3] if len(a) > 3 else None})
    pairs, used = [], set()
    for an in anchors:
        sp, d_ms = an.get("spell"), an.get("d")
        if sp is None or d_ms is None:
            continue
        # if we have session epoch t0, convert; else relative match among spells
        best, best_dt = None, None
        for i, c in enumerate(casts):
            if i in used or c["spell"] != sp:
                continue
            if t0_epoch is not None:
                dt = abs((c["t"] - t0_epoch) * 1000.0 - float(d_ms))
            else:
                # without epoch: only spell co-occurrence count
                dt = 0.0
            if best is None or dt < best_dt:
                best, best_dt = i, dt
        if best is not None and (t0_epoch is None or best_dt <= window_ms):
            used.add(best)
            pairs.append({"anchor": an, "cleu": casts[best], "dt_ms": best_dt})
    return {"matched": len(pairs), "anchors": len(anchors), "pairs": pairs}


def decide_determinism(records, rules):
    """Group decide rows by (r, b) → set of (kind, c); flag non-singleton groups."""
    groups = collections.defaultdict(set)
    for rec in records:
        if rec.get("k") != "decide":
            continue
        key = (rec.get("r"), rec.get("b"))
        groups[key].add((rec.get("kind"), rec.get("c")))
    conflicts = []
    for key, outs in groups.items():
        if len(outs) > 1:
            conflicts.append({"rule": key[0], "bits": key[1], "ruleName": (rules or {}).get(key[0]),
                              "outcomes": sorted(list(outs), key=lambda x: str(x))})
    return {"groups": len(groups), "conflicts": conflicts, "ok": len(conflicts) == 0}


def analyze_session(sess, fx=None):
    hdr = sess.get("hdr") or {}
    tape = reconstruct_tape(sess)
    by_k = collections.Counter(r.get("k") for r in tape)
    rules = sess.get("rules") or {}
    if isinstance(rules, list):
        rules = {i + 1: v for i, v in enumerate(rules)}
    # lua array may be 1-indexed dict
    rules = {int(k) if str(k).isdigit() else k: v for k, v in (rules.items() if isinstance(rules, dict) else [])}
    det = decide_determinism(tape, rules)
    anchors = sess.get("anchors") or as_list(sess.get("anchors"))
    if isinstance(anchors, dict):
        anchors = list(anchors.values())
    t0 = hdr.get("t0")
    # TimeAnchor may be {getTime, epoch}; hdr.anchor
    anchor_meta = hdr.get("anchor") or {}
    t0_epoch = None
    if isinstance(anchor_meta, dict) and anchor_meta.get("epoch") and anchor_meta.get("getTime"):
        # convert session-relative GetTime to epoch via first GetTime sample
        gt0 = float(anchor_meta["getTime"])
        ep0 = float(anchor_meta["epoch"])
        # tape d is ms since sess.t0 (GetTime); epoch ≈ ep0 + (t0 + d/1000 - gt0)
        if t0 is not None:
            t0_epoch = ep0 + (float(t0) - gt0)
    join = join_anchors_cleu(anchors, fx, t0_epoch=t0_epoch)
    priv = privacy_scan({"hdr": hdr, "tape": tape, "rules": rules})
    return {
        "verbosity": hdr.get("verbosity"),
        "verbosityEnd": hdr.get("verbosityEnd"),
        "addonVersion": hdr.get("addonVersion"),
        "schemaVersion": hdr.get("schemaVersion"),
        "groupType": hdr.get("groupType"),
        "groupSize": hdr.get("groupSize"),
        "n": sess.get("n") or len(tape),
        "overwritten": sess.get("overwritten") or 0,
        "overflow": sess.get("overflow") or 0,
        "ringOverflow": sess.get("ringOverflow") or {},
        "dropped": sess.get("dropped") or {},
        "bytes": sess.get("bytes") or 0,
        "byKind": dict(by_k),
        "decide": det,
        "anchorJoin": {k: join[k] for k in ("matched", "anchors") if k in join},
        "anchorJoinRate": (join["matched"] / join["anchors"]) if join.get("anchors") else None,
        "privacyHits": len(priv),
        "privacySamples": priv[:5],
        "seeds": hdr.get("seeds"),
        "mapStart": hdr.get("mapStart"),
        "mapEnd": hdr.get("mapEnd"),
        "combatLogStart": hdr.get("combatLogStart"),
        "combatLogEnd": hdr.get("combatLogEnd"),
    }


def analyze(dump, combatlog_path=None):
    sessions, rep = _sessions(dump)
    fx = None
    if combatlog_path and os.path.isfile(combatlog_path):
        try:
            fx = combatlog.parse_file(combatlog_path)
        except Exception as e:
            fx = {"_error": str(e), "events": []}
    out_sessions = []
    for i, s in enumerate(sessions):
        if not isinstance(s, dict):
            continue
        out_sessions.append(analyze_session(s, fx=fx if isinstance(fx, dict) and "events" in fx else None))
    return {
        "v": rep.get("v") or 1,
        "sessionCount": len(out_sessions),
        "sessions": out_sessions,
        "combatlog": bool(fx and fx.get("events")),
        "summary": _summary(out_sessions),
    }


def _summary(sessions):
    if not sessions:
        return {"ok": True, "note": "no replay sessions in SV (capture with FD_Logs on v2.2.6+)"}
    priv = sum(s.get("privacyHits") or 0 for s in sessions)
    conf = sum(len((s.get("decide") or {}).get("conflicts") or []) for s in sessions)
    return {
        "ok": priv == 0 and conf == 0,
        "privacyHits": priv,
        "decideConflicts": conf,
        "totalRecords": sum(s.get("n") or 0 for s in sessions),
        "verbosities": sorted({s.get("verbosity") for s in sessions if s.get("verbosity")}),
    }


def markdown(res):
    L = ["# ForeverDump sealed replay tape", ""]
    sm = res.get("summary") or {}
    L.append("Sessions: **%d**; records: **%s**; privacy hits: **%s**; decide conflicts: **%s**."
             % (res.get("sessionCount") or 0, sm.get("totalRecords"), sm.get("privacyHits"), sm.get("decideConflicts")))
    L.append("")
    if not res.get("sessions"):
        L.append("_No ForeverDumpLogDB.replay sessions. Capture with FD_Logs (v2.2.6+) — default release elevates to test during capture._")
        L.append("")
        return "\n".join(L)
    for i, s in enumerate(res["sessions"], 1):
        L.append("## Session %d (%s → %s)" % (i, s.get("verbosity"), s.get("verbosityEnd")))
        L.append("- addon %s schema %s; group %s/%s; bytes≈%s; overwritten=%s overflow=%s"
                 % (s.get("addonVersion"), s.get("schemaVersion"), s.get("groupType"), s.get("groupSize"),
                    s.get("bytes"), s.get("overwritten"), s.get("overflow")))
        L.append("- kinds: %s" % ", ".join("%s=%d" % kv for kv in sorted((s.get("byKind") or {}).items())))
        det = s.get("decide") or {}
        L.append("- decide determinism: %s (%d groups, %d conflicts)"
                 % ("OK" if det.get("ok") else "CONFLICTS", det.get("groups") or 0, len(det.get("conflicts") or [])))
        aj = s.get("anchorJoin") or {}
        if aj.get("anchors"):
            L.append("- cast-sync anchors joined to CLEU SUCCESS: %s / %s (rate %s)"
                     % (aj.get("matched"), aj.get("anchors"),
                        ("%.0f%%" % (100 * (s.get("anchorJoinRate") or 0))) if s.get("anchorJoinRate") is not None else "n/a"))
        elif not res.get("combatlog"):
            L.append("- cast-sync anchors: %d (no combat log provided for join)" % (aj.get("anchors") or 0))
        if s.get("privacyHits"):
            L.append("- **privacy hits: %d** samples: %s" % (s["privacyHits"], s.get("privacySamples")))
        if s.get("ringOverflow"):
            L.append("- ring overflows: %s" % s["ringOverflow"])
        L.append("")
    L.append("## Notes")
    L.append("- Default in-game level is **release** (<1% CPU). FD_Logs elevates to **test** (or configured captureLevel) ≤10%, then restores.")
    L.append("- `/fdump level` overrides between captures. One zip ships both modes.")
    L.append("")
    return "\n".join(L)


def write(dump, out_dir, combatlog_path=None):
    os.makedirs(out_dir, exist_ok=True)
    res = analyze(dump, combatlog_path=combatlog_path)
    with open(os.path.join(out_dir, "replay.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2, sort_keys=True)
    md = markdown(res)
    with open(os.path.join(out_dir, "REPLAY.md"), "w", encoding="utf-8") as f:
        f.write(md)
    return res
