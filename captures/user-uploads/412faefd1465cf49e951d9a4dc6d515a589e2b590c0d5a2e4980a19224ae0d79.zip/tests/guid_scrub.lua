-- v2.2.12: the HSM panel showed raw "Player-<server>-<hex>" GUIDs in "Last predictions" and the same unit keys were
-- exported into the SavedVariables (inference.predictions / fights.world / contradictions). Display and export now use
-- the salted IdKey (player:<hash>, npc:<id>). Drives the live engine with GUID-keyed units and scans the panel text and
-- the exported tables. usage: lua5.1 tests/guid_scrub.lua ForeverDump
package.path = "./tests/?.lua;" .. package.path
local addonDir = arg[1] or "ForeverDump"
local fails, passed = 0, 0
local function check(c, m) if c then passed = passed + 1 print("  ok   " .. m) else fails = fails + 1 print("  FAIL " .. m) end end
local W = require("wowenv")
local S = W.state
local files = {}
for line in io.lines(addonDir .. "/ForeverDump.toc") do
    if line:match("%.lua%s*$") then files[#files + 1] = line:match("^%s*(.-)%s*$") end
end
local ns = W.loadAddon(addonDir, files, "ForeverDump")
W.fire("ADDON_LOADED", "ForeverDump")
W.fire("PLAYER_LOGIN")
W.fire("PLAYER_ENTERING_WORLD", true, false)
W.slash("logs on")
W.tick(3)
local I = ns.Inference
local hs = I and I.hs
check(hs ~= nil, "live engine running")
local PG, CG = "Player-4619-0ABCDEF1", "Creature-0-1234-5678-90-12345-0000ABCDEF"
S.combat = true
hs:OnCombatState(true)
hs:OnCast("UNIT_SPELLCAST_SUCCEEDED", "player", 8050, true, PG)
hs:OnCast("UNIT_SPELLCAST_SUCCEEDED", "player", 8050, true, CG)
hs:OnUnitCombat(PG, "WOUND", nil, 100, 4, false)
hs:OnUnitCombat(CG, "WOUND", nil, 50, 4, false)
hs:OnCombatState(false)
S.combat = false
local rawUnits = 0
for _, p in ipairs(hs.predictions) do if type(p.unit) == "string" and p.unit:find("^Player%-") then rawUnits = rawUnits + 1 end end
check(rawUnits > 0, "setup: engine predictions hold raw GUID unit keys in memory (" .. rawUnits .. ")")
local function scan(t, seen, hits, depth, path)
    path = path or ""
    if type(t) == "string" then if t:find("Player%-%d+%-%x+") or t:find("Creature%-%d+%-%d+") then hits[#hits + 1] = path end return end
    if type(t) ~= "table" or seen[t] or depth > 12 then return end
    seen[t] = true
    for k, v in pairs(t) do scan(k, seen, hits, depth + 1, path .. "{key}") scan(v, seen, hits, depth + 1, path .. "." .. tostring(k)) end
end
local hits = {}
scan(hs:Export(), {}, hits, 0)
check(#hits == 0, "Export (SavedVariables): no raw GUID in keys or values (" .. #hits .. ")")
local text = ns.HSMUI and ns.HSMUI.Text and ns.HSMUI.Text() or ""
check(text:find("Last predictions", 1, true) ~= nil, "panel text built")
check(not text:find("Player%-%d+%-%x+") and not text:find("Creature%-%d+%-%d+"), "HSM panel text: no raw GUID")
check(text:find("player:%x%x%x%x%x%x%x%x") ~= nil or text:find("npc:12345", 1, true) ~= nil, "HSM panel shows the IdKey instead")
W.slash("logs off")
W.tick(3)
local hits2 = {}
-- the HSM-exported blocks (inference.player.guid is the deliberate own-character anchor the offline scorer joins the
-- combat log on; it never leaves the box and is not part of this check)
local inf = (ns.db and ns.db.inference) or ForeverDumpLogDB and ForeverDumpLogDB.inference or {}
for _, k in ipairs({ "predictions", "inferences", "contradictions", "fights", "casts", "castModel", "cd" }) do
    scan(inf[k], {}, hits2, 0, k)
end
check(inf.predictions ~= nil and #hits2 == 0, "after OFF: HSM blocks in the SV have no raw GUID (" .. #hits2 .. (hits2[1] and (": " .. hits2[1]:gsub("Player%-[%w%-]+", "<guid>")) or "") .. ")")
print(string.format("guid_scrub: %d passed, %d failed", passed, fails))
if fails > 0 then os.exit(1) end
