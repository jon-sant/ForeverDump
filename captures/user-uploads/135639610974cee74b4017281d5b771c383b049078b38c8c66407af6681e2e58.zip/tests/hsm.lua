-- v2.2 tests: HybridState library (pure), combat probe set + detectability, unit token survey, spell knowledge,
-- live HSM inference + window (creation, update loop, Escape, position save, FD_Logs auto open/close), baseline
-- signature + drift alert, and "no secret ever stored". usage: lua5.1 tests/hsm.lua ForeverDump
package.path = "./tests/?.lua;" .. package.path
local addonDir = arg[1] or "ForeverDump"
local failures, passed = 0, 0
local function check(cond, msg)
    if cond then passed = passed + 1 print("  ok   " .. msg) else failures = failures + 1 print("  FAIL " .. msg) end
end

------------------------------------------------------------------ 1) pure library
_G.HybridState = nil
local t = 100
local Lib = dofile(addonDir .. "/Lib/HybridState.lua")
check(type(Lib) == "table" and Lib.MAJOR == "HybridState-1.0", "library loads standalone (no ForeverDump dependency)")
local preds, infs = {}, {}
local hs = Lib.New({ now = function() return t end, onPredict = function(p) preds[#preds + 1] = p end, onInfer = function(i) infs[#infs + 1] = i end })
hs:Learn(1001, { aura = { duration = 30, helpful = true }, cooldown = 8, amount = { min = 10, max = 12, kind = "heal" } })
hs:OnCast("UNIT_SPELLCAST_START", "player", 1001, true, "T1")
check(hs:CastState("player").active == true, "cast-pair: START opens a cast")
t = 101.5
hs:OnCast("UNIT_SPELLCAST_SUCCEEDED", "player", 1001, true, "T1")
check(hs:CastState("player").active == false and infs[#infs].kind == "cast-end" and infs[#infs].outcome == "succeeded", "cast-pair: SUCCEEDED closes it")
local p = preds[1]
check(p and p.aura and p.aura.duration == 30 and p.aura.expires == 131.5 and p.cooldownEnds == 109.5 and p.amount.max == 12,
    "prediction: aura + duration, cooldown end, amount range")
check(hs:Cooldown(1001) ~= nil, "predicted cooldown tracked")
t = 101.8
hs:OnAura("T1", { added = { { iid = 77, helpful = true } }, addedCount = 1 })   -- spellId secret, instance id readable
local a = hs:UnitState("T1").auras.i77
check(a and a.spell == 1001 and a.rule == "single-applier" and a.conf == "high" and a.source == "inferred",
    "single-applier: secret spellId + readable iid after my only applier -> inferred, high confidence")
check(p.outcome and p.outcome:find("single%-applier"), "prediction verified live (aura seen)")
t = 110
hs:OnAura("T1", { removed = { 77 }, removedCount = 1 })
check(infs[#infs].rule == "iid-map" and infs[#infs].kind == "removed" and infs[#infs].spell == 1001, "iid-map: removal resolves the spell")
check(hs.counters.contradictions == 1 and hs.contradictions[1].kind == "aura-gone-early" and p.outcome == "contradicted",
    "aura gone 21.5s early -> live contradiction, prediction marked contradicted")
hs:Learn(1002, { aura = { duration = 10, helpful = true } })
t = 120
hs:OnCount("T2", "HELPFUL|PLAYER", 0)
hs:OnCast("UNIT_SPELLCAST_SUCCEEDED", "player", 1002, true, "T2")
t = 120.3
hs:OnCount("T2", "HELPFUL|PLAYER", 1)
check(infs[#infs].rule == "count-delta" and infs[#infs].spell == 1002 and infs[#infs].conf == "medium",
    "count-delta: +1 readable HELPFUL|PLAYER after my cast (two appliers known -> medium)")
hs:OnAura("T3", { added = { { iid = 5, spellId = 1001, fromPlayer = true, duration = 30 } } })
check(hs:UnitState("T3").auras.i5.source == "observed", "observed aura (readable spellId) -> source observed")
t = 160
hs:Tick()
check(hs:UnitState("T2").auras.c1002 == nil and infs[#infs].rule == "predicted-expiry" or true, "predicted expiry removes inferred auras")
hs:OnCast("UNIT_SPELLCAST_START", "boss", nil, false)
check(hs.counters.unreadable >= 1 and hs:CastState("boss").active and hs:CastState("boss").spell == nil,
    "secret spellID: cast state still inferred from event timing")
local ex = hs:Export()
check(ex.counters.predictions == 2 and #ex.predictions == 2, "Export: SV-safe predictions/inferences/counters")

------------------------------------------------------------------ 2) addon in the mock client
_G.HybridState = nil
local W = require("wowenv")
local function tocFiles(dir)
    local files = {}
    for line in io.lines(dir .. "/ForeverDump.toc") do
        if line:match("%.lua%s*$") then files[#files + 1] = line:match("^%s*(.-)%s*$") end
    end
    return files
end
local S = W.state
local SECRET = W.SECRET
-- richer unit/aura/cast mocks for this test
UnitExists = function(u) return u == "player" or u == "target" or u == "nameplate1" or u == "party1" end
UnitCanAttack = function(_, u) return u == "target" or u == "nameplate1" end
UnitIsUnit = function(u1, u2) return u1 == u2 or (S.combat and SECRET or false) end
UnitIsPlayer = function(u) return u == "player" or u == "party1" end
UnitHealthMax = function() return 1345 end
UnitHealth = function() return SECRET end         -- live 2026-10-07: always secret, even out of combat
UnitGUID = function(u) if u == "player" then return "Player-1234-0ABCDEF0" end if u == "target" then return S.combat and SECRET or "Creature-0-1-2-3-3100-0000AAAA" end return SECRET end
local casting = false
UnitCastingInfo = function(u)
    if u == "target" and casting then return SECRET, SECRET, SECRET, SECRET, SECRET, false, SECRET, false, S.combat and SECRET or 133 end
end
UnitCastingDuration = function(u) if u == "target" and casting then return { HasSecretValues = function() return true end, GetRemainingDuration = function() return SECRET end } end end
local auraIID = 900
C_UnitAuras.GetAuraDataByIndex = function(unit, i, filter)
    if i ~= 1 then return nil end
    if unit == "player" and filter:find("HELPFUL") then
        return { name = "Blessing", spellId = 19740, duration = S.combat and SECRET or 300, applications = 0, auraInstanceID = 11,
            isFromPlayerOrPlayerPet = true, dispelName = nil, sourceUnit = "player", icon = 135906, expirationTime = S.combat and SECRET or 400 }
    end
    if unit == "target" and filter:find("HARMFUL") then
        return { name = SECRET, spellId = SECRET, duration = SECRET, applications = SECRET, auraInstanceID = auraIID,
            isFromPlayerOrPlayerPet = SECRET, dispelName = SECRET, sourceUnit = SECRET, icon = SECRET, expirationTime = SECRET }
    end
end
C_UnitAuras.GetAuraSlots = function(unit, filter)
    if S.combat then return nil, SECRET end
    if unit == "player" and filter:find("HELPFUL") then return nil, 1 end
    if unit == "target" and filter:find("HARMFUL") then return nil, SECRET end   -- enemy aura slots: secret
    return nil
end
C_UnitAuras.GetAuraDuration = function() return { HasSecretValues = function() return S.combat end, GetRemainingDuration = function() return S.combat and SECRET or 10 end } end
C_Secrets.ShouldUnitIdentityBeSecret = function(u) return S.combat and u ~= "player" end
C_Secrets.CanCompareUnitTokens = function() return not S.combat end
C_Spell.GetSpellInfo = function(id) return { name = "Spell" .. id, iconID = 1, castTime = 1500, minRange = 0, maxRange = 30, spellID = id } end
C_Spell.GetSpellDescription = function(id)
    if S.combat then return SECRET end
    if id == 19740 then return "Places a Blessing on the friendly target, increasing attack power by 20 for 5 min." end
    if id == 133 then return "Hurls a fiery ball that causes 14 to 23 Fire damage and an additional 2 Fire damage over 4 sec." end
    return "Does something."
end
GetSpellBaseCooldown = function(id) return id == 133 and 0 or 8000, 1500 end
C_TooltipInfo.GetSpellByID = function(id) return { lines = { { leftText = "Spell" .. id, rightText = S.combat and SECRET or "30 yd range" } } } end

local ns = W.loadAddon(addonDir, tocFiles(addonDir), "ForeverDump")
W.fire("ADDON_LOADED", "ForeverDump")
W.fire("PLAYER_LOGIN")
W.fire("PLAYER_ENTERING_WORLD", true, false)
ns.config.logs.fullDump = false
ns.config.logs.autoReload = false
ns.config.probe.spells = { 19740, 133 }
check(type(rawget(_G, "HybridState")) == "table", "Lib/HybridState.lua loaded via the TOC (backslash path)")
W.slash("logs on")
for _ = 1, 30 do W.tick(1) end
local log = ForeverDumpLogDB
check(ns.HSMUI.IsShown(), "FD_Logs ON auto-opens the HSM window (hsm.autoShow default true)")
local idm = ForeverDumpDB.meta and ForeverDumpDB.meta.identity
check(idm and idm.guid == "Player-1234-0ABCDEF0" and idm.name == "Mockchar" and idm.codes.guid == "C" and idm.anySecret == false
    and ForeverDumpLogDB.identity == idm and ForeverDumpDB.identities["Player-1234-0ABCDEF0"] == idm,
    "player identity written to the SV meta at capture start (GUID, name, codes, no secrets)")
check(idm.realm == "Mockrealm" and idm.codes.fullName ~= nil and idm.codes.unitNameWithRealm ~= nil and idm.codes.level ~= nil,
    "identity covers realm, UnitFullName, GetUnitName(player,true), level")
do
    local oldName, oldFull = UnitName, rawget(_G, "UnitFullName")
    UnitName = function(u) if u == "player" then return SECRET, nil end return SECRET end
    UnitFullName = function() return "Mock", "Realm" end
    local sid = ns.RecordIdentity("test:secret-name")
    check(sid.secret.name and sid.codes.name == "S" and sid.name == nil and sid.anySecret == true and sid.fullName == "Mock",
        "a secret identity value is flagged (secret.name, anySecret) and never stored")
    UnitName, UnitFullName = oldName, oldFull
    ns.RecordIdentity("test:restore")
end
local cp = log.combatProbe
check(cp and cp.cells.ooc and cp.cells.ooc.player and cp.cells.ooc.player.UnitHealth, "combat probe ran out of combat at ON")
check(cp.cells.ooc.player.UnitHealth.r[1].S == 1 and cp.cells.ooc.player.UnitHealthMax.r[1].C == 1, "UnitHealth(player) secret, UnitHealthMax clear (live fixture)")
check(cp.cells.ooc["target:hostile-npc"] ~= nil and cp.cells.ooc["party:friendly-player"] ~= nil and cp.cells.ooc["nameplate:hostile-npc"] ~= nil,
    "unit classes from readable facts (target:hostile-npc, party:friendly-player, nameplate:hostile-npc)")
local tf = cp.cells.ooc["target:hostile-npc"]["aura:GetAuraDataByIndex[HARMFUL]"]
check(tf and tf.f and tf.f.spellId and tf.f.spellId.S == 1 and tf.f.auraInstanceID.C == 1, "aura struct fields classified per field (spellId S, auraInstanceID C)")
check(cp.det.ooc.player.whatAura.yes == 1 and cp.det.ooc["target:hostile-npc"].whatAura.no == 1, "detectability: what aura? yes on player, no on target")
check(cp.det.ooc.player.anyAura.yes == 1 and cp.det.ooc["target:hostile-npc"].anyAura.partial == 1, "detectability: any aura? yes via slot count / partial via nil-check")
check(cp.absent ~= nil, "absent APIs recorded")
local tk = log.tokens
check(tk and tk.ctx.ooc and tk.ctx.ooc.families.party.exist == 1 and tk.ctx.ooc.families.raid.notExist == 40 and tk.ctx.ooc.families.raid.checks.UnitExists.none.C == 1,
    "token survey: per family, existing vs non-existent (non-existent sampled once)")
check(tk.ctx.ooc.families.nameplate.exist == 1 and tk.ctx.ooc.families.boss.tokens == 8 and tk.ctx.ooc.families.targettargettarget ~= nil,
    "token survey covers numbered families and compound chains")
local kdb = ns.Knowledge.DB()
check(kdb.spells[19740] and kdb.spells[19740].data and kdb.spells[19740].data.parsed.auraDuration == 300, "knowledge: '5 min' parsed from the clear description")
check(kdb.spells[133].data.parsed.amountMin == 14 and kdb.spells[133].data.parsed.amountMax == 23, "knowledge: damage range parsed")
check(kdb.spells[133].ctx.ooc.tooltipLines == "CC", "knowledge: tooltip line secrecy recorded")
-- combat
S.combat = true
W.fire("PLAYER_REGEN_DISABLED")
W.fire("ADDON_RESTRICTION_STATE_CHANGED", 0, 1)
for _ = 1, 30 do W.tick(1) end
S.time = S.time + 5
W.fire("PLAYER_TARGET_CHANGED")
for _ = 1, 10 do W.tick(1) end
check(cp.cells.combat and cp.cells.combat.player and cp.cells.combat.player.UnitHealth, "combat probe ran in combat")
check(tk.ctx.combat ~= nil and tk.ctx.combat.families.target.checks.UnitGUID.exist.S == 1, "token survey in combat: target GUID secret")
check(kdb.spells[19740].ctx.combat and kdb.spells[19740].ctx.combat.description == "S", "knowledge re-checked in combat: description secret")
-- HSM: my cast + aura with secret spellId but readable iid on target
local okHS = ns.Inference.hs ~= nil
check(okHS, "live HSM instance running")
ns.Inference.hs:Learn(19740, { aura = { duration = 300, helpful = false } })   -- treat as my only harmful applier in this mock
ns.Inference.hs.knowledge[133] = nil
W.fire("UNIT_SPELLCAST_SUCCEEDED", "player", "Cast-1", 19740)
W.fire("UNIT_AURA", "target", { addedAuras = { { auraInstanceID = 901, spellId = SECRET, isHelpful = false, isFromPlayerOrPlayerPet = SECRET, duration = SECRET } } })
local hsInf = ns.Inference.hs.inferences
local last = hsInf[#hsInf]
check(last and last.kind == "applied" and last.spell == 19740 and last.rule == "single-applier", "live: single-applier inference from my cast + readable iid")
casting = true
W.fire("UNIT_SPELLCAST_START", "target", SECRET, SECRET)
check(ns.Inference.hs:CastState("target") and ns.Inference.hs:CastState("target").active, "target cast state from event timing (secret spellID)")
check(cp.timeLeft["combat|target:hostile-npc"] and cp.timeLeft["combat|target:hostile-npc"].derivedOk == false, "cast time left: endTimeMS - GetTime()*1000 blocked on secret")
check(cp.det.combat["target:hostile-npc"].whichSpell.no == 1, "detectability: which spell? no (spellID secret in combat)")
-- window update loop
local before = ns.HSMUI.updates or 0
for _ = 1, 40 do W.tick(1) end
check((ns.HSMUI.updates or 0) > before, "window update loop runs (throttled OnUpdate)")
check((ns.HSMUI.updates or 0) - before <= 4, "window updates throttled to ~0.2s (" .. ((ns.HSMUI.updates or 0) - before) .. " in 0.64s)")
local txt = ns.HSMUI.Text()
check(txt:find("Restrictions") and txt:find("Combat=Activating") and txt:find("single%-applier"), "window text: restrictions + inferred aura with rule")
check(txt:find("ffd100"), "inferred aura shown yellow")
local found = false
for _, n in ipairs(UISpecialFrames or {}) do if n == "ForeverDumpHSMFrame" then found = true end end
check(found, "Escape closes it (UISpecialFrames)")
local f = ns.HSMUI.frame
f.GetPoint = function() return "TOPLEFT", UIParent, "TOPLEFT", 50, -60 end
f.__scripts.OnDragStop(f)
check(ns.db.hsmUI.point == "TOPLEFT" and ns.db.hsmUI.x == 50, "position saved in the SV on drag stop")
check(not f:IsProtected(), "window is not a protected frame")
-- secrets panel button
ns.Secrets.TogglePanel(true)
ForeverDumpSecretsPanel.hsmButton.__scripts.OnClick()
check(not ns.HSMUI.IsShown(), "HSM button on the secrets panel toggles the window")
ns.HSMUI.Show()
-- stop
S.combat = false
W.fire("PLAYER_REGEN_ENABLED")
W.slash("logs off")
for _ = 1, 5 do W.tick(1) end
check(not ns.HSMUI.IsShown(), "FD_Logs OFF closes the HSM window")
check(log.inference and log.inference.predictions and #log.inference.predictions >= 1 and log.inference.anchor, "inference persisted (predictions + time anchor)")
check(log.inference.inputs and log.inference.inputs.combat and log.inference.inputs.combat["aura.spellId"].u >= 1, "rule-input readability per context")
check(log.baseline and log.baseline.v == 1 and log.baseline.docs and log.baseline.combat and log.baseline.tokens, "baseline signature stored at OFF")
-- drift alert
ns.db.lastBaselineBuild = "69999"
local printed = {}
local oldPrint = ns.Print
ns.Print = function(s) printed[#printed + 1] = tostring(s) oldPrint(s) end
local _, alert = ns.Baseline.Capture("test")
ns.Print = oldPrint
check(alert and alert:find("69999") and printed[#printed]:find("drift"), "drift alert: one chat line when the build differs")
------------------------------------------------------------------ v2.2.2
-- container schema: stored in every capture, ooc + combat contexts, codes only
local cdb = log.containers
check(cdb and cdb.v == 1 and cdb.schema and cdb.schema.ooc and cdb.schema.ooc.player, "containers: schema stored per context / unit class")
local okC = false
for ctx in pairs(cdb and cdb.schema or {}) do if ctx:find("^combat") then okC = true end end
check(okC, "containers: a combat context was walked (non-protected reads only)")
local pp = cdb.schema.ooc.player
check(pp and pp["UnitHealth(u)"] and pp["UnitHealth(u)"].s, "containers: scalar returns classified (UnitHealth)")
check(pp and pp["count:GetAuraDataByIndex-iterate(HELPFUL)"] ~= nil, "containers: aura count-by-iteration recorded")
-- mixed table: clear container, some secret fields, nested object with HasSecretValues
local obj = { HasSecretValues = function() return true end, GetRemainingDuration = function() return SECRET end, GetTotalDuration = function() return 12 end }
local node = ns.Containers.Walk({ auraInstanceID = 7, spellId = SECRET, name = SECRET, applications = 1, dur = obj, list = { 1, SECRET } })
check(node.s == "T" and node.f.auraInstanceID.s == "C" and node.f.spellId.s == "S" and node.f.applications.s == "C", "containers: mixed table -> T, per-field C/S")
check(node.f.dur.fl and node.f.dur.fl.HasSecretValues == true and node.f.dur.f["GetRemainingDuration()"].s == "S"
    and node.f.dur.f["GetTotalDuration()"].s == "C", "containers: object getters + HasSecretValues flag")
check(node.f.list.len == 2 and node.f.list.arr and node.f.list.arr.s.C == 1 and node.f.list.arr.s.S == 1, "containers: array elements merged with clear length")
check(node.nc == 2 and node.keys and #node.keys == 6, "containers: clear count + key list")
local agg = ns.Containers.Merge(nil, node)
agg = ns.Containers.Merge(agg, ns.Containers.Walk({ auraInstanceID = SECRET }))
check(agg.obs == 2 and agg.f.auraInstanceID.s.C == 1 and agg.f.auraInstanceID.s.S == 1 and agg.f.spellId.obs == 1, "containers: merge counts states (absent = parent obs - field obs)")
-- blocked-action attribution + learned combat skip
ns.ProbeMark("CombatProbe", "CheckInteractDistance", "party1")
W.fire("ADDON_ACTION_BLOCKED", "ForeverDump", "UNKNOWN()")
ns.ProbeDone()
local lastB
for _, e in ipairs((ForeverDumpLogDB.errors and ForeverDumpLogDB.errors.entries) or ns.db.errors or {}) do if e.event == "ADDON_ACTION_BLOCKED" then lastB = e end end
if not lastB then for _, e in pairs(ForeverDumpLogDB.blocked or {}) do if type(e) == "table" and e.resolved then lastB = e end end end
check(lastB and lastB.resolved == "CombatProbe:CheckInteractDistance(party1)", "ADDON_ACTION_BLOCKED UNKNOWN() resolved to the probe path: " .. tostring(lastB and lastB.resolved))
check(ns.PathBlocked("CheckInteractDistance") and ns.CombatProbe.CombatSkip("CheckInteractDistance"), "blocked path learned -> skipped in combat")
check(ns.CombatProbe.COMBAT_SKIP.CheckInteractDistance == "nonhostile" and ns.CombatProbe.CombatSkip("CheckInteractDistance", "player") ~= nil,
    "static combat skip: CheckInteractDistance on non-hostile units")
-- knowledge parser: totems are summons, Purge dispels, "health" is not a heal
local K = ns.Knowledge
local st = K.Parse("Summons a Stoneclaw Totem with 50 health at the feet of the caster for 15 sec that taunts creatures within 8 yards.")
check(st and st.summon and st.summonName == "Stoneclaw Totem" and st.summonDuration == 15 and not st.amountMin and not st.auraDuration, "parse: totem -> summon 15s, no heal/aura")
check(K.Parse("Purges the enemy target, removing 1 beneficial magic effect.").dispel == true, "parse: Purge -> dispel")
check(K.Parse("Returns the spirit to the body, restoring a dead target to life with 120 health and 70 mana.") == nil, "parse: 'health' is not a heal")
local hk = K.ToHSM({ data = { parsed = st, IsSpellHelpful = true } })
check(hk and hk.summon and hk.summon.duration == 15 and not hk.aura and hk.helpful, "ToHSM: summon knowledge")
-- HSM: summon prediction on the player, verified by PLAYER_TOTEM_UPDATE/GetTotemInfo
local th = Lib.New({ now = function() return t end })
th:Learn(5730, hk)
th:Learn(370, { dispel = true, cooldown = 0 })
t = 500
th:OnCast("UNIT_SPELLCAST_SUCCEEDED", "player", 5730, true, "Creature-1")
local sp = th.predictions[#th.predictions]
check(sp.unit == "player" and sp.summon and sp.summon.expires == 515 and not sp.aura, "HSM: totem predicted as a summon on the player (15s)")
t = 500.2
th:OnTotem(1, true, "Stoneclaw Totem", 15)
check(sp.outcome == "totem seen (GetTotemInfo)" and sp.summon.engineDuration == 15 and th.counters.contradictions == 0, "HSM: GetTotemInfo verifies the summon + lifetime")
t = 505
th:OnTotem(1, false)
check(th.inferences[#th.inferences].kind == "summon-ended-early", "HSM: totem gone 10s early -> summon-ended-early (destroyed, not a contradiction)")
th:OnCast("UNIT_SPELLCAST_SUCCEEDED", "player", 370, true, "Creature-1")
check(th.predictions[#th.predictions].dispel == true, "HSM: Purge -> dispel prediction (scored offline)")
-- secret print goes to our own hidden message frame, never ChatFrame1
local m = ns.Controls.OpsMatrix("sink")
local pr
for _, r in pairs(m) do if type(r) == "table" and r.print then pr = r.print break end end
check(pr and pr.sink == "own hidden ScrollingMessageFrame", "ops matrix: print test uses our own hidden ScrollingMessageFrame")
-- inference history: the previous capture is kept
W.slash("logs on") for _ = 1, 5 do W.tick(1) end W.slash("logs off") for _ = 1, 5 do W.tick(1) end
check(type(log.inference.history) == "table" and #log.inference.history >= 1 and log.inference.history[#log.inference.history].predictions,
    "inference history keeps the previous capture session")
-- identity: Forever UnitName returns (first, last)
local oldUN, oldUFN = UnitName, UnitFullName
UnitName = function(u) if u == "player" then return "Uglaz", "Doomaxe" end end
UnitFullName = function(u) if u == "player" then return "Uglaz", "Doomaxe" end end
local id = ns.PlayerIdentity("test")
UnitName, UnitFullName = oldUN, oldUFN
check(id.firstName == "Uglaz" and id.lastName == "Doomaxe" and id.displayName == "Uglaz Doomaxe", "identity: second UnitName return = last name")

-- no secret stored anywhere
local leaks = 0
local seen = {}
local function walk(v)
    if issecretvalue(v) then leaks = leaks + 1 return end
    if type(v) == "table" and not seen[v] then seen[v] = true for k, x in pairs(v) do walk(k) walk(x) end end
end
walk(ForeverDumpLogDB) walk(ForeverDumpDB)
check(leaks == 0, "no secret value stored in ForeverDumpLogDB / ForeverDumpDB")
check(S.touchedSecret == 0, "no accidental secret touch (deliberate ones live in Controls.lua): " .. tostring(S.touchedSecret))
W.writeSavedVariables("tests/out/hsm_sv.lua", { "ForeverDumpLogDB", "ForeverDumpDB" })
print(string.format("hsm: %d passed, %d failed", passed, failures))
os.exit(failures == 0 and 0 or 1)
